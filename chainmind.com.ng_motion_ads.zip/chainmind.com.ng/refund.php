<?php
require_once __DIR__.'/_shared.php';
page_head('Refund Policy','ChainMind refund and cancellation policy for credits and subscriptions.');
$updated = 'June 9, 2025';
?>

<main>
<div class="container">
  <div class="page-hero">
    <div class="eyebrow">Legal</div>
    <h1>Refund Policy</h1>
    <div class="meta">
      <span><i class="ti ti-calendar"></i> Effective: <?=$updated?></span>
    </div>
  </div>

  <div class="legal-body">

    <div class="callout">
      <p><strong>Quick summary:</strong> Unused credits purchased within the last 14 days are refundable. Credits consumed by API usage are not refunded except in cases of platform error. Node operator earnings are non-refundable once paid out.</p>
    </div>

    <h2 id="credits">1. Prepaid credits</h2>
    <h3>Eligible refunds</h3>
    <p>You may request a full refund of <strong>unused</strong> prepaid credits within <strong>14 days</strong> of purchase, provided:</p>
    <ul>
      <li>The credits were purchased directly on chainmind.com.ng.</li>
      <li>You have not consumed more than 10% of the purchased credit amount.</li>
      <li>The purchase was not made using a promotional code or bundle discount (see Section 3).</li>
    </ul>

    <h3>Non-refundable usage</h3>
    <p>Credits that have been consumed by API calls are <strong>not refundable</strong>, even if the output produced was not what you expected. AI models are probabilistic; output quality is not guaranteed by ChainMind. You are responsible for testing models before production use.</p>

    <h3>Platform errors</h3>
    <p>If credits were deducted due to a <strong>verified platform error</strong> (e.g., you were charged for requests that returned 5xx server errors, or a billing bug double-charged your account), we will issue a credit restoration or refund at our discretion. Please report such issues within 30 days of occurrence with supporting logs.</p>

    <h2 id="promotional">2. Free and promotional credits</h2>
    <p>Free-tier credits, sign-up bonuses, referral credits, and promotional credits have <strong>no monetary value</strong> and are <strong>not refundable or redeemable for cash</strong> under any circumstances.</p>

    <h2 id="bundles">3. Discounted bundles and packages</h2>
    <p>Credits purchased as part of a discounted bundle or promotional package are <strong>not eligible for refund</strong>. This is because bundle pricing is contingent on the full amount being consumed. If you believe a bundle was misrepresented, please contact us within 7 days of purchase.</p>

    <h2 id="node-earnings">4. Node operator earnings</h2>
    <p>Earnings paid out to node operators for verified compute contributions are <strong>final and non-refundable</strong>. If you believe a payout was calculated incorrectly, contact us within 14 days of the payout date with detailed logs.</p>

    <h2 id="chargebacks">5. Chargebacks</h2>
    <p>Filing a chargeback or payment dispute with your bank for charges that are covered by this policy and where we have not been given the opportunity to resolve the issue may result in:</p>
    <ul>
      <li>Immediate suspension of your account pending investigation.</li>
      <li>Permanent ban if the chargeback is found to be fraudulent or abusive.</li>
    </ul>
    <p>We encourage you to contact us <em>before</em> disputing a charge — we are committed to resolving issues quickly.</p>

    <h2 id="how-to-request">6. How to request a refund</h2>
    <ol>
      <li>Email <a href="mailto:support@chainmind.com.ng?subject=Refund Request">support@chainmind.com.ng</a> with subject line <strong>Refund Request</strong>.</li>
      <li>Include: your registered email address, the amount paid, the date of purchase, and your reason for the request.</li>
      <li>We will review and respond within <strong>5 business days</strong>.</li>
      <li>Approved refunds are processed to the original payment method within <strong>7–10 business days</strong> (timelines may vary by payment provider).</li>
    </ol>

    <h2 id="changes">7. Changes to this policy</h2>
    <p>We may update this Refund Policy at any time. Changes will be communicated via the website and/or email. Refund requests are processed under the policy in effect at the time of the original purchase.</p>

  </div>
</div>
</main>

<?php page_foot(); ?>