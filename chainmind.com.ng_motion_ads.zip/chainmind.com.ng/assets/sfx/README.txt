ChainMind Motion Ad — Sound Effects Library
============================================

Place .mp3 files in each subdirectory. The node will download and cache them
automatically when rendering motion ads. Use free commercial-use sound effects
from https://mixkit.co/free-sound-effects/ (no account needed).

Recommended files per category:
  whoosh/  — transition whoosh sounds (e.g. whoosh_1.mp3, whoosh_2.mp3)
  pop/     — text/logo pop-in sounds  (e.g. pop_1.mp3)
  chime/   — CTA reveal / highlight   (e.g. chime_1.mp3)
  swipe/   — slide transition sounds  (e.g. swipe_1.mp3)
  impact/  — price/offer reveal       (e.g. impact_1.mp3)

The API endpoint /api/sfx-manifest.php returns a JSON manifest of all files
present in these directories. The node fetches that manifest once and caches
the files locally (never re-downloads unless the cached file is deleted).
