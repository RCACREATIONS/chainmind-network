<?php
// ============================================================
// ChainMind — Admin Email Broadcast
// Upload to: admin/email-broadcast.php
// ============================================================
session_start();
require_once __DIR__ . '/../api/_helpers.php';

$is_session_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
$is_secret_admin  = defined('ADMIN_SECRET') && ($_GET['secret'] ?? '') === ADMIN_SECRET;
if (!$is_session_admin && !$is_secret_admin) {
    header('Location: /auth/login.php?next=/admin/email-broadcast.php'); exit;
}
$qs = $is_secret_admin && !$is_session_admin ? '?secret=' . urlencode($_GET['secret']) : '';

$db = db();

$total_users   = (int)$db->query('SELECT COUNT(*) FROM users WHERE email_verified = 1')->fetchColumn();
$total_nodes   = (int)$db->query("SELECT COUNT(DISTINCT u.id) FROM users u JOIN nodes n ON n.user_id = u.id WHERE u.email_verified = 1")->fetchColumn();
$regular_users = $total_users - $total_nodes;

$all_users = $db->query(
    'SELECT id, email, COALESCE(name, email) AS display_name FROM users WHERE email_verified = 1 ORDER BY name ASC'
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><title>Email Broadcast — ChainMind Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{--bg:#0a0c10;--bg2:#0d1117;--bg3:#161b22;--border:#21262d;--border2:#30363d;
  --text:#e6edf3;--text2:#c9d1d9;--muted:#8b949e;--accent:#58a6ff;--green:#3fb950;
  --green-bg:#1c2a1e;--green-bd:#238636;--red:#f85149;--orange:#ffa657;
  --purple:#a371f7;--purple-bg:rgba(163,113,247,.1);--purple-bd:rgba(163,113,247,.3);
  --teal:#2dd4bf;--teal-bg:rgba(45,212,191,.08);--teal-bd:rgba(45,212,191,.25)}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:system-ui,sans-serif;display:flex;min-height:100vh}

/* SIDEBAR */
.sidebar{width:220px;background:var(--bg2);border-right:1px solid var(--border);
  padding:1.5rem 1rem;display:flex;flex-direction:column;gap:.25rem;flex-shrink:0;min-height:100vh}
.sidebar-logo{font-weight:800;font-size:1.1rem;margin-bottom:1.5rem;padding-left:.5rem}
.sidebar-logo span{color:var(--accent)}
.sidebar a{display:flex;align-items:center;gap:.6rem;padding:.55rem .75rem;border-radius:8px;
  color:var(--muted);text-decoration:none;font-size:.85rem;font-weight:500}
.sidebar a:hover,.sidebar a.active{background:var(--bg3);color:var(--text)}
.sidebar-divider{border:none;border-top:1px solid var(--border);margin:.5rem 0}
.sidebar-section{font-size:.72rem;font-weight:700;letter-spacing:.08em;color:var(--muted);
  text-transform:uppercase;padding:.5rem .75rem;margin-top:.25rem}

/* MAIN */
.main{flex:1;padding:2rem;overflow-x:hidden;max-width:calc(100vw - 220px)}
.page-header{margin-bottom:1.75rem}
.page-header h1{font-size:1.35rem;font-weight:800;margin-bottom:.25rem}
.page-header p{color:var(--muted);font-size:.85rem}

/* LAYOUT */
.broadcast-grid{display:grid;grid-template-columns:1fr 380px;gap:1.5rem;align-items:start}

/* CARD */
.card{background:var(--bg3);border:1px solid var(--border2);border-radius:12px;margin-bottom:1.5rem}
.card-header{padding:1rem 1.25rem;border-bottom:1px solid var(--border2);display:flex;
  align-items:center;justify-content:space-between;gap:.75rem}
.card-header h2{font-size:.95rem;font-weight:700}
.card-body{padding:1.25rem}

/* FORM */
label{display:block;font-size:.8rem;color:var(--muted);margin-bottom:.4rem;font-weight:600;letter-spacing:.03em;text-transform:uppercase}
input[type=text],input[type=email],select,textarea{
  width:100%;background:var(--bg2);border:1px solid var(--border2);border-radius:8px;
  color:var(--text);font-family:inherit;font-size:.875rem;padding:.6rem .85rem;outline:none;transition:border .15s}
input[type=text]:focus,input[type=email]:focus,select:focus,textarea:focus{border-color:var(--accent)}
textarea{resize:vertical;min-height:160px;line-height:1.6}
.form-group{margin-bottom:1.1rem}

/* TABS */
.tab-bar{display:flex;gap:.35rem;border-bottom:1px solid var(--border2);margin-bottom:1.25rem}
.tab{background:none;border:none;border-bottom:2px solid transparent;padding:.5rem .85rem;
  font-family:inherit;font-size:.85rem;font-weight:600;color:var(--muted);cursor:pointer;
  transition:all .15s;margin-bottom:-1px}
.tab:hover{color:var(--text)}
.tab.active{color:var(--accent);border-bottom-color:var(--accent)}
.tab-panel{display:none}.tab-panel.active{display:block}

/* AUDIENCE PILLS */
.audience-pills{display:flex;gap:.5rem;flex-wrap:wrap}
.pill{background:var(--bg2);border:1px solid var(--border2);border-radius:20px;
  padding:.35rem .85rem;font-size:.78rem;cursor:pointer;color:var(--muted);transition:all .15s;user-select:none}
.pill.selected{background:rgba(88,166,255,.12);border-color:var(--accent);color:var(--accent);font-weight:600}
.pill input{display:none}
.audience-count{font-size:.75rem;color:var(--muted);margin-top:.5rem}

/* USER SEARCH */
.user-search-wrap{position:relative}
.user-search-wrap input{padding-right:2.5rem}
.user-search-clear{position:absolute;right:.75rem;top:50%;transform:translateY(-50%);
  background:none;border:none;color:var(--muted);cursor:pointer;font-size:1rem;line-height:1;padding:0;display:none}
.user-dropdown{position:absolute;top:calc(100% + 4px);left:0;right:0;z-index:50;
  background:var(--bg2);border:1px solid var(--border2);border-radius:8px;
  max-height:220px;overflow-y:auto;display:none;box-shadow:0 8px 24px rgba(0,0,0,.5)}
.user-dropdown.open{display:block}
.user-option{padding:.6rem .85rem;font-size:.83rem;cursor:pointer;transition:background .1s;
  display:flex;flex-direction:column;gap:.15rem}
.user-option:hover,.user-option.focused{background:rgba(88,166,255,.08)}
.user-option .uname{color:var(--text);font-weight:600}
.user-option .uemail{color:var(--muted);font-size:.75rem}
.user-option.no-results{color:var(--muted);cursor:default;font-style:italic}
.user-option.no-results:hover{background:none}
.selected-user-badge{display:none;align-items:center;gap:.5rem;background:rgba(88,166,255,.08);
  border:1px solid rgba(88,166,255,.25);border-radius:8px;padding:.5rem .85rem;margin-top:.5rem;font-size:.83rem}
.selected-user-badge.show{display:flex}
.selected-user-badge .sub-name{font-weight:700;color:var(--text)}
.selected-user-badge .sub-email{color:var(--muted);font-size:.75rem;margin-left:.2rem}
.sub-remove{margin-left:auto;background:none;border:none;color:var(--muted);cursor:pointer;
  font-size:1rem;line-height:1;padding:0;transition:color .12s}
.sub-remove:hover{color:var(--red)}

/* ── TEMPLATES ──────────────────────────────────────── */
.templates-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(155px,1fr));gap:.65rem;margin-bottom:.25rem}
.tpl-card{background:var(--bg2);border:1px solid var(--border2);border-radius:10px;
  padding:.85rem .9rem;cursor:pointer;transition:all .17s;position:relative;overflow:hidden}
.tpl-card::before{content:'';position:absolute;inset:0;opacity:0;transition:opacity .17s}
.tpl-card:hover{border-color:var(--accent);transform:translateY(-1px);box-shadow:0 4px 16px rgba(0,0,0,.35)}
.tpl-card:hover::before{opacity:1}
.tpl-card.selected{border-color:var(--accent);background:rgba(88,166,255,.06)}
.tpl-icon{font-size:1.35rem;margin-bottom:.45rem;display:block;line-height:1}
.tpl-name{font-size:.82rem;font-weight:700;color:var(--text);margin-bottom:.2rem}
.tpl-desc{font-size:.72rem;color:var(--muted);line-height:1.45}
.tpl-hint{font-size:.73rem;color:var(--muted);margin-top:.6rem;font-style:italic}

/* AI PANEL */
.ai-badge{background:var(--purple-bg);border:1px solid var(--purple-bd);border-radius:20px;
  font-size:.68rem;font-weight:700;color:var(--purple);padding:.15rem .5rem;letter-spacing:.04em}
.ai-tone-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:.4rem;margin-bottom:.85rem}
.tone-btn{background:var(--bg2);border:1px solid var(--border2);border-radius:7px;
  padding:.4rem .3rem;font-size:.73rem;text-align:center;cursor:pointer;color:var(--muted);transition:all .15s}
.tone-btn:hover{border-color:var(--purple-bd);color:var(--text)}
.tone-btn.active{background:var(--purple-bg);border-color:var(--purple);color:var(--purple);font-weight:600}
.btn-ai{width:100%;background:linear-gradient(135deg,#7c3aed,#4f46e5);border:none;
  border-radius:9px;color:#fff;font-weight:700;font-size:.875rem;padding:.7rem;
  cursor:pointer;transition:opacity .15s;font-family:inherit}
.btn-ai:hover{opacity:.88}
.btn-ai:disabled{opacity:.5;cursor:not-allowed}
.ai-loading{display:none;align-items:center;gap:.5rem;font-size:.8rem;color:var(--purple);margin-top:.75rem;justify-content:center}
.ai-loading.show{display:flex}
.spinner{width:14px;height:14px;border:2px solid rgba(163,113,247,.3);border-top-color:var(--purple);
  border-radius:50%;animation:spin .6s linear infinite;flex-shrink:0}
@keyframes spin{to{transform:rotate(360deg)}}
.ai-cost{font-size:.72rem;color:var(--muted);text-align:center;margin-top:.5rem}

/* PREVIEW */
.preview-card{background:var(--bg2);border:1px solid var(--border2);border-radius:10px;padding:1rem;font-size:.8rem;color:var(--text2);line-height:1.7;margin-top:.75rem;min-height:60px;white-space:pre-wrap;word-break:break-word}
.preview-empty{color:var(--muted);font-style:italic}

/* SUBJECT CHAR COUNT */
.subject-row{position:relative}
.char-count{position:absolute;right:.85rem;top:50%;transform:translateY(-50%);font-size:.72rem;color:var(--muted);pointer-events:none}

/* BUTTONS */
.btn-row{display:flex;gap:.75rem;align-items:center;margin-top:1.5rem;flex-wrap:wrap}
.btn-primary{background:var(--green-bd);border:none;border-radius:9px;color:#fff;
  font-weight:700;font-size:.9rem;padding:.72rem 1.5rem;cursor:pointer;font-family:inherit;transition:opacity .15s}
.btn-primary:hover{opacity:.88}
.btn-primary:disabled{opacity:.5;cursor:not-allowed}
.btn-ghost{background:transparent;border:1px solid var(--border2);border-radius:9px;color:var(--muted);
  font-weight:600;font-size:.88rem;padding:.68rem 1.25rem;cursor:pointer;font-family:inherit;transition:all .15s}
.btn-ghost:hover{border-color:var(--accent);color:var(--text)}
.btn-teal{background:var(--teal-bg);border:1px solid var(--teal-bd);border-radius:9px;color:var(--teal);
  font-weight:600;font-size:.82rem;padding:.5rem 1rem;cursor:pointer;font-family:inherit;transition:all .15s;white-space:nowrap}
.btn-teal:hover{background:rgba(45,212,191,.14)}

/* STATUS BANNER */
.banner{border-radius:9px;padding:.85rem 1.1rem;font-size:.85rem;margin-bottom:1.25rem;display:none;align-items:center;gap:.65rem}
.banner.show{display:flex}
.banner.ok{background:var(--green-bg);border:1px solid var(--green-bd);color:var(--green)}
.banner.err{background:rgba(248,81,73,.08);border:1px solid rgba(248,81,73,.3);color:var(--red)}
.banner.warn{background:#1c1810;border:1px solid #7d4e00;color:var(--orange)}
.banner.info{background:rgba(88,166,255,.06);border:1px solid rgba(88,166,255,.25);color:var(--accent)}

/* STAT PILLS */
.stat-pills{display:flex;gap:.75rem;margin-bottom:1.5rem;flex-wrap:wrap}
.stat-pill{background:var(--bg3);border:1px solid var(--border2);border-radius:10px;
  padding:.75rem 1.1rem;min-width:100px;text-align:center}
.stat-pill .sv{font-size:1.3rem;font-weight:800;color:var(--accent)}
.stat-pill .sl{font-size:.72rem;color:var(--muted);margin-top:.1rem}

/* HISTORY TABLE */
table{width:100%;border-collapse:collapse;font-size:.82rem}
th{padding:.65rem 1rem;text-align:left;color:var(--muted);font-size:.75rem;font-weight:600;
   letter-spacing:.04em;text-transform:uppercase;border-bottom:1px solid var(--border)}
td{padding:.7rem 1rem;border-bottom:1px solid var(--border);vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.02)}
.badge{display:inline-flex;align-items:center;padding:.2rem .55rem;border-radius:20px;font-size:.72rem;font-weight:700}
.badge.sent{background:var(--green-bg);border:1px solid var(--green-bd);color:var(--green)}
.badge.failed{background:rgba(248,81,73,.08);border:1px solid rgba(248,81,73,.28);color:var(--red)}

/* SEPARATOR */
.sep{border:none;border-top:1px solid var(--border);margin:1.1rem 0}

/* GROQ KEY NOTICE */
.key-notice{background:rgba(255,166,87,.06);border:1px solid rgba(255,166,87,.25);border-radius:8px;
  padding:.75rem 1rem;font-size:.78rem;color:var(--orange);margin-bottom:1.1rem;line-height:1.55}
.key-notice code{background:rgba(255,255,255,.06);border-radius:4px;padding:.1rem .35rem;font-size:.75rem}

@media(max-width:900px){.broadcast-grid{grid-template-columns:1fr}}

/* ── Mobile ─────────────────────────────────────────────── */
.ham{display:none;position:fixed;top:.8rem;left:.8rem;z-index:500;
  background:var(--bg2);border:1px solid var(--border2);border-radius:8px;
  width:42px;height:42px;align-items:center;justify-content:center;
  cursor:pointer;font-size:1.25rem;color:var(--text);padding:0;
  line-height:1;box-shadow:0 2px 8px rgba(0,0,0,.3)}
.mob-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);
  z-index:399;backdrop-filter:blur(2px)}
@media(max-width:768px){
  body{display:block!important}
  .ham{display:flex!important}
  .sidebar{position:fixed!important;top:0!important;left:-240px!important;
    height:100vh!important;width:220px!important;z-index:400!important;
    transition:left .25s ease!important;overflow-y:auto!important;
    border-right:1px solid var(--border)!important}
  .sidebar.nav-open{left:0!important}
  .mob-overlay.nav-open{display:block!important}
  .main{padding:1rem!important;padding-top:3.75rem!important}
  .two-col,.form-row,.frow,.stat-row,.grid-2{grid-template-columns:1fr!important}
  .stats{grid-template-columns:repeat(2,1fr)!important}
  .card{overflow-x:auto;-webkit-overflow-scrolling:touch}
  table{min-width:540px}
  .ai-layout{flex-direction:column!important}
}
@media(max-width:480px){
  .stats{grid-template-columns:1fr 1fr!important}
}
</style>
</head>
<body>
<button class="ham" id="mobHam" onclick="mobNav()" aria-label="Menu">&#9776;</button>
<div class="mob-overlay" id="mobOv" onclick="mobClose()"></div>

<nav class="sidebar">
  <div class="sidebar-logo"><span>Chain</span>Mind</div>
  <div class="sidebar-section">Overview</div>
  <a href="/admin/<?= $qs ?>">⬛ Dashboard</a>
  <a href="/admin/users.php<?= $qs ?>">👥 Users</a>
  <a href="/admin/nodes.php<?= $qs ?>">🖥 Nodes</a>
  <a href="/admin/withdrawals.php<?= $qs ?>">💸 Withdrawals</a>
  <a href="/admin/iq-rate.php<?= $qs ?>">⚡ IQ Rate</a>
  <hr class="sidebar-divider">
  <div class="sidebar-section">Communications</div>
  <a href="/admin/email-broadcast.php<?= $qs ?>" class="active">✉ Email Broadcast</a>
  <a href="/admin/blog.php<?= $qs ?>">📝 Blog</a>
  <hr class="sidebar-divider">
  <div class="sidebar-section">Platform</div>
  <a href="/">🌐 Landing page</a>
</nav>

<main class="main">
  <div class="page-header">
    <h1>✉ Email Broadcast</h1>
    <p>Send updates, announcements, or feature emails — to everyone or a single user.</p>
  </div>

  <div class="stat-pills">
    <div class="stat-pill"><div class="sv"><?= number_format($total_users) ?></div><div class="sl">Verified Users</div></div>
    <div class="stat-pill"><div class="sv"><?= number_format($total_nodes) ?></div><div class="sl">Node Operators</div></div>
    <div class="stat-pill"><div class="sv"><?= number_format($regular_users) ?></div><div class="sl">Regular Users</div></div>
  </div>

  <div id="statusBanner" class="banner"></div>

  <div class="broadcast-grid">
    <!-- LEFT: Compose -->
    <div>

      <!-- TEMPLATES CARD -->
      <div class="card">
        <div class="card-header">
          <h2>📋 Templates</h2>
          <span style="font-size:.75rem;color:var(--muted)">Click a template to load it into the editor</span>
        </div>
        <div class="card-body">
          <div class="templates-grid" id="templatesGrid">
            <!-- rendered by JS -->
          </div>
          <p class="tpl-hint" id="tplHint">No template selected — or write from scratch below.</p>
        </div>
      </div>

      <!-- COMPOSE CARD -->
      <div class="card">
        <div class="card-header">
          <h2>✍ Compose Email</h2>
          <button class="btn-teal" id="clearTplBtn" onclick="clearTemplate()" style="display:none">✕ Clear template</button>
        </div>
        <div class="card-body">

          <!-- TABS -->
          <div class="tab-bar">
            <button class="tab active" onclick="switchTab('broadcast', this)">📢 Broadcast</button>
            <button class="tab" onclick="switchTab('single', this)">👤 Single User</button>
          </div>

          <!-- TAB: Broadcast -->
          <div class="tab-panel active" id="tab-broadcast">
            <div class="form-group">
              <label>Audience</label>
              <div class="audience-pills">
                <label class="pill selected" id="pill-all">
                  <input type="radio" name="audience" value="all" checked> 🌐 All Users
                </label>
                <label class="pill" id="pill-nodes">
                  <input type="radio" name="audience" value="nodes"> 🖥 Node Operators only
                </label>
                <label class="pill" id="pill-regular">
                  <input type="radio" name="audience" value="regular"> 👤 Regular Users only
                </label>
              </div>
              <div class="audience-count" id="audienceCount">Sending to <strong><?= number_format($total_users) ?> recipients</strong></div>
            </div>
          </div>

          <!-- TAB: Single User -->
          <div class="tab-panel" id="tab-single">
            <div class="form-group">
              <label>Search User</label>
              <div class="user-search-wrap" id="userSearchWrap">
                <input type="text" id="userSearchInput" placeholder="Type a name or email…" autocomplete="off"
                  oninput="filterUsers(this.value)" onfocus="openDropdown()" onkeydown="handleUserKey(event)">
                <button class="user-search-clear" id="userSearchClear" onclick="clearUserSearch()" title="Clear">✕</button>
                <div class="user-dropdown" id="userDropdown"></div>
              </div>
              <div class="selected-user-badge" id="selectedUserBadge">
                <span>
                  <span class="sub-name" id="badgeName"></span>
                  <span class="sub-email" id="badgeEmail"></span>
                </span>
                <button class="sub-remove" onclick="clearUserSearch()" title="Remove">✕</button>
              </div>
            </div>
          </div>

          <!-- Shared fields -->
          <div class="form-group">
            <label>Subject Line</label>
            <div class="subject-row">
              <input type="text" id="emailSubject" maxlength="100" placeholder="e.g. New feature: Compute earnings just got better ✨"
                oninput="updateCharCount(this,'subjectCount')">
              <span class="char-count" id="subjectCount">0/100</span>
            </div>
          </div>

          <div class="form-group">
            <label>Email Body</label>
            <textarea id="emailBody" placeholder="Write your message here… pick a template above, or use the AI assistant to help." rows="12"></textarea>
          </div>

          <hr class="sep">

          <div class="btn-row">
            <button class="btn-primary" id="sendBtn" onclick="sendEmail()">📨 Send Now</button>
            <button class="btn-ghost" onclick="previewEmail()">👁 Preview</button>
            <button class="btn-ghost" onclick="clearForm()">✕ Clear</button>
          </div>

        </div>
      </div>

      <!-- Preview -->
      <div id="previewSection" style="display:none" class="card">
        <div class="card-header">
          <h2>👁 Email Preview</h2>
          <button onclick="document.getElementById('previewSection').style.display='none'"
            style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:.85rem">✕ Close</button>
        </div>
        <div class="card-body">
          <div style="font-size:.78rem;color:var(--muted);margin-bottom:.5rem">
            From: <strong style="color:var(--text2)">support@chainmind.com.ng</strong>
            &nbsp;|&nbsp; To: <strong id="previewTo" style="color:var(--text2)"></strong>
            &nbsp;|&nbsp; Subject: <strong id="previewSubject" style="color:var(--accent)"></strong>
          </div>
          <hr class="sep">
          <div id="previewBody" class="preview-card"></div>
        </div>
      </div>

      <!-- History -->
      <div class="card">
        <div class="card-header"><h2>📋 Recent Broadcasts</h2></div>
        <div style="overflow-x:auto">
          <table>
            <thead><tr>
              <th>Subject</th><th>To</th><th>Sent</th><th>Date</th><th>Status</th>
            </tr></thead>
            <tbody id="historyBody">
              <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:2rem">No broadcasts yet this session</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- RIGHT: AI + Tips -->
    <div>
      <div class="card">
        <div class="card-header">
          <h2>🤖 AI Writing Assistant</h2>
          <span class="ai-badge">GROQ</span>
        </div>
        <div class="card-body">

          <div class="key-notice">
            ⚙ Set <code>GROQ_API_KEY</code> in <code>config.php</code>. Free key at
            <a href="https://console.groq.com" target="_blank" style="color:var(--orange)">console.groq.com</a>.
          </div>

          <div class="form-group">
            <label>What is this email about?</label>
            <textarea id="aiPrompt" rows="3" placeholder="e.g. We just launched auto-compounding node rewards. Tell users they can enable it in dashboard settings."
              style="min-height:80px"></textarea>
          </div>

          <div class="form-group">
            <label>Tone</label>
            <div class="ai-tone-grid">
              <div class="tone-btn active" onclick="setTone(this,'professional')">💼 Professional</div>
              <div class="tone-btn" onclick="setTone(this,'friendly')">😊 Friendly</div>
              <div class="tone-btn" onclick="setTone(this,'exciting')">🚀 Exciting</div>
              <div class="tone-btn" onclick="setTone(this,'urgent')">⚡ Urgent</div>
              <div class="tone-btn" onclick="setTone(this,'concise')">✂ Concise</div>
              <div class="tone-btn" onclick="setTone(this,'technical')">🔧 Technical</div>
            </div>
          </div>

          <div class="form-group">
            <label>Action</label>
            <select id="aiAction">
              <option value="write">✨ Write email from scratch</option>
              <option value="improve">✏ Improve my existing draft</option>
              <option value="subject">📝 Generate subject line only</option>
              <option value="shorten">✂ Shorten & tighten</option>
              <option value="friendly">😊 Make more friendly</option>
            </select>
          </div>

          <button class="btn-ai" id="aiBtn" onclick="runAI()">✨ Generate with AI</button>
          <div class="ai-loading" id="aiLoading"><div class="spinner"></div> AI is writing your email…</div>
          <div class="ai-cost">Powered by Groq (Llama 3.1) — free tier</div>

          <hr class="sep">

          <div>
            <label>AI Output</label>
            <div id="aiOutput" class="preview-card" style="min-height:80px"><span class="preview-empty">AI-generated content will appear here.</span></div>
            <div style="margin-top:.65rem;display:flex;gap:.5rem;flex-wrap:wrap">
              <button class="btn-ghost" style="font-size:.78rem;padding:.45rem .85rem" onclick="applySubject()" id="applySubjectBtn" disabled>Apply Subject</button>
              <button class="btn-ghost" style="font-size:.78rem;padding:.45rem .85rem" onclick="applyBody()" id="applyBodyBtn" disabled>Apply Body</button>
              <button class="btn-ghost" style="font-size:.78rem;padding:.45rem .85rem" onclick="applyAll()" id="applyAllBtn" disabled>Apply All</button>
            </div>
          </div>

        </div>
      </div>

      <!-- Tips -->
      <div class="card">
        <div class="card-header"><h2>💡 Tips</h2></div>
        <div class="card-body" style="font-size:.8rem;color:var(--muted);line-height:1.75">
          <p>• Keep subject lines under 60 chars for mobile</p>
          <p>• Start body with the most important info</p>
          <p>• Include a clear call-to-action</p>
          <p>• Node operators appreciate technical details</p>
          <p>• Use "you" and personalise where possible</p>
          <p>• Template placeholders like <code style="background:var(--bg2);padding:.1rem .3rem;border-radius:4px">{{name}}</code> are filled in automatically per recipient</p>
          <hr class="sep">
          <p style="font-size:.75rem">Emails use your <code style="background:var(--bg2);padding:.1rem .3rem;border-radius:4px">send_email()</code> helper. Make sure SPF/DKIM are set up on chainmind.com.ng.</p>
        </div>
      </div>
    </div>
  </div>
</main>

<script>
// ══════════════════════════════════════════════════════
//  TEMPLATES
// ══════════════════════════════════════════════════════
const TEMPLATES = [
  {
    id: 'welcome',
    icon: '👋',
    name: 'Welcome',
    desc: 'Greet a new user and guide first steps',
    subject: 'Welcome to ChainMind — let\'s get you started!',
    body: `Hi {{name}},

Welcome to ChainMind! We're really glad you're here.

ChainMind is a decentralised AI compute network where you can run AI jobs on demand, powered by our global network of node operators.

Here's how to get started:

1. Head to your dashboard and grab your API key
2. Make your first API call and see results in seconds
3. Explore the docs at chainmind.com.ng/docs

If you run into any issues or have questions, reply to this email — we read every message.

Welcome aboard!

The ChainMind Team`
  },
  {
    id: 'feature',
    icon: '🚀',
    name: 'New Feature',
    desc: 'Announce a new feature or update',
    subject: '✨ New on ChainMind: [Feature Name]',
    body: `Hi {{name}},

We've just shipped something we think you'll love.

[Feature Name] is now live on ChainMind.

What's new:
• [Benefit 1 — what it does for the user]
• [Benefit 2]
• [Benefit 3]

To try it out, head to your dashboard → [Where to find it].

We built this based on feedback from users like you, so thank you for helping shape ChainMind.

As always, if you have thoughts or run into any issues, just reply to this email.

The ChainMind Team`
  },
  {
    id: 'maintenance',
    icon: '🛠',
    name: 'Maintenance',
    desc: 'Notify users of scheduled downtime',
    subject: '⚠ Scheduled maintenance — [Date]',
    body: `Hi {{name}},

We want to give you advance notice of scheduled maintenance coming up.

📅 Date: [Day, Date]
⏰ Time: [Start time] – [End time] (WAT / UTC+1)
⏱ Duration: Approximately [X hours]

During this window:
• The ChainMind API will be unavailable
• Node operators: your nodes may be temporarily offline
• The dashboard will be in read-only mode

We recommend scheduling any time-sensitive jobs before or after this window.

We'll post updates on our status page at status.chainmind.com.ng and send a follow-up once maintenance is complete.

Sorry for any inconvenience — this upgrade will [brief benefit: improve reliability / increase throughput / etc.].

The ChainMind Team`
  },
  {
    id: 'node',
    icon: '🖥',
    name: 'Node Operator',
    desc: 'Update specifically for node operators',
    subject: '📡 Important update for ChainMind Node Operators',
    body: `Hi {{name}},

As a ChainMind node operator, we have an important update for you.

[Summary of the update — 1-2 sentences]

What this means for your node:
• [Impact 1]
• [Impact 2]
• [Any action required]

Action required by: [Date / "no action needed"]

If you need to update your node software, run:
  chainmind-node update --latest

Your node ID and secret remain unchanged. If you encounter any issues after the update, check the node documentation or reply to this email.

Thank you for powering the ChainMind network — your node earned [X IQ / compute credits] last month.

The ChainMind Team`
  },
  {
    id: 'reengagement',
    icon: '💫',
    name: 'Re-engagement',
    desc: 'Win back users who have gone quiet',
    subject: 'We miss you on ChainMind, {{name}} 👋',
    body: `Hi {{name}},

We noticed you haven't used ChainMind in a while and wanted to check in.

A lot has changed since you last logged in:

🚀 [New feature or improvement]
⚡ [Performance improvement — e.g. "API response times are now 2× faster"]
💰 [Value update — e.g. "Credit pricing is now lower"]

Your account is still active and everything is right where you left it.

Log back in at chainmind.com.ng/dashboard whenever you're ready.

If there's something we could do better, or a reason you stepped away, we'd genuinely love to hear it — just reply to this email.

The ChainMind Team`
  }
];

// ── Render templates ───────────────────────────────────
let activeTemplateId = null;

function renderTemplates() {
  const grid = document.getElementById('templatesGrid');
  grid.innerHTML = TEMPLATES.map(t => `
    <div class="tpl-card${activeTemplateId === t.id ? ' selected' : ''}"
         onclick="loadTemplate('${t.id}')" title="${esc(t.desc)}">
      <span class="tpl-icon">${t.icon}</span>
      <div class="tpl-name">${esc(t.name)}</div>
      <div class="tpl-desc">${esc(t.desc)}</div>
    </div>
  `).join('');
}

function loadTemplate(id) {
  const t = TEMPLATES.find(x => x.id === id);
  if (!t) return;
  if (activeTemplateId === id) { clearTemplate(); return; } // toggle off

  const subjEl = document.getElementById('emailSubject');
  const bodyEl = document.getElementById('emailBody');

  // Warn if there's existing content
  if ((subjEl.value.trim() || bodyEl.value.trim()) && activeTemplateId === null) {
    if (!confirm('Load this template? Your current draft will be replaced.')) return;
  }

  subjEl.value = t.subject;
  bodyEl.value = t.body;
  updateCharCount(subjEl, 'subjectCount');
  activeTemplateId = id;

  document.getElementById('tplHint').innerHTML =
    `<strong style="color:var(--teal)">${t.icon} ${t.name} template loaded.</strong> Edit the placeholders in <code style="background:var(--bg2);padding:.1rem .3rem;border-radius:4px">[square brackets]</code> before sending.`;
  document.getElementById('clearTplBtn').style.display = '';
  renderTemplates();
  showBanner('info', `${t.icon} "${t.name}" template loaded — customise the [placeholders] then hit Send.`);

  // Scroll to compose
  document.getElementById('emailSubject').scrollIntoView({behavior:'smooth', block:'center'});
}

function clearTemplate() {
  activeTemplateId = null;
  document.getElementById('tplHint').textContent = 'No template selected — or write from scratch below.';
  document.getElementById('clearTplBtn').style.display = 'none';
  renderTemplates();
}

renderTemplates();

// ══════════════════════════════════════════════════════
//  USER DATA
// ══════════════════════════════════════════════════════
const ALL_USERS = <?= json_encode(array_map(fn($u) => [
    'id'    => $u['id'],
    'name'  => $u['display_name'],
    'email' => $u['email'],
], $all_users), JSON_UNESCAPED_UNICODE) ?>;

const counts = {
  all: <?= $total_users ?>,
  nodes: <?= $total_nodes ?>,
  regular: <?= $regular_users ?>
};

let selectedTone  = 'professional';
let lastAIResult  = null;
let currentTab    = 'broadcast';
let selectedUser  = null;
let dropdownFocus = -1;
let filteredUsers = [];

// ── Tab switching ──────────────────────────────────────
function switchTab(tab, btn) {
  currentTab = tab;
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.getElementById('tab-' + tab).classList.add('active');
  hideBanner();
}

// ── Audience pills ─────────────────────────────────────
document.querySelectorAll('.pill input').forEach(r => {
  r.addEventListener('change', () => {
    document.querySelectorAll('.pill').forEach(p => p.classList.remove('selected'));
    r.parentElement.classList.add('selected');
    const c = counts[r.value];
    document.getElementById('audienceCount').innerHTML =
      `Sending to <strong>${c.toLocaleString()} recipient${c !== 1 ? 's' : ''}</strong>`;
  });
});

// ── User search ────────────────────────────────────────
function filterUsers(q) {
  document.getElementById('userSearchClear').style.display = q ? 'block' : 'none';
  if (!q.trim()) { closeDropdown(); return; }
  const lq = q.toLowerCase();
  filteredUsers = ALL_USERS.filter(u =>
    u.name.toLowerCase().includes(lq) || u.email.toLowerCase().includes(lq)
  ).slice(0, 30);
  renderDropdown();
  openDropdown();
}
function renderDropdown() {
  const dd = document.getElementById('userDropdown');
  if (!filteredUsers.length) {
    dd.innerHTML = '<div class="user-option no-results">No users found</div>'; return;
  }
  dd.innerHTML = filteredUsers.map((u, i) =>
    `<div class="user-option" data-idx="${i}" onmousedown="selectUser(${i})">
      <span class="uname">${esc(u.name)}</span>
      <span class="uemail">${esc(u.email)}</span>
    </div>`
  ).join('');
}
function openDropdown() {
  if (filteredUsers.length || document.getElementById('userSearchInput').value.trim())
    document.getElementById('userDropdown').classList.add('open');
}
function closeDropdown() {
  document.getElementById('userDropdown').classList.remove('open');
  dropdownFocus = -1;
}
function selectUser(idx) {
  const u = filteredUsers[idx]; if (!u) return;
  selectedUser = u;
  document.getElementById('userSearchInput').value = u.name + ' <' + u.email + '>';
  document.getElementById('userSearchClear').style.display = 'block';
  document.getElementById('badgeName').textContent  = u.name;
  document.getElementById('badgeEmail').textContent = '<' + u.email + '>';
  document.getElementById('selectedUserBadge').classList.add('show');
  closeDropdown();
}
function clearUserSearch() {
  selectedUser = null;
  document.getElementById('userSearchInput').value = '';
  document.getElementById('userSearchClear').style.display = 'none';
  document.getElementById('selectedUserBadge').classList.remove('show');
  document.getElementById('userDropdown').innerHTML = '';
  closeDropdown();
}
function handleUserKey(e) {
  const items = document.querySelectorAll('.user-option:not(.no-results)');
  if (!items.length) return;
  if (e.key==='ArrowDown'){e.preventDefault();dropdownFocus=Math.min(dropdownFocus+1,items.length-1);}
  else if (e.key==='ArrowUp'){e.preventDefault();dropdownFocus=Math.max(dropdownFocus-1,0);}
  else if (e.key==='Enter'&&dropdownFocus>=0){e.preventDefault();selectUser(dropdownFocus);return;}
  else if (e.key==='Escape'){closeDropdown();return;}
  items.forEach((el,i)=>el.classList.toggle('focused',i===dropdownFocus));
}
document.addEventListener('click', e => {
  if (!document.getElementById('userSearchWrap').contains(e.target)) closeDropdown();
});

// ── Char count ─────────────────────────────────────────
function updateCharCount(el, countId) {
  document.getElementById(countId).textContent = `${el.value.length}/${el.maxLength}`;
}

// ── Tone ───────────────────────────────────────────────
function setTone(el, tone) {
  document.querySelectorAll('.tone-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active'); selectedTone = tone;
}

// ── Preview ────────────────────────────────────────────
function previewEmail() {
  const subj = document.getElementById('emailSubject').value.trim();
  const body = document.getElementById('emailBody').value.trim();
  if (!subj && !body) { showBanner('err','Nothing to preview yet.'); return; }
  document.getElementById('previewSubject').textContent = subj || '(no subject)';
  document.getElementById('previewBody').textContent    = body || '(empty body)';
  if (currentTab==='single') {
    document.getElementById('previewTo').textContent = selectedUser
      ? selectedUser.name+' <'+selectedUser.email+'>' : '(no user selected)';
  } else {
    const aud = document.querySelector('input[name="audience"]:checked').value;
    document.getElementById('previewTo').textContent = `${aud} (${counts[aud].toLocaleString()} recipients)`;
  }
  document.getElementById('previewSection').style.display='';
  document.getElementById('previewSection').scrollIntoView({behavior:'smooth',block:'start'});
}

// ── Clear form ─────────────────────────────────────────
function clearForm() {
  if (!confirm('Clear the form?')) return;
  document.getElementById('emailSubject').value='';
  document.getElementById('emailBody').value='';
  document.getElementById('subjectCount').textContent='0/100';
  document.getElementById('previewSection').style.display='none';
  clearUserSearch();
  clearTemplate();
  hideBanner();
}

// ── AI ─────────────────────────────────────────────────
async function runAI() {
  const prompt   = document.getElementById('aiPrompt').value.trim();
  const action   = document.getElementById('aiAction').value;
  const existing = document.getElementById('emailBody').value.trim();
  if (!prompt && action==='write') { showBanner('err','Please describe what the email is about first.'); return; }
  const btn = document.getElementById('aiBtn');
  btn.disabled = true;
  document.getElementById('aiLoading').classList.add('show');
  document.getElementById('aiOutput').innerHTML='<span class="preview-empty">Generating…</span>';
  ['applySubjectBtn','applyBodyBtn','applyAllBtn'].forEach(id=>document.getElementById(id).disabled=true);
  try {
    const res  = await fetch('/admin/api/ai-email.php<?= $qs ?>',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt,action,tone:selectedTone,existing_draft:existing})});
    const data = await res.json();
    if (!res.ok||data.error) throw new Error(data.error||'AI request failed');
    lastAIResult=data;
    let display='';
    if(data.subject) display+=`SUBJECT: ${data.subject}\n\n`;
    if(data.body)    display+=data.body;
    document.getElementById('aiOutput').textContent=display||'(no output)';
    ['applySubjectBtn','applyBodyBtn','applyAllBtn'].forEach(id=>document.getElementById(id).disabled=false);
    if(!data.subject) document.getElementById('applySubjectBtn').disabled=true;
    if(!data.body)    {document.getElementById('applyBodyBtn').disabled=true;document.getElementById('applyAllBtn').disabled=true;}
  } catch(e) {
    document.getElementById('aiOutput').innerHTML=`<span style="color:var(--red)">Error: ${e.message}</span>`;
    showBanner('err','AI generation failed: '+e.message);
  } finally {
    btn.disabled=false;
    document.getElementById('aiLoading').classList.remove('show');
  }
}
function applySubject(){if(lastAIResult?.subject){document.getElementById('emailSubject').value=lastAIResult.subject;updateCharCount(document.getElementById('emailSubject'),'subjectCount');}}
function applyBody(){if(lastAIResult?.body) document.getElementById('emailBody').value=lastAIResult.body;}
function applyAll(){applySubject();applyBody();}

// ── Send ───────────────────────────────────────────────
async function sendEmail() {
  const subject = document.getElementById('emailSubject').value.trim();
  const body    = document.getElementById('emailBody').value.trim();
  if (!subject) { showBanner('err','Please add a subject line.'); return; }
  if (!body)    { showBanner('err','Email body is empty.'); return; }

  // Warn if template placeholders remain
  if (/\[.+?\]/.test(body) || /\[.+?\]/.test(subject)) {
    if (!confirm('Your email still contains unfilled placeholders like [Feature Name].\n\nSend anyway?')) return;
  }

  let payload, confirmMsg, histLabel;
  if (currentTab==='single') {
    if (!selectedUser) { showBanner('err','Please select a user to send to.'); return; }
    payload    = {subject, body, mode:'single', user_id:selectedUser.id};
    confirmMsg = `Send this email to ${selectedUser.name} (${selectedUser.email})?`;
    histLabel  = selectedUser.name+' <'+selectedUser.email+'>';
  } else {
    const audience = document.querySelector('input[name="audience"]:checked').value;
    const cnt = counts[audience];
    payload    = {subject, body, mode:'broadcast', audience};
    confirmMsg = `Send to ${cnt.toLocaleString()} recipient(s)?\n\nSubject: ${subject}`;
    histLabel  = audience+' ('+cnt.toLocaleString()+')';
  }
  if (!confirm(confirmMsg)) return;

  const btn=document.getElementById('sendBtn');
  btn.disabled=true; btn.textContent='⏳ Sending…'; hideBanner();
  try {
    const res  = await fetch('/admin/api/broadcast-email.php<?= $qs ?>',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const data = await res.json();
    if (!res.ok||data.error) throw new Error(data.error||'Send failed');
    showBanner('ok',`✓ Email sent to ${data.sent} recipient(s). ${data.message||''}`);
    addToHistory({subject, to:histLabel, sent:data.sent, date:new Date().toISOString(), status:'sent'});
  } catch(e) {
    showBanner('err','Failed to send: '+e.message);
  } finally {
    btn.disabled=false; btn.textContent='📨 Send Now';
  }
}

// ── History ────────────────────────────────────────────
const history_arr=[];
function addToHistory(item){history_arr.unshift(item);renderHistory();}
function renderHistory(){
  const tbody=document.getElementById('historyBody');
  if(!history_arr.length) return;
  tbody.innerHTML=history_arr.map(r=>`
    <tr>
      <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(r.subject)}</td>
      <td style="color:var(--muted);max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(r.to)}</td>
      <td>${Number(r.sent).toLocaleString()}</td>
      <td style="color:var(--muted);white-space:nowrap">${new Date(r.date).toLocaleString()}</td>
      <td><span class="badge ${r.status}">${r.status}</span></td>
    </tr>`).join('');
}

// ── Helpers ────────────────────────────────────────────
function showBanner(type,msg){const b=document.getElementById('statusBanner');b.className=`banner show ${type}`;b.textContent=msg;b.scrollIntoView({behavior:'smooth',block:'nearest'});}
function hideBanner(){document.getElementById('statusBanner').className='banner';}
function esc(str){return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
</script>
<script>
function mobNav(){var s=document.querySelector('.sidebar'),o=document.getElementById('mobOv');
  if(s){s.classList.toggle('nav-open');o.classList.toggle('nav-open');}}
function mobClose(){var s=document.querySelector('.sidebar'),o=document.getElementById('mobOv');
  if(s){s.classList.remove('nav-open');o.classList.remove('nav-open');}}
</script>
</body>
</html>