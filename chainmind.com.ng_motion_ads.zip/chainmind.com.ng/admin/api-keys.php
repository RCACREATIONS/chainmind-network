<?php
session_start();
require_once __DIR__ . '/../api/_helpers.php';
$is_session_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
$is_secret_admin  = defined('ADMIN_SECRET') && ($_GET['secret'] ?? '') === ADMIN_SECRET;
if (!$is_session_admin && !$is_secret_admin) {
    header('Location: /auth/login.php?next=/admin/api-keys.php'); exit;
}
$qs = $is_secret_admin && !$is_session_admin ? '?secret=' . urlencode($_GET['secret']) : '';

$flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $kid    = (int)($_POST['key_id'] ?? 0);

    if ($action === 'revoke' && $kid) {
        db()->prepare('UPDATE api_keys SET is_active=0 WHERE id=?')->execute([$kid]);
        $flash = '<div class="flash ok">Key revoked.</div>';
    } elseif ($action === 'activate' && $kid) {
        db()->prepare('UPDATE api_keys SET is_active=1 WHERE id=?')->execute([$kid]);
        $flash = '<div class="flash ok">Key activated.</div>';
    } elseif ($action === 'update' && $kid) {
        $rpm   = max(1,(int)($_POST['rate_limit_rpm']??60));
        $rpd   = max(1,(int)($_POST['rate_limit_rpd']??10000));
        $quota = $_POST['credit_quota'] !== '' ? max(0,(int)$_POST['credit_quota']) : null;
        $mdls  = trim($_POST['allowed_models']??'');
        $exp   = trim($_POST['expires_at']??'') ?: null;
        $label = substr(trim($_POST['label']??''),0,100);
        $notes = substr(trim($_POST['notes']??''),0,500);

        $mdl_json = null;
        if ($mdls) {
            $arr = array_filter(array_map('trim', explode(',', $mdls)));
            if ($arr) $mdl_json = json_encode(array_values($arr));
        }

        db()->prepare('UPDATE api_keys SET label=?,rate_limit_rpm=?,rate_limit_rpd=?,
            credit_quota=?,allowed_models=?,expires_at=?,notes=? WHERE id=?')
            ->execute([$label,$rpm,$rpd,$quota,$mdl_json,$exp,$notes?:null,$kid]);
        $flash = '<div class="flash ok">Key updated.</div>';
    } elseif ($action === 'add_credits' && $kid) {
        $amt = max(1,(int)($_POST['credits']??0));
        db()->prepare('INSERT INTO credits (api_key_id,balance) VALUES(?,?)
            ON DUPLICATE KEY UPDATE balance=balance+?')->execute([$kid,$amt,$amt]);
        $flash = '<div class="flash ok">Added '.$amt.' credits.</div>';
    } elseif ($action === 'create') {
        $name  = substr(trim($_POST['owner_name']??''),0,100);
        $email = strtolower(trim($_POST['owner_email']??''));
        $label = substr(trim($_POST['label']??'Default'),0,100);
        if ($name && filter_var($email,FILTER_VALIDATE_EMAIL)) {
            $new_key = 'cm-' . bin2hex(random_bytes(20));
            db()->prepare('INSERT INTO api_keys (api_key,owner_name,owner_email,label,is_active)
                VALUES(?,?,?,?,1)')->execute([$new_key,$name,$email,$label]);
            $kid2 = (int)db()->lastInsertId();
            db()->prepare('INSERT INTO credits (api_key_id,balance) VALUES(?,500)
                ON DUPLICATE KEY UPDATE balance=balance')->execute([$kid2]);
            $flash = '<div class="flash ok">Created: <code>'.$new_key.'</code></div>';
        } else {
            $flash = '<div class="flash err">Invalid name or email.</div>';
        }
    }
    header('Location: /admin/api-keys.php'.$qs); exit;
}

$search = trim($_GET['q']??'');
$page   = max(1,(int)($_GET['page']??1));
$limit  = 30; $offset = ($page-1)*$limit;

$where = $search
    ? " WHERE k.owner_email LIKE ? OR k.owner_name LIKE ? OR k.label LIKE ?"
    : '';
$params = $search ? ["%$search%","%$search%","%$search%"] : [];

$total = (int)db()->query('SELECT COUNT(*) FROM api_keys')->fetchColumn();

$stmt = db()->prepare("
    SELECT k.*,
           COALESCE(c.balance,0)           AS credit_balance,
           COALESCE(u.calls,0)             AS total_calls,
           COALESCE(u.credits_used,0)      AS credits_used,
           COALESCE(u.tokens,0)            AS total_tokens,
           u.last_call
    FROM api_keys k
    LEFT JOIN credits c ON c.api_key_id=k.id
    LEFT JOIN (
        SELECT api_key_id,
               COUNT(*)              AS calls,
               SUM(credits_used)     AS credits_used,
               SUM(tokens_in+tokens_out) AS tokens,
               MAX(created_at)       AS last_call
        FROM api_key_usage GROUP BY api_key_id
    ) u ON u.api_key_id=k.id
    {$where}
    ORDER BY k.created_at DESC LIMIT {$limit} OFFSET {$offset}
");
$stmt->execute($params);
$keys = $stmt->fetchAll();
$pages = (int)ceil($total / $limit);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><title>API Keys — Admin | ChainMind</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{--bg:#0a0c10;--bg2:#0d1117;--bg3:#161b22;--border:#21262d;--border2:#30363d;
  --text:#e6edf3;--muted:#8b949e;--accent:#58a6ff;--green:#3fb950;--green-bd:#238636;
  --red:#f85149;--orange:#d29922;--purple:#8957e5}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:system-ui,sans-serif;display:flex;min-height:100vh;font-size:14px}
.sidebar{width:220px;background:var(--bg2);border-right:1px solid var(--border);padding:1.5rem 1rem;display:flex;flex-direction:column;gap:.2rem;flex-shrink:0}
.sidebar-logo{font-weight:800;font-size:1.1rem;margin-bottom:1.5rem;padding-left:.5rem}
.sidebar-logo span{color:var(--accent)}
.sidebar a{display:flex;align-items:center;gap:.6rem;padding:.5rem .75rem;border-radius:8px;color:var(--muted);text-decoration:none;font-size:.85rem;font-weight:500}
.sidebar a:hover,.sidebar a.active{background:var(--bg3);color:var(--text)}
hr.sd{border:none;border-top:1px solid var(--border);margin:.5rem 0}
.main{flex:1;padding:2rem;overflow-x:hidden}
h1{font-size:1.3rem;font-weight:800;margin-bottom:1.5rem}
.toolbar{display:flex;gap:.75rem;margin-bottom:1.25rem;flex-wrap:wrap;align-items:center}
.toolbar input{padding:.45rem .75rem;border-radius:7px;border:1px solid var(--border2);background:var(--bg2);color:var(--text);font-size:.85rem;width:240px}
.card{background:var(--bg3);border:1px solid var(--border2);border-radius:12px;margin-bottom:1.5rem;overflow:hidden}
.card-head{padding:1rem 1.25rem;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
.card-head h2{font-size:.9rem;font-weight:700}
.card-body{padding:1.25rem}
table{width:100%;border-collapse:collapse;font-size:.8rem}
th{text-align:left;padding:.5rem .9rem;color:var(--muted);border-bottom:1px solid var(--border);font-size:.7rem;font-weight:600;text-transform:uppercase;letter-spacing:.05em}
td{padding:.5rem .9rem;border-bottom:1px solid var(--border);vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.02)}
.badge{display:inline-block;padding:.15rem .45rem;border-radius:20px;font-size:.68rem;font-weight:700}
.b-active{background:rgba(63,185,80,.15);color:var(--green);border:1px solid rgba(63,185,80,.25)}
.b-inactive{background:rgba(248,81,73,.12);color:var(--red);border:1px solid rgba(248,81,73,.25)}
.b-admin{background:rgba(137,87,229,.15);color:var(--purple);border:1px solid rgba(137,87,229,.25)}
.mono{font-family:monospace;font-size:.78rem;color:var(--accent)}
input[type=text],input[type=email],input[type=number],input[type=date],select,textarea{
  padding:.5rem .75rem;border-radius:7px;border:1px solid var(--border2);background:var(--bg2);
  color:var(--text);font-size:.85rem;width:100%;outline:none}
input:focus,select:focus{border-color:var(--accent)}
.btn{display:inline-flex;align-items:center;gap:.3rem;padding:.4rem .85rem;border-radius:7px;font-size:.8rem;font-weight:700;border:none;cursor:pointer;font-family:inherit}
.btn-primary{background:#1f6feb;color:#fff}.btn-primary:hover{background:#388bfd}
.btn-danger{background:rgba(248,81,73,.15);color:var(--red);border:1px solid rgba(248,81,73,.25)}.btn-danger:hover{background:rgba(248,81,73,.25)}
.btn-ghost{background:transparent;border:1px solid var(--border2);color:var(--muted)}.btn-ghost:hover{color:var(--text);border-color:var(--border)}
.btn-sm{padding:.25rem .6rem;font-size:.72rem}
.btn-green{background:rgba(63,185,80,.15);color:var(--green);border:1px solid rgba(63,185,80,.25)}.btn-green:hover{background:rgba(63,185,80,.25)}
.flash{padding:.75rem 1rem;border-radius:8px;margin-bottom:1rem;font-size:.85rem;font-family:monospace}
.flash.ok{background:rgba(63,185,80,.12);border:1px solid rgba(63,185,80,.3);color:var(--green)}
.flash.err{background:rgba(248,81,73,.12);border:1px solid rgba(248,81,73,.3);color:var(--red)}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:.75rem}
.grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:.75rem}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:.75rem;margin-bottom:.75rem}
label.lbl{display:block;font-size:.75rem;color:var(--muted);margin-bottom:.25rem}
details summary{cursor:pointer;font-size:.78rem;color:var(--accent);padding:.4rem 0}
details[open] summary{margin-bottom:.75rem}
.pager{display:flex;gap:.5rem;margin-top:1.25rem;font-size:.82rem}
.pager a{color:var(--accent);text-decoration:none;padding:.3rem .65rem;border:1px solid var(--border2);border-radius:6px}
.stat-row{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:1rem;margin-bottom:1.5rem}
.stat{background:var(--bg3);border:1px solid var(--border2);border-radius:10px;padding:1rem 1.1rem}
.stat .lbl{font-size:.7rem;color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:.05em;margin-bottom:.3rem}
.stat .val{font-size:1.6rem;font-weight:800}
@media(max-width:640px){.sidebar{display:none}.form-row{grid-template-columns:1fr}}

/* ── Mobile ─────────────────────────────────────────────── */
.ham{display:none;position:fixed;top:.8rem;left:.8rem;z-index:500;
  background:var(--bg2);border:1px solid var(--border2);border-radius:8px;
  width:42px;height:42px;align-items:center;justify-content:center;
  cursor:pointer;font-size:1.25rem;color:var(--text);padding:0;
  line-height:1;box-shadow:0 2px 8px rgba(0,0,0,.3)}
.mob-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);
  z-index:399;backdrop-filter:blur(2px)}
@media(max-width:768px){
  body{display:block!important}
  .ham{display:flex!important}
  .sidebar{position:fixed!important;top:0!important;left:-240px!important;
    height:100vh!important;width:220px!important;z-index:400!important;
    transition:left .25s ease!important;overflow-y:auto!important;
    border-right:1px solid var(--border)!important}
  .sidebar.nav-open{left:0!important}
  .mob-overlay.nav-open{display:block!important}
  .main{padding:1rem!important;padding-top:3.75rem!important}
  .two-col,.form-row,.frow,.stat-row,.grid-2{grid-template-columns:1fr!important}
  .stats{grid-template-columns:repeat(2,1fr)!important}
  .card{overflow-x:auto;-webkit-overflow-scrolling:touch}
  table{min-width:540px}
  .ai-layout{flex-direction:column!important}
}
@media(max-width:480px){
  .stats{grid-template-columns:1fr 1fr!important}
}
</style>
</head>
<body>
<button class="ham" id="mobHam" onclick="mobNav()" aria-label="Menu">&#9776;</button>
<div class="mob-overlay" id="mobOv" onclick="mobClose()"></div>

<nav class="sidebar">
  <div class="sidebar-logo"><span>Chain</span>Mind</div>
  <a href="/admin/<?= $qs ?>">⊞ Dashboard</a>
  <a href="/admin/users.php<?= $qs ?>">👥 Users</a>
  <a href="/admin/nodes.php<?= $qs ?>">🖥 Nodes</a>
  <a href="/admin/api-keys.php<?= $qs ?>" class="active">🔑 API Keys</a>
  <a href="/admin/withdrawals.php<?= $qs ?>">💸 Withdrawals</a>
  <a href="/admin/iq-rate.php<?= $qs ?>">⚡ IQ Rate</a>
  <hr class="sd">
  <a href="/">← Landing page</a>
  <a href="/auth/logout.php">⇒ Sign out</a>
</nav>

<div class="main">
  <h1>API Keys <span style="font-size:.85rem;color:var(--muted);font-weight:400">(<?= number_format($total) ?> total)</span></h1>

  <?= $flash ?>

  <?php
  // ── Stats bar ──
  $stats = db()->query("
    SELECT
      COUNT(*)                                               AS total_keys,
      SUM(is_active=1)                                      AS active_keys,
      COALESCE(SUM(c.balance),0)                            AS total_credits,
      (SELECT COUNT(*) FROM api_key_usage WHERE DATE(created_at)=CURDATE()) AS calls_today
    FROM api_keys k LEFT JOIN credits c ON c.api_key_id=k.id
  ")->fetch();
  ?>
  <div class="stat-row">
    <div class="stat"><div class="lbl">Total Keys</div><div class="val"><?= number_format($stats['total_keys']) ?></div></div>
    <div class="stat"><div class="lbl">Active Keys</div><div class="val" style="color:var(--green)"><?= number_format($stats['active_keys']) ?></div></div>
    <div class="stat"><div class="lbl">Credits Held</div><div class="val" style="color:var(--accent)"><?= number_format($stats['total_credits']) ?></div></div>
    <div class="stat"><div class="lbl">API Calls Today</div><div class="val" style="color:var(--orange)"><?= number_format($stats['calls_today']) ?></div></div>
  </div>

  <!-- Create new key -->
  <div class="card">
    <div class="card-head"><h2>➕ Create New Key</h2></div>
    <div class="card-body">
      <form method="POST">
        <input type="hidden" name="action" value="create">
        <div class="form-row">
          <div><label class="lbl">Owner Name *</label><input type="text" name="owner_name" placeholder="John Doe" required></div>
          <div><label class="lbl">Owner Email *</label><input type="email" name="owner_email" placeholder="john@example.com" required></div>
        </div>
        <div class="form-row">
          <div><label class="lbl">Label</label><input type="text" name="label" value="Default" placeholder="e.g. Production Key"></div>
          <div style="display:flex;align-items:flex-end"><button type="submit" class="btn btn-primary">Create Key</button></div>
        </div>
      </form>
    </div>
  </div>

  <!-- Search + table -->
  <div class="card">
    <div class="card-head">
      <h2>All API Keys</h2>
      <form method="GET" style="display:flex;gap:.5rem">
        <?php if ($is_secret_admin && !$is_session_admin): ?><input type="hidden" name="secret" value="<?= htmlspecialchars($_GET['secret']??'') ?>"><?php endif; ?>
        <input type="search" name="q" placeholder="Search name, email, label…" value="<?= htmlspecialchars($search) ?>" style="width:220px">
        <button type="submit" class="btn btn-ghost btn-sm">Search</button>
      </form>
    </div>
    <div style="overflow-x:auto">
    <table>
      <thead><tr>
        <th>#</th><th>Label / Owner</th><th>Key (masked)</th>
        <th>Credits</th><th>Calls</th><th>Rate (rpm)</th>
        <th>Expires</th><th>Status</th><th>Actions</th>
      </tr></thead>
      <tbody>
      <?php foreach ($keys as $k): ?>
      <tr>
        <td><?= $k['id'] ?></td>
        <td>
          <div style="font-weight:600"><?= htmlspecialchars($k['label']??'—') ?></div>
          <div style="color:var(--muted);font-size:.75rem"><?= htmlspecialchars($k['owner_name']) ?> / <?= htmlspecialchars($k['owner_email']) ?></div>
        </td>
        <td><span class="mono"><?= htmlspecialchars(substr($k['api_key'],0,8).'••••'.substr($k['api_key'],-4)) ?></span></td>
        <td><?= number_format((int)$k['credit_balance']) ?></td>
        <td><?= number_format((int)$k['total_calls']) ?></td>
        <td><?= (int)($k['rate_limit_rpm']??60) ?>/min</td>
        <td><?= $k['expires_at'] ? date('Y-m-d', strtotime($k['expires_at'])) : '<span style="color:var(--muted)">Never</span>' ?></td>
        <td>
          <?php if ($k['is_active']): ?><span class="badge b-active">Active</span><?php else: ?><span class="badge b-inactive">Revoked</span><?php endif; ?>
          <?php if ((int)$k['id']===1 || !empty($k['is_admin'])): ?> <span class="badge b-admin">Admin</span><?php endif; ?>
        </td>
        <td>
          <button class="btn btn-ghost btn-sm" onclick="toggleEdit(<?= $k['id'] ?>)">Edit</button>
          <?php if ($k['is_active']): ?>
            <form method="POST" style="display:inline" onsubmit="return confirm('Revoke this key?')">
              <input type="hidden" name="action" value="revoke">
              <input type="hidden" name="key_id" value="<?= $k['id'] ?>">
              <button type="submit" class="btn btn-danger btn-sm">Revoke</button>
            </form>
          <?php else: ?>
            <form method="POST" style="display:inline">
              <input type="hidden" name="action" value="activate">
              <input type="hidden" name="key_id" value="<?= $k['id'] ?>">
              <button type="submit" class="btn btn-green btn-sm">Activate</button>
            </form>
          <?php endif; ?>
        </td>
      </tr>
      <!-- Edit row -->
      <tr id="edit-<?= $k['id'] ?>" style="display:none;background:rgba(255,255,255,.02)">
        <td colspan="9" style="padding:1rem 1.25rem">
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:.75rem;margin-bottom:.75rem">
            <div>
              <label class="lbl">Label</label>
              <form method="POST">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="key_id" value="<?= $k['id'] ?>">
                <input type="text" name="label" value="<?= htmlspecialchars($k['label']??'') ?>">
                <div style="margin-top:.5rem;display:flex;gap:.5rem">
                  <input type="number" name="rate_limit_rpm" value="<?= (int)($k['rate_limit_rpm']??60) ?>" placeholder="RPM" style="width:80px">
                  <input type="number" name="rate_limit_rpd" value="<?= (int)($k['rate_limit_rpd']??10000) ?>" placeholder="RPD" style="width:100px">
                </div>
                <div style="margin-top:.5rem">
                  <input type="text" name="allowed_models" value="<?= htmlspecialchars(implode(', ', json_decode($k['allowed_models']??'[]',true)??[])) ?>" placeholder="allowed models (csv, blank=all)">
                </div>
                <div style="margin-top:.5rem;display:flex;gap:.5rem">
                  <input type="number" name="credit_quota" value="<?= $k['credit_quota']??'' ?>" placeholder="Credit quota (blank=unlimited)" style="flex:1">
                  <input type="date" name="expires_at" value="<?= $k['expires_at'] ? substr($k['expires_at'],0,10) : '' ?>" style="flex:1">
                </div>
                <div style="margin-top:.5rem">
                  <textarea name="notes" rows="2" placeholder="Notes…" style="resize:vertical"><?= htmlspecialchars($k['notes']??'') ?></textarea>
                </div>
                <div style="margin-top:.75rem">
                  <button type="submit" class="btn btn-primary btn-sm">Save Changes</button>
                </div>
              </form>
            </div>
            <div>
              <label class="lbl">Add Credits</label>
              <form method="POST">
                <input type="hidden" name="action" value="add_credits">
                <input type="hidden" name="key_id" value="<?= $k['id'] ?>">
                <input type="number" name="credits" min="1" placeholder="Amount to add">
                <div style="margin-top:.5rem"><button type="submit" class="btn btn-green btn-sm">Add Credits</button></div>
              </form>
            </div>
            <div style="grid-column:span 2">
              <label class="lbl">Usage (last 7 days)</label>
              <?php
              $usage7 = db()->prepare("
                SELECT DATE(created_at) AS d, COUNT(*) AS calls, SUM(credits_used) AS cred
                FROM api_key_usage WHERE api_key_id=? AND created_at >= NOW()-INTERVAL 7 DAY
                GROUP BY DATE(created_at) ORDER BY d DESC
              ");
              $usage7->execute([$k['id']]);
              $rows7 = $usage7->fetchAll();
              ?>
              <?php if ($rows7): ?>
              <table style="min-width:unset">
                <thead><tr><th>Date</th><th>Calls</th><th>Credits</th></tr></thead>
                <tbody>
                <?php foreach ($rows7 as $r): ?>
                <tr><td><?= $r['d'] ?></td><td><?= number_format($r['calls']) ?></td><td><?= number_format($r['cred']) ?></td></tr>
                <?php endforeach; ?>
                </tbody>
              </table>
              <?php else: ?><p style="color:var(--muted);font-size:.8rem">No usage yet.</p><?php endif; ?>
            </div>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </div>

  <?php if ($pages > 1): ?>
  <div class="pager">
    <?php for ($p=1;$p<=$pages;$p++): ?>
      <a href="?page=<?=$p?><?=$search?'&q='.urlencode($search):''?><?=$qs?str_replace('?','&',substr($qs,0)):''?>"
         style="<?=$p===$page?'background:#1f6feb;color:#fff':''?>"><?=$p?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<script>
function toggleEdit(id) {
    const row = document.getElementById('edit-'+id);
    row.style.display = row.style.display === 'none' ? 'table-row' : 'none';
}
</script>
<script>
function mobNav(){var s=document.querySelector('.sidebar'),o=document.getElementById('mobOv');
  if(s){s.classList.toggle('nav-open');o.classList.toggle('nav-open');}}
function mobClose(){var s=document.querySelector('.sidebar'),o=document.getElementById('mobOv');
  if(s){s.classList.remove('nav-open');o.classList.remove('nav-open');}}
</script>
</body>
</html>
