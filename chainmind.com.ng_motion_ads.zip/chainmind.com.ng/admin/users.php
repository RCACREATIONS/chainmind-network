<?php
session_start();
require_once __DIR__ . '/../api/_helpers.php';
$is_session_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
$is_secret_admin  = defined('ADMIN_SECRET') && ($_GET['secret'] ?? '') === ADMIN_SECRET;
if (!$is_session_admin && !$is_secret_admin) { header('Location: /auth/login.php?next=/admin/users.php'); exit; }
$qs = $is_secret_admin && !$is_session_admin ? '?secret=' . urlencode($_GET['secret']) : '';

// Handle role/status changes
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uid    = (int)($_POST['user_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    if ($uid) {
        if ($action === 'make_admin')  db()->prepare('UPDATE users SET role = "admin"  WHERE id = ?')->execute([$uid]);
        if ($action === 'remove_admin')db()->prepare('UPDATE users SET role = "user"   WHERE id = ?')->execute([$uid]);
        if ($action === 'deactivate') db()->prepare('UPDATE users SET is_active = 0   WHERE id = ?')->execute([$uid]);
        if ($action === 'activate')   db()->prepare('UPDATE users SET is_active = 1   WHERE id = ?')->execute([$uid]);
    }
    header('Location: /admin/users.php' . $qs); exit;
}

$search = trim($_GET['q'] ?? '');
$page   = max(1, (int)($_GET['page'] ?? 1));
$limit  = 30; $offset = ($page - 1) * $limit;

if ($search) {
    $stmt = db()->prepare(
        'SELECT u.*, (SELECT COUNT(*) FROM api_keys WHERE user_id = u.id) AS key_count,
                (SELECT COALESCE(SUM(c.balance),0) FROM api_keys k JOIN credits c ON c.api_key_id=k.id WHERE k.user_id=u.id) AS total_credits
         FROM users u WHERE u.email LIKE ? OR u.name LIKE ?
         ORDER BY u.created_at DESC LIMIT ? OFFSET ?'
    );
    $stmt->execute(["%$search%", "%$search%", $limit, $offset]);
} else {
    $stmt = db()->prepare(
        'SELECT u.*, (SELECT COUNT(*) FROM api_keys WHERE user_id = u.id) AS key_count,
                (SELECT COALESCE(SUM(c.balance),0) FROM api_keys k JOIN credits c ON c.api_key_id=k.id WHERE k.user_id=u.id) AS total_credits
         FROM users u ORDER BY u.created_at DESC LIMIT ? OFFSET ?'
    );
    $stmt->execute([$limit, $offset]);
}
$users = $stmt->fetchAll();
$total_users = (int)db()->query('SELECT COUNT(*) FROM users')->fetchColumn();
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><title>Users — Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{--bg:#0a0c10;--bg2:#0d1117;--bg3:#161b22;--border:#21262d;--border2:#30363d;
  --text:#e6edf3;--muted:#8b949e;--accent:#58a6ff;--green:#3fb950;--green-bd:#238636}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:system-ui,sans-serif;display:flex;min-height:100vh}
.sidebar{width:220px;background:var(--bg2);border-right:1px solid var(--border);padding:1.5rem 1rem;display:flex;flex-direction:column;gap:.25rem;flex-shrink:0}
.sidebar-logo{font-weight:800;font-size:1.1rem;margin-bottom:1.5rem;padding-left:.5rem}.sidebar-logo span{color:var(--accent)}
.sidebar a{display:flex;align-items:center;gap:.6rem;padding:.55rem .75rem;border-radius:8px;color:var(--muted);text-decoration:none;font-size:.85rem;font-weight:500}
.sidebar a:hover,.sidebar a.active{background:var(--bg3);color:var(--text)}
hr.sd{border:none;border-top:1px solid var(--border);margin:.5rem 0}
.main{flex:1;padding:2rem;overflow-x:hidden}
h1{font-size:1.35rem;font-weight:800;margin-bottom:1.5rem}
.toolbar{display:flex;gap:.75rem;margin-bottom:1.25rem;flex-wrap:wrap;align-items:center}
.toolbar input{padding:.45rem .75rem;border-radius:7px;border:1px solid var(--border2);background:var(--bg2);color:var(--text);font-size:.88rem;width:260px}
.card{background:var(--bg3);border:1px solid var(--border2);border-radius:12px}
table{width:100%;border-collapse:collapse;font-size:.82rem}
th{text-align:left;padding:.5rem .9rem;color:var(--muted);border-bottom:1px solid var(--border)}
td{padding:.5rem .9rem;border-bottom:1px solid var(--border)}
tr:last-child td{border-bottom:none}
.badge{display:inline-block;padding:.1rem .4rem;border-radius:20px;font-size:.7rem;font-weight:700}
.b-admin{background:#6e40c9;color:#fff}.b-user{background:var(--border2);color:var(--muted)}.b-node{background:#1f6feb;color:#fff}
.b-active{background:var(--green-bd);color:#fff}.b-inactive{background:#da3633;color:#fff}
.muted{color:var(--muted);font-size:.78rem}
form.action{display:inline}
select.act{background:var(--bg2);border:1px solid var(--border2);color:var(--text);border-radius:5px;padding:.2rem .3rem;font-size:.78rem;cursor:pointer}
button.go{background:var(--green-bd);border:none;color:#fff;border-radius:5px;padding:.2rem .5rem;font-size:.78rem;cursor:pointer;margin-left:.25rem}
.pager{display:flex;gap:.5rem;margin-top:1.25rem;font-size:.83rem}
.pager a{color:var(--accent);text-decoration:none;padding:.3rem .65rem;border:1px solid var(--border2);border-radius:6px}

/* ── Mobile ─────────────────────────────────────────────── */
.ham{display:none;position:fixed;top:.8rem;left:.8rem;z-index:500;
  background:var(--bg2);border:1px solid var(--border2);border-radius:8px;
  width:42px;height:42px;align-items:center;justify-content:center;
  cursor:pointer;font-size:1.25rem;color:var(--text);padding:0;
  line-height:1;box-shadow:0 2px 8px rgba(0,0,0,.3)}
.mob-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);
  z-index:399;backdrop-filter:blur(2px)}
@media(max-width:768px){
  body{display:block!important}
  .ham{display:flex!important}
  .sidebar{position:fixed!important;top:0!important;left:-240px!important;
    height:100vh!important;width:220px!important;z-index:400!important;
    transition:left .25s ease!important;overflow-y:auto!important;
    border-right:1px solid var(--border)!important}
  .sidebar.nav-open{left:0!important}
  .mob-overlay.nav-open{display:block!important}
  .main{padding:1rem!important;padding-top:3.75rem!important}
  .two-col,.form-row,.frow,.stat-row,.grid-2{grid-template-columns:1fr!important}
  .stats{grid-template-columns:repeat(2,1fr)!important}
  .card{overflow-x:auto;-webkit-overflow-scrolling:touch}
  table{min-width:540px}
  .ai-layout{flex-direction:column!important}
}
@media(max-width:480px){
  .stats{grid-template-columns:1fr 1fr!important}
}
</style></head><body>
<button class="ham" id="mobHam" onclick="mobNav()" aria-label="Menu">&#9776;</button>
<div class="mob-overlay" id="mobOv" onclick="mobClose()"></div>

<nav class="sidebar">
  <div class="sidebar-logo"><span>Chain</span>Mind</div>
  <a href="/admin/<?= $qs ?>">📊 Dashboard</a>
  <a href="/admin/users.php<?= $qs ?>" class="active">=e Users</a>
  <a href="/admin/nodes.php<?= $qs ?>">🖥 Nodes</a>
  <a href="/admin/withdrawals.php<?= $qs ?>">💸 Withdrawals</a>
  <a href="/admin/iq-rate.php<?= $qs ?>">⚙ IQ Rate</a>
  <hr class="sd">
  <a href="/admin/blog.php<?= $qs ?>">📝 Blog</a>
  <a href="/">← Landing page</a>
  <a href="/auth/logout.php">🚪 Sign out</a>
</nav>
<div class="main">
  <h1>Users <span style="font-size:.9rem;color:var(--muted);font-weight:400">(<?= number_format($total_users) ?> total)</span></h1>
  <div class="toolbar">
    <form method="GET" style="display:flex;gap:.5rem">
      <?php if ($is_secret_admin && !$is_session_admin): ?><input type="hidden" name="secret" value="<?= htmlspecialchars($_GET['secret']) ?>"><?php endif; ?>
      <input type="search" name="q" placeholder="Search email or name&" value="<?= htmlspecialchars($search) ?>">
      <button style="padding:.45rem .9rem;border-radius:7px;border:1px solid var(--border2);background:transparent;color:var(--text);cursor:pointer">Search</button>
    </form>
  </div>
  <div class="card">
    <table>
      <thead><tr><th>#</th><th>Name / Email</th><th>Role</th><th>Status</th><th>Keys</th><th>Credits</th><th>Joined</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($users as $u): ?>
      <tr>
        <td class="muted"><?= $u['id'] ?></td>
        <td>
          <div style="font-weight:600;font-size:.85rem"><?= htmlspecialchars($u['name']) ?></div>
          <div class="muted"><?= htmlspecialchars($u['email']) ?></div>
        </td>
        <td><span class="badge b-<?= $u['role'] ?>"><?= $u['role'] ?></span></td>
        <td><span class="badge b-<?= $u['is_active'] ? 'active' : 'inactive' ?>"><?= $u['is_active'] ? 'active' : 'inactive' ?></span></td>
        <td class="muted"><?= $u['key_count'] ?></td>
        <td class="muted"><?= number_format($u['total_credits']) ?></td>
        <td class="muted"><?= substr($u['created_at'], 0, 10) ?></td>
        <td>
          <form class="action" method="POST">
            <?php if ($is_secret_admin && !$is_session_admin): ?><input type="hidden" name="secret" value="<?= htmlspecialchars($_GET['secret'] ?? '') ?>"><?php endif; ?>
            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
            <select class="act" name="action">
              <?php if ($u['role'] !== 'admin'): ?><option value="make_admin">Make admin</option><?php endif; ?>
              <?php if ($u['role'] === 'admin'): ?><option value="remove_admin">Remove admin</option><?php endif; ?>
              <?php if ($u['is_active']): ?><option value="deactivate">Deactivate</option><?php else: ?><option value="activate">Activate</option><?php endif; ?>
            </select>
            <button class="go" type="submit">Go</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($users)): ?>
        <tr><td colspan="8" style="text-align:center;padding:2rem;color:var(--muted)">No users found</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if ($total_users > $limit): ?>
  <div class="pager">
    <?php if ($page > 1): ?><a href="?page=<?= $page-1 ?><?= $search ? '&q='.urlencode($search) : '' ?><?= $qs ? '&secret='.urlencode($_GET['secret']??'') : '' ?>">� Prev</a><?php endif; ?>
    <span style="padding:.3rem .5rem;color:var(--muted)">Page <?= $page ?> of <?= ceil($total_users/$limit) ?></span>
    <?php if ($page < ceil($total_users/$limit)): ?><a href="?page=<?= $page+1 ?><?= $search ? '&q='.urlencode($search) : '' ?><?= $qs ? '&secret='.urlencode($_GET['secret']??'') : '' ?>">Next �</a><?php endif; ?>
  </div>
  <?php endif; ?>
</div>
<script>
function mobNav(){var s=document.querySelector('.sidebar'),o=document.getElementById('mobOv');
  if(s){s.classList.toggle('nav-open');o.classList.toggle('nav-open');}}
function mobClose(){var s=document.querySelector('.sidebar'),o=document.getElementById('mobOv');
  if(s){s.classList.remove('nav-open');o.classList.remove('nav-open');}}
</script>
</body></html>
