<?php
session_start();
require_once __DIR__ . '/../api/_helpers.php';
require_once __DIR__ . '/../api/billing/credits.php';
$is_session_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
$is_secret_admin  = defined('ADMIN_SECRET') && ($_GET['secret'] ?? '') === ADMIN_SECRET;
if (!$is_session_admin && !$is_secret_admin) { header('Location: /auth/login.php?next=/admin/withdrawals.php'); exit; }
$qs = $is_secret_admin && !$is_session_admin ? '?secret=' . urlencode($_GET['secret']) : '';

// ── Helper: get node owner email ──────────────────────────────────────────────
function node_owner_email(string $node_id): ?array {
    // Try nodes.linked_email first, then join to users
    $stmt = db()->prepare(
        'SELECT n.name AS node_name,
                COALESCE(n.linked_email, u.email) AS email,
                COALESCE(u.name, n.name) AS owner_name
         FROM nodes n
         LEFT JOIN users u ON u.id = n.user_id
         WHERE n.id = ? LIMIT 1'
    );
    $stmt->execute([$node_id]);
    return $stmt->fetch() ?: null;
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $wid    = (int)($_POST['wd_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    $note   = trim($_POST['note'] ?? '');
    $reason = trim($_POST['reason'] ?? '');   // Rejection reason for email

    $wstmt = db()->prepare('SELECT * FROM withdrawals WHERE id = ?');
    $wstmt->execute([$wid]); $wd = $wstmt->fetch();

    if ($wd) {
        $owner = node_owner_email($wd['node_id']);

        if ($action === 'approve') {
            db()->prepare(
                'UPDATE withdrawals SET status = "approved", processed_at = NOW(), admin_note = ? WHERE id = ?'
            )->execute([$note, $wid]);
            $msg = 'Withdrawal approved.';

            // ── Email: approval notification ──────────────────────────────────
            if ($owner && $owner['email']) {
                $amt_iq  = number_format((float)$wd['iq_amount'], 4);
                $amt_usd = number_format((float)$wd['usd_value'], 2);
                $method  = ucfirst($wd['method'] ?? 'crypto');
                $body_html = "
                    <h2 style='color:#3fb950;margin:0 0 .5rem'>✅ Withdrawal Approved</h2>
                    <p style='color:#8b949e;margin:.5rem 0 1.5rem'>Hi {$owner['owner_name']}, your withdrawal request has been approved and is being processed.</p>
                    <table style='width:100%;border-collapse:collapse;font-size:.9rem;margin-bottom:1.5rem'>
                      <tr style='border-bottom:1px solid #21262d'>
                        <td style='padding:.6rem;color:#8b949e'>Amount (IQ)</td>
                        <td style='padding:.6rem;color:#e6edf3;font-weight:700'>{$amt_iq} IQ</td>
                      </tr>
                      <tr style='border-bottom:1px solid #21262d'>
                        <td style='padding:.6rem;color:#8b949e'>Amount (USD)</td>
                        <td style='padding:.6rem;color:#3fb950;font-weight:700'>\${$amt_usd}</td>
                      </tr>
                      <tr style='border-bottom:1px solid #21262d'>
                        <td style='padding:.6rem;color:#8b949e'>Payout Method</td>
                        <td style='padding:.6rem;color:#e6edf3'>{$method}</td>
                      </tr>
                      " . ($note ? "<tr><td style='padding:.6rem;color:#8b949e'>Note</td><td style='padding:.6rem;color:#e6edf3'>" . htmlspecialchars($note) . "</td></tr>" : "") . "
                    </table>
                    <p style='color:#8b949e;font-size:.85rem'>Payment will be sent to your registered payout details within 1–2 business days. Check your dashboard for updates.</p>
                    <div style='margin-top:1.5rem;text-align:center'>
                      <a href='https://chainmind.com.ng/dashboard/node-earnings.php' style='display:inline-block;background:#238636;color:#fff;text-decoration:none;padding:.65rem 1.75rem;border-radius:8px;font-weight:700;font-size:.9rem'>View Earnings Dashboard</a>
                    </div>
                ";
                send_email(
                    $owner['email'],
                    '✅ ChainMind: Withdrawal Approved — $' . $amt_usd,
                    email_html('Withdrawal Approved', $body_html)
                );
            }

        } elseif ($action === 'reject') {
            $reject_reason = $reason ?: ($note ?: 'Rejected by admin');
            db()->prepare(
                'UPDATE withdrawals SET status = "rejected", processed_at = NOW(), admin_note = ? WHERE id = ?'
            )->execute([$reject_reason, $wid]);
            $msg = 'Withdrawal rejected.';

            // ── Email: rejection notification ─────────────────────────────────
            if ($owner && $owner['email']) {
                $amt_iq  = number_format((float)$wd['iq_amount'], 4);
                $amt_usd = number_format((float)$wd['usd_value'], 2);
                $body_html = "
                    <h2 style='color:#f85149;margin:0 0 .5rem'>❌ Withdrawal Request Rejected</h2>
                    <p style='color:#8b949e;margin:.5rem 0 1.5rem'>Hi {$owner['owner_name']}, unfortunately your withdrawal request for {$amt_iq} IQ (\${$amt_usd}) could not be processed.</p>
                    " . ($reject_reason ? "
                    <div style='background:#21262d;border:1px solid #30363d;border-radius:8px;padding:1rem;margin-bottom:1.5rem'>
                      <p style='color:#8b949e;font-size:.78rem;margin:0 0 .35rem;text-transform:uppercase;letter-spacing:.05em'>Reason</p>
                      <p style='color:#f85149;font-size:.93rem;margin:0'>" . htmlspecialchars($reject_reason) . "</p>
                    </div>
                    " : "") . "
                    <p style='color:#8b949e;font-size:.85rem;margin-bottom:1rem'>Your IQ balance has been restored and remains available for a future withdrawal request. If you believe this is a mistake, please contact support.</p>
                    <div style='margin-top:1.5rem;text-align:center'>
                      <a href='https://chainmind.com.ng/dashboard/node-earnings.php' style='display:inline-block;background:#1f6feb;color:#fff;text-decoration:none;padding:.65rem 1.75rem;border-radius:8px;font-weight:700;font-size:.9rem'>View Earnings Dashboard</a>
                    </div>
                ";
                send_email(
                    $owner['email'],
                    '❌ ChainMind: Withdrawal Request Rejected',
                    email_html('Withdrawal Rejected', $body_html)
                );
            }

        } elseif ($action === 'mark_paid') {
            $payout_ref = trim($_POST['payout_ref'] ?? '');
            db()->prepare(
                'UPDATE withdrawals SET status = "paid", payout_ref = ?, processed_at = NOW() WHERE id = ?'
            )->execute([$payout_ref, $wid]);
            $msg = 'Withdrawal marked as paid.';

            // ── Email: paid notification ───────────────────────────────────────
            if ($owner && $owner['email']) {
                $amt_usd = number_format((float)$wd['usd_value'], 2);
                $body_html = "
                    <h2 style='color:#3fb950;margin:0 0 .5rem'>💰 Payment Sent!</h2>
                    <p style='color:#8b949e;margin:.5rem 0 1.5rem'>Hi {$owner['owner_name']}, your payout of <strong style='color:#3fb950'>\${$amt_usd}</strong> has been sent.</p>
                    " . ($payout_ref ? "<p style='color:#8b949e;font-size:.85rem'>Reference: <code style='color:#58a6ff'>" . htmlspecialchars($payout_ref) . "</code></p>" : "") . "
                    <div style='margin-top:1.5rem;text-align:center'>
                      <a href='https://chainmind.com.ng/dashboard/node-earnings.php' style='display:inline-block;background:#238636;color:#fff;text-decoration:none;padding:.65rem 1.75rem;border-radius:8px;font-weight:700;font-size:.9rem'>View Earnings Dashboard</a>
                    </div>
                ";
                send_email(
                    $owner['email'],
                    '💰 ChainMind: Payment of $' . $amt_usd . ' Sent',
                    email_html('Payment Sent', $body_html)
                );
            }

        } elseif ($action === 'auto_pay' && $wd['method'] === 'crypto') {
            $rate = iq_rate();
            $usd  = (float)$wd['iq_amount'] * $rate;
            $r    = @json_decode(file_get_contents('https://api.nowpayments.io/v1/payout', false,
                stream_context_create(['http' => [
                    'method'  => 'POST',
                    'header'  => "x-api-key: " . NOWPAYMENTS_PAYOUT_KEY . "\r\nContent-Type: application/json\r\n",
                    'content' => json_encode([
                        'ipn_callback_url' => '',
                        'withdrawals' => [[
                            'address'          => $wd['wallet'],
                            'currency'         => 'usdttrc20',
                            'amount'           => round($usd, 4),
                            'ipn_callback_url' => '',
                            'extra_id'         => 'cm-wd-' . $wid,
                        ]],
                    ]),
                ]])
            ), true);
            if (!empty($r['id'])) {
                $payout_id = $r['id'];
                db()->prepare('UPDATE withdrawals SET status = "paid", payout_ref = ?, processed_at = NOW() WHERE id = ?')
                    ->execute([$payout_id, $wid]);
                $msg = "Auto-payout sent! NOWPayments batch ID: $payout_id";
            } else {
                $msg = 'Auto-payout failed: ' . json_encode($r);
            }
        }
    }
    header('Location: /admin/withdrawals.php' . ($qs ?: '?') . ($qs ? '&' : '') . 'msg=' . urlencode($msg)); exit;
}

$filter = $_GET['filter'] ?? 'pending';
$safe   = in_array($filter, ['all','pending','approved','paid','rejected']) ? $filter : 'pending';
$where  = $safe === 'all' ? '' : "WHERE w.status = '$safe'";

// Totals
$totals = db()->query(
    "SELECT status, COUNT(*) AS cnt, COALESCE(SUM(usd_value),0) AS usd_sum FROM withdrawals GROUP BY status"
)->fetchAll(\PDO::FETCH_UNIQUE|\PDO::FETCH_ASSOC);

$wds = db()->query(
    "SELECT w.*, n.name AS node_name FROM withdrawals w
     LEFT JOIN nodes n ON n.id = w.node_id $where ORDER BY w.requested_at DESC LIMIT 80"
)->fetchAll();
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><title>Withdrawals — Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{--bg:#0a0c10;--bg2:#0d1117;--bg3:#161b22;--border:#21262d;--border2:#30363d;
  --text:#e6edf3;--muted:#8b949e;--accent:#58a6ff;--green:#3fb950;--green-bd:#238636}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:system-ui,sans-serif;display:flex;min-height:100vh}
.sidebar{width:220px;background:var(--bg2);border-right:1px solid var(--border);padding:1.5rem 1rem;display:flex;flex-direction:column;gap:.25rem;flex-shrink:0}
.sidebar-logo{font-weight:800;font-size:1.1rem;margin-bottom:1.5rem;padding-left:.5rem}.sidebar-logo span{color:var(--accent)}
.sidebar a{display:flex;align-items:center;gap:.6rem;padding:.55rem .75rem;border-radius:8px;color:var(--muted);text-decoration:none;font-size:.85rem;font-weight:500}
.sidebar a:hover,.sidebar a.active{background:var(--bg3);color:var(--text)}
hr.sd{border:none;border-top:1px solid var(--border);margin:.5rem 0}
.main{flex:1;padding:2rem;overflow-x:auto}
h1{font-size:1.35rem;font-weight:800;margin-bottom:1rem}
.totals{display:flex;gap:.75rem;flex-wrap:wrap;margin-bottom:1.25rem}
.total-chip{padding:.4rem .9rem;border-radius:20px;font-size:.82rem;font-weight:600;border:1px solid var(--border2);color:var(--muted)}
.total-chip.t-pending{border-color:#bf8700;color:#ffc107}
.total-chip.t-approved{border-color:#1f6feb;color:var(--accent)}
.total-chip.t-paid{border-color:var(--green-bd);color:var(--green)}
.total-chip.t-rejected{border-color:#da3633;color:#f85149}
.filter-bar{display:flex;gap:.5rem;margin-bottom:1.25rem;flex-wrap:wrap}
.filter-bar a{padding:.4rem .9rem;border-radius:20px;font-size:.82rem;font-weight:600;border:1px solid var(--border2);color:var(--muted);text-decoration:none}
.filter-bar a.active,.filter-bar a:hover{border-color:var(--accent);color:var(--accent)}
.flash{background:#0d2119;border:1px solid var(--green-bd);border-radius:8px;padding:.75rem 1rem;font-size:.87rem;color:var(--green);margin-bottom:1.25rem}
.card{background:var(--bg3);border:1px solid var(--border2);border-radius:12px}
table{width:100%;border-collapse:collapse;font-size:.82rem}
th{text-align:left;padding:.55rem .9rem;color:var(--muted);border-bottom:1px solid var(--border);white-space:nowrap}
td{padding:.5rem .9rem;border-bottom:1px solid var(--border);vertical-align:top}
tr:last-child td{border-bottom:none}
.badge{display:inline-block;padding:.12rem .45rem;border-radius:20px;font-size:.7rem;font-weight:700}
.b-pending{background:#bf8700;color:#0d1117}.b-approved{background:#1f6feb;color:#fff}
.b-paid{background:var(--green-bd);color:#fff}.b-rejected{background:#da3633;color:#fff}
.muted{color:var(--muted);font-size:.78rem}
.btn-sm{padding:.3rem .7rem;border-radius:5px;border:none;font-size:.75rem;font-weight:700;cursor:pointer;white-space:nowrap}
.btn-approve{background:#1f6feb;color:#fff}.btn-reject{background:#da3633;color:#fff}
.btn-paid{background:var(--green-bd);color:#fff}.btn-auto{background:#6e40c9;color:#fff}
.act-form{display:flex;flex-direction:column;gap:.35rem}
input.inp{padding:.3rem .5rem;border-radius:5px;border:1px solid var(--border2);background:var(--bg2);color:var(--text);font-size:.78rem;width:100%;max-width:200px}
textarea.inp{padding:.35rem .5rem;border-radius:5px;border:1px solid var(--border2);background:var(--bg2);color:var(--text);font-size:.78rem;width:100%;max-width:200px;resize:vertical}
.reject-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:9000;align-items:center;justify-content:center}
.reject-modal.open{display:flex}
.modal-box{background:var(--bg3);border:1px solid var(--border2);border-radius:12px;padding:1.75rem;width:420px;max-width:95vw}
.modal-box h2{font-size:1rem;margin-bottom:.75rem;color:#f85149}
.modal-box textarea{width:100%;padding:.6rem .75rem;border-radius:7px;border:1px solid var(--border2);background:var(--bg2);color:var(--text);font-size:.88rem;resize:vertical;min-height:80px}
.modal-row{display:flex;gap:.6rem;justify-content:flex-end;margin-top:1rem}

/* ── Mobile ─────────────────────────────────────────────── */
.ham{display:none;position:fixed;top:.8rem;left:.8rem;z-index:500;
  background:var(--bg2);border:1px solid var(--border2);border-radius:8px;
  width:42px;height:42px;align-items:center;justify-content:center;
  cursor:pointer;font-size:1.25rem;color:var(--text);padding:0;
  line-height:1;box-shadow:0 2px 8px rgba(0,0,0,.3)}
.mob-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);
  z-index:399;backdrop-filter:blur(2px)}
@media(max-width:768px){
  body{display:block!important}
  .ham{display:flex!important}
  .sidebar{position:fixed!important;top:0!important;left:-240px!important;
    height:100vh!important;width:220px!important;z-index:400!important;
    transition:left .25s ease!important;overflow-y:auto!important;
    border-right:1px solid var(--border)!important}
  .sidebar.nav-open{left:0!important}
  .mob-overlay.nav-open{display:block!important}
  .main{padding:1rem!important;padding-top:3.75rem!important}
  .two-col,.form-row,.frow,.stat-row,.grid-2{grid-template-columns:1fr!important}
  .stats{grid-template-columns:repeat(2,1fr)!important}
  .card{overflow-x:auto;-webkit-overflow-scrolling:touch}
  table{min-width:540px}
  .ai-layout{flex-direction:column!important}
}
@media(max-width:480px){
  .stats{grid-template-columns:1fr 1fr!important}
}
</style></head><body>
<button class="ham" id="mobHam" onclick="mobNav()" aria-label="Menu">&#9776;</button>
<div class="mob-overlay" id="mobOv" onclick="mobClose()"></div>


<!-- Reject modal -->
<div class="reject-modal" id="rejectModal">
  <div class="modal-box">
    <h2>❌ Reject Withdrawal</h2>
    <form method="POST" id="rejectForm">
      <?php if ($is_secret_admin && !$is_session_admin): ?><input type="hidden" name="secret" value="<?= htmlspecialchars($_GET['secret']??'') ?>"><?php endif; ?>
      <input type="hidden" name="wd_id" id="reject_wd_id">
      <input type="hidden" name="action" value="reject">
      <label style="font-size:.8rem;color:var(--muted);display:block;margin-bottom:.35rem">
        Reason (sent to node operator by email)
      </label>
      <textarea name="reason" id="rejectReason" placeholder="e.g. Wallet address format invalid, please resubmit with a valid USDT (TRC20) address." required></textarea>
      <label style="font-size:.8rem;color:var(--muted);display:block;margin:.5rem 0 .25rem">Internal admin note (optional)</label>
      <input type="text" class="inp" name="note" placeholder="Internal note…" style="max-width:100%">
      <div class="modal-row">
        <button type="button" onclick="closeRejectModal()" class="btn-sm" style="background:var(--border2);color:var(--text)">Cancel</button>
        <button type="submit" class="btn-sm btn-reject">Reject & Email Node</button>
      </div>
    </form>
  </div>
</div>

<nav class="sidebar">
  <div class="sidebar-logo"><span>Chain</span>Mind</div>
  <a href="/admin/<?= $qs ?>">📊 Dashboard</a>
  <a href="/admin/users.php<?= $qs ?>">👤 Users</a>
  <a href="/admin/nodes.php<?= $qs ?>">🖥 Nodes</a>
  <a href="/admin/withdrawals.php<?= $qs ?>" class="active">💸 Withdrawals</a>
  <a href="/admin/iq-rate.php<?= $qs ?>">⚙ Earnings Settings</a>
  <a href="/admin/api-keys.php<?= $qs ?>">🔑 API Keys</a>
  <hr class="sd">
  <a href="/admin/blog.php<?= $qs ?>">📝 Blog</a>
  <a href="/">← Home</a>
  <a href="/auth/logout.php">🚪 Sign out</a>
</nav>

<div class="main">
  <h1>Withdrawal Requests</h1>

  <?php if (isset($_GET['msg']) && $_GET['msg']): ?>
    <div class="flash">✓ <?= htmlspecialchars($_GET['msg']) ?></div>
  <?php endif; ?>

  <!-- Summary chips -->
  <div class="totals">
    <?php foreach (['pending','approved','paid','rejected'] as $s):
      $cnt = isset($totals[$s]) ? (int)$totals[$s]['cnt'] : 0;
      $usd = isset($totals[$s]) ? number_format((float)$totals[$s]['usd_sum'], 2) : '0.00';
    ?>
    <span class="total-chip t-<?= $s ?>"><?= ucfirst($s) ?>: <?= $cnt ?> ($<?= $usd ?>)</span>
    <?php endforeach; ?>
  </div>

  <div class="filter-bar">
    <?php foreach (['pending','approved','paid','rejected','all'] as $f): ?>
    <a href="?<?= $qs ? 'secret='.urlencode($_GET['secret']??'').'&' : '' ?>filter=<?= $f ?>"
       class="<?= $safe === $f ? 'active' : '' ?>"><?= ucfirst($f) ?></a>
    <?php endforeach; ?>
  </div>

  <div class="card">
    <table>
      <thead><tr>
        <th>Date</th><th>Node</th><th>IQ</th><th>USD</th><th>Method</th>
        <th>Details</th><th>Status</th><th>Action</th>
      </tr></thead>
      <tbody>
      <?php foreach ($wds as $w): ?>
      <tr>
        <td class="muted"><?= substr($w['requested_at'], 0, 10) ?></td>
        <td><?= htmlspecialchars($w['node_name'] ?? $w['node_id']) ?></td>
        <td><?= number_format($w['iq_amount'], 4) ?></td>
        <td>$<?= number_format($w['usd_value'], 2) ?></td>
        <td><?= htmlspecialchars($w['method']) ?></td>
        <td class="muted" style="max-width:180px;word-break:break-all">
          <?php if ($w['method'] === 'crypto'): ?>
            <?= htmlspecialchars($w['wallet'] ?? '') ?>
          <?php else: ?>
            <?= htmlspecialchars($w['bank_name'] ?? '') ?>
            <?php if ($w['bank_account']): ?><br><?= htmlspecialchars($w['bank_account']) ?><?php endif; ?>
          <?php endif; ?>
          <?php if ($w['payout_ref']): ?><br><em><?= htmlspecialchars($w['payout_ref']) ?></em><?php endif; ?>
          <?php if ($w['admin_note']): ?><br><em style="color:var(--muted)"><?= htmlspecialchars($w['admin_note']) ?></em><?php endif; ?>
        </td>
        <td><span class="badge b-<?= $w['status'] ?>"><?= $w['status'] ?></span></td>
        <td>
          <?php if ($w['status'] === 'pending'): ?>
          <div class="act-form">
            <div style="display:flex;gap:.3rem;flex-wrap:wrap">
              <!-- Approve -->
              <form method="POST" style="display:inline">
                <?php if ($is_secret_admin && !$is_session_admin): ?><input type="hidden" name="secret" value="<?= htmlspecialchars($_GET['secret']??'') ?>"><?php endif; ?>
                <input type="hidden" name="wd_id" value="<?= $w['id'] ?>">
                <input type="hidden" name="action" value="<?= $w['method'] === 'crypto' ? 'auto_pay' : 'approve' ?>">
                <input class="inp" type="text" name="note" placeholder="Admin note (optional)" style="margin-bottom:.25rem">
                <button class="btn-sm <?= $w['method'] === 'crypto' ? 'btn-auto' : 'btn-approve' ?>" type="submit">
                  <?= $w['method'] === 'crypto' ? '⚡ Auto Pay' : '✅ Approve' ?>
                </button>
              </form>
              <!-- Reject (opens modal) -->
              <button class="btn-sm btn-reject" onclick="openRejectModal(<?= $w['id'] ?>)">❌ Reject</button>
            </div>
          </div>

          <?php elseif ($w['status'] === 'approved'): ?>
          <form method="POST" style="display:flex;flex-direction:column;gap:.3rem">
            <?php if ($is_secret_admin && !$is_session_admin): ?><input type="hidden" name="secret" value="<?= htmlspecialchars($_GET['secret']??'') ?>"><?php endif; ?>
            <input type="hidden" name="wd_id" value="<?= $w['id'] ?>">
            <input type="hidden" name="action" value="mark_paid">
            <input class="inp" type="text" name="payout_ref" placeholder="Payout ref / TxID">
            <button class="btn-sm btn-paid" type="submit">💰 Mark Paid</button>
          </form>

          <?php else: ?>
          <span class="muted"><?= $w['processed_at'] ? substr($w['processed_at'], 0, 10) : '' ?></span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($wds)): ?>
        <tr><td colspan="8" style="text-align:center;padding:2rem;color:var(--muted)">No <?= $safe ?> withdrawals</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
function openRejectModal(wid) {
  document.getElementById('reject_wd_id').value = wid;
  document.getElementById('rejectReason').value = '';
  document.getElementById('rejectModal').classList.add('open');
}
function closeRejectModal() {
  document.getElementById('rejectModal').classList.remove('open');
}
document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeRejectModal(); });
</script>
<script>
function mobNav(){var s=document.querySelector('.sidebar'),o=document.getElementById('mobOv');
  if(s){s.classList.toggle('nav-open');o.classList.toggle('nav-open');}}
function mobClose(){var s=document.querySelector('.sidebar'),o=document.getElementById('mobOv');
  if(s){s.classList.remove('nav-open');o.classList.remove('nav-open');}}
</script>
</body></html>
