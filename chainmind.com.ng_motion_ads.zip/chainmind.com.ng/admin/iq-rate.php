<?php
session_start();
require_once __DIR__ . '/../api/_helpers.php';
$is_session_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
$is_secret_admin  = defined('ADMIN_SECRET') && ($_GET['secret'] ?? '') === ADMIN_SECRET;
if (!$is_session_admin && !$is_secret_admin) { header('Location: /auth/login.php?next=/admin/iq-rate.php'); exit; }
$qs = $is_secret_admin && !$is_session_admin ? '?secret=' . urlencode($_GET['secret']) : '';

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'iq_rate';

    if ($action === 'iq_rate') {
        $rate = (float)($_POST['usd_per_iq'] ?? 0);
        if ($rate > 0 && $rate < 1000) {
            db()->prepare('UPDATE iq_settings SET usd_per_iq = ? WHERE id = 1')->execute([$rate]);
            $msg = 'IQ rate updated to $' . number_format($rate, 6) . ' per IQ.';
        } else { $msg = 'Invalid rate.'; }

    } elseif ($action === 'commission') {
        $pct = (float)($_POST['commission_pct'] ?? 10);
        $min_usd = (float)($_POST['min_withdraw_usd'] ?? 50);
        if ($pct >= 0 && $pct <= 99) {
            db()->prepare('UPDATE iq_settings SET commission_pct = ?, min_withdraw_usd = ? WHERE id = 1')
                ->execute([$pct, max(1, $min_usd)]);
            $msg = 'Commission set to ' . $pct . '%. Nodes earn ' . (100-$pct) . '% of every credit spend. Minimum withdrawal: $' . number_format($min_usd, 2) . '.';
        } else { $msg = 'Commission must be between 0 and 99.'; }
    }
}

$row = db()->query('SELECT usd_per_iq,
    COALESCE(commission_pct, 10.00) AS commission_pct,
    COALESCE(min_withdraw_usd, 50.00) AS min_withdraw_usd
    FROM iq_settings WHERE id = 1')->fetch();

$current        = (float)($row['usd_per_iq'] ?? 0.01);
$commission_pct = (float)($row['commission_pct'] ?? 10.0);
$min_withdraw   = (float)($row['min_withdraw_usd'] ?? 50.0);
$node_share     = 100 - $commission_pct;

$total_iq_outstanding = (float)db()->query('SELECT COALESCE(SUM(iq_earned),0) FROM nodes')->fetchColumn();
$total_usd_liability  = $total_iq_outstanding * $current;

// Pending withdrawal totals
$pending_usd = (float)db()->query(
    "SELECT COALESCE(SUM(usd_value),0) FROM withdrawals WHERE status='pending'"
)->fetchColumn();
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><title>Earnings Settings — Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{--bg:#0a0c10;--bg2:#0d1117;--bg3:#161b22;--border:#21262d;--border2:#30363d;
  --text:#e6edf3;--muted:#8b949e;--accent:#58a6ff;--green:#3fb950;--green-bd:#238636;
  --orange:#fb8c00;--orange-bg:rgba(251,140,0,.1);--purple:#8957e5;--red:#f85149}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:system-ui,sans-serif;display:flex;min-height:100vh}
.sidebar{width:220px;background:var(--bg2);border-right:1px solid var(--border);padding:1.5rem 1rem;display:flex;flex-direction:column;gap:.25rem;flex-shrink:0}
.sidebar-logo{font-weight:800;font-size:1.1rem;margin-bottom:1.5rem;padding-left:.5rem}.sidebar-logo span{color:var(--accent)}
.sidebar a{display:flex;align-items:center;gap:.6rem;padding:.55rem .75rem;border-radius:8px;color:var(--muted);text-decoration:none;font-size:.85rem;font-weight:500}
.sidebar a:hover,.sidebar a.active{background:var(--bg3);color:var(--text)}
hr.sd{border:none;border-top:1px solid var(--border);margin:.5rem 0}
.main{flex:1;padding:2rem;max-width:700px}
h1{font-size:1.35rem;font-weight:800;margin-bottom:1.5rem}
h2{font-size:.97rem;font-weight:700;margin-bottom:1rem}
.flash{padding:.75rem 1rem;border-radius:8px;font-size:.87rem;margin-bottom:1.25rem;background:rgba(88,166,255,.08);border:1px solid rgba(88,166,255,.25);color:var(--accent)}
.card{background:var(--bg3);border:1px solid var(--border2);border-radius:12px;padding:1.75rem;margin-bottom:1.5rem}
.stat-row{display:grid;grid-template-columns:repeat(auto-fill,minmax(155px,1fr));gap:1rem;margin-bottom:1.5rem}
.stat-box{background:var(--bg2);border:1px solid var(--border2);border-radius:8px;padding:1rem 1.25rem}
.stat-box .lbl{font-size:.73rem;color:var(--muted);margin-bottom:.25rem;text-transform:uppercase;letter-spacing:.04em}
.stat-box .val{font-size:1.3rem;font-weight:800}
.stat-box.hi .val{color:var(--green)}
.stat-box.warn .val{color:var(--orange)}
label{display:block;font-size:.8rem;color:var(--muted);margin:.65rem 0 .25rem}
input[type=number],input[type=text]{width:100%;padding:.55rem .75rem;border-radius:7px;border:1px solid var(--border2);background:var(--bg2);color:var(--text);font-size:.95rem}
input:focus{outline:none;border-color:var(--accent)}
.hint{font-size:.78rem;color:var(--muted);margin:.3rem 0 .5rem;line-height:1.5}
.btn{display:inline-block;padding:.55rem 1.25rem;border-radius:8px;border:none;font-size:.9rem;font-weight:700;cursor:pointer;margin-top:1rem;color:#fff}
.btn-green{background:var(--green-bd)}.btn-green:hover{background:#2ea043}
.btn-purple{background:var(--purple)}.btn-purple:hover{background:#7040c6}
.formula-box{background:var(--bg2);border:1px solid rgba(88,166,255,.2);border-radius:9px;padding:1rem 1.25rem;font-size:.83rem;color:var(--muted);margin:.75rem 0;line-height:1.8}
.formula-box strong{color:var(--text)}
.warn-box{background:rgba(251,140,0,.06);border:1px solid rgba(251,140,0,.25);border-radius:8px;padding:1rem;font-size:.83rem;color:var(--orange);margin-bottom:1rem}
.frow{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
@media(max-width:600px){.frow{grid-template-columns:1fr}}

/* ── Mobile ─────────────────────────────────────────────── */
.ham{display:none;position:fixed;top:.8rem;left:.8rem;z-index:500;
  background:var(--bg2);border:1px solid var(--border2);border-radius:8px;
  width:42px;height:42px;align-items:center;justify-content:center;
  cursor:pointer;font-size:1.25rem;color:var(--text);padding:0;
  line-height:1;box-shadow:0 2px 8px rgba(0,0,0,.3)}
.mob-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);
  z-index:399;backdrop-filter:blur(2px)}
@media(max-width:768px){
  body{display:block!important}
  .ham{display:flex!important}
  .sidebar{position:fixed!important;top:0!important;left:-240px!important;
    height:100vh!important;width:220px!important;z-index:400!important;
    transition:left .25s ease!important;overflow-y:auto!important;
    border-right:1px solid var(--border)!important}
  .sidebar.nav-open{left:0!important}
  .mob-overlay.nav-open{display:block!important}
  .main{padding:1rem!important;padding-top:3.75rem!important}
  .two-col,.form-row,.frow,.stat-row,.grid-2{grid-template-columns:1fr!important}
  .stats{grid-template-columns:repeat(2,1fr)!important}
  .card{overflow-x:auto;-webkit-overflow-scrolling:touch}
  table{min-width:540px}
  .ai-layout{flex-direction:column!important}
}
@media(max-width:480px){
  .stats{grid-template-columns:1fr 1fr!important}
}
</style></head><body>
<button class="ham" id="mobHam" onclick="mobNav()" aria-label="Menu">&#9776;</button>
<div class="mob-overlay" id="mobOv" onclick="mobClose()"></div>

<nav class="sidebar">
  <div class="sidebar-logo"><span>Chain</span>Mind</div>
  <a href="/admin/<?= $qs ?>">📊 Dashboard</a>
  <a href="/admin/users.php<?= $qs ?>">👤 Users</a>
  <a href="/admin/nodes.php<?= $qs ?>">🖥 Nodes</a>
  <a href="/admin/withdrawals.php<?= $qs ?>">💸 Withdrawals</a>
  <a href="/admin/iq-rate.php<?= $qs ?>" class="active">⚙ Earnings Settings</a>
  <a href="/admin/api-keys.php<?= $qs ?>">🔑 API Keys</a>
  <hr class="sd">
  <a href="/admin/blog.php<?= $qs ?>">📝 Blog</a>
  <a href="/">← Home</a>
  <a href="/auth/logout.php">🚪 Sign out</a>
</nav>
<div class="main">
  <h1>Earnings & Commission Settings</h1>

  <?php if ($msg): ?><div class="flash">✓ <?= htmlspecialchars($msg) ?></div><?php endif; ?>

  <!-- Stats overview -->
  <div class="stat-row">
    <div class="stat-box hi">
      <div class="lbl">IQ Rate</div>
      <div class="val">$<?= number_format($current, 6) ?></div>
    </div>
    <div class="stat-box">
      <div class="lbl">Platform Commission</div>
      <div class="val"><?= $commission_pct ?>%</div>
    </div>
    <div class="stat-box hi">
      <div class="lbl">Node Share</div>
      <div class="val"><?= $node_share ?>%</div>
    </div>
    <div class="stat-box">
      <div class="lbl">Min Withdrawal</div>
      <div class="val">$<?= number_format($min_withdraw, 2) ?></div>
    </div>
    <div class="stat-box">
      <div class="lbl">Total IQ Outstanding</div>
      <div class="val"><?= number_format($total_iq_outstanding, 2) ?></div>
    </div>
    <div class="stat-box warn">
      <div class="lbl">USD Liability</div>
      <div class="val">$<?= number_format($total_usd_liability, 2) ?></div>
    </div>
    <div class="stat-box warn">
      <div class="lbl">Pending Withdrawals</div>
      <div class="val">$<?= number_format($pending_usd, 2) ?></div>
    </div>
  </div>

  <!-- Earnings Formula Card -->
  <div class="card">
    <h2>💡 How Earnings Work</h2>
    <div class="formula-box">
      User pays <strong>1,000 credits</strong> = <strong>$1.00</strong><br>
      Platform keeps <strong><?= $commission_pct ?>% = $<?= number_format($commission_pct/100, 4) ?></strong> (your commission)<br>
      Node receives <strong><?= $node_share ?>% = $<?= number_format($node_share/100, 4) ?></strong><br>
      In IQ tokens: <strong>$<?= number_format($node_share/100, 4) ?> ÷ $<?= number_format($current, 6) ?>/IQ = <?= number_format(($node_share/100) / $current, 2) ?> IQ</strong>
    </div>
    <p class="hint">Earnings are calculated per job completion based on credits actually deducted. Webchat jobs (no API key) fall back to the legacy token-based formula.</p>
  </div>

  <!-- Commission & Withdrawal Settings -->
  <div class="card">
    <h2>Commission & Withdrawal</h2>
    <div class="warn-box">
      ⚠ Changes apply immediately to all future job completions and new withdrawal requests.
    </div>
    <form method="POST">
      <?php if ($is_secret_admin && !$is_session_admin): ?><input type="hidden" name="secret" value="<?= htmlspecialchars($_GET['secret']??'') ?>"><?php endif; ?>
      <input type="hidden" name="action" value="commission">
      <div class="frow">
        <div>
          <label>Platform Commission % (0–99)</label>
          <input type="number" name="commission_pct" step="0.1" min="0" max="99" value="<?= $commission_pct ?>">
          <div class="hint">You keep this % of every credit spend. Nodes earn the rest.</div>
        </div>
        <div>
          <label>Minimum Withdrawal (USD)</label>
          <input type="number" name="min_withdraw_usd" step="0.01" min="1" max="10000" value="<?= $min_withdraw ?>">
          <div class="hint">Nodes must have at least this much available before requesting a payout.</div>
        </div>
      </div>
      <button class="btn btn-purple" type="submit">Save Commission Settings</button>
    </form>
  </div>

  <!-- IQ Rate -->
  <div class="card">
    <h2>IQ Token Rate</h2>
    <div class="warn-box">
      ⚠ Changing the IQ rate affects how many IQ tokens nodes earn per job. Existing withdrawal requests keep their USD value locked at submission time.
    </div>
    <form method="POST">
      <?php if ($is_secret_admin && !$is_session_admin): ?><input type="hidden" name="secret" value="<?= htmlspecialchars($_GET['secret']??'') ?>"><?php endif; ?>
      <input type="hidden" name="action" value="iq_rate">
      <label>USD per 1 IQ token</label>
      <input type="number" name="usd_per_iq" step="0.000001" min="0.000001" max="100" value="<?= $current ?>">
      <div class="hint">Default: $0.01 per IQ. At this rate, earning 1,000 IQ = $10.</div>
      <button class="btn btn-green" type="submit">Update IQ Rate</button>
    </form>
  </div>
</div>
<script>
function mobNav(){var s=document.querySelector('.sidebar'),o=document.getElementById('mobOv');
  if(s){s.classList.toggle('nav-open');o.classList.toggle('nav-open');}}
function mobClose(){var s=document.querySelector('.sidebar'),o=document.getElementById('mobOv');
  if(s){s.classList.remove('nav-open');o.classList.remove('nav-open');}}
</script>
</body></html>
