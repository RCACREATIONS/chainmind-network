<?php
// ============================================================
// ChainMind — Admin Blog Manager
// Upload to: admin/blog.php
// ============================================================
session_start();
require_once __DIR__ . '/../api/_helpers.php';

$is_session_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
$is_secret_admin  = defined('ADMIN_SECRET') && ($_GET['secret'] ?? '') === ADMIN_SECRET;
if (!$is_session_admin && !$is_secret_admin) {
    header('Location: /auth/login.php?next=/admin/blog.php'); exit;
}
$qs = $is_secret_admin && !$is_session_admin ? '?secret=' . urlencode($_GET['secret']) : '';

$db = db();

// ── Ensure blog_posts table exists ────────────────────────
$db->exec("CREATE TABLE IF NOT EXISTS blog_posts (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(255) NOT NULL,
    slug        VARCHAR(255) NOT NULL UNIQUE,
    excerpt     TEXT,
    content     LONGTEXT NOT NULL,
    status      ENUM('draft','published') NOT NULL DEFAULT 'draft',
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── Handle POST actions ────────────────────────────────────
$flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id      = (int)($_POST['post_id'] ?? 0);
        $title   = trim($_POST['title'] ?? '');
        $slug    = trim($_POST['slug'] ?? '');
        $excerpt = trim($_POST['excerpt'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $status  = $_POST['status'] === 'published' ? 'published' : 'draft';

        if (!$title || !$slug || !$content) {
            $flash = 'error:Title, slug and content are required.';
        } else {
            // Sanitize slug
            $slug = strtolower(preg_replace('/[^a-z0-9-]/', '', str_replace(' ', '-', $slug)));
            try {
                if ($id > 0) {
                    $st = $db->prepare("UPDATE blog_posts SET title=?,slug=?,excerpt=?,content=?,status=? WHERE id=?");
                    $st->execute([$title,$slug,$excerpt,$content,$status,$id]);
                    $flash = 'success:Post updated successfully.';
                } else {
                    $st = $db->prepare("INSERT INTO blog_posts (title,slug,excerpt,content,status) VALUES (?,?,?,?,?)");
                    $st->execute([$title,$slug,$excerpt,$content,$status]);
                    $flash = 'success:Post created successfully.';
                }
            } catch (PDOException $e) {
                $flash = 'error:Slug already exists. Please use a unique slug.';
            }
        }
    }

    if ($action === 'delete') {
        $id = (int)($_POST['post_id'] ?? 0);
        if ($id > 0) {
            $db->prepare("DELETE FROM blog_posts WHERE id=?")->execute([$id]);
            $flash = 'success:Post deleted.';
        }
    }

    if ($action === 'toggle_status') {
        $id = (int)($_POST['post_id'] ?? 0);
        if ($id > 0) {
            $db->prepare("UPDATE blog_posts SET status = IF(status='published','draft','published') WHERE id=?")->execute([$id]);
            $flash = 'success:Status updated.';
        }
    }
}

// ── Load posts ─────────────────────────────────────────────
$posts = $db->query("SELECT id,title,slug,status,created_at FROM blog_posts ORDER BY created_at DESC")->fetchAll();

// ── Edit mode ──────────────────────────────────────────────
$edit_post = null;
if (isset($_GET['edit'])) {
    $edit_post = $db->prepare("SELECT * FROM blog_posts WHERE id=?")->execute([(int)$_GET['edit']]) ? null : null;
    $st = $db->prepare("SELECT * FROM blog_posts WHERE id=?");
    $st->execute([(int)$_GET['edit']]);
    $edit_post = $st->fetch() ?: null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><title>Blog Manager — ChainMind Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{--bg:#0a0c10;--bg2:#0d1117;--bg3:#161b22;--border:#21262d;--border2:#30363d;
  --text:#e6edf3;--text2:#c9d1d9;--muted:#8b949e;--accent:#58a6ff;--green:#3fb950;
  --green-bg:#1c2a1e;--green-bd:#238636;--red:#f85149;--orange:#ffa657;
  --purple:#a371f7;--purple-bg:rgba(163,113,247,.1);--purple-bd:rgba(163,113,247,.3)}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:system-ui,sans-serif;display:flex;min-height:100vh}
.sidebar{width:220px;background:var(--bg2);border-right:1px solid var(--border);
  padding:1.5rem 1rem;display:flex;flex-direction:column;gap:.25rem;flex-shrink:0;min-height:100vh}
.sidebar-logo{font-weight:800;font-size:1.1rem;margin-bottom:1.5rem;padding-left:.5rem}
.sidebar-logo span{color:var(--accent)}
.sidebar a{display:flex;align-items:center;gap:.6rem;padding:.55rem .75rem;border-radius:8px;
  color:var(--muted);text-decoration:none;font-size:.85rem;font-weight:500}
.sidebar a:hover,.sidebar a.active{background:var(--bg3);color:var(--text)}
.sidebar-divider{border:none;border-top:1px solid var(--border);margin:.5rem 0}
.sidebar-section{font-size:.72rem;font-weight:700;letter-spacing:.08em;color:var(--muted);
  text-transform:uppercase;padding:.5rem .75rem;margin-top:.25rem}
.main{flex:1;padding:2rem;overflow-x:hidden;max-width:calc(100vw - 220px)}
.page-header{margin-bottom:1.75rem}
.page-header h1{font-size:1.35rem;font-weight:800;margin-bottom:.25rem}
.page-header p{color:var(--muted);font-size:.85rem}
.card{background:var(--bg3);border:1px solid var(--border2);border-radius:12px;margin-bottom:1.5rem}
.card-header{padding:1rem 1.25rem;border-bottom:1px solid var(--border2);display:flex;
  align-items:center;justify-content:space-between;gap:.75rem}
.card-header h2{font-size:.95rem;font-weight:700}
.card-body{padding:1.25rem}
label{display:block;font-size:.8rem;color:var(--muted);margin-bottom:.4rem;font-weight:600;
  letter-spacing:.03em;text-transform:uppercase}
input[type=text],select,textarea{width:100%;background:var(--bg2);border:1px solid var(--border2);
  border-radius:8px;color:var(--text);font-family:inherit;font-size:.875rem;padding:.6rem .85rem;
  outline:none;transition:border .15s}
input[type=text]:focus,select:focus,textarea:focus{border-color:var(--accent)}
textarea{resize:vertical;line-height:1.6}
.form-group{margin-bottom:1.1rem}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
.affiliate-link-row{display:grid;grid-template-columns:1fr 1fr auto;gap:.5rem;margin-bottom:.5rem}
.affiliate-link-row input{margin-bottom:0}
.affiliate-link-row button{padding:0 .6rem}
.btn{display:inline-flex;align-items:center;gap:.4rem;padding:.5rem 1rem;border-radius:8px;
  font-size:.85rem;font-weight:600;cursor:pointer;border:none;font-family:inherit;transition:all .15s;text-decoration:none}
.btn-primary{background:var(--accent);color:#0d1117}
.btn-primary:hover{filter:brightness(1.1)}
.btn-ghost{background:var(--bg2);color:var(--text);border:1px solid var(--border2)}
.btn-ghost:hover{border-color:var(--accent);color:var(--accent)}
.btn-danger{background:rgba(248,81,73,.15);color:var(--red);border:1px solid rgba(248,81,73,.3)}
.btn-danger:hover{background:rgba(248,81,73,.25)}
.btn-sm{padding:.3rem .7rem;font-size:.78rem}
.btn-purple{background:var(--purple-bg);color:var(--purple);border:1px solid var(--purple-bd)}
.btn-purple:hover{background:rgba(163,113,247,.2)}
.badge{display:inline-block;padding:.1rem .45rem;border-radius:20px;font-size:.7rem;font-weight:700}
.b-published{background:var(--green-bd);color:#fff}
.b-draft{background:var(--border2);color:var(--muted)}
table{width:100%;border-collapse:collapse;font-size:.82rem}
th{text-align:left;padding:.5rem .9rem;color:var(--muted);border-bottom:1px solid var(--border);white-space:nowrap}
td{padding:.55rem .9rem;border-bottom:1px solid var(--border);vertical-align:middle}
tr:last-child td{border-bottom:none}
.flash{padding:.75rem 1.1rem;border-radius:8px;margin-bottom:1.25rem;font-size:.875rem;font-weight:500}
.flash-success{background:var(--green-bg);border:1px solid var(--green-bd);color:var(--green)}
.flash-error{background:rgba(248,81,73,.1);border:1px solid rgba(248,81,73,.3);color:var(--red)}
.two-col{display:grid;grid-template-columns:1fr 340px;gap:1.5rem;align-items:start}
.ai-panel{background:var(--purple-bg);border:1px solid var(--purple-bd);border-radius:12px;padding:1.25rem}
.ai-panel h3{font-size:.9rem;font-weight:700;color:var(--purple);margin-bottom:1rem;display:flex;align-items:center;gap:.4rem}
.ai-spinner{display:none;width:16px;height:16px;border:2px solid var(--purple-bd);
  border-top-color:var(--purple);border-radius:50%;animation:spin .7s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.ai-status{font-size:.78rem;color:var(--muted);margin-top:.6rem;min-height:1.2em}
#content-textarea{min-height:320px;font-family:system-ui,sans-serif;font-size:.85rem}
.tab-bar{display:flex;gap:.35rem;border-bottom:1px solid var(--border2);margin-bottom:1.25rem}
.tab{background:none;border:none;border-bottom:2px solid transparent;padding:.5rem .85rem;
  font-family:inherit;font-size:.85rem;font-weight:600;color:var(--muted);cursor:pointer;
  transition:all .15s;margin-bottom:-1px}
.tab.active{color:var(--accent);border-bottom-color:var(--accent)}
.tab-panel{display:none}.tab-panel.active{display:block}
.empty{text-align:center;padding:2.5rem;color:var(--muted);font-size:.875rem}
@media(max-width:900px){.two-col{grid-template-columns:1fr}.form-row{grid-template-columns:1fr}}
</style>
</head>
<body>

<nav class="sidebar">
  <div class="sidebar-logo"><span>Chain</span>Mind</div>
  <div class="sidebar-section">Overview</div>
  <a href="/admin/<?= $qs ?>">⬛ Dashboard</a>
  <a href="/admin/users.php<?= $qs ?>">👥 Users</a>
  <a href="/admin/nodes.php<?= $qs ?>">🖥 Nodes</a>
  <a href="/admin/withdrawals.php<?= $qs ?>">💸 Withdrawals</a>
  <a href="/admin/iq-rate.php<?= $qs ?>">⚡ IQ Rate</a>
  <hr class="sidebar-divider">
  <div class="sidebar-section">Communications</div>
  <a href="/admin/email-broadcast.php<?= $qs ?>">✉ Email Broadcast</a>
  <a href="/admin/blog.php<?= $qs ?>" class="active">📝 Blog</a>
  <hr class="sidebar-divider">
  <div class="sidebar-section">Platform</div>
  <a href="/">🌐 Landing page</a>
</nav>

<main class="main">
  <div class="page-header">
    <h1>📝 Blog Manager</h1>
    <p>Create and manage blog posts. Use AI to generate long-form content instantly.</p>
  </div>

  <?php if ($flash): [$type,$msg] = explode(':', $flash, 2); ?>
  <div class="flash flash-<?= $type === 'success' ? 'success' : 'error' ?>"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <div class="tab-bar">
    <button class="tab <?= !$edit_post ? 'active' : '' ?>" onclick="switchTab('list')">All Posts</button>
    <button class="tab <?= $edit_post ? 'active' : '' ?>" id="tab-editor" onclick="switchTab('editor')"><?= $edit_post ? 'Edit Post' : '+ New Post' ?></button>
  </div>

  <!-- POSTS LIST -->
  <div class="tab-panel <?= !$edit_post ? 'active' : '' ?>" id="panel-list">
    <div class="card">
      <div class="card-header">
        <h2>All Blog Posts (<?= count($posts) ?>)</h2>
        <button class="btn btn-primary btn-sm" onclick="switchTab('editor')">+ New Post</button>
      </div>
      <?php if (empty($posts)): ?>
        <div class="empty">No posts yet. Create your first one →</div>
      <?php else: ?>
      <table>
        <thead><tr><th>Title</th><th>Slug</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach ($posts as $p): ?>
          <tr>
            <td><?= htmlspecialchars($p['title']) ?></td>
            <td style="color:var(--muted);font-size:.78rem">/blog/<?= htmlspecialchars($p['slug']) ?></td>
            <td><span class="badge b-<?= $p['status'] ?>"><?= $p['status'] ?></span></td>
            <td style="color:var(--muted);font-size:.78rem"><?= date('M j, Y', strtotime($p['created_at'])) ?></td>
            <td>
              <div style="display:flex;gap:.4rem;flex-wrap:wrap">
                <a href="/admin/blog.php<?= $qs ? $qs.'&' : '?' ?>edit=<?= $p['id'] ?>" class="btn btn-ghost btn-sm">Edit</a>
                <a href="/blog/<?= htmlspecialchars($p['slug']) ?>" target="_blank" class="btn btn-ghost btn-sm">View</a>
                <form method="POST" style="display:inline">
                  <input type="hidden" name="action" value="toggle_status">
                  <input type="hidden" name="post_id" value="<?= $p['id'] ?>">
                  <?php if ($qs): ?><input type="hidden" name="secret" value="<?= htmlspecialchars($_GET['secret'] ?? '') ?>"><?php endif; ?>
                  <button class="btn btn-ghost btn-sm" type="submit"><?= $p['status'] === 'published' ? 'Unpublish' : 'Publish' ?></button>
                </form>
                <form method="POST" style="display:inline" onsubmit="return confirm('Delete this post?')">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="post_id" value="<?= $p['id'] ?>">
                  <?php if ($qs): ?><input type="hidden" name="secret" value="<?= htmlspecialchars($_GET['secret'] ?? '') ?>"><?php endif; ?>
                  <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>
  </div>

  <!-- EDITOR -->
  <div class="tab-panel <?= $edit_post ? 'active' : '' ?>" id="panel-editor">
    <div class="two-col">
      <!-- LEFT: Post Form -->
      <div>
        <form method="POST" id="postForm">
          <input type="hidden" name="action" value="save">
          <input type="hidden" name="post_id" value="<?= $edit_post['id'] ?? 0 ?>">
          <?php if ($qs): ?><input type="hidden" name="secret" value="<?= htmlspecialchars($_GET['secret'] ?? '') ?>"><?php endif; ?>

          <div class="card">
            <div class="card-header"><h2><?= $edit_post ? 'Edit Post' : 'New Post' ?></h2></div>
            <div class="card-body">
              <div class="form-group">
                <label>Title</label>
                <input type="text" name="title" id="f-title" placeholder="e.g. Why Nigerian Developers Are Choosing ChainMind" required
                  value="<?= htmlspecialchars($edit_post['title'] ?? '') ?>">
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label>Slug</label>
                  <input type="text" name="slug" id="f-slug" placeholder="why-nigerian-devs-choose-chainmind" required
                    value="<?= htmlspecialchars($edit_post['slug'] ?? '') ?>">
                </div>
                <div class="form-group">
                  <label>Status</label>
                  <select name="status" id="f-status">
                    <option value="draft" <?= ($edit_post['status'] ?? 'draft') === 'draft' ? 'selected' : '' ?>>Draft</option>
                    <option value="published" <?= ($edit_post['status'] ?? '') === 'published' ? 'selected' : '' ?>>Published</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label>Excerpt (SEO meta description)</label>
                <input type="text" name="excerpt" id="f-excerpt" placeholder="Short summary shown in Google results..."
                  value="<?= htmlspecialchars($edit_post['excerpt'] ?? '') ?>">
              </div>
              <div class="form-group">
                <label>Content (HTML)</label>
                <textarea name="content" id="content-textarea" rows="20" required><?= htmlspecialchars($edit_post['content'] ?? '') ?></textarea>
              </div>
              <div style="display:flex;gap:.75rem;flex-wrap:wrap">
                <button type="submit" class="btn btn-primary">💾 Save Post</button>
                <button type="button" class="btn btn-ghost" onclick="document.getElementById('f-status').value='published';document.getElementById('postForm').submit()">🚀 Save & Publish</button>
                <a href="/admin/blog.php<?= $qs ?>" class="btn btn-ghost">← Back to list</a>
              </div>
            </div>
          </div>
        </form>
      </div>

      <!-- RIGHT: AI Generator -->
      <div>
        <div class="ai-panel">
          <h3>✨ AI Blog Generator</h3>
          <div class="form-group">
            <label>Topic / Prompt</label>
            <textarea id="ai-prompt" rows="4" placeholder="e.g. Why Nigerian developers should stop paying dollar fees for AI APIs and switch to ChainMind's Naira-priced inference network"></textarea>
          </div>
          <div class="form-row" style="margin-bottom:1rem">
            <div>
              <label>Tone</label>
              <select id="ai-tone">
                <option value="technical">Technical (devs)</option>
                <option value="beginner">Beginner-friendly</option>
                <option value="professional">Professional</option>
                <option value="exciting">Exciting / hype</option>
              </select>
            </div>
            <div>
              <label>Length</label>
              <select id="ai-length">
                <option value="long" selected>Long (~1500-2000w)</option>
                <option value="medium">Medium (~1000w)</option>
                <option value="short">Short (~500w)</option>
              </select>
            </div>
          </div>

          <div class="form-group">
            <label>Featured image URL <span style="opacity:.6;font-weight:400">(optional)</span></label>
            <input type="text" id="ai-image-url" placeholder="https://example.com/image.jpg">
          </div>

          <div class="form-group">
            <label>YouTube video URL <span style="opacity:.6;font-weight:400">(optional)</span></label>
            <input type="text" id="ai-youtube-url" placeholder="https://youtube.com/watch?v=...">
          </div>

          <div class="form-group">
            <label>Affiliate links <span style="opacity:.6;font-weight:400">(optional — woven naturally into the post)</span></label>
            <div id="affiliate-links-list"></div>
            <button type="button" class="btn btn-ghost btn-sm" onclick="addAffiliateLinkRow()" style="margin-top:.4rem">+ Add link</button>
            <div style="font-size:.72rem;opacity:.55;margin-top:.4rem">Note: on the free Groq tier, adding more links shortens how long the generated post can be (shared token budget).</div>
          </div>
          <button class="btn btn-purple" onclick="generateBlog()" style="width:100%">
            <span id="ai-btn-text">✨ Generate Blog Post</span>
            <div class="ai-spinner" id="ai-spinner"></div>
          </button>
          <div class="ai-status" id="ai-status"></div>
        </div>

        <div class="card" style="margin-top:1rem">
          <div class="card-header"><h2 style="font-size:.82rem">💡 Blog Ideas</h2></div>
          <div class="card-body" style="display:flex;flex-direction:column;gap:.5rem">
            <?php $ideas = [
              'How to access GPT-4 level AI in Nigeria without spending dollars',
              'What is a DePIN and why ChainMind is building one for Africa',
              'How to run an AI node on your laptop and earn IQ tokens',
              'OpenAI vs ChainMind: a Nigerian developer\'s honest comparison',
              'Building AI-powered apps in Nigeria with a Naira budget',
              'The future of decentralized AI compute in Africa',
            ]; foreach ($ideas as $idea): ?>
            <button class="btn btn-ghost btn-sm" style="text-align:left;white-space:normal;height:auto;padding:.4rem .7rem"
              onclick="document.getElementById('ai-prompt').value=<?= json_encode($idea) ?>">
              <?= htmlspecialchars($idea) ?>
            </button>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<script>
function switchTab(tab) {
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.getElementById('panel-' + tab).classList.add('active');
  const tabs = document.querySelectorAll('.tab');
  if (tab === 'list') tabs[0].classList.add('active');
  else tabs[1].classList.add('active');
}

// Auto-generate slug from title
document.getElementById('f-title')?.addEventListener('input', function() {
  const slug = this.value.toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim().replace(/\s+/g, '-').replace(/-+/g, '-');
  if (!document.getElementById('f-slug').dataset.manual) {
    document.getElementById('f-slug').value = slug;
  }
});
document.getElementById('f-slug')?.addEventListener('input', function() {
  this.dataset.manual = '1';
});

// ---- Affiliate link rows ----
let affiliateLinkCount = 0;

function addAffiliateLinkRow(url = '', anchor = '') {
  const list = document.getElementById('affiliate-links-list');
  const id = affiliateLinkCount++;
  const row = document.createElement('div');
  row.className = 'affiliate-link-row';
  row.id = 'aff-row-' + id;
  row.innerHTML = `
    <input type="text" placeholder="https://example.com/product" value="${url.replace(/"/g, '&quot;')}" class="aff-url">
    <input type="text" placeholder="Anchor text (e.g. 'this hosting plan')" value="${anchor.replace(/"/g, '&quot;')}" class="aff-anchor">
    <button type="button" class="btn btn-ghost btn-sm" onclick="document.getElementById('aff-row-${id}').remove()">✕</button>
  `;
  list.appendChild(row);
}

function getAffiliateLinks() {
  const rows = document.querySelectorAll('#affiliate-links-list .affiliate-link-row');
  const links = [];
  rows.forEach(row => {
    const url = row.querySelector('.aff-url').value.trim();
    const anchor = row.querySelector('.aff-anchor').value.trim();
    if (url) links.push({ url, anchor });
  });
  return links;
}

async function generateBlog() {
  const prompt = document.getElementById('ai-prompt').value.trim();
  if (!prompt) { alert('Please enter a topic or prompt first.'); return; }

  const btn = document.getElementById('ai-btn-text');
  const spinner = document.getElementById('ai-spinner');
  const status = document.getElementById('ai-status');

  btn.textContent = 'Generating…';
  spinner.style.display = 'block';
  status.textContent = 'Sending to Groq (gpt-oss-120b) — long posts can take 30-60 seconds…';

  const secret = new URLSearchParams(window.location.search).get('secret') || '';
  const url = '/admin/api/ai-blog.php' + (secret ? '?secret=' + encodeURIComponent(secret) : '');

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt,
        tone:            document.getElementById('ai-tone').value,
        length:          document.getElementById('ai-length').value,
        image_url:       document.getElementById('ai-image-url').value.trim(),
        youtube_url:     document.getElementById('ai-youtube-url').value.trim(),
        affiliate_links: getAffiliateLinks(),
      })
    });
    const data = await res.json();

    if (!res.ok || data.error) {
      status.textContent = '⚠ Error: ' + (data.error || 'Unknown error');
    } else {
      // Fill editor fields
      if (data.title)   { document.getElementById('f-title').value   = data.title; }
      if (data.slug)    { document.getElementById('f-slug').value    = data.slug; document.getElementById('f-slug').dataset.manual = '1'; }
      if (data.excerpt) { document.getElementById('f-excerpt').value = data.excerpt; }
      if (data.content) { document.getElementById('content-textarea').value = data.content; }
      status.textContent = '✅ Content generated! Review and edit before saving.';
      // Switch to editor if on list tab
      switchTab('editor');
      // Scroll to form
      document.getElementById('f-title').scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  } catch (e) {
    status.textContent = '⚠ Network error: ' + e.message;
  } finally {
    btn.textContent = '✨ Generate Blog Post';
    spinner.style.display = 'none';
  }
}
</script>
</body>
</html>