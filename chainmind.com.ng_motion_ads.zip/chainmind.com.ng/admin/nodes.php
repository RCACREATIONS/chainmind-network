<?php
session_start(); 
require_once __DIR__ . '/../api/_helpers.php';
$is_session_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
$is_secret_admin  = defined('ADMIN_SECRET') && ($_GET['secret'] ?? '') === ADMIN_SECRET;
if (!$is_session_admin && !$is_secret_admin) { header('Location: /auth/login.php?next=/admin/nodes.php'); exit; }
$qs = $is_secret_admin && !$is_session_admin ? '?secret=' . urlencode($_GET['secret']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nid    = trim($_POST['node_id'] ?? '');
    $action = $_POST['action'] ?? '';
    $tier   = $_POST['tier'] ?? '';
    if ($nid) {
        if ($action === 'set_tier' && in_array($tier, ['standard','premium','elite']))
            db()->prepare('UPDATE nodes SET tier = ? WHERE id = ?')->execute([$tier, $nid]);
        if ($action === 'kick')
            db()->prepare("UPDATE nodes SET status = 'offline' WHERE id = ?")->execute([$nid]);
    }
    header('Location: /admin/nodes.php' . $qs); exit;
}

$nodes = db()->query(
    'SELECT n.*,
            TIMESTAMPDIFF(MINUTE, n.last_seen, NOW()) AS idle_min,
            (SELECT COALESCE(SUM(iq_amount),0) FROM withdrawals w WHERE w.node_id=n.id AND w.status!="rejected") AS committed_iq
     FROM nodes n ORDER BY n.status DESC, n.last_seen DESC'
)->fetchAll();

// ALL nodes with a lat/lng — both online AND offline
$map_nodes = array_values(array_filter($nodes, fn($n) =>
    $n['lat'] !== null && $n['lng'] !== null && $n['lat'] != 0 && $n['lng'] != 0
));
$map_json = json_encode(array_map(fn($n) => [
    'id'        => $n['id'],
    'name'      => $n['name'] ?? 'Unnamed',
    'lat'       => (float)$n['lat'],
    'lng'       => (float)$n['lng'],
    'city'      => $n['city']    ?? '',
    'country'   => $n['country'] ?? '',
    'tier'      => $n['tier']    ?? 'nano',
    'status'    => $n['status']  ?? 'offline',
    'jobs'      => (int)($n['jobs_done']  ?? 0),
    'iq'        => (float)($n['iq_earned'] ?? 0),
    // Defensive: only present in the payload if the column exists on the
    // nodes table (n['*'] pulls everything, we just weren't reading these
    // out before). Used client-side to cross-check that lat/lng plausibly
    // matches the reported city/country/IP — not a guarantee of accuracy,
    // just a way to flag obvious mismatches.
    'ip'        => $n['ip_address']      ?? $n['ip'] ?? null,
    'geo_src'   => $n['geo_source']       ?? $n['geolocation_source'] ?? null,
    'geo_acc'   => $n['accuracy_radius']  ?? $n['geo_accuracy'] ?? null,
    'geo_at'    => $n['geo_updated_at']   ?? $n['location_updated_at'] ?? null,
], $map_nodes), JSON_UNESCAPED_UNICODE);

$mapped_online  = count(array_filter($map_nodes, fn($n) => $n['status'] === 'online'));
$mapped_offline = count($map_nodes) - $mapped_online;
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><title>Nodes — Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
:root{--bg:#0a0c10;--bg2:#0d1117;--bg3:#161b22;--border:#21262d;--border2:#30363d;
  --text:#e6edf3;--muted:#8b949e;--accent:#58a6ff;--green:#3fb950;--green-bd:#238636}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:system-ui,sans-serif;display:flex;min-height:100vh}
.sidebar{width:220px;background:var(--bg2);border-right:1px solid var(--border);padding:1.5rem 1rem;display:flex;flex-direction:column;gap:.25rem;flex-shrink:0}
.sidebar-logo{font-weight:800;font-size:1.1rem;margin-bottom:1.5rem;padding-left:.5rem}.sidebar-logo span{color:var(--accent)}
.sidebar a{display:flex;align-items:center;gap:.6rem;padding:.55rem .75rem;border-radius:8px;color:var(--muted);text-decoration:none;font-size:.85rem;font-weight:500}
.sidebar a:hover,.sidebar a.active{background:var(--bg3);color:var(--text)}
hr.sd{border:none;border-top:1px solid var(--border);margin:.5rem 0}
.main{flex:1;padding:2rem;overflow-x:auto}
h1{font-size:1.35rem;font-weight:800;margin-bottom:1.5rem}
.stats{display:flex;gap:1rem;margin-bottom:1.5rem;flex-wrap:wrap}
.stat{background:var(--bg3);border:1px solid var(--border2);border-radius:10px;padding:1rem 1.25rem;min-width:130px}
.stat .lbl{font-size:.75rem;color:var(--muted);margin-bottom:.25rem}.stat .val{font-size:1.4rem;font-weight:800}

/* Map */
.map-card{background:var(--bg3);border:1px solid var(--border2);border-radius:12px;overflow:hidden;margin-bottom:1.5rem}
.map-header{display:flex;align-items:center;justify-content:space-between;padding:.75rem 1rem;border-bottom:1px solid var(--border);flex-wrap:wrap;gap:.5rem}
.map-header h2{font-size:.9rem;font-weight:700;margin:0}
.map-legend{display:flex;gap:.75rem;font-size:.72rem;color:var(--muted);align-items:center;flex-wrap:wrap}
.map-legend span{display:inline-flex;align-items:center;gap:.3rem}
.map-toggle{background:var(--bg2);border:1px solid var(--border2);color:var(--text);border-radius:6px;padding:.3rem .6rem;font-size:.72rem;font-weight:600;cursor:pointer;margin-left:.25rem}
.map-toggle:hover{background:var(--bg3);border-color:var(--accent)}
.map-toggle.active{background:var(--accent);border-color:var(--accent);color:#0a0c10}
.dot{width:9px;height:9px;border-radius:50%;display:inline-block}
#node-map{height:420px;background:#0d1117}

/* Force dark map background while tiles load */
.leaflet-container{background:#0d1117 !important}

/* CARTO dark tiles are already dark + English-labeled, no invert filter needed */

/* Node floating label */
.node-lbl{
  background:rgba(13,17,23,.93);
  border:1px solid #30363d;
  border-radius:7px;
  padding:4px 9px;
  font-size:.71rem;
  font-family:system-ui,sans-serif;
  color:#e6edf3;
  white-space:nowrap;
  line-height:1.45;
  box-shadow:0 2px 8px rgba(0,0,0,.5);
}
.node-lbl b{display:block;font-size:.75rem}
.node-lbl small{font-size:.65rem}
.s-online{color:#3fb950}.s-offline{color:#6e7681}.s-busy{color:#79c0ff}

/* Cluster bubble */
.node-cluster{
  background:rgba(33,38,45,.95);
  border:2px solid #58a6ff;
  border-radius:50%;
  color:#e6edf3;
  font-weight:700;
  font-size:.85rem;
  display:flex;
  align-items:center;
  justify-content:center;
  box-shadow:0 2px 10px rgba(0,0,0,.55);
}
.node-cluster.mixed{border-color:#8b949e}
.node-cluster.all-offline{border-color:#484f58;color:#8b949e}

/* Popup */
.leaflet-popup-content-wrapper{background:#161b22!important;border:1px solid #30363d!important;border-radius:10px!important;color:#e6edf3!important;box-shadow:0 6px 24px rgba(0,0,0,.6)!important}
.leaflet-popup-tip{background:#161b22!important}
.leaflet-popup-content{margin:12px 16px!important;font-size:.8rem;line-height:1.65;min-width:180px}
.p-name{font-weight:700;font-size:.92rem;margin-bottom:5px}
.p-badge{display:inline-block;padding:.12rem .45rem;border-radius:10px;font-size:.67rem;font-weight:700;margin-bottom:7px}
.t-nano{background:#0d2211;color:#3fb950}.t-micro{background:#0d1a1a;color:#56d364}
.t-standard{background:#21262d;color:#8b949e}.t-pro{background:#0d1b35;color:#79c0ff}
.t-premium{background:#1f4b8e;color:#79c0ff}.t-elite{background:#3d1e6e;color:#d2a8ff}
.t-enterprise{background:#3d1212;color:#f78166}
.p-row{display:flex;gap:.4rem;color:#8b949e;font-size:.76rem;margin-bottom:1px}
.p-row strong{color:#e6edf3}

/* Table */
.card{background:var(--bg3);border:1px solid var(--border2);border-radius:12px}
table{width:100%;border-collapse:collapse;font-size:.82rem}
th{text-align:left;padding:.5rem .9rem;color:var(--muted);border-bottom:1px solid var(--border);white-space:nowrap}
td{padding:.5rem .9rem;border-bottom:1px solid var(--border);vertical-align:middle}
tr:last-child td{border-bottom:none}
.badge{display:inline-block;padding:.1rem .4rem;border-radius:20px;font-size:.7rem;font-weight:700;white-space:nowrap}
.b-online{background:var(--green-bd);color:#fff}.b-offline{background:var(--border2);color:var(--muted)}.b-busy{background:#1f6feb;color:#fff}
.muted{color:var(--muted);font-size:.78rem}
select.act{background:var(--bg2);border:1px solid var(--border2);color:var(--text);border-radius:5px;padding:.2rem .3rem;font-size:.78rem;cursor:pointer}
button.kick{background:#da3633;border:none;color:#fff;border-radius:5px;padding:.2rem .5rem;font-size:.78rem;cursor:pointer}
.ticker{font-size:.72rem;color:var(--muted)}

/* Mobile */
.ham{display:none;position:fixed;top:.8rem;left:.8rem;z-index:500;background:var(--bg2);border:1px solid var(--border2);border-radius:8px;width:42px;height:42px;align-items:center;justify-content:center;cursor:pointer;font-size:1.25rem;color:var(--text);padding:0;line-height:1;box-shadow:0 2px 8px rgba(0,0,0,.3)}
.mob-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:399;backdrop-filter:blur(2px)}
@media(max-width:768px){
  body{display:block!important}.ham{display:flex!important}
  .sidebar{position:fixed!important;top:0!important;left:-240px!important;height:100vh!important;width:220px!important;z-index:400!important;transition:left .25s ease!important;overflow-y:auto!important}
  .sidebar.nav-open{left:0!important}.mob-overlay.nav-open{display:block!important}
  .main{padding:1rem!important;padding-top:3.75rem!important}
  .stats{flex-wrap:wrap}#node-map{height:260px}
  .map-card,.card{overflow-x:auto}.table{min-width:540px}
}
</style></head><body>

<button class="ham" onclick="mobNav()">&#9776;</button>
<div class="mob-overlay" id="mobOv" onclick="mobClose()"></div>

<nav class="sidebar">
  <div class="sidebar-logo"><span>Chain</span>Mind</div>
  <a href="/admin/<?= $qs ?>">📊 Dashboard</a>
  <a href="/admin/users.php<?= $qs ?>">👤 Users</a>
  <a href="/admin/nodes.php<?= $qs ?>" class="active">🖥 Nodes</a>
  <a href="/admin/withdrawals.php<?= $qs ?>">💸 Withdrawals</a>
  <a href="/admin/iq-rate.php<?= $qs ?>">⚙ IQ Rate</a>
  <hr class="sd">
  <a href="/admin/blog.php<?= $qs ?>">📝 Blog</a>
  <a href="/">← Landing</a>
  <a href="/auth/logout.php">🚪 Sign out</a>
</nav>

<div class="main">
  <h1>Node Network</h1>
  <?php
  $online     = count(array_filter($nodes, fn($n) => $n['status'] === 'online'));
  $total_iq   = array_sum(array_column($nodes, 'iq_earned'));
  $total_jobs = array_sum(array_column($nodes, 'jobs_done'));
  ?>
  <div class="stats">
    <div class="stat"><div class="lbl">Online</div><div class="val" style="color:var(--green)"><?= $online ?></div></div>
    <div class="stat"><div class="lbl">Total nodes</div><div class="val"><?= count($nodes) ?></div></div>
    <div class="stat"><div class="lbl">Total IQ earned</div><div class="val"><?= number_format($total_iq,2) ?></div></div>
    <div class="stat"><div class="lbl">Total jobs done</div><div class="val"><?= number_format($total_jobs) ?></div></div>
  </div>

  <!-- Live Map -->
  <div class="map-card">
    <div class="map-header">
      <h2>🌍 Live Node Map</h2>
      <div class="map-legend">
        <span><span class="dot" style="background:#3fb950"></span>Online (<?= $mapped_online ?>)</span>
        <span><span class="dot" style="background:#484f58"></span>Offline (<?= $mapped_offline ?>)</span>
        <span><span class="dot" style="background:#79c0ff"></span>Premium</span>
        <span><span class="dot" style="background:#d2a8ff"></span>Elite</span>
        <button id="mapViewToggle" class="map-toggle" type="button" onclick="toggleMapView()">🛰 Satellite</button>
      </div>
    </div>
    <div id="node-map"></div>
  </div>

  <!-- Table -->
  <div class="card">
    <table>
      <thead><tr><th>Node / ID</th><th>Tier</th><th>Status</th><th>Jobs</th><th>IQ earned</th><th>IQ available</th><th>Rep</th><th>Last seen</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($nodes as $n):
        $avail = max(0, (float)$n['iq_earned'] - (float)$n['committed_iq']);
      ?>
      <tr>
        <td>
          <div style="font-weight:600"><?= htmlspecialchars($n['name'] ?? 'Unnamed') ?></div>
          <div class="muted ticker"><?= $n['id'] ?></div>
        </td>
        <td>
          <form method="POST" style="display:inline-flex;gap:.25rem;align-items:center">
            <?php if ($is_secret_admin && !$is_session_admin): ?><input type="hidden" name="secret" value="<?= htmlspecialchars($_GET['secret']??'') ?>"><?php endif; ?>
            <input type="hidden" name="node_id" value="<?= htmlspecialchars($n['id']) ?>">
            <input type="hidden" name="action" value="set_tier">
            <select class="act" name="tier" onchange="this.form.submit()">
              <?php foreach (['standard','premium','elite'] as $t): ?>
                <option value="<?= $t ?>" <?= $n['tier']===$t?'selected':'' ?>><?= ucfirst($t) ?></option>
              <?php endforeach; ?>
            </select>
          </form>
        </td>
        <td><span class="badge b-<?= $n['status'] ?>"><?= $n['status'] ?></span></td>
        <td><?= number_format($n['jobs_done']) ?></td>
        <td><?= number_format($n['iq_earned'],4) ?></td>
        <td><?= number_format($avail,4) ?></td>
        <td><?= number_format($n['reputation'],1) ?></td>
        <td class="muted"><?= $n['last_seen'] ? $n['idle_min'].'m ago' : 'Never' ?></td>
        <td>
          <?php if ($n['status']==='online'): ?>
          <form method="POST" style="display:inline">
            <?php if ($is_secret_admin && !$is_session_admin): ?><input type="hidden" name="secret" value="<?= htmlspecialchars($_GET['secret']??'') ?>"><?php endif; ?>
            <input type="hidden" name="node_id" value="<?= htmlspecialchars($n['id']) ?>">
            <input type="hidden" name="action" value="kick">
            <button class="kick" type="submit" onclick="return confirm('Force offline?')">Kick offline</button>
          </form>
          <?php else: ?>
          <a href="/dashboard/node-earnings.php?node_id=<?= urlencode($n['id']) ?>&secret=<?= defined('NODE_SECRET')?urlencode(NODE_SECRET):'' ?>"
             style="font-size:.78rem;color:var(--accent);text-decoration:none">View earnings</a>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($nodes)): ?>
        <tr><td colspan="9" style="text-align:center;padding:2rem;color:var(--muted)">No nodes yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>
<link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css">
<link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css">
<script>
const ND = <?= $map_json ?>;

const TIER_COL = {
  nano:'#3fb950',micro:'#56d364',standard:'#3fb950',
  pro:'#79c0ff',premium:'#79c0ff',elite:'#d2a8ff',enterprise:'#f78166'
};

function h(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

// Safety-net translit map for place names that came back in Arabic from the
// geolocation API (best long-term fix is forcing lang=en at the API call —
// this just guards against rows saved before that's done, or other locales).
const PLACE_EN = {
  'الرياض':'Riyadh','جدة':'Jeddah','مكة المكرمة':'Mecca','مكة':'Mecca','المدينة المنورة':'Medina',
  'الدمام':'Dammam','الخبر':'Khobar','تبوك':'Tabuk','أبها':'Abha','الطائف':'Taif',
  'المملكة العربية السعودية':'Saudi Arabia','السعودية':'Saudi Arabia',
  'القاهرة':'Cairo','مصر':'Egypt','دبي':'Dubai','أبوظبي':'Abu Dhabi',
  'الإمارات العربية المتحدة':'United Arab Emirates','الإمارات':'United Arab Emirates',
  'الدوحة':'Doha','قطر':'Qatar','الكويت':'Kuwait','عمان':'Amman','الأردن':'Jordan',
  'بيروت':'Beirut','لبنان':'Lebanon','بغداد':'Baghdad','العراق':'Iraq'
};
function enPlace(s){
  if(!s) return s;
  return PLACE_EN[s.trim()] || s;
}

function pin(color, opacity){
  return L.divIcon({
    className:'',
    html:`<svg width="26" height="34" viewBox="0 0 26 34" xmlns="http://www.w3.org/2000/svg" style="opacity:${opacity};filter:drop-shadow(0 2px 4px rgba(0,0,0,.5))">
      <path d="M13 1C7.48 1 3 5.48 3 11c0 8.25 10 22 10 22s10-13.75 10-22c0-5.52-4.48-10-10-10z" fill="${color}" stroke="#0a0c10" stroke-width="2"/>
      <circle cx="13" cy="11" r="5" fill="#0a0c10" opacity=".5"/>
    </svg>`,
    iconSize:[26,34],iconAnchor:[13,34],popupAnchor:[0,-36],tooltipAnchor:[16,-24]
  });
}

function popup(n){
  const loc = [enPlace(n.city),enPlace(n.country)].filter(Boolean).join(', ') || 'Unknown location';
  const sc  = n.status==='online'?'#3fb950':n.status==='busy'?'#79c0ff':'#6e7681';
  const lastSeenNote = n.status==='offline' ? '<div style="font-size:.68rem;color:#6e7681;margin-top:4px">📍 Last known location</div>' : '';

  // Location cross-check block — only renders rows for fields that
  // actually exist on this node. None of this proves the coordinates
  // are correct, it just surfaces what the location is based on so a
  // human can sanity-check it against the city/country shown above.
  const checkRows = [];
  checkRows.push(`<div class="p-row">🌐 Coords: <strong>${n.lat.toFixed(4)}, ${n.lng.toFixed(4)}</strong></div>`);
  if (n.ip)      checkRows.push(`<div class="p-row">IP: <strong>${h(n.ip)}</strong></div>`);
  if (n.geo_src) checkRows.push(`<div class="p-row">Source: <strong>${h(n.geo_src)}</strong></div>`);
  if (n.geo_acc) checkRows.push(`<div class="p-row">Accuracy: <strong>±${h(n.geo_acc)}${typeof n.geo_acc==='number'?'km':''}</strong></div>`);
  if (n.geo_at)  checkRows.push(`<div class="p-row">Geo updated: <strong>${h(n.geo_at)}</strong></div>`);

  return `<div>
    <div class="p-name">${h(n.name)}</div>
    <span class="p-badge t-${h(n.tier)}">${h(n.tier)}</span>
    <div class="p-row">📍 <strong>${h(loc)}</strong></div>
    <div class="p-row">Status: <strong style="color:${sc}">${h(n.status)}</strong></div>
    <div class="p-row">⚙ Jobs: <strong>${n.jobs.toLocaleString()}</strong></div>
    <div class="p-row">💎 IQ: <strong>${n.iq.toFixed(4)}</strong></div>
    ${lastSeenNote}
    <div style="border-top:1px solid #21262d;margin-top:7px;padding-top:6px">
      ${checkRows.join('')}
    </div>
    <div style="font-size:.62rem;color:#484f58;margin-top:5px">${h(n.id)}</div>
  </div>`;
}

// Two base layers: dark (default) and satellite. Toggle button swaps between them.
const darkLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',{
  attribution:'© <a href="https://openstreetmap.org">OpenStreetMap</a> © <a href="https://carto.com">CARTO</a>',
  subdomains:'abcd',
  maxZoom:19
});
const satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',{
  attribution:'Tiles © Esri — Source: Esri, Maxar, Earthstar Geographics',
  maxZoom:19
});

const map = L.map('node-map',{zoom:2,center:[20,15],zoomControl:true,scrollWheelZoom:false,layers:[darkLayer]});

let satelliteActive = false;
function toggleMapView(){
  const btn = document.getElementById('mapViewToggle');
  if (satelliteActive){
    map.removeLayer(satelliteLayer);
    map.addLayer(darkLayer);
    btn.textContent = '🛰 Satellite';
    btn.classList.remove('active');
  } else {
    map.removeLayer(darkLayer);
    map.addLayer(satelliteLayer);
    btn.textContent = '🌙 Dark';
    btn.classList.add('active');
  }
  satelliteActive = !satelliteActive;
}

// Marker cluster group: groups overlapping/nearby pins at low zoom,
// expands automatically as you zoom in or click a cluster
const clusterGroup = L.markerClusterGroup({
  maxClusterRadius: 50,
  spiderfyOnMaxZoom: true,
  showCoverageOnHover: false,
  iconCreateFunction: function(cluster){
    const markers = cluster.getAllChildMarkers();
    const onlineCount = markers.filter(m => m.options.nodeStatus === 'online').length;
    const total = markers.length;
    let cls = 'node-cluster';
    if (onlineCount === 0) cls += ' all-offline';
    else if (onlineCount < total) cls += ' mixed';
    return L.divIcon({
      html:`<div class="${cls}" style="width:${total>9?44:38}px;height:${total>9?44:38}px">${total}</div>`,
      className:'',
      iconSize:[total>9?44:38, total>9?44:38]
    });
  }
});

const bounds=[];
ND.forEach(n=>{
  const online = n.status==='online';
  const color  = online ? (TIER_COL[n.tier]||'#3fb950') : '#484f58';
  const m = L.marker([n.lat,n.lng],{
    icon:pin(color, online?1:0.45),
    zIndexOffset: online?1000:0,
    nodeStatus: n.status
  });
  m.nodeData = n;

  // Permanent floating label — name + city/country + status
  const loc = [enPlace(n.city),enPlace(n.country)].filter(Boolean).join(', ');
  const sc  = online?'s-online':n.status==='busy'?'s-busy':'s-offline';
  m.bindTooltip(
    `<b>${h(n.name)}</b>${loc?'<br><small>📍 '+h(loc)+'</small>':''}<br><small class="${sc}">${h(n.status)}</small>`,
    {permanent:true,direction:'right',offset:[16,-24],opacity:1,className:'node-lbl'}
  );

  m.bindPopup(popup(n),{maxWidth:240});
  clusterGroup.addLayer(m);
  bounds.push([n.lat,n.lng]);
});

map.addLayer(clusterGroup);

// When markers are clustered, give the cluster bubble itself a tooltip
// that lists every node inside — name, location, status — visible on
// hover/click without needing to zoom in or spiderfy first.
clusterGroup.on('clustermouseover', function(e){
  const markers = e.layer.getAllChildMarkers();
  const rows = markers.map(m => {
    const n = m.nodeData;
    const loc = [enPlace(n.city), enPlace(n.country)].filter(Boolean).join(', ') || 'Unknown location';
    const sc  = n.status==='online'?'#3fb950':n.status==='busy'?'#79c0ff':'#6e7681';
    return `<div style="padding:4px 0;border-bottom:1px solid #21262d">
      <b>${h(n.name)}</b><br>
      <small>📍 ${h(loc)}</small><br>
      <small style="color:${sc}">${h(n.status)}</small>
    </div>`;
  }).join('');
  e.layer.bindTooltip(
    `<div style="max-height:220px;overflow-y:auto">${rows}</div>`,
    {direction:'top', offset:[0,-10], opacity:1, className:'node-lbl', sticky:true}
  ).openTooltip();
});

// When a cluster is clicked and its pins spiderfy (fan out), show each
// pin's name/location/status label immediately — don't make the user
// zoom further once the pins are already visually separated.
clusterGroup.on('spiderfied', function(e){
  e.markers.forEach(m => m.openTooltip());
});

if(bounds.length===1)      map.setView(bounds[0],6);
else if(bounds.length>1)   map.fitBounds(bounds,{padding:[60,60],maxZoom:7});

function mobNav(){document.querySelector('.sidebar').classList.toggle('nav-open');document.getElementById('mobOv').classList.toggle('nav-open')}
function mobClose(){document.querySelector('.sidebar').classList.remove('nav-open');document.getElementById('mobOv').classList.remove('nav-open')}
</script>
</body></html>