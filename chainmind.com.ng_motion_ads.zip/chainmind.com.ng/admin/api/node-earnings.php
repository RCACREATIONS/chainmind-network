<?php
// ============================================================
// ChainMind  Node Earnings API  (called by node software)
// GET /api/node/node-earnings.php
// Headers: X-Node-Secret, X-Node-Id
// Returns: earnings, linked account info, withdrawal history
// ============================================================
require_once __DIR__ . '/../../api/_helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') { json_err('GET only', 405); }

validate_node_secret();
$node_id = get_node_id();

// Look up the node
$stmt = db()->prepare(
    'SELECT n.*,
            (SELECT COALESCE(SUM(iq_amount),0) FROM withdrawals w
             WHERE w.node_id = n.id AND w.status != "rejected") AS committed_iq,
            u.email AS linked_email_addr
     FROM nodes n
     LEFT JOIN users u ON u.id = n.user_id
     WHERE n.id = ?
     LIMIT 1'
);
$stmt->execute([$node_id]);
$node = $stmt->fetch();

if (!$node) {
    // Node not registered yet  return minimal structure so dashboard doesn't crash
    json_ok(['node' => null]);
}

$available_iq = max(0.0, (float)$node['iq_earned'] - (float)$node['committed_iq']);
$linked_email = $node['linked_email'] ?? $node['linked_email_addr'] ?? null;

// Recent withdrawals
$wds = db()->prepare(
    'SELECT requested_at, iq_amount, usd_value, method, status
     FROM withdrawals WHERE node_id = ? ORDER BY requested_at DESC LIMIT 20'
);
$wds->execute([$node_id]);
$withdrawals = $wds->fetchAll();

json_ok([
    'node' => [
        'iq_earned'     => (float)$node['iq_earned'],
        'committed_iq'  => (float)$node['committed_iq'],
        'available_iq'  => $available_iq,
        'jobs_done'     => (int)$node['jobs_done'],
        'reputation'    => (float)$node['reputation'],
        'tier'          => $node['tier'],
        'status'        => $node['status'],
        'linked_email'  => $linked_email,
        'linked_at'     => $node['linked_at'] ?? null,
        'withdrawals'   => $withdrawals,
    ]
]);