<?php
// ============================================================
// ChainMind — AI Blog Generator (Groq API)
// Upload to: admin/api/ai-blog.php
// ============================================================
header('Content-Type: application/json');
session_start();
require_once __DIR__ . '/../../api/_helpers.php';

$is_session_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
$is_secret_admin  = defined('ADMIN_SECRET') && ($_GET['secret'] ?? '') === ADMIN_SECRET;
if (!$is_session_admin && !$is_secret_admin) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$groq_key = defined('GROQ_API_KEY') ? GROQ_API_KEY : ($_ENV['GROQ_API_KEY'] ?? '');
if (!$groq_key) {
    http_response_code(500);
    echo json_encode(['error' => 'GROQ_API_KEY is not configured.']);
    exit;
}

$input   = json_decode(file_get_contents('php://input'), true);
$prompt  = trim($input['prompt'] ?? '');
$tone    = $input['tone'] ?? 'technical';
$length  = $input['length'] ?? 'long';

// New optional inputs --------------------------------------------------
// affiliate_links: [{url, anchor}, ...] — links the AI must weave into the content naturally
// image_url: a single image URL to embed inline (e.g. a product photo / diagram)
// youtube_url: a YouTube video URL/ID to embed inline
$affiliate_links = is_array($input['affiliate_links'] ?? null) ? $input['affiliate_links'] : [];
$affiliate_links = array_values(array_filter(array_map(function ($l) {
    $url    = trim($l['url'] ?? '');
    $anchor = trim($l['anchor'] ?? '');
    if (!$url) return null;
    // Basic safety: only allow http/https URLs
    if (!preg_match('#^https?://#i', $url)) return null;
    return ['url' => $url, 'anchor' => $anchor ?: $url];
}, $affiliate_links)));

$image_url   = trim($input['image_url'] ?? '');
if ($image_url && !preg_match('#^https?://#i', $image_url)) $image_url = '';

$youtube_url = trim($input['youtube_url'] ?? '');
$youtube_id  = '';
if ($youtube_url) {
    // Accept full URLs (watch?v=, youtu.be/, embed/) or a bare 11-char video ID
    if (preg_match('#(?:youtube\.com/(?:watch\?v=|embed/|shorts/)|youtu\.be/)([A-Za-z0-9_-]{11})#', $youtube_url, $m)) {
        $youtube_id = $m[1];
    } elseif (preg_match('#^[A-Za-z0-9_-]{11}$#', $youtube_url)) {
        $youtube_id = $youtube_url;
    }
}

if (!$prompt) {
    http_response_code(400);
    echo json_encode(['error' => 'Prompt is required.']);
    exit;
}

$tone_desc = [
    'technical'    => 'technical and detailed, written for developers and builders',
    'beginner'     => 'beginner-friendly, clear and educational with simple analogies',
    'professional' => 'professional and thought-leadership focused',
    'exciting'     => 'exciting and energetic, building hype and enthusiasm',
];
$tone_text = $tone_desc[$tone] ?? 'technical and detailed';

// Token budgets: capped to fit Groq's FREE TIER limit for gpt-oss-120b, which is
// 8,000 tokens per minute TOTAL (prompt + completion combined, per the error:
// "Limit 8000, Requested 9942"). That ceiling can't be raised in code — it's an
// account-level rate limit — so "long" is capped at ~1500-2000 words instead of
// 3500-5000. If you upgrade to Groq's paid Dev Tier later, these numbers can go
// back up (Dev Tier gives ~250K-300K TPM).
$length_desc = [
    'short'  => 'around 400-600 words',
    'medium' => 'around 800-1200 words',
    'long'   => 'around 1500-2000 words, well-organised with clear sections',
];
$length_text = $length_desc[$length] ?? $length_desc['long'];

// ---- Build instructions for affiliate links / image / video, only if provided ----

$links_instructions = '';
if (!empty($affiliate_links)) {
    $links_instructions = "\n\nAFFILIATE LINKS — you MUST include every one of these links exactly once, woven naturally into the body where it makes contextual sense (e.g. when mentioning a relevant tool, product, or resource). Use this exact HTML format: <a href=\"URL\" rel=\"nofollow sponsored\" target=\"_blank\">ANCHOR TEXT</a>. Do not invent extra links. Do not group them all into one list at the end — spread them through the relevant sections. The links to include:\n";
    foreach ($affiliate_links as $i => $l) {
        $n = $i + 1;
        $links_instructions .= "{$n}. URL: {$l['url']} | Anchor text to use: \"{$l['anchor']}\"\n";
    }
}

$image_instructions = '';
if ($image_url) {
    $image_instructions = "\n\nFEATURED IMAGE — embed this exact image once, at a natural point early in the post (e.g. right after the intro), using exactly: <img src=\"{$image_url}\" alt=\"DESCRIPTIVE ALT TEXT\" loading=\"lazy\"> — write a short, relevant alt text yourself based on the post topic.";
}

$video_instructions = '';
if ($youtube_id) {
    $video_instructions = "\n\nYOUTUBE VIDEO — embed this exact video once, at a natural point in the post where a video adds value, using exactly this HTML block:\n<div class=\"video-embed\"><iframe width=\"100%\" height=\"480\" src=\"https://www.youtube.com/embed/{$youtube_id}\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe></div>\nIntroduce the video with a sentence of context before it.";
}

$system = "You are an expert content writer and tech blogger for ChainMind — Africa's first decentralized AI inference network.
ChainMind lets developers access powerful open-source LLMs via an OpenAI-compatible API priced in Naira (no dollar fees), while node operators earn IQ tokens by running AI jobs on their local machines.

Write a {$length_text} blog post in a {$tone_text} tone.

Return ONLY a valid JSON object with this exact shape:
{\"title\": \"...\", \"slug\": \"...\", \"excerpt\": \"...\", \"content\": \"...\"}

Rules:
- title: compelling, SEO-optimised, under 70 characters
- slug: lowercase, hyphenated URL slug derived from title (e.g. 'why-nigerian-devs-choose-chainmind')
- excerpt: 1-2 sentence summary for SEO meta description, under 160 characters
- content: full blog post in clean HTML using only these tags: <h2>, <h3>, <p>, <ul>, <ol>, <li>, <strong>, <em>, <code>, <pre><code>, <a>, <img>, <div>, <iframe>. No <html>, <head>, <body>, <style> tags. No markdown. No backtick fences.
- Include a compelling intro that hooks the reader
- Use subheadings (h2/h3) to break up the content
- End with a clear CTA mentioning ChainMind's API or node programme
- Do NOT include any text outside the JSON object — no preamble, no explanation, no markdown code fences{$links_instructions}{$image_instructions}{$video_instructions}";

$user_msg = "Write a long, engaging blog post about: {$prompt}

Make it highly relevant to Nigerian developers, African tech builders, and anyone interested in decentralized AI / DePIN. Reference ChainMind's value props naturally (Naira pricing, no dollar fees, OpenAI-compatible, earn IQ tokens).";

// ---- Dynamic completion budget, capped to fit Groq free tier's 8K TPM total ----
// Estimate prompt tokens (~4 chars/token is a safe rough average for English+HTML
// instructions). The more affiliate links/media instructions added, the bigger the
// prompt, so this shrinks the completion budget automatically to compensate —
// otherwise more links could silently push a request back over the 8K wall.
$TPM_LIMIT = 8000;
$SAFETY_MARGIN = 600; // headroom for tokenizer estimation error
$estimated_prompt_tokens = (int) ceil((strlen($system) + strlen($user_msg)) / 4);

$length_tokens_base = ['short' => 1200, 'medium' => 2200, 'long' => 3600];
$base_tokens = $length_tokens_base[$length] ?? 3600;

$available_for_completion = $TPM_LIMIT - $estimated_prompt_tokens - $SAFETY_MARGIN;
$max_tokens = max(500, min($base_tokens, $available_for_completion));

// If links/media instructions ate so much of the budget that even a short article
// won't fit, fail clearly now rather than send a doomed request to Groq.
if ($available_for_completion < 500) {
    http_response_code(413);
    echo json_encode([
        'error' => 'Too many affiliate links / media for the free-tier token limit. Remove a link or two and try again.',
    ]);
    exit;
}

$payload = [
    // NOTE: llama-3.3-70b-versatile is deprecated by Groq (shutdown 08/16/26).
    // Switched to openai/gpt-oss-120b. Model itself supports up to ~33K output
    // tokens, but this account is on Groq's FREE TIER, which caps gpt-oss-120b at
    // 8,000 tokens/minute TOTAL (prompt + completion) — see $TPM_LIMIT above.
    'model'              => 'openai/gpt-oss-120b',
    'messages'           => [
        ['role' => 'system', 'content' => $system],
        ['role' => 'user',   'content' => $user_msg],
    ],
    'temperature'        => 0.72,
    // gpt-oss models use max_completion_tokens, not the legacy max_tokens.
    'max_completion_tokens' => $max_tokens,
    // Keep reasoning light — this is a content-writing task, not a hard reasoning
    // problem, and we want the token budget spent on the article, not "thinking".
    'reasoning_effort'   => 'low',
    // Groq's JSON mode: forces the model to emit syntactically valid JSON only.
    // This is far more reliable than asking nicely in the prompt, and removes
    // most causes of the "malformed content" error.
    'response_format'    => ['type' => 'json_object'],
];

$ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $groq_key,
    ],
    CURLOPT_POSTFIELDS     => json_encode($payload),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 60,
]);
$raw      = curl_exec($ch);
$curl_err = curl_error($ch);
$http_code= curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($curl_err) {
    http_response_code(502);
    echo json_encode(['error' => 'Network error contacting Groq: ' . $curl_err]);
    exit;
}

$groq_resp = json_decode($raw, true);

if ($http_code !== 200 || empty($groq_resp['choices'][0]['message']['content'])) {
    $err_msg = $groq_resp['error']['message'] ?? 'Groq returned an unexpected response.';
    http_response_code(502);
    echo json_encode(['error' => $err_msg]);
    exit;
}

$finish_reason = $groq_resp['choices'][0]['finish_reason'] ?? null;
$content = trim($groq_resp['choices'][0]['message']['content']);

// Strip markdown code fences if model wraps anyway (belt-and-suspenders, even with JSON mode)
$content = preg_replace('/^```(?:json)?\s*/i', '', $content);
$content = preg_replace('/\s*```$/', '', $content);
$content = trim($content);

$result = json_decode($content, true);

// If parsing failed and the model was cut off mid-generation, that's almost certainly why.
// Tell the user to shorten the request or pick a shorter length, instead of a vague error.
if (!$result && $finish_reason === 'length') {
    http_response_code(502);
    echo json_encode([
        'error' => 'The AI response was cut off before it finished (hit the token limit). Try a shorter "length" setting or a more specific prompt.',
        'raw'   => $content,
    ]);
    exit;
}

// Fallback: if strict json_decode still fails, try to salvage a JSON object embedded
// in extra text (e.g. stray preamble) by extracting the outermost {...} block.
if (!$result || !isset($result['title'], $result['content'])) {
    if (preg_match('/\{.*\}/s', $content, $m)) {
        $salvaged = json_decode($m[0], true);
        if ($salvaged && isset($salvaged['title'], $salvaged['content'])) {
            $result = $salvaged;
        }
    }
}

if (!$result || !isset($result['title'], $result['content'])) {
    http_response_code(502);
    echo json_encode(['error' => 'AI returned malformed content. Try again.', 'raw' => $content]);
    exit;
}

// ---- Safety net: make sure nothing the user asked for got dropped ----
// LLMs sometimes ignore one instruction in a long prompt. Since affiliate links and
// embeds are the whole point of this request, verify they're present and append
// any missing ones at the end rather than silently losing them.
$final_content = $result['content'] ?? '';

foreach ($affiliate_links as $l) {
    if (stripos($final_content, $l['url']) === false) {
        $final_content .= "\n<p><a href=\"" . htmlspecialchars($l['url'], ENT_QUOTES) . "\" rel=\"nofollow sponsored\" target=\"_blank\">"
            . htmlspecialchars($l['anchor'], ENT_QUOTES) . "</a></p>";
    }
}

if ($image_url && stripos($final_content, $image_url) === false) {
    $final_content .= "\n<img src=\"" . htmlspecialchars($image_url, ENT_QUOTES) . "\" alt=\"" . htmlspecialchars($result['title'] ?? '', ENT_QUOTES) . "\" loading=\"lazy\">";
}

if ($youtube_id && stripos($final_content, $youtube_id) === false) {
    $final_content .= "\n<div class=\"video-embed\"><iframe width=\"100%\" height=\"480\" src=\"https://www.youtube.com/embed/"
        . htmlspecialchars($youtube_id, ENT_QUOTES) . "\" title=\"YouTube video player\" frameborder=\"0\" "
        . "allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe></div>";
}

echo json_encode([
    'title'   => $result['title']   ?? '',
    'slug'    => $result['slug']    ?? '',
    'excerpt' => $result['excerpt'] ?? '',
    'content' => $final_content,
]);