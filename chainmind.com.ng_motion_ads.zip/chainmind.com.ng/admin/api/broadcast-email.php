<?php
// ============================================================
// ChainMind — Broadcast / Single-User Email Sender
// Upload to: admin/api/broadcast-email.php
// ============================================================
header('Content-Type: application/json');
session_start();
require_once __DIR__ . '/../../api/_helpers.php';

$is_session_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
$is_secret_admin  = defined('ADMIN_SECRET') && ($_GET['secret'] ?? '') === ADMIN_SECRET;
if (!$is_session_admin && !$is_secret_admin) {
    http_response_code(403); echo json_encode(['error' => 'Unauthorized']); exit;
}

$input    = json_decode(file_get_contents('php://input'), true);
$subject  = trim($input['subject'] ?? '');
$body     = trim($input['body']    ?? '');
$mode     = $input['mode'] ?? 'broadcast'; // 'broadcast' | 'single'

if (!$subject || !$body) {
    http_response_code(400); echo json_encode(['error' => 'Subject and body are required.']); exit;
}

$db = db();

// ── Build recipient list ───────────────────────────────
if ($mode === 'single') {
    $user_id = (int)($input['user_id'] ?? 0);
    if (!$user_id) {
        http_response_code(400); echo json_encode(['error' => 'user_id is required for single mode.']); exit;
    }
    $stmt = $db->prepare('SELECT id, email, name FROM users WHERE id = ? AND email_verified = 1 LIMIT 1');
    $stmt->execute([$user_id]);
    $recipients = $stmt->fetchAll();
    if (empty($recipients)) {
        http_response_code(404); echo json_encode(['error' => 'User not found or email not verified.']); exit;
    }
} else {
    // broadcast mode
    $audience = $input['audience'] ?? 'all';
    if (!in_array($audience, ['all', 'nodes', 'regular'])) {
        http_response_code(400); echo json_encode(['error' => 'Invalid audience.']); exit;
    }
    switch ($audience) {
        case 'nodes':
            $stmt = $db->query(
                'SELECT DISTINCT u.id, u.email, u.name FROM users u
                 JOIN nodes n ON n.user_id = u.id
                 WHERE u.email_verified = 1 AND u.email IS NOT NULL'
            );
            break;
        case 'regular':
            $stmt = $db->query(
                'SELECT u.id, u.email, u.name FROM users u
                 WHERE u.email_verified = 1 AND u.email IS NOT NULL
                   AND u.id NOT IN (SELECT DISTINCT user_id FROM nodes)'
            );
            break;
        default:
            $stmt = $db->query('SELECT id, email, name FROM users WHERE email_verified = 1 AND email IS NOT NULL');
    }
    $recipients = $stmt->fetchAll();
    if (empty($recipients)) {
        echo json_encode(['sent' => 0, 'message' => 'No recipients found for this audience.']); exit;
    }
}

// ── Send emails ────────────────────────────────────────
$sent  = 0;
$fails = 0;

foreach ($recipients as $user) {
    $name         = $user['name'] ?: explode('@', $user['email'])[0];
    $display_name = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');

    // Convert plain-text body to simple HTML (double newline = paragraph break)
    $html_paragraphs = implode('', array_map(
        fn($p) => $p
            ? "<p style='color:#c9d1d9;font-size:.9rem;line-height:1.75;margin:0 0 1rem'>"
              . nl2br(htmlspecialchars($p, ENT_QUOTES, 'UTF-8')) . "</p>"
            : '<br>',
        explode("\n\n", $body)
    ));

    $body_html = "
        <h2 style='color:#e6edf3;margin:0 0 1rem;font-size:1.1rem'>Hi {$display_name},</h2>
        {$html_paragraphs}
        <hr style='border:none;border-top:1px solid #21262d;margin:1.5rem 0'>
        <p style='color:#8b949e;font-size:.8rem;line-height:1.6'>
            You're receiving this because you have a verified account on ChainMind.<br>
            <a href='https://chainmind.com.ng' style='color:#58a6ff'>chainmind.com.ng</a>
        </p>
    ";

    try {
        send_email($user['email'], $subject, email_html('ChainMind', $body_html));
        $sent++;
    } catch (\Throwable $e) {
        error_log('[broadcast] failed to send to ' . $user['email'] . ': ' . $e->getMessage());
        $fails++;
    }

    // Throttle: 0.5s pause every 20 emails to avoid MTA rate limits
    if ($mode === 'broadcast' && $sent % 20 === 0 && $sent > 0) usleep(500000);
}

echo json_encode([
    'sent'    => $sent,
    'failed'  => $fails,
    'message' => $fails > 0 ? "{$fails} failed. Check server error log." : 'All sent successfully.',
]);