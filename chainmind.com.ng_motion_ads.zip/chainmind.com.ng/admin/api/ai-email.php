<?php
// ============================================================
// ChainMind — AI Email Generator (Groq API)
// Upload to: admin/api/ai-email.php
// ============================================================
header('Content-Type: application/json');
session_start();
require_once __DIR__ . '/../../api/_helpers.php';

$is_session_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
$is_secret_admin  = defined('ADMIN_SECRET') && ($_GET['secret'] ?? '') === ADMIN_SECRET;
if (!$is_session_admin && !$is_secret_admin) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// ── Groq API Key ───────────────────────────────────────────
// Option 1: Define GROQ_API_KEY in your config/env
// Option 2: Set it here directly (not recommended for production)
$groq_key = defined('GROQ_API_KEY') ? GROQ_API_KEY : ($_ENV['GROQ_API_KEY'] ?? '');

if (!$groq_key) {
    http_response_code(500);
    echo json_encode(['error' => 'GROQ_API_KEY is not configured. Define it as a constant or env variable.']);
    exit;
}

// ── Input ──────────────────────────────────────────────────
$input = json_decode(file_get_contents('php://input'), true);
$prompt         = trim($input['prompt'] ?? '');
$action         = $input['action'] ?? 'write';
$tone           = $input['tone'] ?? 'professional';
$existing_draft = trim($input['existing_draft'] ?? '');

if (!$prompt && in_array($action, ['write', 'subject'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Prompt is required.']);
    exit;
}

// ── Build system prompt ────────────────────────────────────
$tone_desc = [
    'professional' => 'professional and polished',
    'friendly'     => 'warm, friendly and conversational',
    'exciting'     => 'exciting, enthusiastic and energetic',
    'urgent'       => 'urgent and direct, motivating action',
    'concise'      => 'brief and to-the-point, no fluff',
    'technical'    => 'technical and detailed, for a developer/operator audience',
];
$tone_text = $tone_desc[$tone] ?? 'professional';

$system = "You are an expert email copywriter for ChainMind, a decentralized AI compute platform.
ChainMind lets users run AI jobs on a network of node operators who earn compute rewards.
Write emails that feel authentic, not overly salesy.

Your output MUST be valid JSON with this exact shape:
{\"subject\": \"...\", \"body\": \"...\"}

Rules:
- subject: compelling, under 70 characters, no ALL CAPS
- body: plain text (no HTML tags), use line breaks for paragraphs
- Tone: {$tone_text}
- Sign off as 'The ChainMind Team'
- Do NOT include any markdown, backticks, or explanation — ONLY the JSON object";

// ── Build user message ─────────────────────────────────────
$user_msg = match($action) {
    'write'    => "Write a complete email about: {$prompt}",
    'improve'  => "Improve this email draft while keeping the core message.\n\nPrompt/context: {$prompt}\n\nExisting draft:\n{$existing_draft}",
    'subject'  => "Write 3 subject line options for an email about: {$prompt}\n\nReturn JSON like: {\"subject\": \"Best option here\", \"body\": \"Option 1: ...\\nOption 2: ...\\nOption 3: ...\"}",
    'shorten'  => "Shorten and tighten this email draft — remove fluff, keep the key message:\n\n{$existing_draft}",
    'friendly' => "Rewrite this email to sound warmer and more friendly:\n\n{$existing_draft}",
    default    => "Write a complete email about: {$prompt}",
};

// ── Call Groq API ──────────────────────────────────────────
$payload = [
    'model'       => 'llama-3.1-8b-instant', // official replacement for llama3-8b-8192
    'messages'    => [
        ['role' => 'system', 'content' => $system],
        ['role' => 'user',   'content' => $user_msg],
    ],
    'temperature' => 0.75,
    'max_tokens'  => 1024,
];

$ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $groq_key,
    ],
    CURLOPT_POSTFIELDS     => json_encode($payload),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 30,
]);
$raw      = curl_exec($ch);
$curl_err = curl_error($ch);
$http_code= curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($curl_err) {
    http_response_code(502);
    echo json_encode(['error' => 'Network error contacting Groq: ' . $curl_err]);
    exit;
}

$groq_resp = json_decode($raw, true);

if ($http_code !== 200 || empty($groq_resp['choices'][0]['message']['content'])) {
    $err_msg = $groq_resp['error']['message'] ?? 'Groq returned an unexpected response.';
    http_response_code(502);
    echo json_encode(['error' => $err_msg]);
    exit;
}

$content = trim($groq_resp['choices'][0]['message']['content']);

// Strip markdown code fences if model wraps output anyway
$content = preg_replace('/^```(?:json)?\s*/i', '', $content);
$content = preg_replace('/\s*```$/', '', $content);
$content = trim($content);

$result = json_decode($content, true);

if (!$result || !isset($result['subject'], $result['body'])) {
    // Fallback: return raw as body
    echo json_encode(['subject' => '', 'body' => $content]);
    exit;
}

echo json_encode([
    'subject' => $result['subject'],
    'body'    => $result['body'],
]);