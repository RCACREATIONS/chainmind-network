<?php
require_once __DIR__.'/_shared.php';
page_head('Acceptable Use Policy','What you may and may not do with ChainMind AI inference.');
$updated = 'June 9, 2025';
?>

<main>
<div class="container">
  <div class="page-hero">
    <div class="eyebrow">Legal</div>
    <h1>Acceptable Use Policy</h1>
    <div class="meta">
      <span><i class="ti ti-calendar"></i> Effective: <?=$updated?></span>
    </div>
  </div>

  <div class="legal-body">

    <div class="callout">
      <p><strong>Principle:</strong> ChainMind is infrastructure for useful AI applications. Use it to build, create, and automate. Do not use it to harm people, break laws, or abuse systems.</p>
    </div>

    <h2 id="purpose">1. Purpose</h2>
    <p>This Acceptable Use Policy ("AUP") governs how you may use ChainMind's inference network, API, AI chat interface, and any related services. It supplements our <a href="/terms.php">Terms of Service</a>. Violation of this AUP may result in immediate account suspension or termination.</p>

    <h2 id="prohibited">2. Absolutely prohibited uses</h2>
    <p>The following uses are <strong>strictly prohibited</strong> on the ChainMind network and will result in immediate account termination and, where appropriate, referral to law enforcement:</p>

    <h3>2.1 Content exploiting or harming minors</h3>
    <ul>
      <li>Generating, distributing, or facilitating child sexual abuse material (CSAM) of any kind.</li>
      <li>Any content that sexualises, grooms, or facilitates harm to minors.</li>
    </ul>

    <h3>2.2 Weapons and violence</h3>
    <ul>
      <li>Generating instructions for creating weapons of mass destruction (biological, chemical, nuclear, or radiological).</li>
      <li>Facilitating real-world violence against specific individuals or groups.</li>
      <li>Creating content to plan, coordinate, or incite terrorist attacks.</li>
    </ul>

    <h3>2.3 Cyber attacks</h3>
    <ul>
      <li>Creating or distributing malware, ransomware, spyware, or other malicious code.</li>
      <li>Generating exploits for unpatched vulnerabilities in production systems without authorisation.</li>
      <li>Automating attacks against computer systems, networks, or applications.</li>
    </ul>

    <h3>2.4 Non-consensual content</h3>
    <ul>
      <li>Generating non-consensual intimate imagery ("deepfake porn") of real individuals.</li>
      <li>Creating content designed to harass, stalk, or intimidate specific individuals.</li>
    </ul>

    <h2 id="restricted">3. Restricted uses (require written approval)</h2>
    <p>The following uses require explicit prior written approval from ChainMind:</p>
    <ul>
      <li>Reselling or white-labelling API access to third-party end-users at scale.</li>
      <li>Automated generation of content for mass political influence campaigns.</li>
      <li>Use in regulated industries (healthcare, finance, legal) where AI-generated outputs are used for clinical, investment, or legal advice without human oversight.</li>
      <li>High-volume scraping, crawling, or data extraction projects exceeding 1M tokens/day on the free tier.</li>
    </ul>
    <p>To apply for approval, email <a href="mailto:support@chainmind.com.ng?subject=AUP Approval Request">support@chainmind.com.ng</a> with subject line <strong>AUP Approval Request</strong>.</p>

    <h2 id="responsible">4. Responsible use expectations</h2>
    <p>Even for permitted uses, you are expected to:</p>
    <ul>
      <li>Implement appropriate content filtering when building user-facing products.</li>
      <li>Not systematically attempt to circumvent safety measures built into models.</li>
      <li>Disclose AI involvement where required by law or platform norms.</li>
      <li>Monitor your application for misuse by end-users.</li>
      <li>Respect rate limits and implement backoff to avoid destabilising the network.</li>
    </ul>

    <h2 id="reporting">5. Reporting violations</h2>
    <p>If you believe someone is violating this AUP or using ChainMind to generate harmful content, please report it immediately to <a href="mailto:support@chainmind.com.ng?subject=AUP Violation Report">support@chainmind.com.ng</a> with subject <strong>AUP Violation Report</strong>. We take all reports seriously and will investigate promptly.</p>

    <h2 id="enforcement">6. Enforcement</h2>
    <p>We may, at our sole discretion:</p>
    <ul>
      <li>Issue warnings for minor or first-time violations.</li>
      <li>Suspend accounts pending investigation.</li>
      <li>Permanently terminate accounts for severe or repeated violations.</li>
      <li>Forfeit unused credits without refund for accounts terminated for AUP violations.</li>
      <li>Report illegal activity to Nigerian and international law enforcement agencies.</li>
    </ul>

    <h2 id="changes">7. Changes to this policy</h2>
    <p>We may update this AUP to address new threats or use cases. Changes will be announced on the website and via email to registered users at least 7 days before taking effect.</p>

  </div>
</div>
</main>

<?php page_foot(); ?>