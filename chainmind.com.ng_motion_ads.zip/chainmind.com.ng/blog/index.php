<?php
// ============================================================
// ChainMind — Blog Index
// Upload to: blog/index.php
// ============================================================
require_once __DIR__ . '/../api/_helpers.php';

$db = db();

// Ensure table exists (graceful if admin hasn't visited yet)
$db->exec("CREATE TABLE IF NOT EXISTS blog_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    excerpt TEXT,
    content LONGTEXT NOT NULL,
    status ENUM('draft','published') NOT NULL DEFAULT 'draft',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$posts = $db->query(
    "SELECT id,title,slug,excerpt,created_at FROM blog_posts WHERE status='published' ORDER BY created_at DESC"
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Blog — ChainMind</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="Insights on decentralized AI, DePIN, and building with LLMs in Nigeria and Africa. Powered by ChainMind.">
<link rel="canonical" href="https://www.chainmind.com.ng/blog/">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap">
<link rel="icon" type="image/png" href="/ChatGPT_Image_Jun_2,_2026,_06_42_49_AM.png">
<style>
:root{--bg:#080b10;--bg2:#0c1018;--bg3:#111620;--border:#1e2430;--border2:#252d3a;
  --text:#e8eef5;--text2:#b8c4d0;--muted:#6b7a8d;--accent:#4f9cf9;--accent2:#7c3aed;
  --green:#22c55e;--mono:'JetBrains Mono',monospace}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:'Plus Jakarta Sans',system-ui,sans-serif;min-height:100vh}
a{color:inherit;text-decoration:none}

/* NAV */
nav{position:sticky;top:0;z-index:100;background:rgba(8,11,16,.85);backdrop-filter:blur(12px);
  border-bottom:1px solid var(--border);padding:0 1.5rem;height:60px;
  display:flex;align-items:center;gap:1rem}
.nav-logo{font-family:'Syne',sans-serif;font-weight:800;font-size:1.1rem;color:var(--text)}
.nav-logo span{color:var(--accent)}
.nav-links{display:flex;gap:.1rem;flex:1;margin-left:.5rem}
.nav-links a{padding:.4rem .7rem;border-radius:7px;font-size:.85rem;color:var(--muted);transition:all .15s}
.nav-links a:hover,.nav-links a.active{color:var(--text);background:var(--bg3)}
.nav-right{margin-left:auto;display:flex;gap:.5rem}
.btn{display:inline-flex;align-items:center;padding:.45rem 1rem;border-radius:8px;
  font-size:.85rem;font-weight:600;cursor:pointer;transition:all .15s}
.btn-solid{background:var(--accent);color:#fff}
.btn-ghost{background:transparent;color:var(--text2);border:1px solid var(--border2)}
.btn-ghost:hover{border-color:var(--accent);color:var(--accent)}
@media(max-width:640px){.nav-links{display:none}}

/* HERO */
.blog-hero{padding:4rem 1.5rem 2.5rem;text-align:center;max-width:700px;margin:0 auto}
.blog-hero h1{font-family:'Syne',sans-serif;font-size:clamp(2rem,5vw,3rem);font-weight:800;
  line-height:1.15;margin-bottom:1rem}
.blog-hero h1 span{background:linear-gradient(135deg,var(--accent),var(--accent2));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.blog-hero p{color:var(--text2);font-size:1.05rem;line-height:1.7}

/* POSTS GRID */
.blog-grid{max-width:1100px;margin:0 auto;padding:1.5rem 1.5rem 5rem;
  display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:1.5rem}
.post-card{background:var(--bg2);border:1px solid var(--border2);border-radius:14px;
  padding:1.6rem;display:flex;flex-direction:column;gap:.75rem;transition:border .2s,transform .2s}
.post-card:hover{border-color:var(--accent);transform:translateY(-2px)}
.post-date{font-size:.75rem;color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:.05em}
.post-title{font-family:'Syne',sans-serif;font-size:1.15rem;font-weight:700;line-height:1.35;color:var(--text)}
.post-excerpt{font-size:.875rem;color:var(--text2);line-height:1.65;flex:1}
.post-read{display:inline-flex;align-items:center;gap:.3rem;font-size:.82rem;
  font-weight:700;color:var(--accent);margin-top:.25rem}
.post-read::after{content:'→';transition:transform .15s}
.post-card:hover .post-read::after{transform:translateX(3px)}

/* EMPTY */
.blog-empty{max-width:500px;margin:4rem auto;text-align:center;color:var(--muted)}
.blog-empty h2{font-size:1.2rem;margin-bottom:.5rem;color:var(--text)}

/* FOOTER */
footer{border-top:1px solid var(--border);padding:2rem 1.5rem;text-align:center;color:var(--muted);font-size:.82rem}
footer a{color:var(--accent)}
</style>
</head>
<body>

<nav>
  <a class="nav-logo" href="/"><span>Chain</span>Mind</a>
  <div class="nav-links">
    <a href="/#what-is-din">What is a DIN?</a>
    <a href="/#who-its-for">Who's it for</a>
    <a href="/#pricing">Pricing</a>
    <a href="/#nodes">Earn</a>
    <a href="/docs.php">Docs</a>
    <a href="/blog/" class="active">Blog</a>
  </div>
  <div class="nav-right">
    <a class="btn btn-ghost" href="/auth/login.php">Sign in</a>
    <a class="btn btn-solid" href="/auth/register.php">Get started free</a>
  </div>
</nav>

<div class="blog-hero">
  <h1>Insights on <span>Decentralized AI</span></h1>
  <p>Deep dives on DePIN, open-source LLMs, and building AI-powered products in Nigeria and Africa.</p>
</div>

<?php if (empty($posts)): ?>
<div class="blog-empty">
  <h2>First post coming soon</h2>
  <p>We're writing deep-dive content on decentralized AI, DePIN, and building for Nigerian developers. Check back soon.</p>
</div>
<?php else: ?>
<div class="blog-grid">
  <?php foreach ($posts as $p): ?>
  <a class="post-card" href="/blog/<?= htmlspecialchars($p['slug']) ?>">
    <div class="post-date"><?= date('F j, Y', strtotime($p['created_at'])) ?></div>
    <div class="post-title"><?= htmlspecialchars($p['title']) ?></div>
    <?php if ($p['excerpt']): ?>
    <div class="post-excerpt"><?= htmlspecialchars($p['excerpt']) ?></div>
    <?php endif; ?>
    <span class="post-read">Read article</span>
  </a>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<footer>
  <p>&copy; <?= date('Y') ?> ChainMind · <a href="/privacy.php">Privacy</a> · <a href="/terms.php">Terms</a> · Built in Nigeria 🇳🇬</p>
</footer>
</body>
</html>
