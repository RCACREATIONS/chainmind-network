<?php
// ============================================================
// ChainMind — Single Blog Post
// Upload to: blog/post.php
// Access via: /blog/<slug>  (requires .htaccess rewrite below)
// ============================================================
require_once __DIR__ . '/../api/_helpers.php';

$db   = db();
$slug = trim($_GET['slug'] ?? '');

if (!$slug) { header('Location: /blog/'); exit; }

$st = $db->prepare("SELECT * FROM blog_posts WHERE slug=? AND status='published' LIMIT 1");
$st->execute([$slug]);
$post = $st->fetch();

if (!$post) {
    http_response_code(404);
    include __DIR__ . '/../404.php';
    exit;
}

// Related posts (latest 3 excluding current)
$related = $db->prepare("SELECT title,slug,excerpt,created_at FROM blog_posts WHERE status='published' AND id!=? ORDER BY created_at DESC LIMIT 3");
$related->execute([$post['id']]);
$related_posts = $related->fetchAll();

$canonical = 'https://www.chainmind.com.ng/blog/' . htmlspecialchars($post['slug']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($post['title']) ?> — ChainMind Blog</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<?php if ($post['excerpt']): ?>
<meta name="description" content="<?= htmlspecialchars($post['excerpt']) ?>">
<?php endif; ?>
<link rel="canonical" href="<?= $canonical ?>">
<!-- Open Graph -->
<meta property="og:title" content="<?= htmlspecialchars($post['title']) ?>">
<meta property="og:description" content="<?= htmlspecialchars($post['excerpt'] ?? '') ?>">
<meta property="og:url" content="<?= $canonical ?>">
<meta property="og:type" content="article">
<meta property="article:published_time" content="<?= date('c', strtotime($post['created_at'])) ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap">
<link rel="icon" type="image/png" href="/ChatGPT_Image_Jun_2,_2026,_06_42_49_AM.png">
<style>
:root{--bg:#080b10;--bg2:#0c1018;--bg3:#111620;--border:#1e2430;--border2:#252d3a;
  --text:#e8eef5;--text2:#b8c4d0;--muted:#6b7a8d;--accent:#4f9cf9;--accent2:#7c3aed;
  --green:#22c55e}
*{box-sizing:border-box;margin:0;padding:0}
html{overflow-x:hidden}
body{background:var(--bg);color:var(--text);font-family:'Plus Jakarta Sans',system-ui,sans-serif;min-height:100vh;overflow-x:hidden}
a{color:inherit;text-decoration:none}
img{max-width:100%;display:block}

/* NAV */
nav{position:sticky;top:0;z-index:100;background:rgba(8,11,16,.85);backdrop-filter:blur(12px);
  border-bottom:1px solid var(--border);padding:0 1.5rem;height:60px;
  display:flex;align-items:center;gap:1rem}
.nav-logo{font-family:'Syne',sans-serif;font-weight:800;font-size:1.1rem}
.nav-logo span{color:var(--accent)}
.nav-links{display:flex;gap:.1rem;flex:1;margin-left:.5rem}
.nav-links a{padding:.4rem .7rem;border-radius:7px;font-size:.85rem;color:var(--muted);transition:all .15s}
.nav-links a:hover,.nav-links a.active{color:var(--text);background:var(--bg3)}
.nav-right{margin-left:auto;display:flex;gap:.5rem}
.btn{display:inline-flex;align-items:center;padding:.45rem 1rem;border-radius:8px;
  font-size:.85rem;font-weight:600;cursor:pointer;transition:all .15s;white-space:nowrap}
.btn-solid{background:var(--accent);color:#fff}
.btn-ghost{background:transparent;color:var(--text2);border:1px solid var(--border2)}
.btn-ghost:hover{border-color:var(--accent);color:var(--accent)}
@media(max-width:640px){
  .nav-links{display:none}
  nav{padding:0 1rem;gap:.5rem}
  .nav-right{gap:.4rem}
  .nav-right .btn{padding:.4rem .7rem;font-size:.78rem}
}
@media(max-width:380px){
  .nav-right .btn-ghost{display:none} /* keep just the primary CTA on very small screens */
}

/* ARTICLE */
.article-wrap{max-width:740px;margin:0 auto;padding:3rem 1.5rem 5rem}
.article-meta{display:flex;align-items:center;gap:.75rem;margin-bottom:1.75rem;flex-wrap:wrap}
.meta-tag{background:rgba(79,156,249,.1);color:var(--accent);border:1px solid rgba(79,156,249,.2);
  padding:.2rem .6rem;border-radius:20px;font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em}
.meta-date{font-size:.82rem;color:var(--muted)}
.article-title{font-family:'Syne',sans-serif;font-size:clamp(1.6rem,4vw,2.5rem);
  font-weight:800;line-height:1.2;margin-bottom:1.1rem;color:var(--text);word-wrap:break-word}
.article-excerpt{font-size:1.05rem;color:var(--text2);line-height:1.7;
  border-left:3px solid var(--accent);padding-left:1.1rem;margin-bottom:2.5rem}
.article-divider{border:none;border-top:1px solid var(--border);margin:2rem 0}

/* PROSE */
.article-body{max-width:100%;overflow-wrap:break-word}
.article-body h2{font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:700;
  margin:2.25rem 0 .75rem;color:var(--text)}
.article-body h3{font-size:1.1rem;font-weight:700;margin:1.75rem 0 .6rem;color:var(--text2)}
.article-body p{line-height:1.8;color:var(--text2);margin-bottom:1.1rem;font-size:.975rem}
.article-body ul,.article-body ol{padding-left:1.4rem;margin-bottom:1.1rem;color:var(--text2)}
.article-body li{line-height:1.75;margin-bottom:.35rem;font-size:.975rem}
.article-body strong{color:var(--text);font-weight:700}
.article-body em{color:var(--text2)}
.article-body code{background:var(--bg3);border:1px solid var(--border2);border-radius:5px;
  padding:.1rem .4rem;font-size:.82rem;color:var(--accent);font-family:'JetBrains Mono',monospace;
  word-break:break-word}
.article-body pre{background:var(--bg2);border:1px solid var(--border2);border-radius:10px;
  padding:1.1rem;overflow-x:auto;margin:1.25rem 0;-webkit-overflow-scrolling:touch}
.article-body pre code{background:none;border:none;padding:0;font-size:.82rem;color:var(--text2);
  word-break:normal;white-space:pre}
.article-body a{color:var(--accent);text-decoration:underline;text-underline-offset:2px;
  overflow-wrap:break-word}
.article-body a:hover{color:#7bbfff}

/* IMAGES — centered, responsive, never overflow the column */
.article-body img{
  max-width:100%;
  height:auto;
  display:block;
  margin:1.75rem auto;
  border-radius:12px;
  border:1px solid var(--border2);
}
/* If the AI/editor wraps an image in a figure, style that as the unit instead */
.article-body figure{margin:1.75rem auto;max-width:100%}
.article-body figure img{margin:0 auto}
.article-body figcaption{text-align:center;font-size:.8rem;color:var(--muted);margin-top:.5rem}

/* VIDEO EMBEDS — responsive 16:9 box regardless of the iframe's fixed width/height attrs */
.article-body .video-embed{
  position:relative;
  width:100%;
  aspect-ratio:16/9;
  margin:1.75rem 0;
  border-radius:12px;
  overflow:hidden;
  border:1px solid var(--border2);
  background:var(--bg2);
}
.article-body .video-embed iframe{
  position:absolute;
  inset:0;
  width:100% !important;
  height:100% !important;
  border:0;
}
/* Fallback for any bare iframe not wrapped in .video-embed (e.g. pasted directly) */
.article-body iframe:not(.video-embed iframe){
  max-width:100%;
  border-radius:12px;
  border:1px solid var(--border2);
}

/* CTA */
.article-cta{background:linear-gradient(135deg,rgba(79,156,249,.08),rgba(124,58,237,.08));
  border:1px solid var(--border2);border-radius:14px;padding:2rem;margin-top:3rem;text-align:center}
.article-cta h3{font-family:'Syne',sans-serif;font-size:1.2rem;font-weight:800;margin-bottom:.5rem}
.article-cta p{color:var(--text2);font-size:.9rem;margin-bottom:1.25rem}
.cta-btns{display:flex;gap:.75rem;justify-content:center;flex-wrap:wrap}
.btn-cta-primary{background:var(--accent);color:#fff;padding:.6rem 1.4rem;border-radius:9px;font-weight:700}
.btn-cta-secondary{background:transparent;color:var(--text2);border:1px solid var(--border2);padding:.6rem 1.4rem;border-radius:9px;font-weight:700}
.btn-cta-secondary:hover{border-color:var(--accent);color:var(--accent)}

/* RELATED */
.related-section{max-width:1000px;margin:0 auto;padding:0 1.5rem 4rem}
.related-section h2{font-family:'Syne',sans-serif;font-size:1.1rem;font-weight:700;
  margin-bottom:1.25rem;padding-bottom:.75rem;border-bottom:1px solid var(--border)}
.related-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1.25rem}
.related-card{background:var(--bg2);border:1px solid var(--border2);border-radius:12px;
  padding:1.25rem;transition:border .15s}
.related-card:hover{border-color:var(--accent)}
.related-card .rc-date{font-size:.72rem;color:var(--muted);margin-bottom:.4rem}
.related-card .rc-title{font-weight:700;font-size:.9rem;line-height:1.4;color:var(--text)}
.related-card .rc-link{font-size:.78rem;color:var(--accent);margin-top:.5rem;display:block}

/* BREADCRUMB */
.breadcrumb{display:flex;align-items:center;gap:.4rem;font-size:.78rem;color:var(--muted);margin-bottom:1.5rem;flex-wrap:wrap}
.breadcrumb a{color:var(--accent)}
.breadcrumb span{opacity:.5}

/* FOOTER */
footer{border-top:1px solid var(--border);padding:2rem 1.5rem;text-align:center;color:var(--muted);font-size:.82rem}
footer a{color:var(--accent)}

/* ---- MOBILE TUNING ---- */
@media(max-width:640px){
  .article-wrap{padding:2rem 1.1rem 3.5rem}
  .article-excerpt{font-size:.95rem;padding-left:.9rem}
  .article-body h2{font-size:1.2rem;margin:1.85rem 0 .6rem}
  .article-body h3{font-size:1rem}
  .article-body p,.article-body li{font-size:.92rem}
  .article-body img{border-radius:9px;margin:1.25rem auto}
  .article-body .video-embed{border-radius:9px;margin:1.25rem 0}
  .article-cta{padding:1.5rem 1.1rem}
  .cta-btns{flex-direction:column}
  .cta-btns a{width:100%;text-align:center}
  .related-grid{grid-template-columns:1fr}
}
</style>
</head>
<body>

<nav>
  <a class="nav-logo" href="/"><span>Chain</span>Mind</a>
  <div class="nav-links">
    <a href="/#what-is-din">What is a DIN?</a>
    <a href="/#who-its-for">Who's it for</a>
    <a href="/#pricing">Pricing</a>
    <a href="/#nodes">Earn</a>
    <a href="/docs.php">Docs</a>
    <a href="/blog/" class="active">Blog</a>
  </div>
  <div class="nav-right">
    <a class="btn btn-ghost" href="/auth/login.php">Sign in</a>
    <a class="btn btn-solid" href="/auth/register.php">Get started free</a>
  </div>
</nav>

<article class="article-wrap">
  <div class="breadcrumb">
    <a href="/">Home</a>
    <span>/</span>
    <a href="/blog/">Blog</a>
    <span>/</span>
    <span><?= htmlspecialchars(substr($post['title'], 0, 40)) . (strlen($post['title']) > 40 ? '…' : '') ?></span>
  </div>

  <div class="article-meta">
    <span class="meta-tag">ChainMind Blog</span>
    <span class="meta-date"><?= date('F j, Y', strtotime($post['created_at'])) ?></span>
  </div>

  <h1 class="article-title"><?= htmlspecialchars($post['title']) ?></h1>

  <?php if ($post['excerpt']): ?>
  <p class="article-excerpt"><?= htmlspecialchars($post['excerpt']) ?></p>
  <?php endif; ?>

  <div class="article-body">
    <?= $post['content'] /* HTML content from admin — already sanitized at write time */ ?>
  </div>

  <div class="article-cta">
    <h3>Ready to build without dollar fees?</h3>
    <p>Access powerful open-source LLMs via ChainMind's OpenAI-compatible API — priced in Naira. No conversion, no surprises.</p>
    <div class="cta-btns">
      <a class="btn-cta-primary" href="/auth/register.php">Get your free API key →</a>
      <a class="btn-cta-secondary" href="/docs.php">Read the docs</a>
    </div>
  </div>
</article>

<?php if (!empty($related_posts)): ?>
<div class="related-section">
  <h2>More from ChainMind</h2>
  <div class="related-grid">
    <?php foreach ($related_posts as $r): ?>
    <a class="related-card" href="/blog/<?= htmlspecialchars($r['slug']) ?>">
      <div class="rc-date"><?= date('M j, Y', strtotime($r['created_at'])) ?></div>
      <div class="rc-title"><?= htmlspecialchars($r['title']) ?></div>
      <span class="rc-link">Read article →</span>
    </a>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<footer>
  <p>&copy; <?= date('Y') ?> ChainMind · <a href="/privacy.php">Privacy</a> · <a href="/terms.php">Terms</a> · Built in Nigeria 🇳🇬</p>
</footer>
</body>
</html>