<?php
// ============================================================
// ChainMind — Google OAuth — Step 2: Handle callback
// Upload to: auth/google-callback.php
// ============================================================

ob_start();
session_start();
require_once __DIR__ . '/../api/_helpers.php';
ob_clean();

$client_id    = getenv('GOOGLE_CLIENT_ID');
$client_secret= getenv('GOOGLE_CLIENT_SECRET');
$redirect_uri = 'https://chainmind.com.ng/auth/google-callback.php';

function goog_post(string $url, array $data): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>http_build_query($data),
        CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_TIMEOUT=>15,CURLOPT_SSL_VERIFYPEER=>true]);
    $body=curl_exec($ch);$err=curl_error($ch);$http=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    if($err||$http!==200){error_log("[Google OAuth] Token exchange failed: curl_err={$err} http={$http} body={$body}");return[];}
    return json_decode($body,true)?:[];
}

function goog_get(string $url, string $token): array {
    $ch=curl_init($url);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_HTTPHEADER=>["Authorization: Bearer {$token}",'Accept: application/json'],
        CURLOPT_TIMEOUT=>12,CURLOPT_SSL_VERIFYPEER=>true]);
    $body=curl_exec($ch);$err=curl_error($ch);curl_close($ch);
    if($err){error_log("[Google OAuth] Userinfo fetch failed: {$err}");return[];}
    return json_decode($body,true)?:[];
}

// CSRF
// State may carry a payload: base64json appended with '.'
$state_raw=$_GET['state']??'';
$state_token=strpos($state_raw,'.')!==false?explode('.',$state_raw,2)[0]:$state_raw;
$stored=$_SESSION['google_oauth_state']??'';unset($_SESSION['google_oauth_state']);
if(!$state_raw||!hash_equals($stored,$state_token)){header('Location: /auth/login.php?error=oauth_state');exit;}
$state=$state_raw;

$code=$_GET['code']??'';
if(!$code){header('Location: /auth/login.php?error=oauth_denied');exit;}

$tokens=goog_post('https://oauth2.googleapis.com/token',[
    'code'=>$code,'client_id'=>$client_id,'client_secret'=>$client_secret,
    'redirect_uri'=>$redirect_uri,'grant_type'=>'authorization_code']);
if(empty($tokens['access_token'])){
    error_log('[Google OAuth] Token exchange failed: '.json_encode($tokens));
    header('Location: /auth/login.php?error=oauth_token');exit;
}

$info=goog_get('https://www.googleapis.com/oauth2/v2/userinfo',$tokens['access_token']);
$google_id=$info['id']??'';$email=strtolower(trim($info['email']??''));
$name=trim($info['name']??'');$email_ok=!empty($info['verified_email']);
if(!$email||!$google_id){header('Location: /auth/login.php?error=oauth_info');exit;}
if(empty($name))$name=explode('@',$email)[0];

$db=db();
$stmt=$db->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
$stmt->execute([$email]);$user=$stmt->fetch();

if($user){
    try{$db->prepare('UPDATE users SET google_id=?,email_verified=GREATEST(email_verified,?) WHERE id=?')
        ->execute([$google_id,$email_ok?1:0,$user['id']]);}catch(\Throwable $e){}
    $_SESSION['user_id']   =(int)$user['id'];$_SESSION['user_email']=$user['email'];
    $_SESSION['user_name'] =$user['name'];   $_SESSION['user_role'] =$user['role'];
    // Check for special action encoded in state
    $state_data = [];
    if (strpos($state, '.') !== false) {
        list(, $state_payload) = explode('.', $state, 2);
        $state_data = json_decode(base64_decode($state_payload), true) ?: [];
    }
    $action = $state_data['action'] ?? '';
    if ($action === 'pw_change') {
        $_SESSION['pw_google_verified'] = time();
        header('Location: /dashboard/profile.php'); exit;
    }
    header('Location: /dashboard/');exit;
}

// New user
$fake_hash=password_hash(bin2hex(random_bytes(24)),PASSWORD_DEFAULT);
try{
    $db->prepare('INSERT INTO users (name,email,password_hash,role,email_verified,google_id,created_at) VALUES(?,?,?,"user",?,?,NOW())')
       ->execute([$name,$email,$fake_hash,$email_ok?1:0,$google_id]);
}catch(\Throwable $e){
    $db->prepare('INSERT INTO users (name,email,password_hash,role,email_verified,created_at) VALUES(?,?,?,"user",?,NOW())')
       ->execute([$name,$email,$fake_hash,$email_ok?1:0]);
}
$user_id=(int)$db->lastInsertId();

// Create API key
$api_key='cm-'.bin2hex(random_bytes(24));
try{
    $db->prepare('INSERT INTO api_keys (user_id,api_key,label,is_active,total_jobs,created_at) VALUES(?,?,"Default",1,0,NOW())')
       ->execute([$user_id,$api_key]);
}catch(\Throwable $e){
    $db->prepare('INSERT INTO api_keys (user_id,api_key,is_active,created_at) VALUES(?,?,1,NOW())')
       ->execute([$user_id,$api_key]);
}
$key_id=(int)$db->lastInsertId();

// 30-credit signup bonus
try{
    $db->prepare('INSERT INTO credits (api_key_id,balance) VALUES(?,30) ON DUPLICATE KEY UPDATE balance=balance+30')
       ->execute([$key_id]);
}catch(\Throwable $e){}

$_SESSION['user_id']   =$user_id;$_SESSION['user_email']=$email;
$_SESSION['user_name'] =$name;   $_SESSION['user_role'] ='user';
header('Location: /auth/pick-role.php');exit;
