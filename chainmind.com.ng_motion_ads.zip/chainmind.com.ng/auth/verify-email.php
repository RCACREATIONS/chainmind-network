<?php
// ============================================================
// ChainMind  Email Verification Handler
// Upload to: auth/verify-email.php
// ============================================================
session_start();
require_once __DIR__ . '/../api/_helpers.php';

$token = trim($_GET['token'] ?? '');

if (!$token) {
    header('Location: /auth/login.php?error=invalid_token'); exit;
}

// Look up token
$stmt = db()->prepare(
    'SELECT * FROM users WHERE verify_token = ? AND verify_token_expires > NOW() LIMIT 1'
);
$stmt->execute([$token]);
$user = $stmt->fetch();

if (!$user) {
    // Token expired or invalid — show friendly page
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><title>Link expired &mdash; ChainMind</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap">
<link rel="icon" type="image/png" href="../ChatGPT Image Jun 2, 2026, 06_43_57 AM.png">
<style>
:root {
  --bg:      #07080f;
  --bg2:     #0b0d1c;
  --bg3:     #101228;
  --border:  #1e2040;
  --border2: #272a52;
  --text:    #eef0ff;
  --text2:   #c5c8f0;
  --muted:   #6b6f9e;
  --purple:  #8b3cf7;
  --indigo:  #4f46e5;
  --accent:  #a78bfa;
  --accent2: #c4b5fd;
  --glow:    rgba(139,60,247,.38);
  --grad:    linear-gradient(135deg,#8b3cf7,#4f46e5);
  --red:     #f87171;
  --red-bg:  rgba(248,113,113,.1);
  --green:   #34d399;
  --green-bg: rgba(52,211,153,.1);
  --orange:  #fb923c;
  --orange-bg: rgba(251,146,60,.1);
  --font:    'Plus Jakarta Sans',system-ui,sans-serif;
  --display: 'Syne',sans-serif;
  --mono:    'JetBrains Mono',monospace;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body {
  background:var(--bg);color:var(--text);font-family:var(--font);
  min-height:100vh;display:flex;flex-direction:column;
  align-items:center;justify-content:center;padding:2rem 1.5rem;
  position:relative;overflow:hidden;
}
body::before {
  content:'';position:fixed;inset:0;
  background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
  opacity:.5;pointer-events:none;z-index:0;
}
body::after {
  content:'';position:fixed;top:-20%;left:50%;transform:translateX(-50%);
  width:700px;height:700px;border-radius:50%;
  background:radial-gradient(ellipse at center,rgba(139,60,247,.18) 0%,transparent 70%);
  pointer-events:none;z-index:0;
}
.auth-card {
  position:relative;z-index:1;width:100%;max-width:440px;
  background:var(--bg2);border:1px solid var(--border2);border-radius:20px;
  padding:2.5rem 2.25rem 2rem;text-align:center;
  box-shadow:0 0 0 1px rgba(139,60,247,.08),0 24px 64px rgba(0,0,0,.55);
}
.logo {
  display:flex;align-items:center;justify-content:center;gap:.6rem;
  margin-bottom:2rem;text-decoration:none;
}
.logo-mark {
  width:36px;height:36px;background:var(--grad);border-radius:10px;
  display:flex;align-items:center;justify-content:center;
  font-family:var(--display);font-size:1.05rem;font-weight:800;color:#fff;
  box-shadow:0 0 20px var(--glow);flex-shrink:0;
}
.logo-text{font-family:var(--display);font-size:1.15rem;font-weight:800;letter-spacing:-.03em;line-height:1;}
.logo-text .chain{color:var(--accent2)}.logo-text .mind{color:var(--text)}
.big-icon{font-size:2.75rem;margin-bottom:1.1rem;display:block}
.auth-title{font-family:var(--display);font-size:1.45rem;font-weight:800;letter-spacing:-.03em;margin-bottom:.45rem}
.auth-sub{color:var(--muted);font-size:.87rem;line-height:1.65;margin-bottom:1.75rem}
.auth-sub strong{color:var(--text2)}
.info-box {
  background:linear-gradient(135deg,rgba(139,60,247,.1),rgba(79,70,229,.06));
  border:1px solid rgba(139,60,247,.22);border-radius:12px;
  padding:1rem 1.25rem;font-size:.84rem;color:var(--text2);
  text-align:left;margin-bottom:1.5rem;line-height:1.6;
}
.info-box .email{font-family:var(--mono);font-size:.82rem;color:var(--accent2);font-weight:600;word-break:break-all}
.btn-primary {
  display:inline-flex;align-items:center;gap:.5rem;
  padding:.7rem 1.5rem;border-radius:11px;border:none;
  font-size:.92rem;font-weight:700;font-family:var(--font);
  cursor:pointer;background:var(--grad);color:#fff;
  box-shadow:0 4px 22px var(--glow);transition:all .2s;text-decoration:none;
}
.btn-primary:hover{opacity:.9;transform:translateY(-1px);box-shadow:0 8px 30px var(--glow)}
.btn-ghost {
  display:inline-flex;align-items:center;gap:.5rem;
  padding:.65rem 1.4rem;border-radius:10px;
  font-size:.88rem;font-weight:600;font-family:var(--font);
  background:transparent;border:1px solid var(--border2);color:var(--muted);
  text-decoration:none;transition:.18s;cursor:pointer;
}
.btn-ghost:hover{border-color:rgba(139,60,247,.4);color:var(--accent)}
.divider{border:none;border-top:1px solid var(--border);margin:1.5rem 0 1.25rem}
.footer-link{font-size:.83rem;color:var(--muted);margin-top:.6rem}
.footer-link a{color:var(--accent);text-decoration:none;font-weight:600}
.footer-link a:hover{color:var(--accent2)}
.err-box{background:var(--red-bg);border:1px solid rgba(248,113,113,.28);border-radius:10px;
  padding:.7rem 1rem;font-size:.84rem;color:var(--red);margin-bottom:1.25rem;text-align:left}
.ok-box{background:var(--green-bg);border:1px solid rgba(52,211,153,.28);border-radius:10px;
  padding:.7rem 1rem;font-size:.84rem;color:var(--green);margin-bottom:1.25rem}
.step-list{list-style:none;text-align:left;margin:1rem 0 1.5rem;display:flex;flex-direction:column;gap:.65rem}
.step-list li{display:flex;align-items:flex-start;gap:.75rem;font-size:.85rem;color:var(--text2)}
.step-num{width:22px;height:22px;border-radius:50%;background:var(--grad);display:flex;
  align-items:center;justify-content:center;font-size:.68rem;font-weight:800;color:#fff;flex-shrink:0;margin-top:.05rem}
.back-link{display:block;text-align:center;color:var(--muted);font-size:.8rem;
  text-decoration:none;margin-top:1.5rem;position:relative;z-index:1;transition:color .15s}
.back-link:hover{color:var(--text2)}
::-webkit-scrollbar{width:5px}::-webkit-scrollbar-thumb{background:var(--border2);border-radius:20px}
</style>
</head>
<body>
<div class="auth-card">
  <a href="/" class="logo">
    <div class="logo-mark">C</div>
    <div class="logo-text"><span class="chain">Chain</span><span class="mind">Mind</span></div>
  </a>

  <span class="big-icon">&#9203;</span>
  <h1 class="auth-title" style="color:var(--red)">Link expired</h1>
  <p class="auth-sub">
    This verification link is no longer valid.<br>
    Links expire after <strong>1 hour</strong> for security.
  </p>

  <a class="btn-primary" href="/auth/login.php" style="width:100%;justify-content:center">
    Sign in to resend
  </a>

  <hr class="divider">
  <p class="footer-link">Need help? <a href="mailto:support@chainmind.com.ng">Contact support</a></p>
</div>
<a class="back-link" href="/">&larr; Back to ChainMind</a>
</body>
</html>
    <?php
    exit;

}

// Mark verified + clear token
db()->prepare(
    'UPDATE users SET email_verified = 1, verify_token = NULL, verify_token_expires = NULL WHERE id = ?'
)->execute([$user['id']]);

// Auto-login
$_SESSION['user_id']    = $user['id'];
$_SESSION['user_email'] = $user['email'];
$_SESSION['user_name']  = $user['name'];
$_SESSION['user_role']  = $user['role'];

// Node operator first login → download page; others → dashboard
$is_node  = $user['role'] === 'node';
$is_first = (int)($user['first_login'] ?? 1); // still 1 at verification time

if ($is_node && $is_first) {
    header('Location: /dashboard/node-download.php'); exit;
}

header('Location: /dashboard/'); exit;
