<?php
// ============================================================
// ChainMind  Role picker — shown once to new users after signup
// Upload to: auth/pick-role.php
// ============================================================
session_start();

// Must be logged in to see this page
if (empty($_SESSION['user_id'])) {
    header('Location: /auth/login.php'); exit;
}

// If they somehow land here again after already picking, send them on
require_once __DIR__ . '/../api/_helpers.php';
$db = db();

// Ensure account_type column exists before querying it
try {
    $row = $db->prepare('SELECT role FROM users WHERE id = ? LIMIT 1');
    $row->execute([$_SESSION['user_id']]);
    $u   = $row->fetch();
} catch (\PDOException $e) {
    if (strpos($e->getMessage(), '1054') !== false || strpos($e->getMessage(), 'role') !== false) {
        $db->exec("ALTER TABLE users ADD COLUMN role VARCHAR(30) DEFAULT NULL");
        $u = ['role' => null];
    } else {
        throw $e;
    }
}

if (!empty($u['role'])) {
    header('Location: /dashboard/'); exit;
}

// ── Handle POST ───────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pick = $_POST['role'] ?? '';
    if (!in_array($pick, ['user', 'node'], true)) {
        $error = 'Please choose one of the options below.';
    } else {
        $db->prepare('UPDATE users SET role = ? WHERE id = ?')
           ->execute([$pick, $_SESSION['user_id']]);

        $_SESSION['role'] = $pick;

        if ($pick === 'node') {
            header('Location: /dashboard/node-download.php'); exit;
        }
        header('Location: /dashboard/'); exit;
    }
}

$name = htmlspecialchars($_SESSION['user_name'] ?? 'there', ENT_QUOTES);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Welcome to ChainMind — Pick your role</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --purple:#8b3cf7;--indigo:#4f46e5;--accent:#a78bfa;--accent2:#c4b5fd;
  --glow:rgba(139,60,247,.38);--grad:linear-gradient(135deg,#8b3cf7,#4f46e5);
  --bg:#080a17;--bg2:#0d0e1c;--bg3:#11132a;--bg4:#161935;
  --border:rgba(139,60,247,.18);--border2:rgba(139,60,247,.32);
  --text:#eeeeff;--text2:#c5c8f0;--muted:#6b6fa0;
  --font:'Plus Jakarta Sans',sans-serif;--display:'Syne',sans-serif;
  --red:#f87171;--green:#6ee7b7;
}
html,body{height:100%}
body{
  font-family:var(--font);background:var(--bg);color:var(--text);
  display:flex;align-items:center;justify-content:center;min-height:100vh;
  padding:1.5rem;
}
body::before{
  content:'';position:fixed;inset:0;
  background:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.04'/%3E%3C/svg%3E");
  pointer-events:none;z-index:0;
}
body::after{
  content:'';position:fixed;top:-20%;left:50%;transform:translateX(-50%);
  width:70vw;height:70vw;max-width:700px;max-height:700px;border-radius:50%;
  background:radial-gradient(circle,var(--glow) 0%,transparent 70%);
  pointer-events:none;z-index:0;
}
.card{
  position:relative;z-index:1;width:100%;max-width:520px;
  background:var(--bg2);border:1px solid var(--border);border-radius:20px;
  padding:2.4rem 2.2rem;box-shadow:0 0 60px rgba(139,60,247,.13);
}
.logo{display:flex;align-items:center;gap:.65rem;margin-bottom:2rem;justify-content:center}
.logo-mark{
  width:38px;height:38px;border-radius:9px;
  background:var(--grad);display:flex;align-items:center;justify-content:center;
  font-family:var(--display);font-weight:800;font-size:1.15rem;color:#fff;
  box-shadow:0 4px 18px rgba(139,60,247,.5);
}
.logo-text{font-family:var(--display);font-size:1.2rem;font-weight:700}
.logo-text .chain{color:var(--accent2)}.logo-text .mind{color:var(--text)}
h1{font-family:var(--display);font-size:1.45rem;font-weight:700;text-align:center;margin-bottom:.45rem}
.sub{color:var(--muted);font-size:.875rem;text-align:center;line-height:1.55;margin-bottom:1.8rem}
.alert{
  padding:.75rem 1rem;border-radius:10px;font-size:.85rem;font-weight:500;margin-bottom:1.2rem;
}
.alert.error{background:rgba(248,113,113,.1);border:1px solid rgba(248,113,113,.3);color:#fca5a5}
.options{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:14px;
  margin-bottom:1.5rem;
}
@media(max-width:480px){
  .options{grid-template-columns:1fr}
  .card{padding:2rem 1.4rem}
}
.option{position:relative;cursor:pointer}
.option input[type="radio"]{position:absolute;opacity:0;width:0;height:0}
.option-label{
  display:block;
  border:1.5px solid var(--border);
  border-radius:14px;
  padding:1.6rem 1.2rem 1.4rem;
  background:var(--bg3);
  transition:border-color .18s,background .18s,box-shadow .18s;
  cursor:pointer;
  text-align:center;
}
.option-label:hover{
  border-color:var(--border2);
  background:var(--bg4);
}
.option input:checked + .option-label{
  border-color:var(--purple);
  background:rgba(139,60,247,.08);
  box-shadow:0 0 0 3px rgba(139,60,247,.15),0 4px 24px rgba(139,60,247,.18);
}
.option-icon-wrap{
  display:inline-flex;
  align-items:center;justify-content:center;
  width:54px;height:54px;border-radius:14px;
  background:var(--bg4);
  border:1px solid var(--border);
  margin-bottom:1rem;
  transition:background .18s,border-color .18s,box-shadow .18s;
}
.option input:checked + .option-label .option-icon-wrap{
  background:var(--grad);
  border-color:transparent;
  box-shadow:0 4px 16px rgba(139,60,247,.4);
}
.option-icon{font-size:1.6rem;line-height:1;display:block}
.option-title{
  font-family:var(--display);
  font-size:.98rem;font-weight:700;
  margin-bottom:.5rem;
  color:var(--text);
  display:block;
}
.option-desc{
  font-size:.78rem;
  color:var(--muted);
  line-height:1.55;
  display:block;
}
.btn{
  width:100%;padding:.78rem;border:none;border-radius:11px;
  background:var(--grad);color:#fff;font:inherit;font-size:.95rem;font-weight:700;
  cursor:pointer;transition:opacity .18s,transform .12s;
  box-shadow:0 4px 20px rgba(139,60,247,.35);
}
.btn:hover{opacity:.9;transform:translateY(-1px)}
.hint{
  margin-top:1.1rem;font-size:.78rem;
  color:var(--muted);text-align:center;
}
</style>
</head>
<body>
<div class="card">

  <div class="logo">
    <div class="logo-mark">C</div>
    <div class="logo-text"><span class="chain">Chain</span><span class="mind">Mind</span></div>
  </div>

  <h1>Welcome, <?= $name ?>!</h1>
  <p class="sub">You're almost in. Tell us how you plan to use ChainMind so we can set up the right dashboard for you.</p>

  <?php if (!empty($error)): ?>
    <div class="alert error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST" action="/auth/pick-role.php">
    <div class="options">

      <label class="option">
        <input type="radio" name="role" value="user" required>
        <span class="option-label">
          <span class="option-icon-wrap">
            <span class="option-icon">⚡</span>
          </span>
          <span class="option-title">API User</span>
          <span class="option-desc">Send jobs to the network. Use ChainMind's API to run AI inference from your apps or scripts.</span>
        </span>
      </label>

      <label class="option">
        <input type="radio" name="role" value="node">
        <span class="option-label">
          <span class="option-icon-wrap">
            <span class="option-icon">🖥️</span>
          </span>
          <span class="option-title">Node Operator</span>
          <span class="option-desc">Contribute GPU power to the network and earn credits for every job your node completes.</span>
        </span>
      </label>

    </div>

    <button type="submit" class="btn">Continue →</button>
  </form>

  <p class="hint">You can add or change roles later from your account settings.</p>

</div>
</body>
</html>