<?php
// ============================================================
// ChainMind  Login Page
// Upload to: auth/login.php
// ============================================================
session_start();
if (isset($_SESSION['user_id'])) { header('Location: /dashboard/'); exit; }
$error  = $_GET['error']  ?? '';
$redir  = $_GET['next']   ?? '/dashboard/';
$errors = [
    'invalid'  => 'Invalid email or password.',
    'inactive' => 'Account not active. Contact support.',
        'google_not_configured' => 'Google Sign-In is not set up yet. Use email/password for now.',
    'oauth_state'   => 'Invalid request. Please try again.',
    'oauth_denied'  => 'Google sign-in was cancelled.',
    'oauth_token'   => 'Could not complete Google sign-in. Please try again.',
    'oauth_info'    => 'Could not retrieve your Google profile. Please try again.',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><title>Sign in &mdash; ChainMind</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap">
<link rel="icon" type="image/png" href="../ChatGPT Image Jun 2, 2026, 06_43_57 AM.png">
<style>
:root {
  --bg:      #07080f;
  --bg2:     #0b0d1c;
  --bg3:     #101228;
  --border:  #1e2040;
  --border2: #272a52;
  --text:    #eef0ff;
  --text2:   #c5c8f0;
  --muted:   #6b6f9e;
  --purple:  #8b3cf7;
  --indigo:  #4f46e5;
  --accent:  #a78bfa;
  --accent2: #c4b5fd;
  --glow:    rgba(139,60,247,.38);
  --grad:    linear-gradient(135deg,#8b3cf7,#4f46e5);
  --red:     #f87171;
  --red-bg:  rgba(248,113,113,.1);
  --green:   #34d399;
  --green-bg: rgba(52,211,153,.1);
  --font:    'Plus Jakarta Sans',system-ui,sans-serif;
  --display: 'Syne',sans-serif;
  --mono:    'JetBrains Mono',monospace;
}

*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}

body {
  background: var(--bg);
  color: var(--text);
  font-family: var(--font);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 1.5rem;
  position: relative;
  overflow: hidden;
}

/* Noise */
body::before {
  content: '';
  position: fixed;
  inset: 0;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
  opacity: .5;
  pointer-events: none;
  z-index: 0;
}

/* Glow orb */
body::after {
  content: '';
  position: fixed;
  top: -20%;
  left: 50%;
  transform: translateX(-50%);
  width: 700px;
  height: 700px;
  border-radius: 50%;
  background: radial-gradient(ellipse at center, rgba(139,60,247,.18) 0%, transparent 70%);
  pointer-events: none;
  z-index: 0;
}

/* ─── CARD ─── */
.auth-card {
  position: relative;
  z-index: 1;
  width: 100%;
  max-width: 420px;
  background: var(--bg2);
  border: 1px solid var(--border2);
  border-radius: 20px;
  padding: 2.5rem 2.25rem 2rem;
  box-shadow: 0 0 0 1px rgba(139,60,247,.08), 0 24px 64px rgba(0,0,0,.55);
}

/* ─── LOGO ─── */
.logo {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: .6rem;
  margin-bottom: 2rem;
  text-decoration: none;
}
.logo-mark {
  width: 36px;
  height: 36px;
  background: var(--grad);
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--display);
  font-size: 1.05rem;
  font-weight: 800;
  color: #fff;
  box-shadow: 0 0 20px var(--glow);
  flex-shrink: 0;
}
.logo-text {
  font-family: var(--display);
  font-size: 1.15rem;
  font-weight: 800;
  letter-spacing: -.03em;
  line-height: 1;
}
.logo-text .chain { color: var(--accent2); }
.logo-text .mind  { color: var(--text); }

/* ─── HEADINGS ─── */
.auth-title {
  font-family: var(--display);
  font-size: 1.5rem;
  font-weight: 800;
  text-align: center;
  letter-spacing: -.03em;
  margin-bottom: .4rem;
}
.auth-sub {
  text-align: center;
  color: var(--muted);
  font-size: .86rem;
  margin-bottom: 2rem;
  line-height: 1.5;
}

/* ─── FORM ─── */
.form-group {
  margin-bottom: 1.1rem;
}
label {
  display: block;
  font-size: .78rem;
  font-weight: 600;
  color: var(--muted);
  margin-bottom: .35rem;
  letter-spacing: .01em;
  text-transform: uppercase;
}
input[type=email],
input[type=password],
input[type=text] {
  width: 100%;
  padding: .7rem .95rem;
  border-radius: 10px;
  border: 1px solid var(--border2);
  background: var(--bg3);
  color: var(--text);
  font-size: .9rem;
  font-family: var(--font);
  outline: none;
  transition: border-color .18s, box-shadow .18s;
}
input:focus {
  border-color: rgba(139,60,247,.6);
  box-shadow: 0 0 0 3px rgba(139,60,247,.12);
}
input::placeholder { color: var(--muted); opacity: .7; }

.btn-submit {
  width: 100%;
  padding: .75rem;
  border-radius: 11px;
  border: none;
  font-size: .95rem;
  font-weight: 700;
  font-family: var(--font);
  letter-spacing: -.01em;
  cursor: pointer;
  margin-top: .5rem;
  background: var(--grad);
  color: #fff;
  box-shadow: 0 4px 22px var(--glow);
  transition: all .2s;
}
.btn-submit:hover {
  opacity: .9;
  transform: translateY(-1px);
  box-shadow: 0 8px 30px var(--glow);
}
.btn-submit:active { transform: none; }

/* ─── ALERTS ─── */
.err-box {
  background: var(--red-bg);
  border: 1px solid rgba(248,113,113,.28);
  border-radius: 10px;
  padding: .7rem 1rem;
  font-size: .84rem;
  color: var(--red);
  margin-bottom: 1.25rem;
  display: flex;
  align-items: center;
  gap: .5rem;
}
.ok-box {
  background: var(--green-bg);
  border: 1px solid rgba(52,211,153,.28);
  border-radius: 10px;
  padding: .7rem 1rem;
  font-size: .84rem;
  color: var(--green);
  margin-bottom: 1.25rem;
}

/* ─── DIVIDER ─── */
.divider {
  border: none;
  border-top: 1px solid var(--border);
  margin: 1.5rem 0 1.25rem;
}

/* ─── FOOTER LINKS ─── */
.footer-link {
  text-align: center;
  font-size: .84rem;
  color: var(--muted);
  margin-top: .75rem;
}
.footer-link a {
  color: var(--accent);
  text-decoration: none;
  font-weight: 600;
  transition: color .15s;
}
.footer-link a:hover { color: var(--accent2); }

.back-link {
  display: block;
  text-align: center;
  color: var(--muted);
  font-size: .8rem;
  text-decoration: none;
  margin-top: 1.5rem;
  position: relative;
  z-index: 1;
  transition: color .15s;
}
.back-link:hover { color: var(--text2); }

/* scrollbar */
::-webkit-scrollbar{width:5px}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:20px}
/* ─── GOOGLE BUTTON ─── */
.btn-google {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: .7rem;
  padding: .7rem 1rem;
  border-radius: 11px;
  border: 1px solid var(--border2);
  background: var(--bg3);
  color: var(--text2);
  font-size: .92rem;
  font-weight: 600;
  font-family: var(--font);
  cursor: pointer;
  text-decoration: none;
  transition: all .18s;
  margin-bottom: 1.1rem;
}
.btn-google:hover {
  border-color: rgba(255,255,255,.2);
  background: var(--bg4, #161935);
  color: var(--text);
}
.btn-google svg { flex-shrink: 0; }

/* ─── OR DIVIDER ─── */
.or-divider {
  display: flex;
  align-items: center;
  gap: .75rem;
  margin-bottom: 1.1rem;
  color: var(--muted);
  font-size: .78rem;
  font-weight: 600;
  letter-spacing: .05em;
  text-transform: uppercase;
}
.or-divider::before,
.or-divider::after {
  content: '';
  flex: 1;
  height: 1px;
  background: var(--border);
}

</style>
</head>
<body>
<div class="auth-card">
  <a href="/" class="logo">
    <div class="logo-mark">C</div>
    <div class="logo-text"><span class="chain">Chain</span><span class="mind">Mind</span></div>
  </a>

  <h1 class="auth-title">Welcome back</h1>
  <p class="auth-sub">Sign in to access your dashboard and API keys</p>

  <?php if ($error && isset($errors[$error])): ?>
    <div class="err-box">&#9888; <?= $errors[$error] ?></div>
  <?php endif; ?>

  <a href="/auth/google.php" class="btn-google">
    <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.31-8.16 2.31-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
      <path fill="none" d="M0 0h48v48H0z"/>
    </svg>
    Continue with Google
  </a>
  <div class="or-divider">or</div>

  <form method="POST" action="/api/auth/login.php">
    <input type="hidden" name="next" value="<?= htmlspecialchars($redir) ?>">
    <div class="form-group">
      <label for="email">Email address</label>
      <input type="email" id="email" name="email" required autocomplete="email" autofocus placeholder="you@example.com">
    </div>
    <div class="form-group">
      <label for="password">Password</label>
      <input type="password" id="password" name="password" required autocomplete="current-password" placeholder="••••••••">
    </div>
    <div style="text-align:right;margin-bottom:.85rem">
      <a href="/auth/forgot-password.php" style="font-size:.8rem;color:var(--muted);text-decoration:none" onmouseover="this.style.color='var(--accent2)'" onmouseout="this.style.color='var(--muted)'">Forgot password?</a>
    </div>
    <button class="btn-submit" type="submit">Sign in &rarr;</button>
  </form>

  <hr class="divider">
  <p class="footer-link">Don&rsquo;t have an account? <a href="/auth/register.php">Create one free</a></p>
  <p class="footer-link" style="margin-top:.4rem">
    <a href="/auth/register.php?role=node" style="color:var(--muted);font-weight:500">Registering a node? &rarr;</a>
  </p>
</div>
<a class="back-link" href="/">&larr; Back to ChainMind</a>
</body>
</html>
