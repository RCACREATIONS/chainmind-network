<?php
// ============================================================
// ChainMind  Google OAuth — Step 1: Redirect to Google
// Upload to: auth/google.php
//
// Requires two env vars (set in your hosting control panel):
//   GOOGLE_CLIENT_ID     — from Google Cloud Console
//   GOOGLE_CLIENT_SECRET — from Google Cloud Console
//
// In Google Cloud Console → Credentials → OAuth Client:
//   Authorised redirect URI: https://chainmind.com.ng/auth/google-callback.php
// ============================================================
session_start();

$client_id    = getenv('GOOGLE_CLIENT_ID');
$redirect_uri = 'https://chainmind.com.ng/auth/google-callback.php';

if (!$client_id) {
    // Google not configured yet — send back with a friendly note
    header('Location: /auth/login.php?error=google_not_configured'); exit;
}

// Random state token to prevent CSRF
$state = bin2hex(random_bytes(20));
$_SESSION['google_oauth_state'] = $state;

$params = http_build_query([
    'client_id'     => $client_id,
    'redirect_uri'  => $redirect_uri,
    'response_type' => 'code',
    'scope'         => 'openid email profile',
    'state'         => $state,
    'access_type'   => 'online',
    'prompt'        => 'select_account',   // always show account picker
]);

header('Location: https://accounts.google.com/o/oauth2/v2/auth?' . $params);
exit;
