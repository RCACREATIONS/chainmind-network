<?php
session_start();
$token = trim($_GET['token'] ?? '');
$error = match($_GET['error'] ?? '') {
    'no_token'      => 'Invalid or missing reset link.',
    'invalid_token' => 'This reset link is invalid or has already been used.',
    'expired'       => 'This reset link has expired. Please request a new one.',
    'short'         => 'Password must be at least 8 characters.',
    'mismatch'      => 'Passwords do not match.',
    'failed'        => 'Could not update password. Please try again.',
    default         => '',
};
$success = isset($_GET['done']);

if (!$token && !$success) {
    header('Location: /auth/forgot-password.php?error=no_token'); exit;
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>New Password — ChainMind</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --purple:#8b3cf7;--indigo:#4f46e5;--accent:#a78bfa;--accent2:#c4b5fd;
  --glow:rgba(139,60,247,.38);--grad:linear-gradient(135deg,#8b3cf7,#4f46e5);
  --bg:#080a17;--bg2:#0d0e1c;--bg3:#11132a;
  --border:rgba(139,60,247,.18);--border2:rgba(139,60,247,.32);
  --text:#eeeeff;--text2:#c5c8f0;--muted:#6b6fa0;
  --font:'Plus Jakarta Sans',sans-serif;--display:'Syne',sans-serif;
  --red:#f87171;--green:#6ee7b7;
}
html,body{height:100%}
body{
  font-family:var(--font);background:var(--bg);color:var(--text);
  display:flex;align-items:center;justify-content:center;min-height:100vh;padding:1.5rem;
}
body::before{
  content:'';position:fixed;inset:0;
  background:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.04'/%3E%3C/svg%3E");
  pointer-events:none;z-index:0;
}
body::after{
  content:'';position:fixed;top:-20%;left:50%;transform:translateX(-50%);
  width:70vw;height:70vw;max-width:700px;max-height:700px;border-radius:50%;
  background:radial-gradient(circle,var(--glow) 0%,transparent 70%);
  pointer-events:none;z-index:0;
}
.card{
  position:relative;z-index:1;width:100%;max-width:420px;
  background:var(--bg2);border:1px solid var(--border);border-radius:20px;
  padding:2.4rem 2.2rem;box-shadow:0 0 60px rgba(139,60,247,.13);
}
.logo{display:flex;align-items:center;gap:.65rem;margin-bottom:2rem;justify-content:center}
.logo-mark{
  width:38px;height:38px;border-radius:9px;background:var(--grad);
  display:flex;align-items:center;justify-content:center;
  font-family:var(--display);font-weight:800;font-size:1.15rem;color:#fff;
  box-shadow:0 4px 18px rgba(139,60,247,.5);
}
.logo-text{font-family:var(--display);font-size:1.2rem;font-weight:700}
.logo-text .chain{color:var(--accent2)}.logo-text .mind{color:var(--text)}
h1{font-family:var(--display);font-size:1.45rem;font-weight:700;text-align:center;margin-bottom:.45rem}
.sub{color:var(--muted);font-size:.875rem;text-align:center;line-height:1.55;margin-bottom:1.8rem}
.alert{padding:.75rem 1rem;border-radius:10px;font-size:.85rem;font-weight:500;margin-bottom:1.2rem}
.alert.error{background:rgba(248,113,113,.1);border:1px solid rgba(248,113,113,.3);color:#fca5a5}
.field{margin-bottom:1.1rem;position:relative}
label{display:block;font-size:.8rem;font-weight:600;color:var(--text2);margin-bottom:.45rem;letter-spacing:.02em;text-transform:uppercase}
.pw-wrap{position:relative}
input[type=password],input[type=text]{
  width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:10px;
  padding:.72rem 2.6rem .72rem 1rem;color:var(--text);font:inherit;font-size:.92rem;
  outline:none;transition:border .18s;
}
input[type=password]:focus,input[type=text]:focus{border-color:var(--purple)}
input::placeholder{color:var(--muted)}
.eye{
  position:absolute;right:.85rem;top:50%;transform:translateY(-50%);
  background:none;border:none;color:var(--muted);cursor:pointer;padding:0;line-height:1;
}
.eye:hover{color:var(--accent2)}
.strength{display:flex;gap:4px;margin-top:.5rem}
.strength span{flex:1;height:3px;border-radius:2px;background:var(--bg3);transition:background .25s}
.s1{background:var(--red)!important}.s2{background:#fbbf24!important}.s3{background:#34d399!important}
.hint{font-size:.75rem;color:var(--muted);margin-top:.35rem}
.btn{
  width:100%;padding:.78rem;border:none;border-radius:11px;
  background:var(--grad);color:#fff;font:inherit;font-size:.95rem;font-weight:700;
  cursor:pointer;transition:opacity .18s,transform .12s;margin-top:.3rem;
  box-shadow:0 4px 20px rgba(139,60,247,.35);
}
.btn:hover{opacity:.9;transform:translateY(-1px)}
.back{display:block;text-align:center;margin-top:1.4rem;color:var(--muted);font-size:.85rem;text-decoration:none}
.back:hover{color:var(--accent2)}
.success-icon{
  width:56px;height:56px;border-radius:50%;background:rgba(110,231,183,.12);
  border:1px solid rgba(110,231,183,.3);display:flex;align-items:center;justify-content:center;
  margin:0 auto 1.4rem;
}
</style>
</head>
<body>
<div class="card">
  <div class="logo">
    <div class="logo-mark">C</div>
    <div class="logo-text"><span class="chain">Chain</span><span class="mind">Mind</span></div>
  </div>

<?php if ($success): ?>
  <div class="success-icon">
    <svg width="24" height="24" fill="none" stroke="#6ee7b7" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
      <path d="M20 6L9 17l-5-5"/>
    </svg>
  </div>
  <h1>Password updated!</h1>
  <p class="sub">Your password has been changed. You can now sign in with your new password.</p>
  <a href="/auth/login.php" class="back" style="display:block;text-align:center;margin-top:1.2rem;
     background:var(--grad);color:#fff;padding:.72rem;border-radius:11px;font-weight:700;text-decoration:none">
    Sign in now
  </a>

<?php else: ?>
  <h1>New password</h1>
  <p class="sub">Choose a strong password for your account.</p>

  <?php if ($error): ?>
    <div class="alert error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST" action="/api/auth/reset-password.php" id="pwForm">
    <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">

    <div class="field">
      <label>New password</label>
      <div class="pw-wrap">
        <input type="password" name="password" id="pw1" placeholder="At least 8 characters" required autocomplete="new-password">
        <button type="button" class="eye" onclick="togglePw('pw1',this)" aria-label="Show password">
          <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
        </button>
      </div>
      <div class="strength" id="strength">
        <span id="s1"></span><span id="s2"></span><span id="s3"></span><span id="s4"></span>
      </div>
      <div class="hint" id="hint"></div>
    </div>

    <div class="field">
      <label>Confirm password</label>
      <div class="pw-wrap">
        <input type="password" name="password_confirm" id="pw2" placeholder="Repeat your password" required autocomplete="new-password">
        <button type="button" class="eye" onclick="togglePw('pw2',this)" aria-label="Show password">
          <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
        </button>
      </div>
    </div>

    <button class="btn" type="submit">Update password</button>
  </form>
<?php endif; ?>
</div>

<script>
function togglePw(id, btn) {
  const el = document.getElementById(id);
  const show = el.type === 'password';
  el.type = show ? 'text' : 'password';
  btn.style.color = show ? 'var(--accent2)' : 'var(--muted)';
}

const pw1 = document.getElementById('pw1');
const bars = [document.getElementById('s1'),document.getElementById('s2'),
              document.getElementById('s3'),document.getElementById('s4')];
const hint = document.getElementById('hint');
if (pw1) {
  pw1.addEventListener('input', () => {
    const v = pw1.value;
    let score = 0;
    if (v.length >= 8) score++;
    if (/[A-Z]/.test(v)) score++;
    if (/[0-9]/.test(v)) score++;
    if (/[^A-Za-z0-9]/.test(v)) score++;
    const cls = ['','s1','s2','s3','s3'];
    bars.forEach((b,i) => { b.className = i < score ? cls[score] : ''; });
    const labels = ['','Weak','Fair','Good','Strong'];
    hint.textContent = v.length ? labels[score] : '';
    hint.style.color = ['','var(--red)','#fbbf24','#34d399','#6ee7b7'][score];
  });
}
</script>
</body>
</html>
