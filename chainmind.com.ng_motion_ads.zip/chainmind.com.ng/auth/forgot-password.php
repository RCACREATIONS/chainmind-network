<?php
session_start();
$error   = match($_GET['error'] ?? '') {
    'no_email'    => 'Please enter your email address.',
    'invalid_email'=> 'Please enter a valid email address.',
    'rate_limit'  => 'Too many requests. Please wait 15 minutes and try again.',
    'send_failed' => 'Could not send the email. Please try again shortly.',
    default       => '',
};
$success = isset($_GET['sent']);
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reset Password — ChainMind</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --purple:#8b3cf7;--indigo:#4f46e5;--accent:#a78bfa;--accent2:#c4b5fd;
  --glow:rgba(139,60,247,.38);--grad:linear-gradient(135deg,#8b3cf7,#4f46e5);
  --bg:#080a17;--bg2:#0d0e1c;--bg3:#11132a;--bg4:#161935;
  --border:rgba(139,60,247,.18);--border2:rgba(139,60,247,.32);
  --text:#eeeeff;--text2:#c5c8f0;--muted:#6b6fa0;
  --font:'Plus Jakarta Sans',sans-serif;--display:'Syne',sans-serif;
  --red:#f87171;--green:#6ee7b7;
}
html,body{height:100%}
body{
  font-family:var(--font);background:var(--bg);color:var(--text);
  display:flex;align-items:center;justify-content:center;min-height:100vh;
  padding:1.5rem;
}
body::before{
  content:'';position:fixed;inset:0;
  background:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.04'/%3E%3C/svg%3E");
  pointer-events:none;z-index:0;
}
body::after{
  content:'';position:fixed;top:-20%;left:50%;transform:translateX(-50%);
  width:70vw;height:70vw;max-width:700px;max-height:700px;border-radius:50%;
  background:radial-gradient(circle,var(--glow) 0%,transparent 70%);
  pointer-events:none;z-index:0;
}
.card{
  position:relative;z-index:1;width:100%;max-width:420px;
  background:var(--bg2);border:1px solid var(--border);border-radius:20px;
  padding:2.4rem 2.2rem;box-shadow:0 0 60px rgba(139,60,247,.13);
}
.logo{display:flex;align-items:center;gap:.65rem;margin-bottom:2rem;justify-content:center}
.logo-mark{
  width:38px;height:38px;border-radius:9px;
  background:var(--grad);display:flex;align-items:center;justify-content:center;
  font-family:var(--display);font-weight:800;font-size:1.15rem;color:#fff;
  box-shadow:0 4px 18px rgba(139,60,247,.5);
}
.logo-text{font-family:var(--display);font-size:1.2rem;font-weight:700}
.logo-text .chain{color:var(--accent2)}.logo-text .mind{color:var(--text)}
h1{font-family:var(--display);font-size:1.45rem;font-weight:700;text-align:center;margin-bottom:.45rem}
.sub{color:var(--muted);font-size:.875rem;text-align:center;line-height:1.55;margin-bottom:1.8rem}
.alert{
  padding:.75rem 1rem;border-radius:10px;font-size:.85rem;font-weight:500;margin-bottom:1.2rem;
}
.alert.error{background:rgba(248,113,113,.1);border:1px solid rgba(248,113,113,.3);color:#fca5a5}
.alert.success{background:rgba(110,231,183,.1);border:1px solid rgba(110,231,183,.3);color:var(--green)}
.field{margin-bottom:1.1rem}
label{display:block;font-size:.8rem;font-weight:600;color:var(--text2);margin-bottom:.45rem;letter-spacing:.02em;text-transform:uppercase}
input[type=email]{
  width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:10px;
  padding:.72rem 1rem;color:var(--text);font:inherit;font-size:.92rem;
  outline:none;transition:border .18s;
}
input[type=email]:focus{border-color:var(--purple)}
input[type=email]::placeholder{color:var(--muted)}
.btn{
  width:100%;padding:.78rem;border:none;border-radius:11px;
  background:var(--grad);color:#fff;font:inherit;font-size:.95rem;font-weight:700;
  cursor:pointer;transition:opacity .18s,transform .12s;margin-top:.3rem;
  box-shadow:0 4px 20px rgba(139,60,247,.35);
}
.btn:hover{opacity:.9;transform:translateY(-1px)}
.back{display:block;text-align:center;margin-top:1.4rem;color:var(--muted);font-size:.85rem;text-decoration:none}
.back:hover{color:var(--accent2)}
.success-icon{
  width:56px;height:56px;border-radius:50%;background:rgba(110,231,183,.12);
  border:1px solid rgba(110,231,183,.3);display:flex;align-items:center;justify-content:center;
  margin:0 auto 1.4rem;
}
</style>
</head>
<body>
<div class="card">
  <div class="logo">
    <div class="logo-mark">C</div>
    <div class="logo-text"><span class="chain">Chain</span><span class="mind">Mind</span></div>
  </div>

<?php if ($success): ?>
  <div class="success-icon">
    <svg width="24" height="24" fill="none" stroke="#6ee7b7" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
      <path d="M20 6L9 17l-5-5"/>
    </svg>
  </div>
  <h1>Check your inbox</h1>
  <p class="sub">If that email is registered, we've sent a password reset link. It expires in <strong>30 minutes</strong>.</p>
  <a href="/auth/login.php" class="back">← Back to sign in</a>

<?php else: ?>
  <h1>Reset password</h1>
  <p class="sub">Enter the email on your account and we'll send you a reset link.</p>

  <?php if ($error): ?>
    <div class="alert error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST" action="/api/auth/forgot-password.php">
    <div class="field">
      <label>Email address</label>
      <input type="email" name="email" placeholder="you@example.com"
             value="<?= htmlspecialchars($_GET['email'] ?? '') ?>" required autofocus>
    </div>
    <button class="btn" type="submit">Send reset link</button>
  </form>
  <a href="/auth/login.php" class="back">← Back to sign in</a>
<?php endif; ?>
</div>
</body>
</html>
