<?php
// ============================================================
// ChainMind  Register Page
// Upload to: auth/register.php
// ============================================================
session_start();
if (isset($_SESSION['user_id'])) { header('Location: /dashboard/'); exit; }
$error = $_GET['error'] ?? '';
$role  = $_GET['role']  ?? 'user';
$errors = [
    'email_taken' => 'That email is already registered. <a href="/auth/login.php" style="color:var(--red)">Sign in instead</a>.',
    'weak_pass'   => 'Password must be at least 8 characters.',
    'mismatch'    => 'Passwords do not match.',
    'failed'      => 'Registration failed. Please try again.',
        'google_not_configured' => 'Google Sign-In is not set up yet. Use email/password for now.',
    'oauth_state'   => 'Invalid request. Please try again.',
    'oauth_denied'  => 'Google sign-in was cancelled.',
    'oauth_token'   => 'Could not complete Google sign-in. Please try again.',
    'oauth_info'    => 'Could not retrieve your Google profile. Please try again.',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11291682357"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11291682357');
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NC3T6B56');</script>
<!-- End Google Tag Manager -->
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-QP1R08VS4N"></script>
<!-- Event snippet for Sign-up (2) conversion page
In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->
<script>
function gtag_report_conversion(url) {
  var callback = function () {
    if (typeof(url) != 'undefined') {
      window.location = url;
    }
  };
  gtag('event', 'conversion', {
      'send_to': 'AW-11291773808/KUqpCKqTnMwcEPCWq4gq',
      'value': 1.0,
      'currency': 'USD',
      'event_callback': callback
  });
  return false;
}
</script>

<meta charset="UTF-8"><title>Create account &mdash; ChainMind</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap">
<link rel="icon" type="image/png" href="../ChatGPT Image Jun 2, 2026, 06_43_57 AM.png">
<style>
:root {
  --bg:      #07080f;
  --bg2:     #0b0d1c;
  --bg3:     #101228;
  --border:  #1e2040;
  --border2: #272a52;
  --text:    #eef0ff;
  --text2:   #c5c8f0;
  --muted:   #6b6f9e;
  --purple:  #8b3cf7;
  --indigo:  #4f46e5;
  --accent:  #a78bfa;
  --accent2: #c4b5fd;
  --glow:    rgba(139,60,247,.38);
  --grad:    linear-gradient(135deg,#8b3cf7,#4f46e5);
  --red:     #f87171;
  --red-bg:  rgba(248,113,113,.1);
  --green:   #34d399;
  --green-bg: rgba(52,211,153,.1);
  --font:    'Plus Jakarta Sans',system-ui,sans-serif;
  --display: 'Syne',sans-serif;
  --mono:    'JetBrains Mono',monospace;
}

*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}

body {
  background: var(--bg);
  color: var(--text);
  font-family: var(--font);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 2rem 1.5rem;
  position: relative;
  overflow-x: hidden;
}

/* Noise */
body::before {
  content: '';
  position: fixed;
  inset: 0;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
  opacity: .5;
  pointer-events: none;
  z-index: 0;
}

/* Glow orb */
body::after {
  content: '';
  position: fixed;
  top: -20%;
  left: 50%;
  transform: translateX(-50%);
  width: 700px;
  height: 700px;
  border-radius: 50%;
  background: radial-gradient(ellipse at center, rgba(139,60,247,.18) 0%, transparent 70%);
  pointer-events: none;
  z-index: 0;
}

/* ─── CARD ─── */
.auth-card {
  position: relative;
  z-index: 1;
  width: 100%;
  max-width: 440px;
  background: var(--bg2);
  border: 1px solid var(--border2);
  border-radius: 20px;
  padding: 2.5rem 2.25rem 2rem;
  box-shadow: 0 0 0 1px rgba(139,60,247,.08), 0 24px 64px rgba(0,0,0,.55);
}

/* ─── LOGO ─── */
.logo {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: .6rem;
  margin-bottom: 2rem;
  text-decoration: none;
}
.logo-mark {
  width: 36px;
  height: 36px;
  background: var(--grad);
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--display);
  font-size: 1.05rem;
  font-weight: 800;
  color: #fff;
  box-shadow: 0 0 20px var(--glow);
  flex-shrink: 0;
}
.logo-text {
  font-family: var(--display);
  font-size: 1.15rem;
  font-weight: 800;
  letter-spacing: -.03em;
  line-height: 1;
}
.logo-text .chain { color: var(--accent2); }
.logo-text .mind  { color: var(--text); }

/* ─── HEADINGS ─── */
.auth-title {
  font-family: var(--display);
  font-size: 1.5rem;
  font-weight: 800;
  text-align: center;
  letter-spacing: -.03em;
  margin-bottom: .4rem;
}
.auth-sub {
  text-align: center;
  color: var(--muted);
  font-size: .86rem;
  margin-bottom: 1.75rem;
  line-height: 1.5;
}

/* ─── ROLE TABS ─── */
.role-tabs {
  display: flex;
  gap: .5rem;
  margin-bottom: 1.5rem;
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: .3rem;
}
.role-tab {
  flex: 1;
  padding: .5rem .75rem;
  border-radius: 9px;
  border: none;
  background: transparent;
  color: var(--muted);
  font-size: .83rem;
  font-weight: 600;
  font-family: var(--font);
  cursor: pointer;
  text-align: center;
  transition: all .18s;
}
.role-tab.active {
  background: var(--grad);
  color: #fff;
  box-shadow: 0 2px 10px var(--glow);
}
.role-tab:not(.active):hover { color: var(--text2); }

/* ─── FORM ─── */
.form-group {
  margin-bottom: 1rem;
}
label {
  display: block;
  font-size: .78rem;
  font-weight: 600;
  color: var(--muted);
  margin-bottom: .35rem;
  letter-spacing: .01em;
  text-transform: uppercase;
}
input[type=email],
input[type=password],
input[type=text],
select {
  width: 100%;
  padding: .7rem .95rem;
  border-radius: 10px;
  border: 1px solid var(--border2);
  background: var(--bg3);
  color: var(--text);
  font-size: .9rem;
  font-family: var(--font);
  outline: none;
  transition: border-color .18s, box-shadow .18s;
}
input:focus, select:focus {
  border-color: rgba(139,60,247,.6);
  box-shadow: 0 0 0 3px rgba(139,60,247,.12);
}
input::placeholder { color: var(--muted); opacity: .7; }
select option { background: var(--bg3); }

.btn-submit {
  width: 100%;
  padding: .75rem;
  border-radius: 11px;
  border: none;
  font-size: .95rem;
  font-weight: 700;
  font-family: var(--font);
  letter-spacing: -.01em;
  cursor: pointer;
  margin-top: .5rem;
  background: var(--grad);
  color: #fff;
  box-shadow: 0 4px 22px var(--glow);
  transition: all .2s;
}
.btn-submit:hover {
  opacity: .9;
  transform: translateY(-1px);
  box-shadow: 0 8px 30px var(--glow);
}
.btn-submit:active { transform: none; }

/* ─── BONUS BADGE ─── */
.bonus-badge {
  display: flex;
  align-items: center;
  gap: .6rem;
  background: linear-gradient(135deg, rgba(139,60,247,.12), rgba(79,70,229,.07));
  border: 1px solid rgba(139,60,247,.22);
  border-radius: 11px;
  padding: .75rem 1rem;
  margin-bottom: 1.5rem;
  font-size: .83rem;
  color: var(--text2);
}
.bonus-badge .icon { font-size: 1.1rem; }
.bonus-badge strong { color: var(--accent2); }

/* ─── ALERTS ─── */
.err-box {
  background: var(--red-bg);
  border: 1px solid rgba(248,113,113,.28);
  border-radius: 10px;
  padding: .7rem 1rem;
  font-size: .84rem;
  color: var(--red);
  margin-bottom: 1.25rem;
  display: flex;
  align-items: flex-start;
  gap: .5rem;
}
.err-box a { color: var(--red); }

/* ─── DIVIDER ─── */
.divider {
  border: none;
  border-top: 1px solid var(--border);
  margin: 1.5rem 0 1.25rem;
}

/* ─── FOOTER LINKS ─── */
.footer-link {
  text-align: center;
  font-size: .84rem;
  color: var(--muted);
  margin-top: .75rem;
}
.footer-link a {
  color: var(--accent);
  text-decoration: none;
  font-weight: 600;
  transition: color .15s;
}
.footer-link a:hover { color: var(--accent2); }

.back-link {
  display: block;
  text-align: center;
  color: var(--muted);
  font-size: .8rem;
  text-decoration: none;
  margin-top: 1.5rem;
  position: relative;
  z-index: 1;
  transition: color .15s;
}
.back-link:hover { color: var(--text2); }

/* scrollbar */
::-webkit-scrollbar{width:5px}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:20px}
/* ─── GOOGLE BUTTON ─── */
.btn-google {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: .7rem;
  padding: .7rem 1rem;
  border-radius: 11px;
  border: 1px solid var(--border2);
  background: var(--bg3);
  color: var(--text2);
  font-size: .92rem;
  font-weight: 600;
  font-family: var(--font);
  cursor: pointer;
  text-decoration: none;
  transition: all .18s;
  margin-bottom: 1.1rem;
}
.btn-google:hover {
  border-color: rgba(255,255,255,.2);
  background: var(--bg4, #161935);
  color: var(--text);
}
.btn-google svg { flex-shrink: 0; }

/* ─── OR DIVIDER ─── */
.or-divider {
  display: flex;
  align-items: center;
  gap: .75rem;
  margin-bottom: 1.1rem;
  color: var(--muted);
  font-size: .78rem;
  font-weight: 600;
  letter-spacing: .05em;
  text-transform: uppercase;
}
.or-divider::before,
.or-divider::after {
  content: '';
  flex: 1;
  height: 1px;
  background: var(--border);
}

</style>
</head>
<body>
<div class="auth-card">
  <a href="/" class="logo">
    <div class="logo-mark">C</div>
    <div class="logo-text"><span class="chain">Chain</span><span class="mind">Mind</span></div>
  </a>

  <h1 class="auth-title">Create account</h1>
  <p class="auth-sub">Join the decentralized AI network &mdash; free to start</p>

  <div class="bonus-badge">
    <span class="icon">&#10024;</span>
    <span>Get <strong>500 free credits</strong> on signup &mdash; no card required</span>
  </div>

  <?php if ($error && isset($errors[$error])): ?>
    <div class="err-box">&#9888; <?= $errors[$error] ?></div>
  <?php endif; ?>

  <a href="/auth/google.php" class="btn-google">
    <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.31-8.16 2.31-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
      <path fill="none" d="M0 0h48v48H0z"/>
    </svg>
    Continue with Google
  </a>
  <div class="or-divider">or</div>

  <!-- Role selector -->
  <div class="role-tabs">
    <button type="button" class="role-tab <?= $role!=='node'?'active':'' ?>" onclick="setRole('user')">
      &#127760; API User
    </button>
    <button type="button" class="role-tab <?= $role==='node'?'active':'' ?>" onclick="setRole('node')">
      &#9881;&#65039; Node Operator
    </button>
  </div>

  <form method="POST" action="/api/auth/register.php" id="reg-form">
    <input type="hidden" name="role" id="role-input" value="<?= htmlspecialchars($role) ?>">

    <div class="form-group">
      <label for="name">Full name</label>
      <input type="text" id="name" name="name" required placeholder="Your name" autocomplete="name" autofocus>
    </div>
    <div class="form-group">
      <label for="email">Email address</label>
      <input type="email" id="email" name="email" required placeholder="you@example.com" autocomplete="email">
    </div>
    <div class="form-group">
      <label for="password">Password</label>
      <input type="password" id="password" name="password" required placeholder="Min. 8 characters" autocomplete="new-password">
    </div>
    <div class="form-group">
      <label for="password2">Confirm password</label>
      <input type="password" id="password2" name="password_confirm" required placeholder="••••••••" autocomplete="new-password">
    </div>

    <button class="btn-submit" type="submit">Create account &rarr;</button>
  </form>

  <hr class="divider">
  <p class="footer-link">Already have an account? <a href="/auth/login.php">Sign in</a></p>
</div>
<a class="back-link" href="/">&larr; Back to ChainMind</a>

<script>
function setRole(r) {
  document.getElementById('role-input').value = r;
  document.querySelectorAll('.role-tab').forEach(b => b.classList.remove('active'));
  // fix: use the button that was clicked, not global event
  document.querySelector(`.role-tab[onclick="setRole('${r}')"]`).classList.add('active');
}

// Catch password mismatch before the form ever submits
document.getElementById('reg-form').addEventListener('submit', function(e) {
  const p1 = document.getElementById('password').value;
  const p2 = document.getElementById('password2').value;
  if (p1 !== p2) {
    e.preventDefault();
    alert('Passwords do not match.');
    document.getElementById('password2').focus();
    return false;
  }
  if (p1.length < 8) {
    e.preventDefault();
    alert('Password must be at least 8 characters.');
    document.getElementById('password').focus();
    return false;
  }
});
</script>
</body>
</html>
