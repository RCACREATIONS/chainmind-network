<?php
// ============================================================
// ChainMind — Initiate Google OAuth just to verify identity
// for password change. Redirects back to profile.php after.
// Upload to: auth/google-verify-pw.php
// ============================================================
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: /auth/login.php'); exit; }

$client_id    = getenv('GOOGLE_CLIENT_ID');
$redirect_uri = 'https://chainmind.com.ng/auth/google-callback.php';

// Build state: random token + base64 payload with action
$token   = bin2hex(random_bytes(16));
$payload = base64_encode(json_encode(['action' => 'pw_change']));
$state   = $token . '.' . $payload;
$_SESSION['google_oauth_state'] = $token;

$params = http_build_query([
    'client_id'     => $client_id,
    'redirect_uri'  => $redirect_uri,
    'response_type' => 'code',
    'scope'         => 'openid email profile',
    'state'         => $state,
    'prompt'        => 'consent',
    'access_type'   => 'online',
]);

header('Location: https://accounts.google.com/o/oauth2/v2/auth?' . $params);
exit;
