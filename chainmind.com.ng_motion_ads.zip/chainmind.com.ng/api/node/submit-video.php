<?php
// ============================================================
// ChainMind  Node Submit Video
// POST /api/node/submit-video.php
//
// Called by nodes after rendering a motion_ad job.
// Accepts the raw MP4 via multipart/form-data and stores it
// under uploads/generated_ads/<job_id>.mp4.
//
// Separate from submit-result.php because base64-encoding a
// multi-MB video through JSON is wasteful (33% bloat).
// Node still calls submit-result.php afterward to trigger IQ
// payout — that flow is unchanged.
// ============================================================

require_once __DIR__ . '/../_helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST only', 405);
validate_node_secret();
$node_id = get_node_id();

$job_id = trim($_POST['job_id'] ?? '');
if (!$job_id) json_err('job_id is required');

$stmt = db()->prepare("SELECT id, claimed_by FROM jobs WHERE id = ?");
$stmt->execute([$job_id]);
$job = $stmt->fetch();
if (!$job) json_err('Job not found', 404);
if ($job['claimed_by'] !== $node_id) json_err('Job belongs to a different node', 403);

if (empty($_FILES['video'])) json_err('video file field is required', 400);
if ($_FILES['video']['error'] !== UPLOAD_ERR_OK) json_err('Upload error: ' . $_FILES['video']['error'], 400);
if ($_FILES['video']['size'] > 30 * 1024 * 1024) json_err('Video exceeds 30 MB limit', 400);

// ── Ensure result_video_url column exists ─────────────────────
try {
    $col_check = db()->prepare("SHOW COLUMNS FROM jobs LIKE 'result_video_url'");
    $col_check->execute();
    if ($col_check->rowCount() === 0) {
        db()->exec("ALTER TABLE jobs ADD COLUMN result_video_url VARCHAR(500) NULL");
    }
} catch (\Throwable $e) {
    // Column might already exist — safe to continue
}

// ── Save the video ────────────────────────────────────────────
$dest_dir = __DIR__ . '/../../uploads/generated_ads';
if (!is_dir($dest_dir)) mkdir($dest_dir, 0755, true);

$filename  = $job_id . '.mp4';
$dest_path = $dest_dir . '/' . $filename;

if (!move_uploaded_file($_FILES['video']['tmp_name'], $dest_path)) {
    json_err('Failed to save video', 500);
}

$video_url = 'https://chainmind.com.ng/uploads/generated_ads/' . $filename;

db()->prepare("UPDATE jobs SET result_video_url = ? WHERE id = ?")
    ->execute([$video_url, $job_id]);

json_ok(['video_url' => $video_url]);
