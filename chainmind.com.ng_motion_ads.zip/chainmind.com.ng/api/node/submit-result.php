<?php
// ============================================================
// ChainMind  Node Submit Result (Updated)
// POST /api/node/submit-result.php
//
// UPDATED: accepts result_images (base64 array) from image gen jobs.
// Fully backward compatible — existing nodes work unchanged.
// ============================================================

require_once __DIR__ . '/../_helpers.php';
require_once __DIR__ . '/../../api/billing/credits.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST only', 405);

validate_node_secret();
$node_id = get_node_id();
$b       = require_json_body();

$job_id        = trim($b['job_id'] ?? '');
$status        = trim($b['status'] ?? '');
$result        = $b['result'] ?? '';
$tokens_in     = (int)($b['tokens_in']  ?? 0);
$tokens_out    = (int)($b['tokens_out'] ?? 0);
$duration      = (int)($b['duration_ms'] ?? 0);
$result_images = $b['result_images'] ?? null;   // NEW: array of base64 strings

if (!$job_id) json_err('job_id is required');
if (!in_array($status, ['done', 'error'], true)) json_err('status must be done or error');

$stmt = db()->prepare("SELECT id, status, claimed_by FROM jobs WHERE id = ?");
$stmt->execute([$job_id]);
$job = $stmt->fetch();

if (!$job) json_err('Job not found', 404);
if ($job['claimed_by'] !== $node_id) json_err('This job belongs to a different node', 403);
if (!in_array($job['status'], ['claimed', 'running'], true)) {
    json_err('Job is not in a claimable state (status: ' . $job['status'] . ')', 409);
}

// Encode result_images as JSON if provided
$result_images_json = null;
if (!empty($result_images) && is_array($result_images)) {
    $result_images_json = json_encode($result_images);
}

db()->prepare("
    UPDATE jobs
    SET status = ?, result = ?, tokens_in = ?, tokens_out = ?,
        duration_ms = ?, finished_at = NOW(), result_images = ?
    WHERE id = ?
")->execute([
    $status,
    encrypt_field((string)$result),
    $tokens_in,
    $tokens_out,
    $duration,
    $result_images_json,  // NEW
    $job_id,
]);

// ── IQ Earnings (unchanged logic) ────────────────────────────
$iq_earned = 0;

if ($status === 'done') {
    $settings_row = db()->query(
        'SELECT usd_per_iq,
                COALESCE(commission_pct, 10.00)   AS commission_pct,
                COALESCE(min_withdraw_usd, 50.00) AS min_withdraw_usd
         FROM iq_settings WHERE id = 1 LIMIT 1'
    )->fetch();
    $commission_pct = $settings_row ? (float)$settings_row['commission_pct'] : 10.0;
    $usd_per_iq     = $settings_row ? (float)$settings_row['usd_per_iq']     : 0.01;

    $cd = db()->prepare('SELECT COALESCE(SUM(amount), 0) FROM credit_deductions WHERE job_id = ?');
    $cd->execute([$job_id]);
    $credits_used = (int)$cd->fetchColumn();

    if ($credits_used > 0 && $usd_per_iq > 0) {
        $node_share = 1.0 - ($commission_pct / 100.0);
        $usd_earned = ($credits_used / CREDITS_PER_USD) * $node_share;
        $iq_earned  = round($usd_earned / $usd_per_iq, 6);
    } else {
        $tier_multipliers = ['nano'=>1,'micro'=>3,'standard'=>8,'pro'=>20,'enterprise'=>50];
        $nrow = db()->prepare("SELECT tier FROM nodes WHERE id = ?");
        $nrow->execute([$node_id]);
        $ndata = $nrow->fetch();
        $tier  = $ndata['tier'] ?? 'nano';
        $mult  = $tier_multipliers[$tier] ?? 1;
        $iq_earned = round(($tokens_in + $tokens_out) * 0.001 * $mult, 6);
    }
}

db()->prepare("
    INSERT INTO nodes (id, status, last_seen, jobs_done, iq_earned)
    VALUES (?, 'online', NOW(), 1, ?)
    ON DUPLICATE KEY UPDATE
        status    = 'online',
        last_seen = NOW(),
        jobs_done = jobs_done + 1,
        iq_earned = iq_earned + ?
")->execute([$node_id, $iq_earned, $iq_earned]);

$rep_delta = ($status === 'done') ? 2.0 : -5.0;
db()->prepare("
    UPDATE nodes
    SET reputation = LEAST(1000, GREATEST(0, reputation + ?))
    WHERE id = ?
")->execute([$rep_delta, $node_id]);

error_log(sprintf(
    '[earnings] node=%s job=%s status=%s credits_used=%d iq_earned=%.6f has_images=%s',
    $node_id, $job_id, $status,
    $credits_used ?? 0, $iq_earned,
    $result_images_json ? 'yes' : 'no'
));

json_ok([
    'accepted'  => true,
    'job_id'    => $job_id,
    'iq_earned' => $iq_earned,
    'rep_delta' => $rep_delta,
]);
