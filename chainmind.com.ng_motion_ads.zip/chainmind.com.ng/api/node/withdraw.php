<?php
// ============================================================
// ChainMind — Node Withdrawal Request API
// POST /api/node/withdraw.php
// Headers: X-Node-Secret, X-Node-Id
// Body JSON: { iq_amount, method, wallet? | bank? + account? }
// ============================================================
require_once __DIR__ . '/../../api/_helpers.php';
require_once __DIR__ . '/../../api/billing/credits.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { json_err('Method not allowed', 405); }

$secret  = $_SERVER['HTTP_X_NODE_SECRET'] ?? '';
$node_id = $_SERVER['HTTP_X_NODE_ID']     ?? '';

if (!$secret || $secret !== NODE_SECRET) { json_err('Invalid node secret', 403); }
if (!$node_id) { json_err('X-Node-Id header required', 400); }

$node_row = db()->prepare('SELECT * FROM nodes WHERE id = ?');
$node_row->execute([$node_id]); $node = $node_row->fetch();
if (!$node) { json_err('Node not found', 404); }

$body      = json_decode(file_get_contents('php://input'), true) ?? [];
$iq_amount = (float)($body['iq_amount'] ?? 0);
$method    = ($body['method'] ?? 'crypto') === 'fiat' ? 'fiat' : 'crypto';
$wallet    = trim($body['wallet']  ?? '');
$bank      = trim($body['bank']    ?? '');
$account   = trim($body['account'] ?? '');

// ── Minimum withdrawal: load from DB (admin-controlled, default $50) ─────────
$settings = db()->query(
    'SELECT usd_per_iq,
            COALESCE(min_withdraw_usd, 50.00) AS min_withdraw_usd
     FROM iq_settings WHERE id = 1 LIMIT 1'
)->fetch();
$iq_rate_val    = (float)($settings['usd_per_iq']     ?? 0.01);
$min_usd        = (float)($settings['min_withdraw_usd'] ?? 50.0);
$min_iq         = $iq_rate_val > 0 ? ($min_usd / $iq_rate_val) : 5000;

// Current USD value of requested amount
$usd_value = $iq_amount * $iq_rate_val;

if ($iq_amount <= 0 || $usd_value < $min_usd) {
    json_err(
        'Minimum withdrawal is $' . number_format($min_usd, 2) .
        ' USD (' . number_format($min_iq, 2) . ' IQ at current rate). ' .
        'Requested: $' . number_format($usd_value, 2),
        400
    );
}

// Calculate available IQ
$total_iq = (float)$node['iq_earned'];
$c = db()->prepare('SELECT COALESCE(SUM(iq_amount),0) FROM withdrawals WHERE node_id = ? AND status != "rejected"');
$c->execute([$node_id]); $committed = (float)$c->fetchColumn();

$available = $total_iq - $committed;
if ($iq_amount > $available) {
    json_err('Insufficient available IQ. Available: ' . round($available, 6), 400);
}

// Validate payout details
if ($method === 'crypto' && !$wallet) { json_err('wallet address required for crypto payout', 400); }
if ($method === 'fiat' && (!$bank || !$account)) { json_err('bank and account required for fiat payout', 400); }

// No duplicate pending withdrawal
$pending = db()->prepare('SELECT id FROM withdrawals WHERE node_id = ? AND status = "pending"');
$pending->execute([$node_id]);
if ($pending->fetch()) { json_err('You already have a pending withdrawal request', 409); }

db()->prepare(
    'INSERT INTO withdrawals (node_id, iq_amount, usd_value, method, wallet, bank_name, bank_account)
     VALUES (?, ?, ?, ?, ?, ?, ?)'
)->execute([$node_id, $iq_amount, $usd_value, $method, $wallet ?: null, $bank ?: null, $account ?: null]);

json_ok([
    'requested'  => true,
    'iq_amount'  => $iq_amount,
    'usd_value'  => $usd_value,
    'method'     => $method,
    'message'    => 'Withdrawal request submitted. It will be reviewed and processed within 2 business days.',
]);
