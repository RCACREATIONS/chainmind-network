<?php
// ============================================================
// ChainMind  Unlink Node API
// POST /api/node/unlink.php
// Body JSON: { node_id }
// ============================================================
session_start();
require_once __DIR__ . '/../../api/_helpers.php';
cors();

if (!isset($_SESSION['user_id'])) { json_err('Not logged in', 401); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { json_err('POST only', 405); }

$user_id = (int)$_SESSION['user_id'];
$b       = require_json_body();
$node_id = trim($b['node_id'] ?? '');
if (!$node_id) { json_err('node_id required', 400); }

// Verify ownership
$stmt = db()->prepare('SELECT id FROM nodes WHERE id = ? AND user_id = ?');
$stmt->execute([$node_id, $user_id]);
if (!$stmt->fetch()) { json_err('Node not found or not yours', 404); }

// Unlink (keep history  just remove user association)
db()->prepare(
    'UPDATE nodes SET user_id = NULL, linked_email = NULL, linked_at = NULL WHERE id = ?'
)->execute([$node_id]);

json_ok(['unlinked' => true]);
