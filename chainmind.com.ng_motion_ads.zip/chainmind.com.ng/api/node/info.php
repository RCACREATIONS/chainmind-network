<?php
// ============================================================
// ChainMind  Node Info API  (web dashboard uses this)
// GET /api/node/info.php?node_id=xxx
// Requires: session login + must own the node
// ============================================================
session_start();
require_once __DIR__ . '/../../api/_helpers.php';
cors();

if (!isset($_SESSION['user_id'])) { json_err('Not logged in', 401); }
$user_id = (int)$_SESSION['user_id'];
$node_id = trim($_GET['node_id'] ?? '');

if (!$node_id) { json_err('node_id required', 400); }

$stmt = db()->prepare(
    'SELECT n.*,
            (SELECT COALESCE(SUM(iq_amount),0) FROM withdrawals w WHERE w.node_id = n.id AND w.status != "rejected") AS committed_iq
     FROM nodes n
     WHERE n.id = ? AND n.user_id = ?
     LIMIT 1'
);
$stmt->execute([$node_id, $user_id]);
$node = $stmt->fetch();

if (!$node) { json_err('Node not found or not linked to your account', 404); }

// Parse models JSON
$node['models_list'] = json_decode($node['models'] ?? '[]', true) ?: [];
$node['available_iq'] = max(0, (float)$node['iq_earned'] - (float)$node['committed_iq']);

// Recent withdrawals
$wds = db()->prepare(
    'SELECT * FROM withdrawals WHERE node_id = ? ORDER BY requested_at DESC LIMIT 20'
);
$wds->execute([$node_id]);
$node['withdrawals'] = $wds->fetchAll();

// Recent heartbeats (last 24h)
$hbs = db()->prepare(
    'SELECT ts, jobs_done, iq_earned FROM node_heartbeats
     WHERE node_id = ? AND ts > DATE_SUB(NOW(), INTERVAL 24 HOUR)
     ORDER BY ts DESC LIMIT 50'
);
$hbs->execute([$node_id]);
$node['heartbeats'] = $hbs->fetchAll();

json_ok(['node' => $node]);
