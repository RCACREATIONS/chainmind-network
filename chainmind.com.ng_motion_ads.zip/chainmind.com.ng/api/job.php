<?php
// GET /api/job.php?id=<job_id>
// Poll for the status and result of a submitted job.
//
// Returns:
//   { job_id, status, result, result_images, result_video_url, tokens_in, tokens_out, duration_ms, ... }
//
// status values: pending | claimed | done | error | timeout

require_once __DIR__ . '/_helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') json_err('GET only', 405);

$id = trim($_GET['id'] ?? '');
if (!$id) json_err('id parameter is required');

// Sweep stale jobs on every few polls (cheap heuristic: 10% of the time)
if (mt_rand(1, 10) === 1) sweep_timeouts();

// ── Ensure result_video_url column exists before querying it ──
$has_video_col = false;
try {
    $col_check = db()->prepare("SHOW COLUMNS FROM jobs LIKE 'result_video_url'");
    $col_check->execute();
    $has_video_col = $col_check->rowCount() > 0;
    if (!$has_video_col) {
        db()->exec("ALTER TABLE jobs ADD COLUMN result_video_url VARCHAR(500) NULL");
        $has_video_col = true;
    }
} catch (\Throwable $e) {
    // Safe to continue — we just won't select the column
}

$video_col = $has_video_col ? ', result_video_url' : '';

$stmt = db()->prepare("
    SELECT id, status, result, result_images{$video_col}, model, tokens_in, tokens_out,
           duration_ms, claimed_by, source, created_at, finished_at
    FROM jobs WHERE id = ?
");
$stmt->execute([$id]);
$job = $stmt->fetch();

if (!$job) json_err('Job not found', 404);

// Decode result_images JSON array (stored as JSON column)
$result_images = null;
if (!empty($job['result_images'])) {
    $decoded = json_decode($job['result_images'], true);
    if (is_array($decoded)) $result_images = $decoded;
}

json_ok([
    'job_id'           => $job['id'],
    'status'           => $job['status'],
    'result'           => decrypt_field($job['result']),
    'result_images'    => $result_images,
    'result_video_url' => $has_video_col ? ($job['result_video_url'] ?? null) : null,
    'model'            => $job['model'],
    'tokens_in'        => (int)$job['tokens_in'],
    'tokens_out'       => (int)$job['tokens_out'],
    'duration_ms'      => (int)$job['duration_ms'],
    'node_id'          => $job['claimed_by'],
    'source'           => $job['source'],
    'created_at'       => $job['created_at'],
    'finished_at'      => $job['finished_at'],
]);
