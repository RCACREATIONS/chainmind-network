<?php
// ============================================================
// ChainMind  Vision / Multimodal Endpoint
// POST /api/vision.php
//
// Understands images + text using LLaVA (or compatible) nodes.
// Accepts:
//   - files:[{name, type, data}]  ← inline base64 array from dashboard
//   - image: "<base64>"           ← single image (API usage)
//   - file_id: "<id>"             ← uploaded file ref from /api/upload.php
//
// Returns: { job_id, status, poll_url }
// ============================================================

require_once __DIR__ . '/_helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST only', 405);

// ── Auth ───────────────────────────────────────────────────────
$api_key_id = null;
$user_id    = null;

// Start session before reading session vars
if (session_status() === PHP_SESSION_NONE) session_start();
$user_id = $_SESSION['user_id'] ?? null;

$key_header = $_SERVER['HTTP_X_API_KEY'] ?? '';
if ($key_header) {
    $keyRow     = validate_api_key();
    $source     = 'api';
    $api_key_id = (int)$keyRow['id'];
} else {
    $source = 'webchat';
}

if (!$user_id && !$api_key_id) {
    json_err('Authentication required.', 401);
}

// ── Ensure schema columns exist ────────────────────────────────
ensure_jobs_columns();

// ── Node availability ─────────────────────────────────────────
sweep_offline_nodes();
$online = (int)db()->query("SELECT COUNT(*) FROM nodes WHERE status = 'online'")->fetchColumn();
if ($online === 0) json_err('No nodes online right now.', 503);

// ── Parse body ────────────────────────────────────────────────
$b = require_json_body();

$prompt  = trim($b['prompt'] ?? '');
$model   = trim($b['model'] ?? 'llava');
$file_id = trim($b['file_id'] ?? '');
$b64_img = $b['image'] ?? null;
$files   = $b['files'] ?? null;   // FIX: dashboard sends files:[{name,type,data}]

if (!$prompt) json_err('prompt is required', 400);

// ── Resolve image data ────────────────────────────────────────
$image_b64_list = [];
$file_texts     = [];
$file_id_ref    = null;

// Path 1: inline files array from dashboard {name, type, data}
if (!empty($files) && is_array($files)) {
    foreach ($files as $f) {
        $name = $f['name'] ?? 'file';
        $type = $f['type'] ?? 'application/octet-stream';
        $data = $f['data'] ?? '';

        if (!$data) continue;

        // Strip data URL prefix if present
        if (str_starts_with($data, 'data:')) {
            $data = preg_replace('/^data:[^;]+;base64,/', '', $data);
        }

        if (str_starts_with($type, 'image/')) {
            $image_b64_list[] = ['name' => $name, 'data' => $data, 'mime' => $type];
        } else {
            // Non-image files: decode base64 and treat as text
            $decoded = base64_decode($data, true);
            if ($decoded !== false) {
                $file_texts[] = "=== $name ===\n" . mb_substr($decoded, 0, 50000);
            }
        }
    }
}

// Path 2: file_id from a prior upload
if ($file_id) {
    db()->exec("
        CREATE TABLE IF NOT EXISTS uploaded_files (
            id VARCHAR(36) PRIMARY KEY,
            file_id VARCHAR(36) NOT NULL,
            user_id INT NULL,
            api_key_id INT NULL,
            original_name VARCHAR(255) NOT NULL,
            mime_type VARCHAR(100) NOT NULL,
            size_bytes INT NOT NULL,
            content_text MEDIUMTEXT NULL,
            content_b64 MEDIUMTEXT NULL,
            created_at DATETIME NOT NULL DEFAULT NOW(),
            INDEX idx_file_id (file_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $stmt = db()->prepare(
        "SELECT original_name, mime_type, content_text, content_b64
         FROM uploaded_files WHERE file_id = ? ORDER BY id ASC"
    );
    $stmt->execute([$file_id]);
    $rows = $stmt->fetchAll();

    if (empty($rows)) {
        json_err("file_id '{$file_id}' not found. Upload files first via /api/upload.php", 404);
    }

    foreach ($rows as $row) {
        if ($row['content_b64']) {
            $image_b64_list[] = [
                'name' => $row['original_name'],
                'data' => $row['content_b64'],
                'mime' => $row['mime_type'],
            ];
        }
        if ($row['content_text']) {
            $file_texts[] = "=== " . $row['original_name'] . " ===\n" . $row['content_text'];
        }
    }

    $file_id_ref = $file_id;
}

// Path 3: single base64 image in body (API usage)
if ($b64_img && empty($image_b64_list)) {
    if (str_starts_with($b64_img, 'data:')) {
        $b64_img = preg_replace('/^data:[^;]+;base64,/', '', $b64_img);
    }
    $image_b64_list[] = ['name' => 'inline_image', 'data' => $b64_img, 'mime' => 'image/png'];
}

if (empty($image_b64_list) && empty($file_texts)) {
    json_err('Provide "files" array, "image" (base64), or "file_id" from /api/upload.php.', 400);
}

// ── Build the enriched prompt ──────────────────────────────────
$full_prompt = $prompt;
if (!empty($file_texts)) {
    $full_prompt .= "\n\n" . implode("\n\n", $file_texts);
}

$has_images = !empty($image_b64_list);

// ── Credit check ──────────────────────────────────────────────
require_once __DIR__ . '/billing/credits.php';

$vision_cost = $has_images ? 5 : 3;
if ($api_key_id) {
    $balance = credits_get($api_key_id);
    if ($balance < $vision_cost) {
        json_err(
            "Insufficient credits. Balance: {$balance}, required: {$vision_cost}.",
            402
        );
    }
}

// ── Queue job ─────────────────────────────────────────────────
$job_id = uuid4();

$image_param_data = $has_images ? json_encode([
    'images' => $image_b64_list,
]) : null;

$file_ids_json = $file_id_ref ? json_encode([$file_id_ref]) : null;

db()->prepare("
    INSERT INTO jobs
        (id, prompt, model, system_prompt, status, source, api_key_id,
         job_type, image_params, file_ids, created_at)
    VALUES (?, ?, ?, '', 'pending', ?, ?,
            ?, ?, ?, NOW())
")->execute([
    $job_id,
    encrypt_field($full_prompt),
    $model ?: 'llava',
    $source,
    $api_key_id,
    $has_images ? 'vision' : 'file_qa',
    $image_param_data,
    $file_ids_json,
]);

// ── Deduct credits ────────────────────────────────────────────
if ($api_key_id) {
    credits_deduct($api_key_id, $job_id, $vision_cost);
}

json_ok([
    'job_id'       => $job_id,
    'status'       => 'pending',
    'poll_url'     => "/api/job.php?id={$job_id}",
    'job_type'     => $has_images ? 'vision' : 'file_qa',
    'images_count' => count($image_b64_list),
    'files_count'  => count($file_texts),
    'message'      => 'Vision job queued. Poll poll_url for result.',
    'credits_used' => $vision_cost,
]);
