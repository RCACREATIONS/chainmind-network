<?php
// ============================================================
// ChainMind  OpenAI-Compatible Chat Completions
// POST /api/v1/chat/completions
//
// UPDATED: supports multimodal messages with file attachments.
// File references: { "type": "image_url", "image_url": { "url": "file://<file_id>" } }
//                  { "type": "text", "text": "..." }
//
// Clients can also send: "file_ids": ["<id>"] at the top level.
// ============================================================

require_once __DIR__ . '/_auth.php';
v1_cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    v1_error('Method not allowed. Use POST.', 405, 'method_not_allowed');
}

// ── 1. Authenticate ───────────────────────────────────────────
$key_row = v1_authenticate();

// ── 2. Parse body ─────────────────────────────────────────────
$raw  = file_get_contents('php://input');
$body = json_decode($raw, true);
if (!$body) v1_error('Request body must be valid JSON.', 400);

$messages   = $body['messages'] ?? [];
$top_file_ids = $body['file_ids'] ?? [];  // NEW: top-level file_ids
if (empty($messages) || !is_array($messages)) {
    v1_error('messages array is required and must not be empty.', 400);
}

$model  = trim($body['model'] ?? 'mistral');
$stream = !empty($body['stream']);

// ── 3. Rate limit ─────────────────────────────────────────────
v1_check_rate_limit($key_row);

// ── 4. Model access ───────────────────────────────────────────
v1_check_model($key_row, $model);

// ── 5. Convert messages to prompt + system + extract files ────
$system_content  = '';
$prompt_parts    = [];
$inline_images   = [];   // base64 images found in content array
$file_id_refs    = [];   // file:// references found in content

foreach ($messages as $msg) {
    $role    = $msg['role']    ?? 'user';
    $content = $msg['content'] ?? '';

    // Content can be a string OR an array (multimodal OpenAI format)
    if (is_array($content)) {
        $text_parts = [];
        foreach ($content as $part) {
            $type = $part['type'] ?? 'text';

            if ($type === 'text') {
                $text_parts[] = $part['text'] ?? '';

            } elseif ($type === 'image_url') {
                $url = $part['image_url']['url'] ?? '';

                if (str_starts_with($url, 'file://')) {
                    // Reference to a ChainMind uploaded file
                    $file_id_refs[] = substr($url, 7);

                } elseif (str_starts_with($url, 'data:')) {
                    // Inline base64 image
                    $b64 = preg_replace('/^data:[^;]+;base64,/', '', $url);
                    $inline_images[] = ['data' => $b64, 'name' => 'inline', 'mime' => 'image/png'];
                }
            }
        }
        $content = implode(' ', $text_parts);
    }

    if ($role === 'system') {
        $system_content = $content;
    } elseif ($role === 'assistant') {
        $prompt_parts[] = "Assistant: {$content}";
    } else {
        $prompt_parts[] = "User: {$content}";
    }
}
$prompt = implode("\n\n", $prompt_parts);
if (!$prompt) v1_error('No user messages found.', 400);

// ── 6. Resolve file_ids from top-level and content ───────────
$all_file_ids = array_unique(array_merge($top_file_ids, $file_id_refs));
$file_texts   = [];
$file_images  = $inline_images;

if (!empty($all_file_ids)) {
    // Ensure table exists (idempotent)
    try {
        db()->exec("
            CREATE TABLE IF NOT EXISTS uploaded_files (
                id VARCHAR(36) PRIMARY KEY,
                file_id VARCHAR(36) NOT NULL,
                user_id INT NULL,
                api_key_id INT NULL,
                original_name VARCHAR(255) NOT NULL,
                mime_type VARCHAR(100) NOT NULL,
                size_bytes INT NOT NULL,
                content_text MEDIUMTEXT NULL,
                content_b64 MEDIUMTEXT NULL,
                created_at DATETIME NOT NULL DEFAULT NOW(),
                INDEX idx_file_id (file_id),
                INDEX idx_apikey (api_key_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    } catch (\Throwable $e) {}

    $placeholders = implode(',', array_fill(0, count($all_file_ids), '?'));
    $stmt = db()->prepare(
        "SELECT original_name, mime_type, content_text, content_b64
         FROM uploaded_files WHERE file_id IN ({$placeholders}) ORDER BY id ASC"
    );
    $stmt->execute($all_file_ids);
    $rows = $stmt->fetchAll();

    foreach ($rows as $row) {
        if ($row['content_text']) {
            $file_texts[] = "=== " . $row['original_name'] . " ===\n" . $row['content_text'];
        }
        if ($row['content_b64']) {
            $file_images[] = [
                'data' => $row['content_b64'],
                'name' => $row['original_name'],
                'mime' => $row['mime_type'],
            ];
        }
    }
}

// Append file texts to prompt
if (!empty($file_texts)) {
    $prompt .= "\n\n" . implode("\n\n", $file_texts);
}

// ── 7. Determine job type ─────────────────────────────────────
$has_images = !empty($file_images);
$job_type   = $has_images ? 'vision' : 'text';

// Force vision model if images present and model doesn't support it
if ($has_images && !str_contains(strtolower($model), 'llava') &&
    !str_contains(strtolower($model), 'vision') &&
    !str_contains(strtolower($model), 'bakllava')) {
    $model = 'llava';  // auto-switch to vision model
}

// ── 8. Estimate credits & check balance ──────────────────────
$est_tokens = (int)(mb_strlen($prompt) / 3) + 500;
$est_cost   = v1_calc_credits($model, $est_tokens);
if ($has_images) $est_cost += count($file_images) * 3;  // vision surcharge
v1_check_credits($key_row, $est_cost);

// ── 9. Ensure schema ──────────────────────────────────────────
ensure_jobs_columns();

// ── 10. Run job through node network ─────────────────────────
$tokens_in = $tokens_out = $duration_ms = 0;
$used_model = $model;

$image_param_data = $has_images ? json_encode(['images' => $file_images]) : null;
$file_ids_json    = !empty($all_file_ids) ? json_encode($all_file_ids) : null;

$result = v1_run_job_extended(
    $prompt, $model, $system_content ?: null,
    $key_row['api_key'],
    $tokens_in, $tokens_out, $used_model, $duration_ms,
    $job_type, $image_param_data, $file_ids_json,
    (int)$key_row['id']
);

// ── 11. Log usage ─────────────────────────────────────────────
$total_tokens = $tokens_in + $tokens_out;
if ($total_tokens === 0) $total_tokens = $est_tokens;
$credits_used = v1_calc_credits($used_model, $total_tokens);
if ($has_images) $credits_used += count($file_images) * 3;

v1_log_usage((int)$key_row['id'], $used_model, '/v1/chat/completions',
    $tokens_in, $tokens_out, $credits_used, $duration_ms, 200);

// ── 12. Return OpenAI-compatible response ─────────────────────
$created = time();
$cid     = 'chatcmpl-' . bin2hex(random_bytes(8));

echo json_encode([
    'id'      => $cid,
    'object'  => 'chat.completion',
    'created' => $created,
    'model'   => $used_model,
    'choices' => [[
        'index'         => 0,
        'message'       => ['role' => 'assistant', 'content' => $result],
        'finish_reason' => 'stop',
    ]],
    'usage'   => [
        'prompt_tokens'     => $tokens_in,
        'completion_tokens' => $tokens_out,
        'total_tokens'      => $total_tokens,
    ],
    'system_fingerprint' => null,
], JSON_UNESCAPED_UNICODE);

// ============================================================
//  Extended job runner — supports vision and file_qa job types
// ============================================================

function v1_run_job_extended(
    string $prompt, string $model, ?string $system,
    string $api_key,
    int &$tokens_in, int &$tokens_out,
    string &$used_model, int &$duration_ms,
    string $job_type = 'text',
    ?string $image_params = null,
    ?string $file_ids_json = null,
    int $api_key_id = 0
): string {
    $start = microtime(true);

    sweep_offline_nodes();
    $online = db()->query("SELECT COUNT(*) FROM nodes WHERE status = 'online'")->fetchColumn();
    if ($online == 0) v1_error('No nodes online right now.', 503, 'service_unavailable');

    $job_id = uuid4();

    db()->prepare("
        INSERT INTO jobs
            (id, prompt, model, system_prompt, status, source, api_key_id,
             job_type, image_params, file_ids, created_at)
        VALUES (?, ?, ?, ?, 'pending', 'api', ?,
                ?, ?, ?, NOW())
    ")->execute([
        $job_id,
        encrypt_field($prompt),
        $model,
        $system ?? '',
        $api_key_id,
        $job_type,
        $image_params,
        $file_ids_json,
    ]);

    // Poll for result (90s timeout for text, 120s for vision)
    $timeout  = $job_type === 'vision' ? 120 : 90;
    $deadline = time() + $timeout;

    while (time() < $deadline) {
        usleep(1500000); // 1.5s

        $stmt = db()->prepare(
            "SELECT status, result, model, tokens_in, tokens_out, duration_ms
             FROM jobs WHERE id = ?"
        );
        $stmt->execute([$job_id]);
        $job = $stmt->fetch();

        $status = $job['status'] ?? 'pending';

        if ($status === 'done') {
            $tokens_in   = (int)($job['tokens_in']  ?? 0);
            $tokens_out  = (int)($job['tokens_out'] ?? 0);
            $used_model  = $job['model']             ?? $model;
            $duration_ms = (int)(($job['duration_ms'] ?? 0)
                           ?: round((microtime(true) - $start) * 1000));
            return decrypt_field($job['result'] ?? '');
        }

        if ($status === 'error') {
            v1_error(decrypt_field($job['result'] ?? 'Node returned an error.'), 502, 'upstream_error');
        }
        if ($status === 'timeout') {
            v1_error('No nodes available right now.', 503, 'service_unavailable');
        }
    }

    v1_error('Request timed out.', 504, 'timeout');
}
