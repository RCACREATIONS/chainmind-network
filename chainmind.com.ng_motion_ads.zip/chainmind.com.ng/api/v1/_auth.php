<?php
// ============================================================
// ChainMind  Advanced API Key Authentication & Enforcement
// Include in every /api/v1/ endpoint.
// ============================================================

if (!function_exists('db')) {
    require_once __DIR__ . '/../../api/_helpers.php';
}

// Model cost table (credits per 1000 tokens)
const V1_MODEL_COSTS = [
    'phi3'        => 1,
    'gemma2:2b'   => 1,
    'llama3.2:1b' => 1,
    'llama3.2:3b' => 1,
    'tinyllama'   => 1,
    'qwen2:0.5b'  => 1,
    'mistral'     => 2,
    'llama3.1:8b' => 2,
    'llama3.2'    => 2,
    'gemma2:9b'   => 2,
    'deepseek'    => 2,
    'qwen2'       => 2,
    'mixtral'     => 3,
    'llama3.1:70b'=> 3,
    'qwen2:72b'   => 3,
    'default'     => 2,
];

function v1_calc_credits(string $model, int $total_tokens): int {
    $lm = strtolower($model);
    $rate = V1_MODEL_COSTS['default'];
    foreach (V1_MODEL_COSTS as $k => $v) {
        if ($k !== 'default' && str_contains($lm, $k)) {
            $rate = $v;
            break;
        }
    }
    return max(1, (int)ceil($total_tokens / 1000 * $rate));
}

/**
 * Extract the bearer token or X-Api-Key from the request.
 */
function v1_extract_key(): string {
    // Standard OpenAI: Authorization: Bearer sk-...
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if ($auth && preg_match('/^Bearer\s+(.+)$/i', trim($auth), $m)) {
        return trim($m[1]);
    }
    // Fallback: X-Api-Key header (our native format)
    $xkey = $_SERVER['HTTP_X_API_KEY'] ?? '';
    if ($xkey) return trim($xkey);
    // Fallback: query param
    return trim($_GET['api_key'] ?? '');
}

/**
 * Validate the key and enforce all advanced policies.
 * Returns the full key row on success. Dies with OpenAI-format error on failure.
 */
function v1_authenticate(): array {
    $raw_key = v1_extract_key();
    if (!$raw_key) {
        v1_error('Missing API key. Send: Authorization: Bearer <key>', 401, 'invalid_api_key');
    }

    $stmt = db()->prepare('SELECT k.*, COALESCE(c.balance,0) AS credit_balance
        FROM api_keys k
        LEFT JOIN credits c ON c.api_key_id = k.id
        WHERE k.api_key = ? AND k.is_active = 1
        LIMIT 1');
    $stmt->execute([$raw_key]);
    $row = $stmt->fetch();

    if (!$row) {
        v1_error('Invalid API key.', 401, 'invalid_api_key');
    }

    // Expiry check
    if (!empty($row['expires_at']) && strtotime($row['expires_at']) < time()) {
        db()->prepare('UPDATE api_keys SET is_active=0 WHERE id=?')->execute([$row['id']]);
        v1_error('API key has expired.', 403, 'key_expired');
    }

    // Update last_used
    db()->prepare('UPDATE api_keys SET last_used=NOW(), total_jobs=total_jobs+1 WHERE id=?')
        ->execute([$row['id']]);

    return $row;
}

/**
 * Check per-minute rate limit. Enforces key's rate_limit_rpm.
 */
function v1_check_rate_limit(array $key_row): void {
    $rpm   = (int)($key_row['rate_limit_rpm'] ?? 60);
    $kid   = (int)$key_row['id'];
    $minute = date('Y-m-d H:i:00');

    // Ensure table exists (idempotent, cheap)
    db()->exec("CREATE TABLE IF NOT EXISTS api_rate_windows (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        api_key_id INT NOT NULL,
        window_minute DATETIME NOT NULL,
        request_count INT NOT NULL DEFAULT 1,
        UNIQUE KEY uk_key_window (api_key_id, window_minute)
    ) ENGINE=InnoDB");

    // Upsert the current window
    $stmt = db()->prepare(
        'INSERT INTO api_rate_windows (api_key_id, window_minute, request_count)
         VALUES (?, ?, 1)
         ON DUPLICATE KEY UPDATE request_count = request_count + 1'
    );
    $stmt->execute([$kid, $minute]);

    // Read back the current count
    $row = db()->prepare('SELECT request_count FROM api_rate_windows WHERE api_key_id=? AND window_minute=?');
    $row->execute([$kid, $minute]);
    $count = (int)($row->fetchColumn() ?: 1);

    if ($count > $rpm) {
        $retry = 60 - (int)date('s');
        header('Retry-After: ' . $retry);
        v1_error("Rate limit exceeded ({$rpm} req/min). Retry after {$retry}s.", 429, 'rate_limit_exceeded');
    }
}

/**
 * Check credit balance.
 */
function v1_check_credits(array $key_row, int $est_cost): void {
    $balance = (int)($key_row['credit_balance'] ?? 0);
    if ($balance < $est_cost) {
        v1_error(
            "Insufficient credits. Balance: {$balance}, required: ~{$est_cost}. " .
            "Top up at https://chainmind.com.ng/dashboard/billing.php",
            402, 'insufficient_quota'
        );
    }
}

/**
 * Check if model is allowed for this key.
 */
function v1_check_model(array $key_row, string $model): void {
    $allowed_raw = trim($key_row['allowed_models'] ?? '');
    if (!$allowed_raw) return; // no restriction = all models allowed

    $allowed = json_decode($allowed_raw, true);
    if (!is_array($allowed) || empty($allowed)) return;

    $lm = strtolower($model);
    foreach ($allowed as $a) {
        $la = strtolower(trim($a));
        if ($la === $lm || str_contains($lm, $la) || str_contains($la, $lm)) return;
    }

    v1_error("Model '{$model}' is not permitted for this API key.", 403, 'model_not_allowed');
}

/**
 * Log a v1 API call for analytics.
 */
function v1_log_usage(int $key_id, string $model, string $endpoint,
    int $tokens_in, int $tokens_out, int $credits_used,
    int $duration_ms, int $status_code): void
{
    try {
        db()->prepare(
            'INSERT INTO api_key_usage
             (api_key_id, model, endpoint, tokens_in, tokens_out, credits_used, duration_ms, status_code)
             VALUES (?,?,?,?,?,?,?,?)'
        )->execute([$key_id, $model, $endpoint, $tokens_in, $tokens_out, $credits_used, $duration_ms, $status_code]);
    } catch (\Throwable $e) {
        error_log('[v1_log_usage] ' . $e->getMessage());
    }
}

/**
 * Emit an OpenAI-compatible error and exit.
 */
function v1_error(string $message, int $code = 400, string $err_code = 'invalid_request_error'): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode([
        'error' => [
            'message' => $message,
            'type'    => $err_code,
            'code'    => $err_code,
        ]
    ]);
    exit;
}

/**
 * Set CORS headers for OpenAI-compatible clients.
 */
function v1_cors(): void {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Authorization, Content-Type, X-Api-Key');
    header('Content-Type: application/json');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
}

/**
 * Submit a job to the node network and poll until done.
 * Returns the job result string, and sets $tokens_in/$tokens_out/$model/$duration_ms.
 */
function v1_run_job(string $prompt, string $model, ?string $system,
    string $api_key, int &$tokens_in, int &$tokens_out,
    string &$used_model, int &$duration_ms): string
{
    $start = microtime(true);
    $base  = 'https://' . ($_SERVER['HTTP_HOST'] ?? 'chainmind.com.ng');

    // Submit job via internal curl
    $payload = json_encode(array_filter([
        'prompt' => $prompt,
        'model'  => $model ?: null,
        'system' => $system ?: null,
    ], fn($v) => $v !== null));

    $ch = curl_init($base . '/api/infer.php');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'X-Api-Key: ' . $api_key,
            'X-Internal-Summary: 1',
        ],
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $body = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http !== 200) {
        $err = json_decode($body, true);
        $msg = $err['error'] ?? "Failed to submit job (HTTP {$http})";
        v1_error($msg, $http >= 500 ? 502 : $http, 'upstream_error');
    }

    $submitted = json_decode($body, true);
    $job_id    = $submitted['job_id'] ?? null;
    if (!$job_id) v1_error('No job_id returned from node network.', 502, 'upstream_error');

    // Poll for result
    $deadline = time() + 90;
    while (time() < $deadline) {
        usleep(1500000); // 1.5s

        $ch2 = curl_init($base . '/api/job.php?id=' . urlencode($job_id));
        curl_setopt_array($ch2, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $jbody = curl_exec($ch2);
        curl_close($ch2);

        $job = json_decode($jbody, true);
        $status = $job['status'] ?? 'pending';

        if ($status === 'done') {
            $tokens_in   = (int)($job['tokens_in']  ?? 0);
            $tokens_out  = (int)($job['tokens_out'] ?? 0);
            $used_model  = $job['model']             ?? $model;
            $duration_ms = (int)(($job['duration_ms'] ?? 0) ?: round((microtime(true) - $start) * 1000));
            return $job['result'] ?? '';
        }

        if ($status === 'error') {
            v1_error($job['result'] ?? 'Node returned an error.', 502, 'upstream_error');
        }

        if ($status === 'timeout') {
            v1_error('No nodes available right now. Please try again shortly.', 503, 'service_unavailable');
        }
    }

    v1_error('Request timed out waiting for a node to process it.', 504, 'timeout');
}
