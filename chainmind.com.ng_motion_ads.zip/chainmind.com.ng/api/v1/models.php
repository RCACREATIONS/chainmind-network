<?php
// ============================================================
// GET /api/v1/models  — OpenAI-compatible models endpoint
// Returns models available on the ChainMind network.
// ============================================================

require_once __DIR__ . '/_auth.php';
v1_cors();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    v1_error('Method not allowed. Use GET.', 405, 'method_not_allowed');
}

$key_row = v1_authenticate();

// Full model list (matches node config.yaml)
$all_models = [
    ['id' => 'mistral',        'desc' => 'Mistral 7B — best balance of speed & quality',  'ctx' => 8192,  'tier' => 'medium'],
    ['id' => 'llama3.1:8b',   'desc' => 'LLaMA 3.1 8B — fast & efficient',               'ctx' => 8192,  'tier' => 'medium'],
    ['id' => 'llama3.1:70b',  'desc' => 'LLaMA 3.1 70B — server-grade quality',          'ctx' => 8192,  'tier' => 'large'],
    ['id' => 'llama3.2:3b',   'desc' => 'LLaMA 3.2 3B — recommended for 8 GB RAM',       'ctx' => 8192,  'tier' => 'small'],
    ['id' => 'llama3.2:1b',   'desc' => 'LLaMA 3.2 1B — very fast',                      'ctx' => 4096,  'tier' => 'small'],
    ['id' => 'gemma2:9b',     'desc' => "Gemma 2 9B — Google's medium model",             'ctx' => 8192,  'tier' => 'medium'],
    ['id' => 'gemma2:2b',     'desc' => "Gemma 2 2B — Google's small model",              'ctx' => 8192,  'tier' => 'small'],
    ['id' => 'mixtral:8x7b',  'desc' => 'Mixtral 8×7B — mixture of experts',             'ctx' => 32768, 'tier' => 'large'],
    ['id' => 'qwen2:72b',     'desc' => 'Qwen2 72B — maximum quality',                   'ctx' => 32768, 'tier' => 'large'],
    ['id' => 'deepseek-r1:7b','desc' => 'DeepSeek R1 7B — reasoning model',              'ctx' => 8192,  'tier' => 'medium'],
    ['id' => 'phi3:mini',     'desc' => 'Phi-3 Mini 3.8B — best tiny quality',           'ctx' => 4096,  'tier' => 'tiny'],
    ['id' => 'tinyllama',     'desc' => 'TinyLlama 1.1B — lowest resource usage',        'ctx' => 2048,  'tier' => 'tiny'],
    ['id' => 'qwen2:0.5b',    'desc' => 'Qwen2 0.5B — fastest, any machine',             'ctx' => 2048,  'tier' => 'tiny'],
];

// Filter by key's allowed_models if set
$allowed_raw = trim($key_row['allowed_models'] ?? '');
if ($allowed_raw) {
    $allowed = json_decode($allowed_raw, true) ?: [];
    if (!empty($allowed)) {
        $all_models = array_values(array_filter($all_models, function($m) use ($allowed) {
            foreach ($allowed as $a) {
                $la = strtolower(trim($a));
                if (str_contains(strtolower($m['id']), $la) || str_contains($la, strtolower($m['id']))) {
                    return true;
                }
            }
            return false;
        }));
    }
}

$data = array_map(function($m) {
    return [
        'id'          => $m['id'],
        'object'      => 'model',
        'created'     => 1720000000,
        'owned_by'    => 'chainmind',
        'description' => $m['desc'],
        'context_window' => $m['ctx'],
        'tier'        => $m['tier'],
    ];
}, $all_models);

// Handle GET /v1/models/<id>
$path  = $_SERVER['REQUEST_URI'] ?? '';
$parts = explode('/v1/models/', $path);
$model_id = isset($parts[1]) ? trim(explode('?', $parts[1])[0], '/') : '';

if ($model_id) {
    foreach ($data as $m) {
        if ($m['id'] === $model_id) {
            echo json_encode($m, JSON_UNESCAPED_UNICODE);
            exit;
        }
    }
    v1_error("Model '{$model_id}' not found.", 404, 'model_not_found');
}

echo json_encode(['object' => 'list', 'data' => $data], JSON_UNESCAPED_UNICODE);
