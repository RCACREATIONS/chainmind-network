<?php
// ============================================================
// ChainMind  OpenAI-Compatible Image Generation Endpoint
// POST /api/v1/images/generations
//
// Drop-in replacement for OpenAI's image generation API.
// Clients using OpenAI SDK just change the base URL.
//
// Request (OpenAI format):
//   { "prompt": "...", "n": 1, "size": "512x512",
//     "model": "sd", "response_format": "b64_json|url" }
//
// Response (OpenAI format):
//   { "created": 1234567890, "data": [{"b64_json": "..."}] }
// ============================================================

require_once __DIR__ . '/_auth.php';
v1_cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    v1_error('Method not allowed. Use POST.', 405, 'method_not_allowed');
}

$key_row = v1_authenticate();
v1_check_rate_limit($key_row);

// ── Ensure schema ─────────────────────────────────────────────
ensure_jobs_columns();

// ── Parse request ─────────────────────────────────────────────
$body = json_decode(file_get_contents('php://input'), true);
if (!$body) v1_error('Request body must be valid JSON.', 400);

$prompt          = trim($body['prompt'] ?? '');
$n               = max(1, min(4, (int)($body['n'] ?? 1)));
$size            = trim($body['size'] ?? '512x512');
$model           = trim($body['model'] ?? 'auto');
$response_format = trim($body['response_format'] ?? 'b64_json');
$negative_prompt = trim($body['negative_prompt'] ?? '');

if (!$prompt) v1_error('prompt is required.', 400);

$valid_sizes = ['256x256','512x512','768x768','1024x1024','512x768','768x512'];
if (!in_array($size, $valid_sizes, true)) {
    v1_error('Invalid size. Allowed: ' . implode(', ', $valid_sizes), 400);
}

// ── Credit check: 10 credits per image ───────────────────────
$cost_per_image = 10;
$total_cost     = $cost_per_image * $n;
v1_check_credits($key_row, $total_cost);

// ── Node availability ─────────────────────────────────────────
sweep_offline_nodes();
$online = db()->query("SELECT COUNT(*) FROM nodes WHERE status = 'online'")->fetchColumn();
if ($online == 0) v1_error('No nodes online right now.', 503, 'service_unavailable');

// ── Queue jobs and poll for each image ───────────────────────
$image_results = [];
$image_params  = json_encode([
    'negative_prompt' => $negative_prompt,
    'model'           => $model,
    'size'            => $size,
    'steps'           => (int)($body['steps'] ?? 20),
    'guidance_scale'  => (float)($body['guidance_scale'] ?? 7.5),
    'seed'            => isset($body['seed']) ? (int)$body['seed'] : -1,
]);

for ($img_n = 0; $img_n < $n; $img_n++) {
    $job_id = uuid4();

    db()->prepare("
        INSERT INTO jobs
            (id, prompt, model, system_prompt, status, source, api_key_id,
             job_type, image_params, created_at)
        VALUES (?, ?, ?, '', 'pending', 'api', ?,
                'image_gen', ?, NOW())
    ")->execute([
        $job_id,
        encrypt_field($prompt),
        $model ?: 'sd',
        (int)$key_row['id'],
        $image_params,
    ]);

    // Deduct per image
    require_once __DIR__ . '/../../api/billing/credits.php';
    credits_deduct((int)$key_row['id'], $job_id, $cost_per_image);

    // Poll for result (up to 120s per image)
    $result_b64 = null;
    $deadline   = time() + 120;

    while (time() < $deadline) {
        usleep(2000000); // 2s poll interval for image gen
        $stmt = db()->prepare("SELECT status, result, result_images FROM jobs WHERE id = ?");
        $stmt->execute([$job_id]);
        $job = $stmt->fetch();

        if (!$job) break;

        if ($job['status'] === 'done') {
            // Node stores image as base64 in result_images JSON
            $ri = json_decode($job['result_images'] ?? '[]', true);
            if (!empty($ri[0])) {
                $result_b64 = $ri[0];
            } else {
                // Fallback: result field may contain base64 directly
                $result_b64 = decrypt_field($job['result']);
            }
            break;
        }
        if (in_array($job['status'], ['error', 'timeout'], true)) {
            v1_error('Image generation failed: ' . decrypt_field($job['result']), 502, 'upstream_error');
        }
    }

    if (!$result_b64) {
        v1_error('Image generation timed out.', 504, 'timeout');
    }

    if ($response_format === 'b64_json') {
        $image_results[] = ['b64_json' => $result_b64];
    } else {
        // For URL format — encode as data URL (client can use directly)
        $image_results[] = ['url' => 'data:image/png;base64,' . $result_b64];
    }
}

// ── Log usage ─────────────────────────────────────────────────
v1_log_usage(
    (int)$key_row['id'], $model ?: 'sd', '/v1/images/generations',
    0, 0, $total_cost, 0, 200
);

echo json_encode([
    'created' => time(),
    'data'    => $image_results,
], JSON_UNESCAPED_UNICODE);
