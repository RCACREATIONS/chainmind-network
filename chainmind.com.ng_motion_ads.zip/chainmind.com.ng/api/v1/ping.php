<?php
header('Content-Type: application/json');

echo json_encode([
    'status' => 'ok',
    'service' => 'ChainMind API',
    'version' => 'v1',
    'timestamp' => time()
]);