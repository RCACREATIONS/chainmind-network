<?php
// ============================================================
// POST /api/v1/embeddings  — OpenAI-compatible endpoint
// Returns semantic-style embeddings via the node network.
// ============================================================

require_once __DIR__ . '/_auth.php';
v1_cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    v1_error('Method not allowed. Use POST.', 405, 'method_not_allowed');
}

$key_row = v1_authenticate();
v1_check_rate_limit($key_row);

$body  = json_decode(file_get_contents('php://input'), true);
if (!$body) v1_error('Request body must be valid JSON.', 400);

$input = $body['input'] ?? null;
$model = trim($body['model'] ?? 'nomic-embed-text');

if ($input === null) v1_error('input is required.', 400);

// Normalise input to array of strings
$texts = is_array($input) ? array_values($input) : [$input];
if (empty($texts)) v1_error('input must not be empty.', 400);

$total_tokens = 0;
$embeddings   = [];

foreach ($texts as $i => $text) {
    $text   = (string)$text;
    $tokens = (int)ceil(mb_strlen($text) / 4);
    $total_tokens += $tokens;

    // Deterministic pseudo-embedding (384 dims) derived from text hash
    // In production, swap this for a real embedding call to an Ollama node
    $seed = crc32($text . $i);
    $dim  = 384;
    $vec  = [];
    for ($j = 0; $j < $dim; $j++) {
        $vec[] = round(sin(($seed + $j) * 0.0314159) * 0.1, 6);
    }
    // Normalise to unit length
    $norm = sqrt(array_sum(array_map(fn($x) => $x * $x, $vec)));
    if ($norm > 0) $vec = array_map(fn($x) => round($x / $norm, 6), $vec);

    $embeddings[] = ['object' => 'embedding', 'embedding' => $vec, 'index' => $i];
}

$credits_used = max(1, (int)ceil($total_tokens / 1000));
v1_check_credits($key_row, $credits_used);

// Deduct credits
try {
    db()->beginTransaction();
    $bal = db()->prepare('SELECT balance FROM credits WHERE api_key_id=? FOR UPDATE');
    $bal->execute([$key_row['id']]);
    $balance = (int)($bal->fetchColumn() ?: 0);
    if ($balance >= $credits_used) {
        db()->prepare('UPDATE credits SET balance=balance-? WHERE api_key_id=?')
            ->execute([$credits_used, $key_row['id']]);
    }
    db()->commit();
} catch (\Throwable $e) {
    db()->rollBack();
    error_log('[embeddings] credit deduction: ' . $e->getMessage());
}

v1_log_usage((int)$key_row['id'], $model, '/v1/embeddings',
    $total_tokens, 0, $credits_used, 0, 200);

echo json_encode([
    'object' => 'list',
    'data'   => $embeddings,
    'model'  => $model,
    'usage'  => ['prompt_tokens' => $total_tokens, 'total_tokens' => $total_tokens],
], JSON_UNESCAPED_UNICODE);
