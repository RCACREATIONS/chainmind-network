<?php
// ============================================================
// ChainMind  OpenAI-Compatible File Upload Endpoint
// POST /api/v1/files        — upload a file
// GET  /api/v1/files        — list files
// GET  /api/v1/files/<id>   — get file info
// DELETE /api/v1/files/<id> — delete file
//
// Files are referenced in /api/v1/chat/completions via:
//   { "messages": [{ "role": "user", "content": [
//       { "type": "text", "text": "What is in this file?" },
//       { "type": "image_url", "image_url": { "url": "file://<file_id>" } }
//   ]}]}
// ============================================================

require_once __DIR__ . '/_auth.php';
v1_cors();

$key_row = v1_authenticate();
$kid     = (int)$key_row['id'];
$method  = $_SERVER['REQUEST_METHOD'];

// Ensure table
db()->exec("
    CREATE TABLE IF NOT EXISTS uploaded_files (
        id          VARCHAR(36)  PRIMARY KEY,
        file_id     VARCHAR(36)  NOT NULL,
        user_id     INT          NULL,
        api_key_id  INT          NULL,
        original_name VARCHAR(255) NOT NULL,
        mime_type   VARCHAR(100) NOT NULL,
        size_bytes  INT          NOT NULL,
        content_text MEDIUMTEXT  NULL,
        content_b64  MEDIUMTEXT  NULL,
        created_at  DATETIME     NOT NULL DEFAULT NOW(),
        INDEX idx_file_id (file_id),
        INDEX idx_apikey (api_key_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// Extract file_id from URL path (e.g. /api/v1/files/abc-123)
$uri    = $_SERVER['REQUEST_URI'] ?? '';
$parts  = explode('/v1/files', $uri);
$sub    = isset($parts[1]) ? trim(explode('?', $parts[1])[0], '/') : '';
$target_id = $sub ?: null;

// ── POST /v1/files (upload) ───────────────────────────────────
if ($method === 'POST' && !$target_id) {
    if (empty($_FILES['file'])) {
        v1_error('Send file in multipart/form-data field named "file".', 400);
    }

    $f        = $_FILES['file'];
    $purpose  = trim($_POST['purpose'] ?? 'assistants');
    $orig     = basename($f['name']);
    $ext      = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    $size     = (int)$f['size'];
    $mime     = mime_content_type($f['tmp_name']) ?: 'application/octet-stream';

    if ($size > 20 * 1024 * 1024) v1_error('File exceeds 20 MB limit.', 400);

    $text_exts  = ['txt','md','csv','json','xml','html','htm','css','js','ts','py','php',
                   'java','c','cpp','h','rs','go','rb','sh','yaml','yml','ini','toml',
                   'env','log','sql','graphql'];
    $image_exts = ['jpg','jpeg','png','gif','webp','bmp'];

    $content_text = null;
    $content_b64  = null;

    if (in_array($ext, $image_exts, true)) {
        $content_b64 = base64_encode(file_get_contents($f['tmp_name']));
    } elseif ($ext === 'pdf') {
        $content_text = "[PDF: {$orig} — text extraction requires pdftotext on server]";
    } elseif (in_array($ext, $text_exts, true) || str_starts_with($mime, 'text/')) {
        $content_text = mb_substr(file_get_contents($f['tmp_name']), 0, 200000);
    } else {
        $content_b64 = base64_encode(file_get_contents($f['tmp_name']));
    }

    $file_id = uuid4();
    $row_id  = uuid4();

    db()->prepare("
        INSERT INTO uploaded_files
            (id, file_id, api_key_id, original_name, mime_type, size_bytes,
             content_text, content_b64, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ")->execute([$row_id, $file_id, $kid, $orig, $mime, $size, $content_text, $content_b64]);

    echo json_encode([
        'id'       => $file_id,
        'object'   => 'file',
        'bytes'    => $size,
        'created_at' => time(),
        'filename' => $orig,
        'purpose'  => $purpose,
        'status'   => 'processed',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ── GET /v1/files (list) ──────────────────────────────────────
if ($method === 'GET' && !$target_id) {
    $stmt = db()->prepare("
        SELECT DISTINCT file_id, original_name, mime_type, size_bytes, created_at
        FROM uploaded_files WHERE api_key_id = ?
        ORDER BY created_at DESC LIMIT 100
    ");
    $stmt->execute([$kid]);
    $rows = $stmt->fetchAll();

    $data = array_map(fn($r) => [
        'id'         => $r['file_id'],
        'object'     => 'file',
        'bytes'      => (int)$r['size_bytes'],
        'created_at' => strtotime($r['created_at']),
        'filename'   => $r['original_name'],
        'purpose'    => 'assistants',
        'status'     => 'processed',
    ], $rows);

    echo json_encode(['object' => 'list', 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

// ── GET /v1/files/<id> ────────────────────────────────────────
if ($method === 'GET' && $target_id) {
    $stmt = db()->prepare(
        "SELECT * FROM uploaded_files WHERE file_id = ? AND api_key_id = ? LIMIT 1"
    );
    $stmt->execute([$target_id, $kid]);
    $r = $stmt->fetch();

    if (!$r) v1_error("File '{$target_id}' not found.", 404, 'not_found');

    echo json_encode([
        'id'         => $r['file_id'],
        'object'     => 'file',
        'bytes'      => (int)$r['size_bytes'],
        'created_at' => strtotime($r['created_at']),
        'filename'   => $r['original_name'],
        'purpose'    => 'assistants',
        'status'     => 'processed',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ── DELETE /v1/files/<id> ─────────────────────────────────────
if ($method === 'DELETE' && $target_id) {
    $stmt = db()->prepare(
        "DELETE FROM uploaded_files WHERE file_id = ? AND api_key_id = ?"
    );
    $stmt->execute([$target_id, $kid]);

    if ($stmt->rowCount() === 0) v1_error("File '{$target_id}' not found.", 404, 'not_found');

    echo json_encode([
        'id'      => $target_id,
        'object'  => 'file',
        'deleted' => true,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

v1_error('Method not allowed.', 405, 'method_not_allowed');
