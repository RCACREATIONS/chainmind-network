<?php
// ============================================================
// ChainMind — Reset Password API
// POST /api/auth/reset-password.php
// ============================================================
session_start();
require_once __DIR__ . '/../../api/_helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /auth/login.php'); exit;
}

$token    = trim($_POST['token']            ?? '');
$password = $_POST['password']              ?? '';
$confirm  = $_POST['password_confirm']      ?? '';

if (!$token) {
    header('Location: /auth/forgot-password.php?error=no_token'); exit;
}

// Validate password
if (strlen($password) < 8) {
    header('Location: /auth/reset-password.php?token=' . urlencode($token) . '&error=short'); exit;
}
if ($password !== $confirm) {
    header('Location: /auth/reset-password.php?token=' . urlencode($token) . '&error=mismatch'); exit;
}

$db         = db();
$token_hash = hash('sha256', $token);

// Look up the token
$stmt = $db->prepare(
    'SELECT * FROM password_resets WHERE token = ? AND expires_at > NOW() LIMIT 1'
);
$stmt->execute([$token_hash]);
$reset = $stmt->fetch();

if (!$reset) {
    // Distinguish expired vs invalid
    $check = $db->prepare('SELECT expires_at FROM password_resets WHERE token = ? LIMIT 1');
    $check->execute([$token_hash]);
    $old = $check->fetch();
    $err = $old ? 'expired' : 'invalid_token';
    header('Location: /auth/reset-password.php?token=' . urlencode($token) . '&error=' . $err); exit;
}

// Update password
$hash = password_hash($password, PASSWORD_DEFAULT);
$upd  = $db->prepare('UPDATE users SET password_hash = ? WHERE email = ?');
$upd->execute([$hash, $reset['email']]);

if ($upd->rowCount() === 0) {
    header('Location: /auth/reset-password.php?token=' . urlencode($token) . '&error=failed'); exit;
}

// Consume the token (delete it so it can't be reused)
$db->prepare('DELETE FROM password_resets WHERE token = ?')->execute([$token_hash]);

// Invalidate any active sessions for this user (security best practice)
// (skip if you don't track sessions in DB)

header('Location: /auth/reset-password.php?done=1'); exit;
