<?php
// ============================================================
// ChainMind — Forgot Password API
// POST /api/auth/forgot-password.php
// ============================================================
session_start();
require_once __DIR__ . '/../../api/_helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /auth/forgot-password.php'); exit;
}

$email = strtolower(trim($_POST['email'] ?? ''));

if (!$email) {
    header('Location: /auth/forgot-password.php?error=no_email'); exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: /auth/forgot-password.php?error=invalid_email&email=' . urlencode($email)); exit;
}

// ── Rate limit: max 3 requests per email per 15 minutes ───────────────────────
$db = db();
$recent = $db->prepare(
    'SELECT COUNT(*) FROM password_resets WHERE email = ? AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)'
);
$recent->execute([$email]);
if ((int)$recent->fetchColumn() >= 3) {
    header('Location: /auth/forgot-password.php?error=rate_limit&email=' . urlencode($email)); exit;
}

// ── Look up user (we respond the same whether found or not — prevents enumeration) ──
$stmt = $db->prepare('SELECT id, name FROM users WHERE email = ? LIMIT 1');
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user) {
    // Delete any existing tokens for this email
    $db->prepare('DELETE FROM password_resets WHERE email = ?')->execute([$email]);

    // Generate a secure token
    $token   = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', time() + 1800); // 30 minutes

    $db->prepare(
        'INSERT INTO password_resets (email, token, expires_at, created_at) VALUES (?, ?, ?, NOW())'
    )->execute([$email, hash('sha256', $token), $expires]);

    // Build reset link
    $link = 'https://chainmind.com.ng/auth/reset-password.php?token=' . urlencode($token);
    $name = htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8');

    // ── Send email ────────────────────────────────────────────────────────────
    $subject = 'Reset your ChainMind password';
    $body    = "Hi {$user['name']},\n\n"
             . "We received a request to reset your ChainMind password.\n\n"
             . "Click the link below to choose a new password (expires in 30 minutes):\n\n"
             . $link . "\n\n"
             . "If you didn't request this, you can safely ignore this email.\n\n"
             . "— The ChainMind Team";

    $html_body = <<<HTML
<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
  body{font-family:'Plus Jakarta Sans',Arial,sans-serif;background:#080a17;color:#eeeeff;margin:0;padding:0}
  .wrap{max-width:560px;margin:40px auto;padding:0 20px}
  .card{background:#0d0e1c;border:1px solid rgba(139,60,247,.2);border-radius:16px;padding:36px}
  .logo{font-size:22px;font-weight:800;margin-bottom:28px}
  .chain{color:#c4b5fd}.mind{color:#eeeeff}
  h2{font-size:20px;font-weight:700;margin:0 0 12px}
  p{color:#c5c8f0;font-size:15px;line-height:1.6;margin:0 0 16px}
  .btn{display:inline-block;background:linear-gradient(135deg,#8b3cf7,#4f46e5);color:#fff;
       text-decoration:none;padding:13px 28px;border-radius:10px;font-weight:700;font-size:15px;margin:8px 0 24px}
  .footer{color:#6b6fa0;font-size:12px;margin-top:24px;border-top:1px solid rgba(139,60,247,.12);padding-top:16px}
  .link-text{color:#a78bfa;word-break:break-all;font-size:13px}
</style></head>
<body><div class="wrap"><div class="card">
  <div class="logo"><span class="chain">Chain</span><span class="mind">Mind</span></div>
  <h2>Reset your password</h2>
  <p>Hi {$name},</p>
  <p>We received a request to reset your password. Click the button below — this link expires in <strong>30 minutes</strong>.</p>
  <a href="{$link}" class="btn">Reset my password</a>
  <p>If the button doesn't work, copy this link into your browser:</p>
  <p class="link-text">{$link}</p>
  <div class="footer">If you didn't request a password reset, ignore this email. Your password won't change.</div>
</div></div></body></html>
HTML;

    $boundary = '=_ChainMind_' . md5(uniqid());
    $headers  = implode("\r\n", [
        'From: ChainMind <noreply@chainmind.com.ng>',
        'Reply-To: noreply@chainmind.com.ng',
        'MIME-Version: 1.0',
        "Content-Type: multipart/alternative; boundary=\"{$boundary}\"",
        'X-Mailer: ChainMind/1.0',
    ]);

    $message = "--{$boundary}\r\n"
             . "Content-Type: text/plain; charset=UTF-8\r\n\r\n"
             . $body . "\r\n\r\n"
             . "--{$boundary}\r\n"
             . "Content-Type: text/html; charset=UTF-8\r\n\r\n"
             . $html_body . "\r\n\r\n"
             . "--{$boundary}--";

    $sent = @mail($email, $subject, $message, $headers);

    if (!$sent) {
        error_log("[ChainMind] mail() failed for password reset to {$email}");
        // Still redirect to success — don't reveal whether email exists
    }
}

// Always show success (prevents email enumeration)
header('Location: /auth/forgot-password.php?sent=1'); exit;
