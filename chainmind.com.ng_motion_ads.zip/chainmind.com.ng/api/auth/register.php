<?php
// ============================================================
// ChainMind — Auth API: Register  (with email verification)
// Upload to: api/auth/register.php
// ============================================================
session_start();
require_once __DIR__ . '/../../api/_helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { json_err('Method not allowed', 405); }

$name     = trim($_POST['name']             ?? '');
$email    = strtolower(trim($_POST['email'] ?? ''));
$pass     = $_POST['password']              ?? '';
$confirm  = $_POST['password_confirm']      ?? '';
$role     = ($_POST['role'] ?? 'user') === 'node' ? 'node' : 'user';
$nodename = trim($_POST['node_name']        ?? '');

// Validate
if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: /auth/register.php?error=bad_email'); exit;
}
if (strlen($pass) < 8) { header('Location: /auth/register.php?error=weak_pass'); exit; }
if ($pass !== $confirm) { header('Location: /auth/register.php?error=mismatch'); exit; }

// Check duplicate
$dup = db()->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
$dup->execute([$email]);
if ($dup->fetch()) { header('Location: /auth/register.php?error=email_taken'); exit; }

$hash         = password_hash($pass, PASSWORD_BCRYPT, ['cost' => 11]);
$verify_token = bin2hex(random_bytes(32));
$token_expiry = date('Y-m-d H:i:s', time() + 3600); // 1 hour

db()->beginTransaction();
try {
    $display_name = $name ?: explode('@', $email)[0];

    db()->prepare(
        'INSERT INTO users (email, password_hash, name, role, email_verified, verify_token, verify_token_expires, first_login)
         VALUES (?, ?, ?, ?, 0, ?, ?, 1)'
    )->execute([$email, $hash, $display_name, $role, $verify_token, $token_expiry]);
    $user_id = (int)db()->lastInsertId();

    // Default API key
    $api_key = 'cm-' . bin2hex(random_bytes(20));
    db()->prepare(
        'INSERT INTO api_keys (api_key, owner_name, owner_email, user_id, is_active)
         VALUES (?, ?, ?, ?, 1)'
    )->execute([$api_key, $display_name, $email, $user_id]);

    $ak = db()->prepare('SELECT id FROM api_keys WHERE api_key = ? LIMIT 1');
    $ak->execute([$api_key]);
    $key_id = (int)($ak->fetchColumn() ?: 0);

    // 30-credit signup bonus
    if ($key_id) {
        db()->prepare(
            'INSERT INTO credits (api_key_id, balance) VALUES (?, 30)
             ON DUPLICATE KEY UPDATE balance = balance + 30'
        )->execute([$key_id]);
    }

    // If node operator — create node placeholder linked to this user
    $node_secret_for_email = null;
    if ($role === 'node' && $nodename) {
        $node_id         = uuid4();
        $per_node_secret = bin2hex(random_bytes(16));
        db()->prepare(
            'INSERT INTO nodes (id, name, secret, user_id, linked_email, linked_at, status, tier)
             VALUES (?, ?, ?, ?, ?, NOW(), "offline", "standard")'
        )->execute([$node_id, $nodename, $per_node_secret, $user_id, $email]);
        $node_secret_for_email = $per_node_secret;
    }

    db()->commit();
} catch (\Throwable $e) {
    db()->rollBack();
    error_log('[register] ' . $e->getMessage());
    header('Location: /auth/register.php?error=failed'); exit;
}

// ── Send verification + welcome email ─────────────────────────────────────────
$verify_url = 'https://chainmind.com.ng/auth/verify-email.php?token=' . urlencode($verify_token);

if ($role === 'node') {
    $body_html = "
        <h2 style='color:#e6edf3;margin:0 0 .5rem'>Welcome to ChainMind, {$display_name}! 🚀</h2>
        <p style='color:#8b949e;font-size:.9rem;margin:.5rem 0 1.5rem'>You've registered as a <strong style='color:#58a6ff'>Node Operator</strong>. Please verify your email to activate your account.</p>
        <div style='background:#0d1117;border:1px solid #30363d;border-radius:8px;padding:1.25rem;margin-bottom:1.5rem;text-align:center'>
            <p style='color:#8b949e;font-size:.8rem;margin:0 0 .75rem'>Click the button below to verify your email address</p>
            <a href='{$verify_url}' style='display:inline-block;background:#238636;color:#fff;text-decoration:none;padding:.65rem 1.75rem;border-radius:8px;font-weight:700;font-size:.9rem'>✓ Verify Email &amp; Get Started</a>
            <p style='color:#8b949e;font-size:.75rem;margin:.75rem 0 0'>Link expires in 1 hour</p>
        </div>
        <p style='color:#c9d1d9;font-size:.875rem;margin-bottom:1rem'>After verifying, you'll be taken to the <strong>Node Download Page</strong> where you'll find:</p>
        <ul style='color:#c9d1d9;font-size:.875rem;padding-left:1.25rem;margin-bottom:1.5rem'>
            <li style='margin-bottom:.4rem'>ChainMind Node download</li>
            <li style='margin-bottom:.4rem'>Your unique <strong>node secret</strong> to paste into config.yaml</li>
            <li style='margin-bottom:.4rem'>Step-by-step setup instructions</li>
        </ul>
        <div style='background:rgba(88,166,255,.06);border:1px solid rgba(88,166,255,.2);border-radius:8px;padding:1rem;font-size:.8rem;color:#8b949e'>
            If the button doesn't work, copy this link:<br>
            <a href='{$verify_url}' style='color:#58a6ff;word-break:break-all'>{$verify_url}</a>
        </div>
    ";
    send_email($email, 'Welcome to ChainMind — Verify your email to get your node secret', email_html('Welcome to ChainMind', $body_html));
} else {
    $body_html = "
        <h2 style='color:#e6edf3;margin:0 0 .5rem'>Welcome to ChainMind, {$display_name}!</h2>
        <p style='color:#8b949e;font-size:.9rem;margin:.5rem 0 1.5rem'>Your account has been created. Please verify your email to access the dashboard.</p>
        <div style='background:#0d1117;border:1px solid #30363d;border-radius:8px;padding:1.25rem;margin-bottom:1.5rem;text-align:center'>
            <p style='color:#8b949e;font-size:.8rem;margin:0 0 .75rem'>Click the button below to verify your email address</p>
            <a href='{$verify_url}' style='display:inline-block;background:#238636;color:#fff;text-decoration:none;padding:.65rem 1.75rem;border-radius:8px;font-weight:700;font-size:.9rem'>✓ Verify My Email</a>
            <p style='color:#8b949e;font-size:.75rem;margin:.75rem 0 0'>Link expires in 1 hour</p>
        </div>
        <p style='color:#c9d1d9;font-size:.875rem;margin-bottom:1rem'>Once verified you can:</p>
        <ul style='color:#c9d1d9;font-size:.875rem;padding-left:1.25rem;margin-bottom:1.5rem'>
            <li style='margin-bottom:.4rem'>Use the ChainMind AI chat</li>
            <li style='margin-bottom:.4rem'>Access your API key</li>
            <li style='margin-bottom:.4rem'>Buy credits and manage billing</li>
        </ul>
        <div style='background:rgba(88,166,255,.06);border:1px solid rgba(88,166,255,.2);border-radius:8px;padding:1rem;font-size:.8rem;color:#8b949e'>
            If the button doesn't work, copy this link:<br>
            <a href='{$verify_url}' style='color:#58a6ff;word-break:break-all'>{$verify_url}</a>
        </div>
    ";
    send_email($email, 'Welcome to ChainMind — Verify your email', email_html('Welcome to ChainMind', $body_html));
}

header('Location: /auth/check-email.php?email=' . urlencode($email) . '&role=' . urlencode($role)); exit;
