<?php
  // ============================================================
  // ChainMind  Resend Verification Email
  // Upload to: api/auth/resend-verification.php
  // Supports both:
  //   - Regular form POST  → redirects back (with ?resend=xxx)
  //   - AJAX POST (X-Requested-With: XMLHttpRequest OR json=1)
  //     → returns {"status":"sent"|"too_soon"|"error"|"already_verified"}
  // ============================================================
  session_start();
  require_once __DIR__ . '/../../api/_helpers.php';

  // Only accept POST
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
      header('Location: /auth/login.php'); exit;
  }

  $is_ajax = (
      ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest' ||
      !empty($_POST['json'])
  );

  function json_resp(string $status, string $msg = ''): void {
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['status' => $status, 'msg' => $msg]);
      exit;
  }

  function redir(string $base, string $key, string $value, bool $ajax): void {
      if ($ajax) { json_resp($value); }
      $sep = strpos($base, '?') !== false ? '&' : '?';
      header('Location: ' . $base . $sep . rawurlencode($key) . '=' . rawurlencode($value));
      exit;
  }

  $email     = strtolower(trim($_POST['email'] ?? ''));
  $role_hint = trim($_POST['role'] ?? 'user');

  $redirect_to = trim($_POST['redirect_to'] ?? '');
  if (!preg_match('#^/[a-zA-Z0-9/_?&=.%-]*$#', $redirect_to)) {
      $redirect_to = '';
  }

  function base_url(string $redirect_to, string $email, string $role): string {
      if ($redirect_to) return $redirect_to;
      return '/auth/check-email.php?email=' . urlencode($email) . '&role=' . urlencode($role);
  }

  // Validate email format
  if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
      redir(
          $redirect_to ?: '/auth/check-email.php?email=' . urlencode($email),
          'resend', 'bad_email', $is_ajax
      );
  }

  // Look up the user
  $stmt = db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
  $stmt->execute([$email]);
  $user = $stmt->fetch();

  if (!$user) {
      // Don\'t reveal whether the email exists
      redir(base_url($redirect_to, $email, $role_hint), 'resend', 'sent', $is_ajax);
  }

  if ((int)$user['email_verified'] === 1) {
      redir($redirect_to ?: '/auth/login.php', 'resend', 'already_verified', $is_ajax);
  }

  $role = $user['role'] ?: 'user';

  // Rate limit: max 1 resend per 60 seconds
  if (!empty($user['verify_token_expires'])) {
      $expires_ts    = strtotime($user['verify_token_expires']);
      $token_age_sec = 3600 - ($expires_ts - time());
      if ($token_age_sec < 60) {
          redir(base_url($redirect_to, $email, $role), 'resend', 'too_soon', $is_ajax);
      }
  }

  // Generate a fresh token
  $new_token  = bin2hex(random_bytes(32));
  $new_expiry = date('Y-m-d H:i:s', time() + 3600);

  db()->prepare(
      'UPDATE users SET verify_token = ?, verify_token_expires = ? WHERE id = ?'
  )->execute([$new_token, $new_expiry, $user['id']]);

  // Build the verification URL
  $verify_url   = 'https://chainmind.com.ng/auth/verify-email.php?token=' . urlencode($new_token);
  $display_name = $user['name'] ?: explode('@', $email)[0];

  // Email body based on role
  if ($role === 'node') {
      $body_html = "
          <h2 style='color:#e6edf3;margin:0 0 .5rem'>Verify your ChainMind account</h2>
          <p style='color:#8b949e;font-size:.9rem;margin:.5rem 0 1.5rem'>
              Hi <strong style='color:#e6edf3'>{$display_name}</strong> &mdash; here is your new verification link.
              Your previous link has been replaced. This one expires in <strong>1 hour</strong>.
          </p>
          <div style='background:#0d1117;border:1px solid #30363d;border-radius:8px;padding:1.5rem;margin-bottom:1.5rem;text-align:center'>
              <p style='color:#8b949e;font-size:.85rem;margin:0 0 1rem'>Click below to verify and get your node secret</p>
              <a href='{$verify_url}'
                 style='display:inline-block;background:#238636;color:#ffffff;text-decoration:none;
                        padding:.75rem 2rem;border-radius:8px;font-weight:700;font-size:.95rem'>
                  &#10003; Verify My Email
              </a>
              <p style='color:#8b949e;font-size:.75rem;margin:1rem 0 0'>Link expires in 1 hour</p>
          </div>
          <ul style='color:#c9d1d9;font-size:.875rem;padding-left:1.25rem;margin-bottom:1.5rem;line-height:1.8'>
              <li>ChainMind Node download link</li>
              <li>Your unique <strong>node secret</strong> for config.yaml</li>
              <li>Step-by-step setup guide</li>
          </ul>
          <div style='background:rgba(88,166,255,.06);border:1px solid rgba(88,166,255,.2);border-radius:8px;
                      padding:1rem;font-size:.8rem;color:#8b949e;word-break:break-all'>
              If the button does not work, copy this link into your browser:<br><br>
              <a href='{$verify_url}' style='color:#58a6ff'>{$verify_url}</a>
          </div>
      ";
      $subject = 'ChainMind - New verification link for your node operator account';
  } else {
      $body_html = "
          <h2 style='color:#e6edf3;margin:0 0 .5rem'>Verify your ChainMind account</h2>
          <p style='color:#8b949e;font-size:.9rem;margin:.5rem 0 1.5rem'>
              Hi <strong style='color:#e6edf3'>{$display_name}</strong> &mdash; here is your new verification link.
              Your previous link has been replaced. This one expires in <strong>1 hour</strong>.
          </p>
          <div style='background:#0d1117;border:1px solid #30363d;border-radius:8px;padding:1.5rem;margin-bottom:1.5rem;text-align:center'>
              <p style='color:#8b949e;font-size:.85rem;margin:0 0 1rem'>Click below to activate your account</p>
              <a href='{$verify_url}'
                 style='display:inline-block;background:#238636;color:#ffffff;text-decoration:none;
                        padding:.75rem 2rem;border-radius:8px;font-weight:700;font-size:.95rem'>
                  &#10003; Verify My Email
              </a>
              <p style='color:#8b949e;font-size:.75rem;margin:1rem 0 0'>Link expires in 1 hour</p>
          </div>
          <ul style='color:#c9d1d9;font-size:.875rem;padding-left:1.25rem;margin-bottom:1.5rem;line-height:1.8'>
              <li>Use the ChainMind AI chat</li>
              <li>Access your API key</li>
              <li>Buy credits and manage billing</li>
          </ul>
          <div style='background:rgba(88,166,255,.06);border:1px solid rgba(88,166,255,.2);border-radius:8px;
                      padding:1rem;font-size:.8rem;color:#8b949e;word-break:break-all'>
              If the button does not work, copy this link into your browser:<br><br>
              <a href='{$verify_url}' style='color:#58a6ff'>{$verify_url}</a>
          </div>
      ";
      $subject = 'ChainMind - New verification link for your account';
  }

  $sent = send_email($email, $subject, email_html('Verify your ChainMind account', $body_html));

  if (!$sent) {
      error_log("[resend_verification] send_email failed for {$email}");
  }

  redir(base_url($redirect_to, $email, $role), 'resend', $sent ? 'sent' : 'error', $is_ajax);
  