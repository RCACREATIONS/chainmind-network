<?php
// ============================================================
// ChainMind  Auth API: Login
// Upload to: api/auth/login.php
// ============================================================
session_start();
require_once __DIR__ . '/../../api/_helpers.php';
cors();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { json_err('Method not allowed', 405); }
$email    = trim($_POST['email']    ?? '');
$password = $_POST['password'] ?? '';
$next     = trim($_POST['next']     ?? '/dashboard/');
if (!$email || !$password) {
    header('Location: /auth/login.php?error=invalid'); exit;
}
$stmt = db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
$stmt->execute([strtolower($email)]);
$user = $stmt->fetch();
if (!$user || !password_verify($password, $user['password_hash'])) {
    header('Location: /auth/login.php?error=invalid'); exit;
}
// Block unverified accounts
if (!($user['email_verified'] ?? 1)) {
    header('Location: /auth/check-email.php?email=' . urlencode($email) . '&role=' . urlencode($user['role'])); exit;
}
// Update last login + clear first_login flag after reading it
$is_first   = (int)($user['first_login'] ?? 0);
$is_node    = $user['role'] === 'node';
db()->prepare('UPDATE users SET last_login = NOW(), first_login = 0 WHERE id = ?')->execute([$user['id']]);
$_SESSION['user_id']    = $user['id'];
$_SESSION['user_email'] = $user['email'];
$_SESSION['user_name']  = $user['name'];
$_SESSION['user_role']  = $user['role'];
// Node operator + first login → take them to the download & setup page
if ($is_node && $is_first) {
    header('Location: /dashboard/node-download.php'); exit;
}
// Sanitise redirect
$safe_next = preg_match('#^/#', $next) ? $next : '/dashboard/';
// Default API/regular users to the chat tab instead of overview
if (!$is_node && $safe_next === '/dashboard/') {
    $safe_next = '/dashboard/?tab=chat';
}
header('Location: ' . $safe_next); exit;