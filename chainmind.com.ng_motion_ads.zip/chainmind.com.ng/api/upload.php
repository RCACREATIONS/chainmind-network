<?php
// ============================================================
// ChainMind  File Upload Endpoint
// POST /api/upload.php
//
// Accepts: images, text files, PDFs, CSVs, ZIPs, code files
// Returns: { file_id, files: [{name, type, size, content_preview}] }
//
// The returned file_id is passed to /api/infer.php or
// /api/v1/chat/completions as  "file_ids": ["<file_id>"]
// ============================================================

require_once __DIR__ . '/_helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST only', 405);

// ── Auth: session user OR api key ─────────────────────────────
$api_key_id = null;
$user_id    = null;

session_start();
if (!empty($_SESSION['user_id'])) {
    $user_id = (int)$_SESSION['user_id'];
} elseif (!empty($_SERVER['HTTP_X_API_KEY'])) {
    $keyRow     = validate_api_key();
    $api_key_id = (int)$keyRow['id'];
} else {
    json_err('Authentication required. Send X-Api-Key header or log in.', 401);
}

// ── Ensure upload storage table exists ───────────────────────
db()->exec("
    CREATE TABLE IF NOT EXISTS uploaded_files (
        id          VARCHAR(36)  PRIMARY KEY,
        file_id     VARCHAR(36)  NOT NULL,
        user_id     INT          NULL,
        api_key_id  INT          NULL,
        original_name VARCHAR(255) NOT NULL,
        mime_type   VARCHAR(100) NOT NULL,
        size_bytes  INT          NOT NULL,
        content_text MEDIUMTEXT  NULL,
        content_b64  MEDIUMTEXT  NULL,
        created_at  DATETIME     NOT NULL DEFAULT NOW(),
        INDEX idx_file_id (file_id),
        INDEX idx_user (user_id),
        INDEX idx_apikey (api_key_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// ── Config ────────────────────────────────────────────────────
const MAX_FILE_SIZE    = 20 * 1024 * 1024;  // 20 MB per file
const MAX_TOTAL_SIZE   = 50 * 1024 * 1024;  // 50 MB total per request
const MAX_FILES        = 10;
const MAX_TEXT_CHARS   = 200000;             // chars extracted per text file

const ALLOWED_MIME = [
    // Images (passed as base64 to vision models)
    'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/bmp',
    // Text
    'text/plain', 'text/csv', 'text/html', 'text/markdown',
    'text/x-python', 'text/x-php', 'text/javascript', 'text/css',
    'text/x-c', 'text/x-c++', 'text/x-java',
    // Application
    'application/json', 'application/xml', 'application/pdf',
    'application/zip', 'application/x-zip-compressed',
    'application/octet-stream',  // generic — we sniff by extension
];

const TEXT_EXTENSIONS = [
    'txt','md','csv','json','xml','html','htm','css','js','ts',
    'py','php','java','c','cpp','h','rs','go','rb','sh','yaml','yml',
    'ini','toml','env','log','sql','graphql','tf','dockerfile',
];

const IMAGE_EXTENSIONS = ['jpg','jpeg','png','gif','webp','bmp'];

// ── Validate upload ───────────────────────────────────────────
if (empty($_FILES)) {
    json_err('No files uploaded. Send multipart/form-data with field name "files[]".', 400);
}

$uploaded = $_FILES['files'] ?? $_FILES['file'] ?? null;
if (!$uploaded) {
    json_err('File field must be named "files[]" or "file".', 400);
}

// Normalise single-file upload to array format
if (!is_array($uploaded['name'])) {
    $uploaded = [
        'name'     => [$uploaded['name']],
        'type'     => [$uploaded['type']],
        'tmp_name' => [$uploaded['tmp_name']],
        'error'    => [$uploaded['error']],
        'size'     => [$uploaded['size']],
    ];
}

$count = count($uploaded['name']);
if ($count > MAX_FILES) json_err('Too many files. Max ' . MAX_FILES . ' per request.', 400);

// ── Process each file ─────────────────────────────────────────
$file_id      = uuid4();   // one group ID for all files in this upload
$saved_files  = [];
$total_bytes  = 0;

for ($i = 0; $i < $count; $i++) {
    if ($uploaded['error'][$i] !== UPLOAD_ERR_OK) {
        json_err("Upload error on file {$uploaded['name'][$i]}: code {$uploaded['error'][$i]}", 400);
    }

    $orig_name  = basename($uploaded['name'][$i]);
    $size       = (int)$uploaded['size'][$i];
    $tmp_path   = $uploaded['tmp_name'][$i];
    $ext        = strtolower(pathinfo($orig_name, PATHINFO_EXTENSION));

    if ($size > MAX_FILE_SIZE) {
        json_err("File '{$orig_name}' exceeds 20 MB limit.", 400);
    }
    $total_bytes += $size;
    if ($total_bytes > MAX_TOTAL_SIZE) {
        json_err('Total upload size exceeds 50 MB limit.', 400);
    }

    $mime = mime_content_type($tmp_path) ?: 'application/octet-stream';

    // ── Extract content ───────────────────────────────────────
    $content_text = null;
    $content_b64  = null;
    $content_preview = null;

    if (in_array($ext, IMAGE_EXTENSIONS, true)) {
        // Image: store as base64 for vision model
        $raw         = file_get_contents($tmp_path);
        $content_b64 = base64_encode($raw);
        $content_preview = "[Image: {$orig_name}, " . round($size/1024, 1) . " KB]";

    } elseif ($ext === 'zip') {
        // ZIP: extract and process each file inside
        $content_text = extract_zip_contents($tmp_path, $orig_name);
        $content_preview = mb_substr($content_text, 0, 300) . '...';

    } elseif ($ext === 'pdf') {
        // PDF: extract text via pdftotext if available, else note it
        $content_text = extract_pdf_text($tmp_path, $orig_name);
        $content_preview = mb_substr($content_text, 0, 300) . '...';

    } elseif (in_array($ext, TEXT_EXTENSIONS, true) || str_starts_with($mime, 'text/')) {
        // Plain text / code / data
        $raw = file_get_contents($tmp_path);
        if (!mb_detect_encoding($raw, 'UTF-8', true)) {
            $raw = mb_convert_encoding($raw, 'UTF-8', 'auto');
        }
        $content_text    = mb_substr($raw, 0, MAX_TEXT_CHARS);
        $content_preview = mb_substr($content_text, 0, 300) . '...';

    } else {
        // Unknown binary — store raw as base64, let the model decide
        $raw         = file_get_contents($tmp_path);
        $content_b64 = base64_encode($raw);
        $content_preview = "[Binary file: {$orig_name}, " . round($size/1024, 1) . " KB]";
    }

    // ── Persist to DB ─────────────────────────────────────────
    $row_id = uuid4();
    db()->prepare("
        INSERT INTO uploaded_files
            (id, file_id, user_id, api_key_id, original_name, mime_type,
             size_bytes, content_text, content_b64, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ")->execute([
        $row_id, $file_id,
        $user_id, $api_key_id,
        $orig_name, $mime,
        $size,
        $content_text ? mb_substr($content_text, 0, MAX_TEXT_CHARS) : null,
        $content_b64,
    ]);

    $saved_files[] = [
        'name'            => $orig_name,
        'type'            => $mime,
        'extension'       => $ext,
        'size_bytes'      => $size,
        'content_preview' => $content_preview,
        'has_text'        => $content_text !== null,
        'has_image'       => $content_b64 !== null && in_array($ext, IMAGE_EXTENSIONS, true),
    ];
}

json_ok([
    'file_id'   => $file_id,
    'files'     => $saved_files,
    'total_files' => count($saved_files),
    'message'   => 'Files uploaded. Pass file_id to /api/infer.php or /api/v1/chat/completions.',
]);

// ============================================================
//  Helpers
// ============================================================

/**
 * Extract text content from a ZIP archive.
 * Recursively reads text and image files inside.
 */
function extract_zip_contents(string $tmp_path, string $zip_name): string {
    $za = new ZipArchive();
    if ($za->open($tmp_path) !== true) {
        return "[Could not open ZIP file: {$zip_name}]";
    }

    $text_extensions  = TEXT_EXTENSIONS;
    $image_extensions = IMAGE_EXTENSIONS;
    $output_parts     = ["=== Contents of {$zip_name} ===\n"];
    $total_chars      = 0;
    $max_chars        = 150000;

    for ($j = 0; $j < $za->numFiles; $j++) {
        $stat = $za->statIndex($j);
        $inner_name = $stat['name'];

        // Skip directories and hidden files
        if (str_ends_with($inner_name, '/') || str_starts_with(basename($inner_name), '.')) {
            continue;
        }

        $inner_ext  = strtolower(pathinfo($inner_name, PATHINFO_EXTENSION));
        $inner_size = (int)$stat['size'];

        // Skip large files inside zip
        if ($inner_size > 5 * 1024 * 1024) {
            $output_parts[] = "\n--- {$inner_name} [SKIPPED: too large ({$inner_size} bytes)] ---\n";
            continue;
        }

        if (in_array($inner_ext, $text_extensions, true)) {
            $content = $za->getFromIndex($j);
            if ($content === false) continue;
            $text = mb_substr($content, 0, 50000);
            $output_parts[] = "\n--- FILE: {$inner_name} ---\n{$text}\n";
            $total_chars += strlen($text);
        } elseif (in_array($inner_ext, $image_extensions, true)) {
            $output_parts[] = "\n--- IMAGE: {$inner_name} ({$inner_size} bytes) ---\n[Image file — upload separately for vision analysis]\n";
        } else {
            $output_parts[] = "\n--- {$inner_name} [{$inner_ext}, {$inner_size} bytes — binary, skipped] ---\n";
        }

        if ($total_chars >= $max_chars) {
            $output_parts[] = "\n[Truncated: too much content in ZIP]\n";
            break;
        }
    }

    $za->close();
    return implode('', $output_parts);
}

/**
 * Extract text from PDF using system pdftotext (poppler-utils).
 * Falls back to a note if not available.
 */
function extract_pdf_text(string $tmp_path, string $pdf_name): string {
    // Check if pdftotext is available
    $which = shell_exec('which pdftotext 2>/dev/null');
    if ($which) {
        $out_file = sys_get_temp_dir() . '/' . md5($tmp_path) . '.txt';
        shell_exec("pdftotext -enc UTF-8 " . escapeshellarg($tmp_path) . " " . escapeshellarg($out_file) . " 2>/dev/null");
        if (file_exists($out_file)) {
            $text = file_get_contents($out_file);
            unlink($out_file);
            return mb_substr($text, 0, MAX_TEXT_CHARS);
        }
    }

    // Fallback: try to extract raw text chars from PDF binary (rough)
    $raw  = file_get_contents($tmp_path);
    preg_match_all('/BT\s+.*?ET/s', $raw, $matches);
    if (!empty($matches[0])) {
        $text = implode(' ', $matches[0]);
        $text = preg_replace('/[^\x20-\x7E\n]/', ' ', $text);
        $text = preg_replace('/\s+/', ' ', $text);
        return "[PDF text extracted (rough)]\n" . mb_substr(trim($text), 0, 50000);
    }

    return "[PDF file: {$pdf_name}. Could not extract text automatically. " .
           "Install pdftotext (poppler-utils) on the server for better PDF support.]";
}
