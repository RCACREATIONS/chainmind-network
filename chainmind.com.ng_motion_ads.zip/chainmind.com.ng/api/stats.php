<?php
// GET /api/stats.php
// Public endpoint  returns network stats and leaderboard.
// No auth required.

require_once __DIR__ . '/_helpers.php';
cors();

sweep_offline_nodes();

$network = db()->query("
    SELECT
        COUNT(*) AS total_nodes,
        SUM(CASE WHEN status='online' THEN 1 ELSE 0 END) AS online_nodes,
        SUM(jobs_done)  AS total_jobs,
        SUM(iq_earned)  AS total_iq
    FROM nodes
")->fetch();

$jobs = db()->query("
    SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN status='done'    THEN 1 ELSE 0 END) AS done,
        SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending,
        SUM(CASE WHEN status='error'   THEN 1 ELSE 0 END) AS errors
    FROM jobs
")->fetch();

$leaderboard = db()->query("
    SELECT id, name, tier, reputation, jobs_done, iq_earned, status, last_seen
    FROM nodes
    ORDER BY iq_earned DESC
    LIMIT 20
")->fetchAll();

// Strip node URLs and truncate IDs  never expose IPs in public endpoint
foreach ($leaderboard as &$node) {
    $node['id'] = substr($node['id'], 0, 8) . '...';
    unset($node['url']);
}
unset($node);

json_ok([
    'network'     => [
        'total_nodes'  => (int)$network['total_nodes'],
        'online_nodes' => (int)$network['online_nodes'],
        'total_jobs'   => (int)($network['total_jobs'] ?? 0),
        'total_iq'     => round((float)($network['total_iq'] ?? 0), 4),
    ],
    'jobs'        => [
        'total'   => (int)$jobs['total'],
        'done'    => (int)$jobs['done'],
        'pending' => (int)$jobs['pending'],
        'errors'  => (int)$jobs['errors'],
    ],
    'leaderboard' => $leaderboard,
    'version'     => VERSION,
]);
