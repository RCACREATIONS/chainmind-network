<?php
// ============================================================
// ChainMind  SFX Manifest
// GET /api/sfx-manifest.php
//
// Returns a JSON manifest of all sound effect files hosted
// under assets/sfx/{category}/*.mp3
// Public, read-only, no auth needed — just filenames + URLs.
// ============================================================

require_once __DIR__ . '/_helpers.php';
cors();

$base     = __DIR__ . '/../assets/sfx';
$manifest = [];

if (is_dir($base)) {
    foreach (scandir($base) as $category) {
        if ($category === '.' || $category === '..') continue;
        $dir = $base . '/' . $category;
        if (!is_dir($dir)) continue;
        $files = [];
        foreach (scandir($dir) as $file) {
            if (str_ends_with($file, '.mp3')) {
                $files[] = [
                    'name' => $file,
                    'url'  => 'https://chainmind.com.ng/assets/sfx/' . $category . '/' . $file,
                ];
            }
        }
        if ($files) $manifest[$category] = $files;
    }
}

json_ok(['categories' => $manifest]);
