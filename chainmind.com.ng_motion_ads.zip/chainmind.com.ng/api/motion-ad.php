<?php
// ============================================================
// ChainMind  Motion Ad Generator
// POST /api/motion-ad.php
//
// Queues a motion_ad job on the node network.
// A capable node (one with rembg + moviepy + edge-tts installed
// and advertising 'motion_ad' in its capabilities) will claim
// the job, render a short MP4 ad, upload it via submit-video.php,
// then call submit-result.php to complete the earnings payout.
//
// Request body (JSON):
//   {
//     "business_name": "Acme Co",
//     "product":       "Running Shoes",
//     "offer":         "30% off this weekend",
//     "tone":          "energetic",      // optional, default "friendly"
//     "brand_color":   "#7C3AED",        // optional
//     "file_ids":      ["<upload_id>"]   // optional user product photos
//   }
//
// Returns:
//   { job_id, status, poll_url, message, credits_used }
//
// Poll /api/job.php?id=<job_id> — result_video_url will be
// present once done.
// ============================================================

require_once __DIR__ . '/_helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST only', 405);

// ── Auth (API key or web session) ─────────────────────────────
session_start();
$api_key_id = null;
$source     = 'webchat';

$key_header = $_SERVER['HTTP_X_API_KEY'] ?? '';
if ($key_header) {
    $keyRow     = validate_api_key();
    $source     = 'api';
    $api_key_id = (int)$keyRow['id'];
}

// ── Ensure new columns exist ──────────────────────────────────
ensure_jobs_columns();

// ── Ensure result_video_url column exists ─────────────────────
try {
    $col_check = db()->prepare("SHOW COLUMNS FROM jobs LIKE 'result_video_url'");
    $col_check->execute();
    if ($col_check->rowCount() === 0) {
        db()->exec("ALTER TABLE jobs ADD COLUMN result_video_url VARCHAR(500) NULL");
    }
} catch (\Throwable $e) {
    // Safe to ignore — column may already exist
}

// ── Check for capable nodes online ───────────────────────────
sweep_offline_nodes();
$capable = (int)db()->query("
    SELECT COUNT(*) FROM nodes
    WHERE status = 'online'
      AND capabilities LIKE '%motion_ad%'
")->fetchColumn();

if ($capable === 0) {
    json_err(
        'No motion-ad-capable nodes online right now. ' .
        'A node operator needs to install the render dependencies (rembg, moviepy, edge-tts). ' .
        'Try again shortly.',
        503
    );
}

// ── Parse body ────────────────────────────────────────────────
$b            = require_json_body();
$business_name = trim($b['business_name'] ?? '');
$product       = trim($b['product']       ?? '');
$offer         = trim($b['offer']         ?? '');
$tone          = trim($b['tone']          ?? 'friendly');
$brand_color   = trim($b['brand_color']   ?? '#7C3AED');
$file_ids      = $b['file_ids']           ?? [];

if (!$business_name || !$product) json_err('business_name and product are required', 400);
if (mb_strlen($business_name) > 200) json_err('business_name too long (max 200 chars)', 400);
if (mb_strlen($product) > 500)       json_err('product too long (max 500 chars)', 400);
if (mb_strlen($offer) > 500)         json_err('offer too long (max 500 chars)', 400);

$valid_tones = ['friendly', 'energetic', 'professional', 'funny', 'luxury', 'urgent'];
if (!in_array($tone, $valid_tones, true)) $tone = 'friendly';

// ── Credit check ─────────────────────────────────────────────
require_once __DIR__ . '/billing/credits.php';
$ad_cost = 25; // motion ad costs more compute than a single image_gen call

if ($api_key_id) {
    $balance = credits_get($api_key_id);
    if ($balance < $ad_cost) {
        json_err(
            "Insufficient credits. Balance: {$balance}, required: {$ad_cost}. " .
            "Top up at: https://chainmind.com.ng/dashboard/billing.php",
            402
        );
    }
}

// ── Queue job ────────────────────────────────────────────────
$job_id       = uuid4();
$image_params = json_encode([
    'business_name' => $business_name,
    'product'       => $product,
    'offer'         => $offer,
    'tone'          => $tone,
    'brand_color'   => $brand_color,
]);

db()->prepare("
    INSERT INTO jobs (id, prompt, model, system_prompt, status, source, api_key_id,
                      job_type, image_params, file_ids, created_at)
    VALUES (?, '', '', '', 'pending', ?, ?, 'motion_ad', ?, ?, NOW())
")->execute([$job_id, $source, $api_key_id, $image_params, json_encode($file_ids)]);

if ($api_key_id) credits_deduct($api_key_id, $job_id, $ad_cost);

json_ok([
    'job_id'       => $job_id,
    'status'       => 'pending',
    'poll_url'     => "/api/job.php?id={$job_id}",
    'message'      => 'Motion ad queued. Poll poll_url — result_video_url will contain the MP4 link once done.',
    'credits_used' => $ad_cost,
]);
