<?php
// ============================================================
// ChainMind  Image Generation Endpoint
// POST /api/image-gen.php
//
// Queues an image generation job on the node network.
// Nodes with SD or LLaVA pick up job_type='image_gen'.
//
// Request body (JSON):
//   { "prompt": "...", "model": "sd|sdxl|auto", "size": "512x512",
//     "steps": 20, "negative_prompt": "..." }
//
// Returns: { job_id, status, poll_url }
// ============================================================

require_once __DIR__ . '/_helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST only', 405);

// ── Auth ───────────────────────────────────────────────────────
$api_key_id = null;
$source     = 'webchat';

session_start();
$user_id = $_SESSION['user_id'] ?? null;

$key_header = $_SERVER['HTTP_X_API_KEY'] ?? '';
if ($key_header) {
    $keyRow     = validate_api_key();
    $source     = 'api';
    $api_key_id = (int)$keyRow['id'];
}

// ── Ensure job_type column exists on jobs table ────────────────
ensure_jobs_columns();

// ── Ensure image-capable node exists ─────────────────────────
sweep_offline_nodes();
$img_nodes = (int)db()->query("
    SELECT COUNT(*) FROM nodes
    WHERE status = 'online'
      AND (capabilities LIKE '%image_gen%' OR capabilities LIKE '%sd%' OR capabilities LIKE '%stable_diffusion%')
")->fetchColumn();

// Fall back to any online node if no specialist node is online
// (the node will reject if it can't handle it, and the job will re-queue)
$online = (int)db()->query("SELECT COUNT(*) FROM nodes WHERE status = 'online'")->fetchColumn();
if ($online === 0) {
    json_err('No nodes online right now. Try again shortly.', 503);
}

// ── Parse body ────────────────────────────────────────────────
$b = require_json_body();

$prompt          = trim($b['prompt'] ?? '');
$negative_prompt = trim($b['negative_prompt'] ?? '');
$model           = trim($b['model'] ?? 'auto');
$size            = trim($b['size'] ?? '512x512');
$steps           = max(10, min(50, (int)($b['steps'] ?? 20)));
$guidance_scale  = max(1.0, min(20.0, (float)($b['guidance_scale'] ?? 7.5)));
$seed            = isset($b['seed']) ? (int)$b['seed'] : -1;

if (!$prompt) json_err('prompt is required', 400);
if (mb_strlen($prompt) > 2000) json_err('Prompt too long (max 2000 chars)', 400);

// Validate size
$valid_sizes = ['256x256','512x512','768x768','1024x1024','512x768','768x512'];
if (!in_array($size, $valid_sizes, true)) {
    json_err('Invalid size. Allowed: ' . implode(', ', $valid_sizes), 400);
}

// ── Credit check ─────────────────────────────────────────────
require_once __DIR__ . '/billing/credits.php';

// Image gen costs 10 credits (= roughly $0.01)
$img_cost = 10;
if ($api_key_id) {
    $balance = credits_get($api_key_id);
    if ($balance < $img_cost) {
        json_err(
            "Insufficient credits. Balance: {$balance}, required: {$img_cost}. " .
            "Top up at: https://chainmind.com.ng/dashboard/billing.php",
            402
        );
    }
}

// ── Queue image gen job ───────────────────────────────────────
$job_id = uuid4();

$image_params = json_encode([
    'negative_prompt' => $negative_prompt,
    'model'          => $model,
    'size'           => $size,
    'steps'          => $steps,
    'guidance_scale' => $guidance_scale,
    'seed'           => $seed,
]);

db()->prepare("
    INSERT INTO jobs
        (id, prompt, model, system_prompt, status, source, api_key_id,
         job_type, image_params, created_at)
    VALUES (?, ?, ?, '', 'pending', ?, ?,
            'image_gen', ?, NOW())
")->execute([
    $job_id,
    encrypt_field($prompt),
    $model ?: 'sd',
    $source,
    $api_key_id,
    $image_params,
]);

// ── Deduct credits immediately ────────────────────────────────
if ($api_key_id) {
    credits_deduct($api_key_id, $job_id, $img_cost);
}

json_ok([
    'job_id'    => $job_id,
    'status'    => 'pending',
    'poll_url'  => "/api/job.php?id={$job_id}",
    'message'   => 'Image generation queued. Poll poll_url — result will contain base64 image or URL.',
    'credits_used' => $img_cost,
]);
