<?php
// ============================================================
// ChainMind  API Keys  (enhanced with advanced features)
// POST /api/keys.php       — create a key  (auth required or self-service)
// GET  /api/keys.php       — list keys (admin: all keys; user: own keys)
// DELETE /api/keys.php     — revoke a key  { "key_id": N }
// PATCH  /api/keys.php     — update a key  { "key_id": N, "label":..., ... }
// ============================================================

require_once __DIR__ . '/_helpers.php';
cors();

$method = $_SERVER['REQUEST_METHOD'];

// ── Helper: get caller's user_id from session (if running as dashboard) ──
function caller_user_id(): ?int {
    if (session_status() === PHP_SESSION_NONE) @session_start();
    $uid = $_SESSION['user_id'] ?? null;
    return $uid ? (int)$uid : null;
}

// ── Helper: is admin key (id=1 or role=admin) ───────────────────────────
function is_admin_key(array $key_row): bool {
    return (int)$key_row['id'] === 1 || !empty($key_row['is_admin']);
}

// ============================================================
// GET — list keys
// ============================================================
if ($method === 'GET') {
    $key_row = validate_api_key();

    if (is_admin_key($key_row)) {
        // Admin: list all keys with usage stats
        $keys = db()->query("
            SELECT k.*,
                   COALESCE(c.balance,0)              AS credit_balance,
                   COALESCE(u.total_calls,0)           AS total_calls,
                   COALESCE(u.total_credits_used,0)    AS total_credits_used,
                   COALESCE(u.total_tokens,0)          AS total_tokens
            FROM api_keys k
            LEFT JOIN credits c ON c.api_key_id = k.id
            LEFT JOIN (
                SELECT api_key_id,
                       COUNT(*)            AS total_calls,
                       SUM(credits_used)   AS total_credits_used,
                       SUM(tokens_in+tokens_out) AS total_tokens
                FROM api_key_usage GROUP BY api_key_id
            ) u ON u.api_key_id = k.id
            ORDER BY k.created_at DESC
        ")->fetchAll();
    } else {
        // User: own keys only
        $stmt = db()->prepare("
            SELECT k.*,
                   COALESCE(c.balance,0)              AS credit_balance,
                   COALESCE(u.total_calls,0)           AS total_calls,
                   COALESCE(u.total_credits_used,0)    AS total_credits_used
            FROM api_keys k
            LEFT JOIN credits c ON c.api_key_id = k.id
            LEFT JOIN (
                SELECT api_key_id, COUNT(*) AS total_calls, SUM(credits_used) AS total_credits_used
                FROM api_key_usage GROUP BY api_key_id
            ) u ON u.api_key_id = k.id
            WHERE k.owner_email = ? OR k.id = ?
            ORDER BY k.id ASC
        ");
        $stmt->execute([$key_row['owner_email'], $key_row['id']]);
        $keys = $stmt->fetchAll();
    }

    // Mask actual key values
    foreach ($keys as &$k) {
        $raw = $k['api_key'] ?? '';
        $k['api_key_masked'] = strlen($raw) > 8
            ? substr($raw,0,8) . str_repeat('*', max(0, strlen($raw)-12)) . substr($raw,-4)
            : '****';
        unset($k['api_key']);
    }
    json_ok(['keys' => $keys]);
}

// ============================================================
// POST — create key
// ============================================================
if ($method === 'POST') {
    $b = require_json_body();

    // Self-service: user creates their own key (via dashboard session)
    $user_id   = caller_user_id();
    $caller    = null;

    // If X-Api-Key present, validate it (admin usage)
    $xkey = $_SERVER['HTTP_X_API_KEY'] ?? '';
    if ($xkey) {
        $caller = validate_api_key();
    } elseif (!$user_id) {
        json_err('Authentication required. Send X-Api-Key header or be logged in.', 401);
    }

    // Collect key config
    $owner_name   = substr(trim($b['owner_name']    ?? ($caller['owner_name']    ?? '')), 0, 100);
    $owner_email  = substr(strtolower(trim($b['owner_email'] ?? ($caller['owner_email'] ?? ''))), 0, 150);
    $label        = substr(trim($b['label']          ?? 'Default'), 0, 100);
    $rate_rpm     = max(1, min(10000, (int)($b['rate_limit_rpm']  ?? 60)));
    $rate_rpd     = max(1, min(1000000, (int)($b['rate_limit_rpd'] ?? 10000)));
    $credit_quota = isset($b['credit_quota']) ? max(0, (int)$b['credit_quota']) : null;
    $allowed_mdl  = isset($b['allowed_models']) && is_array($b['allowed_models'])
                    ? json_encode(array_map('trim', $b['allowed_models'])) : null;
    $expires_days = isset($b['expires_days']) ? max(1,(int)$b['expires_days']) : null;
    $expires_at   = $expires_days ? date('Y-m-d H:i:s', time() + $expires_days * 86400) : null;
    $notes        = substr(trim($b['notes'] ?? ''), 0, 500);

    if (!$owner_name)  json_err('owner_name is required');
    if (!$owner_email || !filter_var($owner_email, FILTER_VALIDATE_EMAIL))
        json_err('A valid owner_email is required');

    // Non-admin users: limit to 5 keys
    if (!$caller || !is_admin_key($caller)) {
        $count = db()->prepare('SELECT COUNT(*) FROM api_keys WHERE user_id=? AND is_active=1');
        $count->execute([$user_id]);
        if ((int)$count->fetchColumn() >= 5) {
            json_err('Maximum of 5 active keys per user. Revoke an existing key first.', 403);
        }
    }

    $new_key = 'cm-' . bin2hex(random_bytes(20));

    db()->prepare("
        INSERT INTO api_keys
          (api_key, owner_name, owner_email, user_id, label,
           rate_limit_rpm, rate_limit_rpd, credit_quota,
           allowed_models, expires_at, notes, is_active)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,1)
    ")->execute([
        $new_key, $owner_name, $owner_email,
        $user_id ?: ($caller['user_id'] ?? null),
        $label, $rate_rpm, $rate_rpd, $credit_quota,
        $allowed_mdl, $expires_at, $notes ?: null,
    ]);

    $key_id = (int)db()->lastInsertId();

    // Give 30-credit welcome bonus to new keys
    db()->prepare(
        'INSERT INTO credits (api_key_id, balance) VALUES (?,30)
         ON DUPLICATE KEY UPDATE balance = balance'
    )->execute([$key_id]);

    json_ok([
        'api_key'        => $new_key,
        'key_id'         => $key_id,
        'label'          => $label,
        'owner_name'     => $owner_name,
        'owner_email'    => $owner_email,
        'rate_limit_rpm' => $rate_rpm,
        'rate_limit_rpd' => $rate_rpd,
        'credit_quota'   => $credit_quota,
        'allowed_models' => $allowed_mdl ? json_decode($allowed_mdl) : null,
        'expires_at'     => $expires_at,
        'message'        => 'Keep this key safe — it will not be shown again.',
    ], 201);
}

// ============================================================
// DELETE — revoke key
// ============================================================
if ($method === 'DELETE') {
    $b      = require_json_body();
    $key_id = (int)($b['key_id'] ?? 0);
    if (!$key_id) json_err('key_id is required');

    $user_id = caller_user_id();
    $xkey    = $_SERVER['HTTP_X_API_KEY'] ?? '';
    $caller  = null;

    if ($xkey) {
        $caller = validate_api_key();
        if (!is_admin_key($caller)) {
            // User can only revoke their own keys
            $stmt = db()->prepare('SELECT id FROM api_keys WHERE id=? AND owner_email=?');
            $stmt->execute([$key_id, $caller['owner_email']]);
            if (!$stmt->fetch()) json_err('Key not found or permission denied.', 403);
        }
    } elseif ($user_id) {
        $stmt = db()->prepare('SELECT id FROM api_keys WHERE id=? AND user_id=?');
        $stmt->execute([$key_id, $user_id]);
        if (!$stmt->fetch()) json_err('Key not found or permission denied.', 403);
    } else {
        json_err('Authentication required.', 401);
    }

    db()->prepare('UPDATE api_keys SET is_active=0 WHERE id=?')->execute([$key_id]);
    json_ok(['message' => 'Key revoked successfully.', 'key_id' => $key_id]);
}

// ============================================================
// PATCH — update key settings
// ============================================================
if ($method === 'PATCH') {
    $b      = require_json_body();
    $key_id = (int)($b['key_id'] ?? 0);
    if (!$key_id) json_err('key_id is required');

    $user_id = caller_user_id();
    $xkey    = $_SERVER['HTTP_X_API_KEY'] ?? '';
    $caller  = null;
    $is_admin = false;

    if ($xkey) {
        $caller   = validate_api_key();
        $is_admin = is_admin_key($caller);
        if (!$is_admin) {
            $stmt = db()->prepare('SELECT id FROM api_keys WHERE id=? AND owner_email=?');
            $stmt->execute([$key_id, $caller['owner_email']]);
            if (!$stmt->fetch()) json_err('Key not found or permission denied.', 403);
        }
    } elseif ($user_id) {
        $stmt = db()->prepare('SELECT id FROM api_keys WHERE id=? AND user_id=?');
        $stmt->execute([$key_id, $user_id]);
        if (!$stmt->fetch()) json_err('Key not found or permission denied.', 403);
    } else {
        json_err('Authentication required.', 401);
    }

    $set = []; $params = [];

    if (isset($b['label'])) {
        $set[] = 'label=?';
        $params[] = substr(trim($b['label']), 0, 100);
    }
    if ($is_admin && isset($b['rate_limit_rpm'])) {
        $set[] = 'rate_limit_rpm=?';
        $params[] = max(1, min(10000, (int)$b['rate_limit_rpm']));
    }
    if ($is_admin && isset($b['rate_limit_rpd'])) {
        $set[] = 'rate_limit_rpd=?';
        $params[] = max(1, min(1000000, (int)$b['rate_limit_rpd']));
    }
    if ($is_admin && array_key_exists('credit_quota', $b)) {
        $set[] = 'credit_quota=?';
        $params[] = $b['credit_quota'] !== null ? max(0,(int)$b['credit_quota']) : null;
    }
    if ($is_admin && isset($b['allowed_models'])) {
        $set[] = 'allowed_models=?';
        $params[] = is_array($b['allowed_models']) && count($b['allowed_models'])
            ? json_encode($b['allowed_models']) : null;
    }
    if ($is_admin && array_key_exists('expires_at', $b)) {
        $set[] = 'expires_at=?';
        $params[] = $b['expires_at'] ?: null;
    }
    if (isset($b['notes'])) {
        $set[] = 'notes=?';
        $params[] = substr(trim($b['notes']), 0, 500) ?: null;
    }
    if ($is_admin && isset($b['is_active'])) {
        $set[] = 'is_active=?';
        $params[] = $b['is_active'] ? 1 : 0;
    }

    if (empty($set)) json_err('No updatable fields provided.', 400);

    $params[] = $key_id;
    db()->prepare('UPDATE api_keys SET ' . implode(',', $set) . ' WHERE id=?')
        ->execute($params);

    json_ok(['message' => 'Key updated.', 'key_id' => $key_id]);
}

json_err('Method not allowed', 405);
