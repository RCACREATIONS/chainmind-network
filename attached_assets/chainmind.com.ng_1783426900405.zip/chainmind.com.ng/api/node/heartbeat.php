<?php
// POST /api/node/heartbeat.php
// Nodes call this every 30s to stay online and update their profile.
//
// Headers: X-Node-Secret, X-Node-Id
//
// Body (JSON):
// {
//   "name":       "my-node",
//   "url":        "http://203.0.113.10:8000",
//   "tier":       "micro",
//   "models":     ["tinyllama","mistral"],
//   "jobs_done":  42,
//   "iq_earned":  3.14,
//   "reputation": 210.0
// }
require_once __DIR__ . '/../_helpers.php';
require_once __DIR__ . '/../geolocate_node_ip.php'; // ← ADD THIS

cors();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST only', 405);
validate_node_secret();
$node_id = get_node_id();
$b       = require_json_body();

$name       = substr(trim($b['name']       ?? 'unnamed'), 0, 100);
$url        = substr(trim($b['url']        ?? ''),        0, 255);
$tier       = trim($b['tier']              ?? 'nano');
$models     = json_encode($b['models']     ?? []);
$jobs_done  = (int)($b['jobs_done']        ?? 0);
$iq_earned  = (float)($b['iq_earned']      ?? 0.0);
$reputation = (float)($b['reputation']     ?? 100.0);

$valid_tiers = ['nano','micro','standard','pro','enterprise'];
if (!in_array($tier, $valid_tiers, true)) $tier = 'nano';

db()->prepare("
    INSERT INTO nodes (id, name, url, tier, models, jobs_done, iq_earned, reputation, status, last_seen, registered_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'online', NOW(), NOW())
    ON DUPLICATE KEY UPDATE
        name       = VALUES(name),
        url        = VALUES(url),
        tier       = VALUES(tier),
        models     = VALUES(models),
        jobs_done  = VALUES(jobs_done),
        iq_earned  = VALUES(iq_earned),
        reputation = VALUES(reputation),
        status     = 'online',
        last_seen  = NOW()
")->execute([$node_id, $name, $url, $tier, $models, $jobs_done, $iq_earned, $reputation]);

// ── Geolocate the node (skips API call if IP hasn't changed) ─────────────────
geolocate_node_ip(db(), $node_id, get_node_ip()); // ← ADD THIS

// Log heartbeat
db()->prepare("
    INSERT INTO node_heartbeats (node_id, ts, jobs_done, iq_earned)
    VALUES (?, NOW(), ?, ?)
")->execute([$node_id, $jobs_done, $iq_earned]);

// Return network-wide stats so nodes can display them
$stats = db()->query("
    SELECT
        COUNT(*) AS total_nodes,
        SUM(jobs_done) AS total_jobs,
        SUM(CASE WHEN status='online' THEN 1 ELSE 0 END) AS online_nodes
    FROM nodes
")->fetch();

json_ok([
    'ok'      => true,
    'node_id' => $node_id,
    'network' => [
        'total_nodes'  => (int)$stats['total_nodes'],
        'online_nodes' => (int)$stats['online_nodes'],
        'total_jobs'   => (int)$stats['total_jobs'],
    ],
]);