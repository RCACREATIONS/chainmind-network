<?php
// ============================================================
// ChainMind  User Dashboard Home (with Chat)
// ============================================================
session_start();
require_once __DIR__ . '/../api/_helpers.php';
require_once __DIR__ . '/../api/billing/credits.php';

if (!isset($_SESSION['user_id'])) { header('Location: /auth/login.php?next=/dashboard/'); exit; }

$user_id   = (int)$_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';
$is_admin  = ($_SESSION['user_role'] ?? '') === 'admin';

$_urow = db()->prepare('SELECT email_verified FROM users WHERE id = ? LIMIT 1');
$_urow->execute([$user_id]);
$_udata = $_urow->fetch();
$email_verified = (bool)(int)($_udata['email_verified'] ?? 0);
if ($email_verified) { $_SESSION['email_verified'] = 1; }

$keys = db()->prepare('SELECT * FROM api_keys WHERE user_id = ? AND is_active = 1 ORDER BY id ASC');
$keys->execute([$user_id]);
$keys = $keys->fetchAll();

$primary_key = $keys[0] ?? null;
$api_key_id  = $primary_key ? (int)$primary_key['id'] : 0;
$balance     = $api_key_id ? credits_get($api_key_id) : 0;

$recent_jobs = [];
if ($api_key_id) {
    $rj = db()->prepare('SELECT * FROM jobs WHERE api_key_id = ? ORDER BY created_at DESC LIMIT 8');
    $rj->execute([$api_key_id]);
    $recent_jobs = $rj->fetchAll();
}

$sub = null;
if ($api_key_id) {
    $sq = db()->prepare('SELECT * FROM subscriptions WHERE api_key_id = ? AND status = "active" ORDER BY id DESC LIMIT 1');
    $sq->execute([$api_key_id]);
    $sub = $sq->fetch();
}

$spend = 0;
if ($api_key_id) {
    $sq = db()->prepare('SELECT COALESCE(SUM(amount_usd),0) FROM payments WHERE api_key_id = ? AND status = "confirmed"');
    $sq->execute([$api_key_id]);
    $spend = (float)$sq->fetchColumn();
}

$low_credits    = $balance < 100;
$no_credits     = $balance <= 0;
$active_tab     = $_GET['tab'] ?? 'overview';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><title>Dashboard — ChainMind</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap">
<link rel="icon" type="image/png" href="../ChatGPT Image Jun 2, 2026, 06_43_57 AM.png">
<style>
:root {
  --bg:        #07080f;
  --bg2:       #0b0d1c;
  --bg3:       #101228;
  --bg4:       #161935;
  --border:    #1e2040;
  --border2:   #272a52;
  --border3:   #323670;

  --text:      #eef0ff;
  --text2:     #c5c8f0;
  --muted:     #6b6f9e;
  --muted2:    #474b78;

  --purple:    #8b3cf7;
  --purple-1:  #8b3cf7;
  --purple-2:  #6d28d9;
  --purple2:   #6d28d9;
  --violet:    #7c3aed;
  --indigo:    #4f46e5;
  --accent:    #a78bfa;
  --accent-2:  #c4b5fd;
  --accent2:   #c4b5fd;
  --blue:      #60a5fa;
  --neon:      #a78bfa;
  --glow:      rgba(139, 60, 247, .35);

  --green:     #34d399;
  --green-bg:  rgba(52, 211, 153, .12);
  --green-bd:  rgba(52, 211, 153, .35);
  --orange:    #fb923c;
  --orange-bg: rgba(251, 146, 60, .12);
  --red:       #f87171;
  --red-bg:    rgba(248, 113, 113, .12);
  --gold:      #f59e0b;

  --grad:      linear-gradient(135deg, var(--purple-1), var(--indigo));
  --grad-soft: linear-gradient(135deg, rgba(139,60,247,.15), rgba(79,70,229,.08));

  --font:    'Plus Jakarta Sans', system-ui, sans-serif;
  --display: 'Syne', sans-serif;
  --mono:    'JetBrains Mono', monospace;

  --r-sm: 8px;
  --r-md: 12px;
  --r-lg: 16px;
  --r-xl: 20px;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  background: var(--bg);
  color: var(--text);
  font-family: var(--font);
  display: flex;
  min-height: 100vh;
  font-size: 15px;
}

/* ─── NOISE OVERLAY ─── */
body::before {
  content: '';
  position: fixed;
  inset: 0;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
  pointer-events: none;
  z-index: 0;
  opacity: 0.5;
}

/* ─── SIDEBAR ─── */
.sidebar {
  width: 240px;
  background: var(--bg2);
  border-right: 1px solid var(--border);
  padding: 1.75rem 1.25rem;
  display: flex;
  flex-direction: column;
  gap: .2rem;
  flex-shrink: 0;
  min-height: 100vh;
  position: relative;
  z-index: 10;
}

.sidebar::after {
  content: '';
  position: absolute;
  top: 0; right: 0; bottom: 0;
  width: 1px;
  background: linear-gradient(to bottom, transparent, rgba(139,60,247,0.4) 30%, rgba(79,70,229,0.3) 70%, transparent);
  pointer-events: none;
}

.sidebar-logo {
  display: flex;
  align-items: center;
  gap: .7rem;
  margin-bottom: 2rem;
  padding-left: .25rem;
}

.logo-mark {
  width: 36px;
  height: 36px;
  background: var(--grad);
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1rem;
  font-weight: 800;
  color: #fff;
  box-shadow: 0 0 20px var(--glow);
  flex-shrink: 0;
}

.logo-text {
  font-size: 1.1rem;
  font-weight: 800;
  letter-spacing: -.02em;
}
.logo-text .chain { color: var(--accent2); }
.logo-text .mind  { color: var(--text); }

.sidebar-section {
  font-size: .68rem;
  font-weight: 700;
  letter-spacing: .1em;
  color: var(--muted2);
  text-transform: uppercase;
  padding: .6rem .75rem .3rem;
  margin-top: .5rem;
}

.sidebar a {
  display: flex;
  align-items: center;
  gap: .65rem;
  padding: .6rem .85rem;
  border-radius: 10px;
  color: var(--muted);
  text-decoration: none;
  font-size: .88rem;
  font-weight: 500;
  transition: all .18s ease;
  position: relative;
}

.sidebar a svg { opacity: .6; flex-shrink: 0; transition: opacity .18s; }
.sidebar a:hover { background: var(--bg3); color: var(--text2); }
.sidebar a:hover svg { opacity: 1; }
.sidebar a.active {
  background: linear-gradient(135deg, rgba(139,60,247,0.18), rgba(79,70,229,0.1));
  color: var(--accent2);
  border: 1px solid rgba(139,60,247,0.25);
}
.sidebar a.active svg { opacity: 1; color: var(--accent); }
.sidebar a.active::before {
  content: '';
  position: absolute;
  left: 0; top: 20%; bottom: 20%;
  width: 3px;
  background: var(--grad);
  border-radius: 0 3px 3px 0;
}

hr.sd { border: none; border-top: 1px solid var(--border); margin: .6rem 0; }

.sidebar-user {
  margin-top: auto;
  padding: .85rem;
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 12px;
  display: flex;
  align-items: center;
  gap: .7rem;
  margin-bottom: .5rem;
}
.user-avatar {
  width: 32px;
  height: 32px;
  background: var(--grad);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: .85rem;
  color: #fff;
  flex-shrink: 0;
}
.user-info { min-width: 0; }
.user-info .uname { font-size: .83rem; font-weight: 600; color: var(--text2); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.user-info .urole { font-size: .7rem; color: var(--muted); }

/* ─── MAIN ─── */
.main { flex: 1; display: flex; flex-direction: column; overflow: hidden; position: relative; z-index: 1; }

/* ─── TABS ─── */
.tabs {
  display: flex;
  border-bottom: 1px solid var(--border);
  background: var(--bg2);
  padding: 0 2rem;
  flex-shrink: 0;
  gap: .25rem;
}

.tab-btn {
  padding: .9rem 1.1rem;
  font-size: .85rem;
  font-weight: 600;
  color: var(--muted);
  background: none;
  border: none;
  border-bottom: 2px solid transparent;
  cursor: pointer;
  text-decoration: none;
  display: flex;
  align-items: center;
  gap: .45rem;
  transition: all .18s;
  margin-bottom: -1px;
  font-family: var(--font);
  letter-spacing: -.01em;
}
.tab-btn:hover { color: var(--text2); }
.tab-btn.active { color: var(--accent2); border-bottom-color: var(--purple-1); }

/* ─── TAB PANELS ─── */
.tab-panel { display: none; flex: 1; overflow: hidden; }
.tab-panel.active { display: flex; flex-direction: column; }

/* ─── OVERVIEW ─── */
.overview-scroll {
  flex: 1;
  overflow-y: auto;
  padding: 2.25rem 2.5rem;
}

.page-header { margin-bottom: 2rem; }
.page-header .greeting-line {
  font-family: var(--display);
  font-size: 1.65rem;
  font-weight: 800;
  letter-spacing: -.03em;
  color: var(--text);
  line-height: 1.2;
}
.page-header .greeting-line .name-highlight {
  background: var(--grad);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
.page-header .subtitle {
  font-size: .88rem;
  color: var(--muted);
  margin-top: .35rem;
}

/* ─── BANNERS ─── */
.banner {
  border-radius: 12px;
  padding: .9rem 1.2rem;
  margin-bottom: 1rem;
  font-size: .85rem;
  display: flex;
  align-items: center;
  gap: .85rem;
  flex-wrap: wrap;
}
.banner-icon { font-size: 1.15rem; flex-shrink: 0; }
.banner-content { flex: 1; }
.banner-content strong { font-weight: 700; }
.banner-danger { background: var(--red-bg); border: 1px solid rgba(248,113,113,.3); }
.banner-warn { background: var(--orange-bg); border: 1px solid rgba(251,146,60,.3); }
.banner-info { background: var(--grad-soft); border: 1px solid rgba(139,60,247,.25); }
.banner-cta {
  display: inline-flex;
  align-items: center;
  gap: .4rem;
  padding: .4rem 1rem;
  border-radius: 8px;
  font-weight: 700;
  font-size: .82rem;
  text-decoration: none;
  white-space: nowrap;
  margin-left: auto;
  transition: all .18s;
}
.banner-danger .banner-cta { background: var(--red); color: #fff; }
.banner-warn .banner-cta   { background: var(--orange); color: #07080f; }
.banner-info .banner-cta   { background: var(--grad); color: #fff; box-shadow: 0 4px 16px var(--glow); }
.banner-cta:hover { opacity: .88; transform: translateY(-1px); }

/* ─── STATS GRID ─── */
.stats {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 1rem;
  margin-bottom: 1.75rem;
}

.stat-card {
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 1.4rem 1.25rem;
  position: relative;
  overflow: hidden;
  transition: border-color .2s, transform .2s;
}
.stat-card:hover { border-color: var(--border2); transform: translateY(-2px); }
.stat-card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 2px;
  background: var(--grad);
  opacity: 0;
  transition: opacity .2s;
}
.stat-card:hover::before { opacity: 1; }

.stat-card .sc-icon {
  width: 36px;
  height: 36px;
  border-radius: 9px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: .85rem;
  font-size: 1rem;
}
.sc-purple { background: rgba(139,60,247,.15); color: var(--accent); }
.sc-green  { background: var(--green-bg); color: var(--green); }
.sc-orange { background: var(--orange-bg); color: var(--orange); }
.sc-red    { background: var(--red-bg); color: var(--red); }
.sc-blue   { background: rgba(99,179,237,.12); color: #63b3ed; }

.stat-card .sc-label { font-size: .73rem; font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: var(--muted); margin-bottom: .4rem; }
.stat-card .sc-value { font-size: 1.75rem; font-weight: 800; letter-spacing: -.03em; line-height: 1; }
.stat-card .sc-sub   { font-size: .73rem; color: var(--muted); margin-top: .35rem; font-family: 'JetBrains Mono', monospace; }

.sc-ok     .sc-value { color: var(--green); }
.sc-warn   .sc-value { color: var(--orange); }
.sc-danger .sc-value { color: var(--red); }
.sc-purple-val .sc-value { color: var(--accent2); }

/* ─── API KEY BOX ─── */
.api-key-box {
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
}
.section-label {
  font-size: .72rem;
  font-weight: 700;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: var(--muted);
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  gap: .5rem;
}
.section-label::after {
  content: '';
  flex: 1;
  height: 1px;
  background: var(--border);
}

.key-row {
  display: flex;
  align-items: center;
  gap: .75rem;
  background: var(--bg2);
  border: 1px solid var(--border2);
  border-radius: 10px;
  padding: .7rem 1rem;
  transition: border-color .18s;
}
.key-row:hover { border-color: rgba(139,60,247,.4); }
.key-icon { color: var(--accent); flex-shrink: 0; }
.key-val  {
  flex: 1;
  font-family: 'JetBrains Mono', monospace;
  font-size: .82rem;
  color: var(--text2);
  word-break: break-all;
  letter-spacing: .02em;
}
.copy-btn {
  background: rgba(139,60,247,.15);
  border: 1px solid rgba(139,60,247,.3);
  color: var(--accent);
  border-radius: 7px;
  padding: .35rem .8rem;
  cursor: pointer;
  font-size: .78rem;
  font-weight: 600;
  font-family: var(--font);
  transition: all .18s;
  flex-shrink: 0;
}
.copy-btn:hover { background: rgba(139,60,247,.28); border-color: rgba(139,60,247,.5); }
.copy-btn.copied { background: var(--green-bg); border-color: var(--green); color: var(--green); }

.key-hint {
  font-size: .75rem;
  color: var(--muted);
  margin-top: .7rem;
  display: flex;
  align-items: center;
  gap: .5rem;
  flex-wrap: wrap;
}
.key-hint code {
  font-family: 'JetBrains Mono', monospace;
  font-size: .75rem;
  background: var(--bg);
  color: var(--accent);
  padding: .15rem .45rem;
  border-radius: 4px;
  border: 1px solid var(--border2);
}

/* ─── SUB BOX ─── */
.sub-box {
  background: rgba(52,211,153,.05);
  border: 1px solid rgba(52,211,153,.25);
  border-radius: 12px;
  padding: 1.1rem 1.25rem;
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  gap: .85rem;
}
.sub-badge {
  background: var(--green-bg);
  border: 1px solid rgba(52,211,153,.35);
  color: var(--green);
  border-radius: 6px;
  padding: .2rem .6rem;
  font-size: .72rem;
  font-weight: 700;
  letter-spacing: .05em;
  text-transform: uppercase;
  flex-shrink: 0;
}
.sub-info .sub-title { font-size: .9rem; font-weight: 700; color: var(--green); }
.sub-info .sub-detail { font-size: .78rem; color: var(--muted); margin-top: .15rem; }

/* ─── ACTION BUTTON ─── */
.btn-primary {
  display: inline-flex;
  align-items: center;
  gap: .5rem;
  padding: .65rem 1.4rem;
  border-radius: 10px;
  font-size: .88rem;
  font-weight: 700;
  text-decoration: none;
  background: var(--grad);
  color: #fff;
  box-shadow: 0 4px 20px var(--glow);
  margin-bottom: 1.5rem;
  transition: all .2s;
  font-family: var(--font);
  letter-spacing: -.01em;
}
.btn-primary:hover { opacity: .9; transform: translateY(-2px); box-shadow: 0 8px 28px var(--glow); }

/* ─── CARD ─── */
.card {
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 14px;
  margin-bottom: 1.5rem;
  overflow: hidden;
}
.card-header {
  padding: 1.1rem 1.4rem;
  border-bottom: 1px solid var(--border);
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: rgba(255,255,255,.01);
}
.card-header h2 { font-size: .92rem; font-weight: 700; letter-spacing: -.01em; }
.card-header a  { font-size: .8rem; color: var(--accent); text-decoration: none; font-weight: 600; }
.card-header a:hover { color: var(--accent2); }

table { width: 100%; border-collapse: collapse; font-size: .82rem; }
th {
  text-align: left;
  padding: .65rem 1rem;
  color: var(--muted);
  border-bottom: 1px solid var(--border);
  font-size: .72rem;
  font-weight: 600;
  letter-spacing: .06em;
  text-transform: uppercase;
}
td { padding: .65rem 1rem; border-bottom: 1px solid var(--border); color: var(--text2); }
tr:last-child td { border-bottom: none; }
tr:hover td { background: rgba(255,255,255,.018); }

.badge {
  display: inline-flex;
  align-items: center;
  gap: .3rem;
  padding: .18rem .55rem;
  border-radius: 20px;
  font-size: .7rem;
  font-weight: 700;
  letter-spacing: .03em;
}
.b-done       { background: var(--green-bg); color: var(--green); border: 1px solid rgba(52,211,153,.25); }
.b-pending    { background: rgba(251,146,60,.12); color: var(--orange); border: 1px solid rgba(251,146,60,.25); }
.b-processing { background: rgba(99,179,237,.12); color: #63b3ed; border: 1px solid rgba(99,179,237,.25); }
.b-failed,
.b-timeout    { background: var(--red-bg); color: var(--red); border: 1px solid rgba(248,113,113,.25); }

.muted { color: var(--muted); font-size: .78rem; }
.mono  { font-family: 'JetBrains Mono', monospace; font-size: .78rem; }


/* ─── CHAT PANEL ─── */
.chat-panel { flex: 1; display: flex; overflow: hidden; }

.chat-sidebar {
  width: 270px;
  min-width: 270px;
  background: var(--bg2);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  padding: 1.25rem 1rem;
  gap: 1.1rem;
  overflow-y: auto;
}

.cs-section-title {
  font-size: .68rem;
  font-weight: 700;
  letter-spacing: .1em;
  color: var(--muted2);
  text-transform: uppercase;
  margin-bottom: .35rem;
}

.net-stat-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: .3rem 0;
}
.net-stat-label { font-size: .8rem; color: var(--muted); }
.net-stat-val {
  font-size: .8rem;
  font-weight: 700;
  color: var(--accent);
  font-family: 'JetBrains Mono', monospace;
}

.model-select-wrap select {
  width: 100%;
  background: var(--bg3);
  border: 1px solid var(--border2);
  color: var(--text);
  border-radius: 9px;
  padding: .55rem .75rem;
  font-size: .83rem;
  outline: none;
  font-family: var(--font);
  transition: border-color .18s;
  cursor: pointer;
}
.model-select-wrap select:focus { border-color: var(--purple-1); }

.key-display-label { font-size: .7rem; color: var(--muted); margin-bottom: .35rem; }
.key-display {
  background: var(--bg3);
  border: 1px solid var(--border2);
  border-radius: 9px;
  padding: .55rem .75rem;
  font-size: .72rem;
  font-family: 'JetBrains Mono', monospace;
  color: var(--accent);
  word-break: break-all;
  letter-spacing: .02em;
}

.lb-section h3 {
  font-size: .68rem;
  font-weight: 700;
  letter-spacing: .1em;
  color: var(--muted2);
  text-transform: uppercase;
  margin-bottom: .55rem;
}
.lb-item {
  display: flex;
  align-items: center;
  gap: .5rem;
  padding: .4rem 0;
  border-bottom: 1px solid var(--border);
  font-size: .78rem;
}
.lb-rank   { color: var(--muted2); width: 16px; text-align: right; font-family: 'JetBrains Mono', monospace; font-size: .72rem; }
.lb-name   { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--text2); }
.lb-iq     { color: var(--accent); font-family: 'JetBrains Mono', monospace; font-size: .72rem; font-weight: 600; }
.lb-dot    { width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0; }
.lb-dot.online  { background: var(--green); box-shadow: 0 0 6px rgba(52,211,153,.5); }
.lb-dot.offline { background: var(--muted2); }

/* ─── CHAT MAIN ─── */
.chat-main { flex: 1; display: flex; flex-direction: column; min-width: 0; }

.chat-topbar {
  padding: 1rem 1.5rem;
  border-bottom: 1px solid var(--border);
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-shrink: 0;
  background: var(--bg2);
}
.chat-topbar h2 { font-size: .98rem; font-weight: 700; letter-spacing: -.01em; }
.chat-topbar p  { font-size: .78rem; color: var(--muted); margin-top: .1rem; }

.chat-credit-pill {
  background: var(--green-bg);
  border: 1px solid rgba(52,211,153,.3);
  color: var(--green);
  border-radius: 20px;
  padding: .3rem .9rem;
  font-size: .78rem;
  font-weight: 700;
  display: flex;
  align-items: center;
  gap: .4rem;
}
.chat-credit-pill::before { content: ''; width: 6px; height: 6px; background: var(--green); border-radius: 50%; box-shadow: 0 0 6px rgba(52,211,153,.6); }
.chat-credit-pill.low { background: var(--orange-bg); border-color: rgba(251,146,60,.3); color: var(--orange); }
.chat-credit-pill.low::before { background: var(--orange); box-shadow: 0 0 6px rgba(251,146,60,.5); }
.chat-credit-pill.empty { background: var(--red-bg); border-color: rgba(248,113,113,.3); color: var(--red); }
.chat-credit-pill.empty::before { background: var(--red); box-shadow: 0 0 6px rgba(248,113,113,.5); }

.messages {
  flex: 1;
  overflow-y: auto;
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.1rem;
  scroll-behavior: smooth;
  position: relative;
}

.message { display: flex; max-width: 80%; }
.message.user      { align-self: flex-end; flex-direction: row-reverse; }
.message.assistant { align-self: flex-start; }

.message-bubble {
  padding: .85rem 1.1rem;
  border-radius: 16px;
  line-height: 1.65;
  font-size: .88rem;
}
.message.user .message-bubble {
  background: linear-gradient(135deg, rgba(139,60,247,.22), rgba(79,70,229,.15));
  border: 1px solid rgba(139,60,247,.3);
  border-bottom-right-radius: 4px;
  color: var(--text);
}
.message.assistant .message-bubble {
  background: var(--bg3);
  border: 1px solid var(--border);
  border-bottom-left-radius: 4px;
}

.message-meta {
  font-size: .68rem;
  color: var(--muted2);
  margin-top: .5rem;
  font-family: 'JetBrains Mono', monospace;
}

.message-bubble p + p { margin-top: .5rem; }
.message-bubble pre {
  background: var(--bg);
  border: 1px solid var(--border2);
  border-radius: 9px;
  padding: .85rem 1rem;
  overflow-x: auto;
  font-family: 'JetBrains Mono', monospace;
  font-size: .78rem;
  margin: .6rem 0;
}
.message-bubble code {
  font-family: 'JetBrains Mono', monospace;
  font-size: .8rem;
  background: var(--bg);
  color: var(--accent);
  padding: .1rem .35rem;
  border-radius: 4px;
  border: 1px solid var(--border2);
}
.message-bubble pre code { background: transparent; padding: 0; border: none; color: var(--text2); }

.typing-dots span {
  display: inline-block;
  width: 5px;
  height: 5px;
  background: var(--muted);
  border-radius: 50%;
  animation: bounce 1.2s infinite;
  margin: 0 2px;
}
.typing-dots span:nth-child(2) { animation-delay: .2s; }
.typing-dots span:nth-child(3) { animation-delay: .4s; }
@keyframes bounce { 0%,60%,100% { transform:translateY(0) } 30% { transform:translateY(-5px) } }

/* ─── CHAT INPUT ─── */
.input-area {
  padding: 1rem 1.5rem 1.4rem;
  border-top: 1px solid var(--border);
  background: var(--bg);
  flex-shrink: 0;
}

/* ─── INPUT TOOLBAR (new) ─── */
.input-toolbar {
  display: flex;
  align-items: center;
  gap: .4rem;
  margin-bottom: .5rem;
  flex-wrap: wrap;
}
.tool-btn {
  display: flex; align-items: center; gap: .3rem;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--border2);
  border-radius: 7px;
  color: var(--muted);
  padding: .28rem .65rem;
  font-size: .73rem;
  font-weight: 600;
  font-family: var(--font);
  cursor: pointer;
  transition: all .15s;
  white-space: nowrap;
  line-height: 1;
}
.tool-btn:hover { background: rgba(139,60,247,.1); border-color: rgba(139,60,247,.3); color: var(--accent); }
.tool-btn.active { background: rgba(139,60,247,.15); border-color: rgba(139,60,247,.45); color: var(--accent2); }
.tool-btn svg { flex-shrink: 0; }

/* ─── FILE CHIPS (new) ─── */
.file-chips {
  display: flex;
  flex-wrap: wrap;
  gap: .35rem;
  margin-bottom: .45rem;
}
.file-chip {
  display: inline-flex;
  align-items: center;
  gap: .35rem;
  background: rgba(139,60,247,.1);
  border: 1px solid rgba(139,60,247,.28);
  border-radius: 6px;
  padding: .22rem .55rem;
  font-size: .73rem;
  color: var(--accent);
  max-width: 200px;
}
.file-chip span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; }
.file-chip button {
  background: none; border: none; color: var(--muted2);
  cursor: pointer; padding: 0; font-size: .8rem; line-height: 1;
  flex-shrink: 0; transition: color .12s;
}
.file-chip button:hover { color: var(--red); }
.file-chip.img-chip { border-color: rgba(52,211,153,.3); background: rgba(52,211,153,.07); color: var(--green); }

/* ─── MAIN INPUT ROW ─── */
.input-row {
  display: flex;
  align-items: flex-end;
  gap: .65rem;
  background: var(--bg2);
  border: 1px solid var(--border2);
  border-radius: 14px;
  padding: .7rem .75rem .7rem 1.1rem;
  transition: border-color .18s, box-shadow .18s;
}
.input-row:focus-within {
  border-color: rgba(139,60,247,.5);
  box-shadow: 0 0 0 3px rgba(139,60,247,.1);
}
.input-row textarea {
  flex: 1;
  background: transparent;
  border: none;
  outline: none;
  color: var(--text);
  font-size: .9rem;
  font-family: var(--font);
  resize: none;
  line-height: 1.5;
  max-height: 160px;
  overflow-y: auto;
}
.input-row textarea::placeholder { color: var(--muted2); }

/* ─── ICON BUTTONS in input row ─── */
.icon-btn {
  background: transparent;
  border: none;
  color: var(--muted);
  border-radius: 8px;
  width: 34px; height: 34px;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; flex-shrink: 0;
  transition: all .15s;
}
.icon-btn:hover { background: rgba(139,60,247,.1); color: var(--accent); }
.icon-btn.active { color: var(--accent2); background: rgba(139,60,247,.15); }

.send-btn {
  background: var(--grad);
  border: none;
  border-radius: 10px;
  color: #fff;
  width: 38px;
  height: 38px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  flex-shrink: 0;
  transition: all .18s;
  box-shadow: 0 2px 12px var(--glow);
}
.send-btn:hover { opacity: .9; transform: translateY(-1px); box-shadow: 0 6px 20px var(--glow); }
.send-btn:disabled { background: var(--bg4); box-shadow: none; cursor: not-allowed; }

.input-hint {
  font-size: .72rem;
  color: var(--muted2);
  margin-top: .55rem;
  text-align: center;
}
.input-hint a { color: var(--muted); text-decoration: none; }

/* ─── INLINE IMAGES (new) ─── */
.msg-image {
  max-width: 100%;
  max-height: 320px;
  border-radius: 10px;
  display: block;
  margin-top: .55rem;
  border: 1px solid var(--border2);
  cursor: zoom-in;
  transition: opacity .15s;
}
.msg-image:hover { opacity: .9; }
.msg-image-grid { display: flex; flex-wrap: wrap; gap: .5rem; margin-top: .5rem; }

/* ─── IMAGE GEN SPINNER (new) ─── */
.img-gen-status {
  display: flex; align-items: center; gap: .5rem;
  font-size: .82rem; color: var(--muted); padding: .2rem 0;
}
.img-gen-status .spin {
  width: 14px; height: 14px;
  border: 2px solid var(--border2);
  border-top-color: var(--accent);
  border-radius: 50%;
  animation: spin .75s linear infinite;
  flex-shrink: 0;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* ─── DRAG OVER INDICATOR (new) ─── */
.messages.drag-over {
  outline: 2px dashed rgba(139,60,247,.5);
  outline-offset: -6px;
  background: rgba(139,60,247,.04);
}

/* ─── NO CREDITS OVERLAY ─── */
.chat-blocked {
  display: flex; flex-direction: column; align-items: center;
  justify-content: center; flex: 1; padding: 2rem;
  text-align: center; gap: 1.1rem;
}
.chat-blocked .cb-icon {
  width: 64px; height: 64px;
  background: var(--red-bg);
  border: 1px solid rgba(248,113,113,.3);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 1.75rem;
}
.chat-blocked h3  { font-size: 1.1rem; font-weight: 800; letter-spacing: -.02em; }
.chat-blocked p   { color: var(--muted); font-size: .87rem; max-width: 360px; line-height: 1.6; }
.chat-blocked a   {
  display: inline-block; padding: .65rem 1.75rem;
  background: var(--grad); color: #fff; border-radius: 10px;
  font-weight: 700; text-decoration: none; font-size: .9rem;
  box-shadow: 0 4px 20px var(--glow); transition: all .2s;
}
.chat-blocked a:hover { opacity: .9; transform: translateY(-2px); }

/* ─── SUMMARY BANNER ─── */
#summaryBanner {
  background: rgba(139,60,247,.06);
  border: 1px solid rgba(139,60,247,.2);
  border-radius: 10px;
  margin: .75rem 1.5rem 0;
  padding: .7rem 1rem;
  font-size: .8rem;
  color: var(--muted);
  line-height: 1.5;
}
#summaryBanner strong { color: var(--accent); font-size: .72rem; text-transform: uppercase; letter-spacing: .06em; display: block; margin-bottom: .2rem; }

/* ─── SCROLLBAR ─── */
::-webkit-scrollbar       { width: 5px; height: 5px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 10px; }
::-webkit-scrollbar-thumb:hover { background: rgba(139,60,247,.4); }

/* ─── SESSION LIST ─── */
.dash-session {
  padding: .45rem .6rem;
  border-radius: 8px;
  cursor: pointer;
  transition: background .15s;
  display: flex;
  align-items: center;
  gap: .35rem;
}
.dash-session:hover { background: var(--bg3); }
.dash-session.active { background: rgba(139,60,247,.12); border: 1px solid rgba(139,60,247,.2); }

/* ─── EMAIL VERIFY BANNER ─── */
#verify-banner {
  position: fixed; top: 0; left: 0; right: 0; z-index: 999;
  background: rgba(12,13,26,.95);
  border-bottom: 1px solid rgba(251,146,60,.4);
  backdrop-filter: blur(12px);
  padding: .65rem 1.5rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  flex-wrap: wrap;
}

/* ─── RESPONSIVE ─── */
@media (max-width:900px) { .chat-sidebar { display: none; } }
@media (max-width:700px) { .sidebar { display: none; } .tabs { padding: 0 1rem; } .overview-scroll { padding: 1.5rem 1.25rem; } }


  /* =========================================================
     CHAINMIND MOBILE PATCH — appended, nothing removed above
     ========================================================= */

  /* Mobile top bar */
  .cm-mobile-bar {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0;
    height: 54px;
    z-index: 9000;
    background: var(--bg2, #0b0d1c);
    border-bottom: 1px solid var(--border, #1e2040);
    align-items: center;
    justify-content: space-between;
    padding: 0 1rem;
    gap: .75rem;
  }
  .cm-mobile-bar .cm-mob-logo {
    display: flex; align-items: center; gap: .55rem; text-decoration: none;
  }
  .cm-hamburger {
    width: 42px; height: 42px;
    border-radius: 9px;
    background: transparent;
    border: 1px solid var(--border2, #272a52);
    color: var(--text2, #c5c8f0);
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    gap: 5px; cursor: pointer; flex-shrink: 0;
    transition: border-color .18s, color .18s;
  }
  .cm-hamburger:hover { border-color: var(--accent, #a78bfa); color: var(--accent, #a78bfa); }
  .cm-hamburger span {
    display: block; width: 20px; height: 2px;
    background: currentColor; border-radius: 2px;
    transition: transform .25s, opacity .2s;
  }
  .cm-hamburger.cm-open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
  .cm-hamburger.cm-open span:nth-child(2) { opacity: 0; transform: scaleX(0); }
  .cm-hamburger.cm-open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

  /* Overlay */
  .cm-overlay {
    display: none;
    position: fixed; inset: 0;
    background: rgba(0,0,0,.65);
    backdrop-filter: blur(4px);
    z-index: 8900;
  }
  .cm-overlay.cm-show { display: block; }

  @media (max-width: 768px) {

    /* Show the mobile bar */
    .cm-mobile-bar { display: flex !important; }

    /* Push body content below the bar */
    body { padding-top: 54px !important; }

    /* Turn sidebar into a slide-in drawer */
    .sidebar {
      display: flex !important;
      flex-direction: column !important;
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      bottom: 0 !important;
      width: 270px !important;
      min-height: 100vh !important;
      z-index: 9500 !important;
      transform: translateX(-100%) !important;
      transition: transform .28s cubic-bezier(.4, 0, .2, 1) !important;
      overflow-y: auto !important;
      overflow-x: hidden !important;
    }
    .sidebar.cm-open {
      transform: translateX(0) !important;
      box-shadow: 4px 0 40px rgba(0,0,0,.6) !important;
    }

    /* Main content fills full width */
    .main { overflow-x: hidden; }

    /* Stats grid: 2 columns on mobile */
    .stats { grid-template-columns: repeat(2, 1fr) !important; }

    /* Tabs: horizontal scroll */
    .tabs {
      overflow-x: auto !important;
      -webkit-overflow-scrolling: touch;
      scrollbar-width: none;
      flex-wrap: nowrap !important;
      padding-left: 1rem !important;
      padding-right: 1rem !important;
    }
    .tabs::-webkit-scrollbar { display: none; }
    .tab-btn { white-space: nowrap; }

    /* Tables: horizontal scroll wrapper */
    .card { overflow-x: auto; }
    table { min-width: 480px; }

    /* Overview padding */
    .overview-scroll { padding: 1.25rem 1rem !important; }

    /* Page header sizing */
    h1 { font-size: 1.3rem !important; }

    /* Reduce main padding */
    .main { padding: 1.25rem 1rem !important; }

    /* Collapse multi-col form rows */
    .fld-row { grid-template-columns: 1fr !important; }

    /* Payment method grids */
    .pay-methods { grid-template-columns: 1fr !important; }
    .info-grid { grid-template-columns: 1fr 1fr !important; }

    /* Hide chat sidebar on small screens */
    .chat-sidebar { display: none !important; }
    .chat-panel { flex-direction: column !important; }

    /* Input area */
    .input-area { padding: .75rem 1rem 1rem !important; }

    /* Toolbar wraps on small screens */
    .input-toolbar { gap: .3rem; }
    .tool-btn { font-size: .7rem; padding: .25rem .5rem; }
  }

  @media (max-width: 480px) {
    .stats { grid-template-columns: 1fr 1fr !important; }
    .stat-card .sc-value,
    .stat .val { font-size: 1.4rem !important; }
    .page-header .greeting-line { font-size: 1.2rem !important; }
    .overview-scroll { padding: 1rem .85rem !important; }
  }
</style>
</head>
<body>

  <!-- ── CHAINMIND MOBILE TOPBAR ───────────────────── -->
  <div class="cm-mobile-bar" id="cmBar">
    <a href="/dashboard/" class="cm-mob-logo">
      <div style="width:32px;height:32px;background:linear-gradient(135deg,#8b3cf7,#4f46e5);border-radius:9px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.85rem;color:#fff;flex-shrink:0;box-shadow:0 0 14px rgba(139,60,247,.5)">CM</div>
      <div style="font-size:1rem;font-weight:800;letter-spacing:-.02em"><span style="color:#c4b5fd">Chain</span><span style="color:#eef0ff">Mind</span></div>
    </a>
    <button class="cm-hamburger" id="cmHamburger" onclick="cmToggle()" aria-label="Toggle navigation">
      <span></span><span></span><span></span>
    </button>
  </div>
  <div class="cm-overlay" id="cmOverlay" onclick="cmClose()"></div>
  <!-- ── END MOBILE TOPBAR ─────────────────────────── -->
  

  <?php if (!$email_verified): ?>
    <div id="verify-banner">
      <div style="display:flex;align-items:center;gap:.65rem;font-size:.85rem;color:var(--orange)">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
        <span><strong>Verify your email</strong> — check your inbox at <strong><?= htmlspecialchars($_SESSION['user_email'] ?? '') ?></strong></span>
      </div>
      <div style="display:flex;align-items:center;gap:.75rem">
        <span id="resend-msg" style="font-size:.8rem;display:none"></span>
        <button id="resend-btn" onclick="doResend(this)"
          style="font-size:.8rem;color:var(--orange);background:rgba(251,146,60,.12);border:1px solid rgba(251,146,60,.3);
            padding:.35rem .9rem;border-radius:8px;cursor:pointer;font-family:var(--font);font-weight:600">
          Resend email →
        </button>
      </div>
    </div>
    <div style="height:46px"></div>
    <script>
    function doResend(btn) {
      btn.disabled = true; btn.textContent = 'Sending…';
      const msg = document.getElementById('resend-msg');
      const fd = new FormData();
      fd.append('email', <?= json_encode($_SESSION['user_email'] ?? '') ?>);
      fd.append('role',  <?= json_encode($_SESSION['user_role']  ?? 'user') ?>);
      fd.append('json',  '1');
      fetch('/api/auth/resend-verification.php', { method:'POST', body:fd, headers:{'X-Requested-With':'XMLHttpRequest'} })
        .then(r=>r.json()).then(data => {
          msg.style.display='inline';
          if (data.status==='sent')             { msg.style.color='var(--green)'; msg.textContent='✓ Email sent!'; btn.style.display='none'; }
          else if (data.status==='too_soon')    { msg.style.color='var(--orange)'; msg.textContent='⧖ Wait 60s.'; setTimeout(()=>{btn.disabled=false;btn.textContent='Resend email →';msg.style.display='none';},5000); }
          else if (data.status==='already_verified') { msg.style.color='var(--green)'; msg.textContent='✓ Already verified! Refresh.'; btn.style.display='none'; }
          else { msg.style.color='var(--red)'; msg.textContent='✗ Failed. Try again.'; btn.disabled=false; btn.textContent='Resend email →'; }
        }).catch(()=>{ msg.style.display='inline'; msg.style.color='var(--red)'; msg.textContent='✗ Network error.'; btn.disabled=false; btn.textContent='Resend email →'; });
    }
    </script>
  <?php endif; ?>

<!-- SIDEBAR -->
<nav class="sidebar">
  <div class="sidebar-logo">
    <div class="logo-mark">CM</div>
    <div class="logo-text"><span class="chain">Chain</span><span class="mind">Mind</span></div>
  </div>

  <div class="sidebar-section">Account</div>
  <a href="/dashboard/?tab=overview" class="<?= $active_tab==='overview'?'active':'' ?>">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>
    Overview
  </a>
  <a href="/dashboard/?tab=chat" class="<?= $active_tab==='chat'?'active':'' ?>">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
    Chat
  </a>
  <a href="/dashboard/billing.php">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
    Billing
  </a>
  <a href="/dashboard/node-earnings.php">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
    Node Earnings
  </a>

  <hr class="sd">
  <?php if ($is_admin): ?>
  <div class="sidebar-section">Admin</div>
  <a href="/admin/">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
    Admin Panel
  </a>
  <hr class="sd">
  <?php endif; ?>

  <a href="/">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></svg>
    Home
  </a>
  <a href="/docs.php">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14,2 14,8 20,8"/></svg>
    API Docs
  </a>

  <?php if (($_SESSION['user_role'] ?? '') === 'node'): ?>
  <hr class="sd">
  <div class="sidebar-section">Node</div>
  <a href="/dashboard/node-earnings.php">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg>
    Earnings
  </a>
  <a href="/dashboard/node-settings.php">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
    Settings
  </a>
  <a href="/dashboard/node-download.php">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
    Download Guide
  </a>
  <?php endif; ?>

  <div class="sidebar-user">
    <div class="user-avatar"><?= strtoupper(substr($user_name, 0, 1)) ?></div>
    <div class="user-info">
      <div class="uname"><?= htmlspecialchars($user_name) ?></div>
      <div class="urole"><?= $is_admin ? 'Admin' : ucfirst($_SESSION['user_role'] ?? 'User') ?></div>
    </div>
  </div>
  
    <!-- ── NEW PAGES ─────────────────────────────── -->
    <hr class="sd">
    <div class="ss">More</div>
    <a href="/dashboard/profile.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      Profile
    </a>
    <a href="/dashboard/api-keys.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.78 7.78 5.5 5.5 0 017.78-7.78l1.06-1.06a2 2 0 012.83 0l1.06 1.06a2 2 0 010 2.83z"/></svg>
      API Keys
    </a>
    <a href="/dashboard/notifications.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
      Notifications
    </a>
    <a href="/dashboard/support.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
      Support
    </a>
    <!-- ── END NEW PAGES ──────────────────────────── -->
  
  <a href="/auth/logout.php" style="color:var(--muted);font-size:.82rem">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16,17 21,12 16,7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
    Sign out
  </a>
</nav>

<!-- MAIN -->
<div class="main">

  <!-- TABS -->
  <div class="tabs">
    <a href="/dashboard/?tab=overview" class="tab-btn <?= $active_tab==='overview'?'active':'' ?>">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>
      Overview
    </a>
    <a href="/dashboard/?tab=chat" class="tab-btn <?= $active_tab==='chat'?'active':'' ?>">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
      Chat
    </a>
    <a href="/dashboard/billing.php" class="tab-btn">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
      Billing
    </a>
  </div>

  <!-- ====== OVERVIEW TAB ====== -->
  <div class="tab-panel <?= $active_tab==='overview'?'active':'' ?>" id="panel-overview">
    <div class="overview-scroll">

      <?php
        $resend_status = $_GET['resend'] ?? '';
        if ($resend_status === 'sent'): ?>
        <div style="background:var(--green-bg);border:1px solid rgba(52,211,153,.3);border-radius:10px;padding:.75rem 1rem;margin-bottom:1rem;font-size:.85rem;color:var(--green);display:flex;align-items:center;gap:.5rem">
          ✓ <strong>Verification email sent!</strong> Check your inbox.
        </div>
      <?php elseif ($resend_status === 'too_soon'): ?>
        <div style="background:var(--orange-bg);border:1px solid rgba(251,146,60,.3);border-radius:10px;padding:.75rem 1rem;margin-bottom:1rem;font-size:.85rem;color:var(--orange)">
          ⧖ Please wait 60 seconds before resending.
        </div>
      <?php elseif ($resend_status === 'error'): ?>
        <div style="background:var(--red-bg);border:1px solid rgba(248,113,113,.3);border-radius:10px;padding:.75rem 1rem;margin-bottom:1rem;font-size:.85rem;color:var(--red)">
          ✗ Failed to send. Contact support@chainmind.com.ng
        </div>
      <?php endif; ?>

      <div class="page-header">
        <div class="greeting-line">Welcome back, <span class="name-highlight"><?= htmlspecialchars(explode(' ', $user_name)[0]) ?></span> 👋</div>
        <div class="subtitle"><?= htmlspecialchars($_SESSION['user_email'] ?? '') ?> · <?= date('l, F j, Y') ?></div>
      </div>

      <?php if ($no_credits): ?>
      <div class="banner banner-danger">
        <div class="banner-icon">🚫</div>
        <div class="banner-content"><strong>No credits remaining.</strong> Chat and API access are paused until you top up.</div>
        <a href="/dashboard/billing.php" class="banner-cta">Buy Credits →</a>
      </div>
      <?php elseif ($low_credits): ?>
      <div class="banner banner-warn">
        <div class="banner-icon">⚠️</div>
        <div class="banner-content"><strong>Running low</strong> — only <strong><?= number_format($balance) ?></strong> credits remain.</div>
        <a href="/dashboard/billing.php" class="banner-cta">Top Up →</a>
      </div>
      <?php endif; ?>

      <?php if (!$sub): ?>
      <div class="banner banner-info">
        <div class="banner-icon">✨</div>
        <div class="banner-content"><strong>Upgrade to Pro</strong> — 20,000 credits/month + priority queue for just <strong>$15/mo</strong></div>
        <a href="/dashboard/billing.php" class="banner-cta">Upgrade →</a>
      </div>
      <?php endif; ?>

      <!-- STATS -->
      <div class="stats">
        <div class="stat-card <?= $no_credits?'sc-danger':($low_credits?'sc-warn':'sc-ok') ?>">
          <div class="sc-icon <?= $no_credits?'sc-red':($low_credits?'sc-orange':'sc-green') ?>">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg>
          </div>
          <div class="sc-label">Credit Balance</div>
          <div class="sc-value"><?= number_format($balance) ?></div>
          <div class="sc-sub">≈ $<?= number_format($balance / CREDITS_PER_USD, 4) ?> USD</div>
        </div>
        <div class="stat-card sc-purple-val">
          <div class="sc-icon sc-purple">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
          </div>
          <div class="sc-label">Total Jobs</div>
          <div class="sc-value"><?= number_format($primary_key['total_jobs'] ?? 0) ?></div>
        </div>
        <div class="stat-card">
          <div class="sc-icon sc-blue">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
          </div>
          <div class="sc-label">Total Spend</div>
          <div class="sc-value" style="color:var(--text2)">$<?= number_format($spend, 2) ?></div>
        </div>
        <div class="stat-card">
          <div class="sc-icon sc-purple">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2"/></svg>
          </div>
          <div class="sc-label">API Keys</div>
          <div class="sc-value" style="color:var(--accent2)"><?= count($keys) ?></div>
        </div>
      </div>

      <?php if (!$primary_key): ?>
      <div class="banner banner-warn">
        <div class="banner-icon">⚠️</div>
        <div class="banner-content">No API key found. Please <a href="mailto:support@chainmind.com.ng" style="color:var(--orange);font-weight:700">contact support</a>.</div>
      </div>
      <?php else: ?>

      <!-- API KEY -->
      <div class="api-key-box">
        <div class="section-label">Your API Key</div>
        <div class="key-row">
          <svg class="key-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.78 7.78 5.5 5.5 0 017.78-7.78l1.06-1.06a2 2 0 012.83 0l1.06 1.06a2 2 0 010 2.83z"/></svg>
          <span class="key-val" id="api-key-val"><?= htmlspecialchars($primary_key['api_key']) ?></span>
          <button class="copy-btn" onclick="copyKey()">Copy</button>
        </div>
        <div class="key-hint">
          Header: <code>X-Api-Key: <?= htmlspecialchars(substr($primary_key['api_key'],0,24)) ?>…</code>
          &nbsp;·&nbsp; Endpoint: <code>POST /api/infer.php</code>
        </div>
      </div>

      <?php if ($sub): ?>
      <div class="sub-box">
        <div class="sub-badge">Active</div>
        <div class="sub-info">
          <div class="sub-title">⭐ <?= ucfirst($sub['plan']) ?> Plan</div>
          <div class="sub-detail"><?= number_format($sub['credits_month']) ?> credits/mo · $<?= number_format($sub['price_usd'],2) ?>/mo · Renews <?= $sub['renews_at'] ?></div>
        </div>
      </div>
      <?php endif; ?>

      <a class="btn-primary" href="/dashboard/billing.php">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Top up credits / manage billing
      </a>

      <div class="card">
        <div class="card-header">
          <h2>Recent Jobs</h2>
          <a href="/dashboard/?tab=chat">Chat now →</a>
        </div>
        <table>
          <thead>
            <tr><th>Job ID</th><th>Model</th><th>Tokens</th><th>Status</th><th>Date</th></tr>
          </thead>
          <tbody>
          <?php foreach ($recent_jobs as $j): ?>
          <tr>
            <td class="mono muted"><?= substr($j['id'],0,12) ?>…</td>
            <td style="color:var(--text2)"><?= htmlspecialchars($j['model'] ?? '') ?></td>
            <td class="mono muted"><?= number_format(($j['tokens_in']??0)+($j['tokens_out']??0)) ?></td>
            <td><span class="badge b-<?= $j['status'] ?>"><?= $j['status'] ?></span></td>
            <td class="muted"><?= substr($j['created_at'],0,10) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($recent_jobs)): ?>
            <tr><td colspan="5" style="text-align:center;padding:2rem;color:var(--muted)">
              No jobs yet. <a href="/dashboard/?tab=chat" style="color:var(--accent);font-weight:600">Try the chat →</a>
            </td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- ====== CHAT TAB ====== -->
  <div class="tab-panel <?= $active_tab==='chat'?'active':'' ?>" id="panel-chat">
    <div class="chat-panel">

      <!-- Chat sidebar -->
      <div class="chat-sidebar">
        <div>
          <div class="cs-section-title">Network Status</div>
          <div class="net-stat-row"><span class="net-stat-label">Nodes online</span><span class="net-stat-val" id="cs-nodes">—</span></div>
          <div class="net-stat-row"><span class="net-stat-label">Jobs done</span><span class="net-stat-val" id="cs-jobs">—</span></div>
          <div class="net-stat-row"><span class="net-stat-label">IQ distributed</span><span class="net-stat-val" id="cs-iq">—</span></div>
        </div>

        <div class="model-select-wrap">
          <div class="cs-section-title" style="margin-bottom:.5rem">Model</div>
          <select id="modelSelect">
            <option value="">Auto (node decides)</option>
            <option value="tinyllama">TinyLlama (fastest)</option>
            <option value="phi3:mini">Phi-3 Mini</option>
            <option value="llama3.2:3b">Llama 3.2 3B</option>
            <option value="mistral">Mistral 7B</option>
            <option value="llama3.1:8b">Llama 3.1 8B</option>
            <option value="llava:7b">LLaVA 7B (vision)</option>
          </select>
        </div>

        <?php if ($primary_key): ?>
        <div>
          <div class="key-display-label">API Key (auto-applied)</div>
          <div class="key-display"><?= htmlspecialchars(substr($primary_key['api_key'],0,28)) ?>…</div>
        </div>
        <?php endif; ?>

        <div style="flex:1;display:flex;flex-direction:column;min-height:0;overflow:hidden">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:.5rem">
            <div class="cs-section-title" style="margin:0">Conversations</div>
            <button id="newSessionBtn" style="background:rgba(139,60,247,.12);border:1px solid rgba(139,60,247,.25);color:var(--accent);
              border-radius:6px;padding:.2rem .55rem;font-size:.73rem;cursor:pointer;font-weight:700;font-family:var(--font);transition:all .15s">+ New</button>
          </div>
          <div id="sessionList" style="overflow-y:auto;flex:1;margin:0 -.15rem">
            <p class="muted" style="font-size:.78rem;padding:.3rem .5rem">Loading...</p>
          </div>
        </div>

        <div class="lb-section">
          <h3>🏆 Node Leaderboard</h3>
          <div id="cs-leaderboard"><p class="muted" style="font-size:.75rem">Loading...</p></div>
        </div>
      </div>

      <!-- Chat main area -->
      <div class="chat-main">
        <div class="chat-topbar">
          <div style="min-width:0">
            <h2 id="chatTopTitle">Chat with the Network</h2>
            <p id="chatTopSub">Powered by community GPU nodes — No cloud</p>
          </div>
          <div class="chat-credit-pill <?= $no_credits?'empty':($low_credits?'low':'') ?>" id="creditPill">
            <?= $no_credits ? 'No credits' : ($low_credits ? number_format($balance).' credits' : number_format($balance).' credits') ?>
          </div>
        </div>

        <?php if ($no_credits): ?>
        <div class="chat-blocked">
          <div class="cb-icon">🔒</div>
          <h3>You're out of credits</h3>
          <p>Add credits to start chatting. Plans from $5 for 5,000 credits — roughly 1 million tokens.</p>
          <a href="/dashboard/billing.php">Buy Credits →</a>
          <p style="font-size:.78rem;color:var(--muted);margin-top:.25rem">Already subscribed? Credits renew automatically.</p>
        </div>
        <?php else: ?>

        <div id="summaryBanner" style="display:none">
          <strong>Earlier context (summarised)</strong>
          <span id="summaryText"></span>
        </div>

        <div class="messages" id="chatMessages">
          <div class="message assistant">
            <div class="message-bubble">
              <p>Hello, <?= htmlspecialchars(explode(' ', $user_name)[0]) ?>! I'm ChainMind — ask me anything, upload files, or generate images.</p>
              <?php if ($low_credits): ?>
              <p style="color:var(--orange);font-size:.82rem;margin-top:.5rem">⚠️ <?= number_format($balance) ?> credits left. <a href="/dashboard/billing.php" style="color:var(--orange);font-weight:600">Top up here</a>.</p>
              <?php endif; ?>
              <p class="message-meta">ChainMind Network · Ready</p>
            </div>
          </div>
        </div>

        <div class="input-area">
          <?php if ($low_credits && !$no_credits): ?>
          <div style="background:var(--orange-bg);border:1px solid rgba(251,146,60,.3);border-radius:9px;padding:.6rem 1rem;margin-bottom:.75rem;font-size:.78rem;display:flex;align-items:center;justify-content:space-between;gap:.5rem">
            <span>⚠️ <strong><?= number_format($balance) ?> credits left</strong></span>
            <a href="/dashboard/billing.php" style="color:var(--orange);font-weight:700;white-space:nowrap;text-decoration:none">Top Up →</a>
          </div>
          <?php endif; ?>

          <!-- ── INPUT TOOLBAR (new) ── -->
          <div class="input-toolbar">
            <button class="tool-btn" id="attachBtn" onclick="document.getElementById('fileInput').click()" title="Attach files — images, PDFs, text, code, zip">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg>
              Attach file
            </button>
            <button class="tool-btn" id="imgGenBtn" onclick="toggleImgGen()" title="Toggle image generation mode">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26 12,2"/></svg>
              Image gen
            </button>
            <span id="toolbarHint" style="font-size:.7rem;color:var(--muted2);margin-left:auto">Drag &amp; drop files into the chat area</span>
          </div>

          <!-- Hidden file input -->
          <input type="file" id="fileInput" multiple
            accept="image/*,text/*,.pdf,.csv,.json,.md,.py,.js,.php,.ts,.zip,.txt"
            style="display:none" onchange="handleFileInputChange(this)">

          <!-- File chips rendered here by JS -->
          <div id="fileChips" class="file-chips"></div>

          <div class="input-row">
            <textarea id="chatInput" placeholder="Ask anything… (Enter to send, Shift+Enter for newline)" rows="1"></textarea>
            <button class="send-btn" id="chatSendBtn" onclick="dashSend()">
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
            </button>
          </div>
          <p class="input-hint" id="chatStatus">Ready · Credits active · <a href="/dashboard/billing.php">Manage</a></p>
        </div>
        <?php endif; ?>
      </div>

    </div>
  </div>

</div><!-- .main -->

<script>
function copyKey() {
  const v = document.getElementById('api-key-val').textContent;
  navigator.clipboard.writeText(v).then(() => {
    const b = document.querySelector('.copy-btn');
    b.textContent = '✓ Copied';
    b.classList.add('copied');
    setTimeout(() => { b.textContent = 'Copy'; b.classList.remove('copied'); }, 2000);
  });
}

document.querySelectorAll('.tab-btn, .sidebar a').forEach(a => {
  a.addEventListener('click', e => {
    const href = a.getAttribute('href') || '';
    if (href.includes('tab=chat') && <?= $no_credits ? 'true' : 'false' ?>) {
      e.preventDefault();
      window.location.href = '/dashboard/billing.php?reason=nocredits';
    }
  });
});

async function loadChatStats() {
  try {
    const r = await fetch('/api/stats.php'); if (!r.ok) return;
    const d = await r.json(); const n = d.network || {};
    const el = id => document.getElementById(id);
    if (el('cs-nodes')) el('cs-nodes').textContent = (n.online_nodes||0) + ' / ' + (n.total_nodes||0);
    if (el('cs-jobs'))  el('cs-jobs').textContent  = Number(n.total_jobs||0).toLocaleString();
    if (el('cs-iq'))    el('cs-iq').textContent    = Number(n.total_iq||0).toFixed(2) + ' IQ';
    const lb = d.leaderboard || [];
    const lbEl = el('cs-leaderboard');
    if (lbEl) {
      lbEl.innerHTML = lb.length ? lb.slice(0,6).map((n,i) => `
        <div class="lb-item">
          <span class="lb-rank">${i+1}</span>
          <span class="lb-dot ${n.status}"></span>
          <span class="lb-name">${esc(n.name||n.id.slice(0,8))}</span>
          <span class="lb-iq">${Number(n.iq_earned).toFixed(1)}</span>
        </div>`).join('') : '<p class="muted" style="font-size:.75rem">No nodes yet</p>';
    }
  } catch(_) {}
}
loadChatStats();
setInterval(loadChatStats, 15000);

<?php if (!$no_credits): ?>
const API_KEY     = <?= $primary_key ? json_encode($primary_key['api_key']) : 'null' ?>;
const MEMORY_API  = '/api/chat_memory.php';
const POLL_MS     = 1500;
const MAX_POLLS   = 80;

const messagesEl    = document.getElementById('chatMessages');
const chatInput     = document.getElementById('chatInput');
const chatSendBtn   = document.getElementById('chatSendBtn');
const chatStatus    = document.getElementById('chatStatus');
const modelSelect   = document.getElementById('modelSelect');
const sessionList   = document.getElementById('sessionList');
const summaryBanner = document.getElementById('summaryBanner');
const summaryText   = document.getElementById('summaryText');

let currentSessionId = null;
let sessions = [];
let isWaiting = false;

/* ================================================================
   MULTIMODAL STATE
   ================================================================ */
let attachedFiles = [];   /* [{name, type, b64, isImage}] */
let imgGenMode    = false;

/* ── File input bridge ── */
window.handleFileInputChange = function(input) {
  handleFileSelect(Array.from(input.files));
  input.value = '';
};

function handleFileSelect(files) {
  files.forEach(f => {
    const reader = new FileReader();
    reader.onload = e => {
      const b64 = e.target.result.split(',')[1];
      attachedFiles.push({ name: f.name, type: f.type, b64, isImage: f.type.startsWith('image/') });
      renderFileChips();
    };
    reader.readAsDataURL(f);
  });
}

function renderFileChips() {
  const chips = document.getElementById('fileChips');
  if (!chips) return;
  chips.innerHTML = attachedFiles.map((f, i) => `
    <div class="file-chip ${f.isImage ? 'img-chip' : ''}">
      ${f.isImage
        ? `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21,15 16,10 5,21"/></svg>`
        : `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14,2 14,8 20,8"/></svg>`}
      <span title="${esc(f.name)}">${esc(f.name)}</span>
      <button onclick="removeFile(${i})" title="Remove">✕</button>
    </div>`).join('');
}

window.removeFile = function(i) {
  attachedFiles.splice(i, 1);
  renderFileChips();
};

/* ── Image generation toggle ── */
window.toggleImgGen = function() {
  imgGenMode = !imgGenMode;
  const btn = document.getElementById('imgGenBtn');
  if (btn) btn.classList.toggle('active', imgGenMode);
  if (chatInput) {
    chatInput.placeholder = imgGenMode
      ? 'Describe the image you want… (Enter to generate)'
      : 'Ask anything… (Enter to send, Shift+Enter for newline)';
  }
  const hint = document.getElementById('toolbarHint');
  if (hint) hint.textContent = imgGenMode
    ? '✦ Image gen ON — describe what you want'
    : 'Drag & drop files into the chat area';
};

/* ── Drag and drop ── */
if (messagesEl) {
  messagesEl.addEventListener('dragover', e => { e.preventDefault(); messagesEl.classList.add('drag-over'); });
  messagesEl.addEventListener('dragleave', e => { if (!messagesEl.contains(e.relatedTarget)) messagesEl.classList.remove('drag-over'); });
  messagesEl.addEventListener('drop', e => {
    e.preventDefault(); messagesEl.classList.remove('drag-over');
    handleFileSelect(Array.from(e.dataTransfer.files));
  });
}

/* ================================================================
   SESSION MANAGEMENT (unchanged)
   ================================================================ */
(async function boot() {
  await refreshSessions();
  if (sessions.length > 0) await loadSession(sessions[0].id);
  else await createSession();
})();

async function refreshSessions() {
  const d = await memApi({ action: 'list_sessions' });
  if (!d) return;
  sessions = d.sessions || [];
  renderSessions();
}

function renderSessions() {
  if (!sessionList) return;
  if (!sessions.length) {
    sessionList.innerHTML = '<p class="muted" style="font-size:.78rem;padding:.3rem .5rem">No conversations yet</p>';
    return;
  }
  sessionList.innerHTML = sessions.map(s => `
    <div class="dash-session ${s.id === currentSessionId ? 'active' : ''}" data-id="${esc(s.id)}">
      <span style="flex:1;font-size:.78rem;color:${s.id===currentSessionId?'var(--text2)':'var(--muted)'};
        white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(s.title)}</span>
      <button data-del="${esc(s.id)}" style="background:none;border:none;color:var(--muted2);font-size:.72rem;
        cursor:pointer;padding:.1rem .3rem;opacity:0;border-radius:3px;flex-shrink:0;transition:opacity .15s" class="del-btn">✕</button>
    </div>
  `).join('');

  sessionList.querySelectorAll('[data-id]').forEach(el => {
    el.addEventListener('mouseenter', () => el.querySelector('.del-btn').style.opacity = '1');
    el.addEventListener('mouseleave', e => { if (!el.contains(e.relatedTarget)) el.querySelector('.del-btn').style.opacity = '0'; });
    el.addEventListener('click', e => { if (e.target.closest('[data-del]')) return; loadSession(el.dataset.id); });
  });
  sessionList.querySelectorAll('[data-del]').forEach(btn => {
    btn.addEventListener('click', e => { e.stopPropagation(); deleteSession(btn.dataset.del); });
  });
}

async function createSession() {
  const d = await memApi({ action: 'new_session' }); if (!d) return;
  currentSessionId = d.session_id;
  sessions.unshift({ id: d.session_id, title: d.title });
  renderSessions(); clearMessages(); hideSummary(); updateTopbar('New conversation');
}

async function loadSession(sid) {
  currentSessionId = sid; renderSessions(); clearMessages();
  const d = await memApi({ action: 'get_history', session_id: sid }); if (!d) return;
  const s = sessions.find(x => x.id === sid);
  if (s) updateTopbar(s.title);
  if (d.summary) { summaryBanner.style.display = 'block'; summaryText.textContent = d.summary; }
  else hideSummary();
  (d.messages || []).forEach(m => appendMsg(m.role, m.content, null, false, false, false));
  messagesEl.scrollTop = messagesEl.scrollHeight;
  setStatus('Ready · Credits active · <a href="/dashboard/billing.php">Manage</a>');
}

async function deleteSession(sid) {
  if (!confirm('Delete this conversation?')) return;
  await memApi({ action: 'delete_session', session_id: sid });
  sessions = sessions.filter(s => s.id !== sid); renderSessions();
  if (currentSessionId === sid) { sessions.length > 0 ? await loadSession(sessions[0].id) : await createSession(); }
}

document.getElementById('newSessionBtn')?.addEventListener('click', createSession);

chatInput.addEventListener('input', () => {
  chatInput.style.height = 'auto';
  chatInput.style.height = Math.min(chatInput.scrollHeight, 160) + 'px';
});
chatInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); dashSend(); }
});

/* ================================================================
   MAIN SEND — handles text, file understanding, image generation
   ================================================================ */
window.dashSend = async function() {
  const prompt = chatInput.value.trim();
  const files  = [...attachedFiles];

  /* ── IMAGE GENERATION MODE ── */
  if (imgGenMode && prompt) {
    if (isWaiting) return;
    isWaiting = true; chatSendBtn.disabled = true;
    if (!currentSessionId) await createSession();

    appendMsg('user', '🎨 ' + prompt);
    chatInput.value = ''; chatInput.style.height = 'auto';
    attachedFiles = []; renderFileChips();

    const typId = 'typ' + Date.now();
    appendImgGenStatus(typId);
    setStatus('Routing image generation job to a node…');

    try {
      const headers = { 'Content-Type': 'application/json' };
      if (API_KEY) headers['X-Api-Key'] = API_KEY;

      const res = await fetch('/api/image-gen.php', {
        method: 'POST', headers,
        body: JSON.stringify({ prompt, model: modelSelect?.value || null }),
      });
      const sub = await res.json();
      if (!res.ok) throw new Error(sub.error || 'Image gen submission failed');

      let polls = 0;
      const result = await new Promise((resolve, reject) => {
        const timer = setInterval(async () => {
          if (++polls > MAX_POLLS) { clearInterval(timer); reject(new Error('Timed out waiting for node')); return; }
          try {
            const r  = await fetch('/api/job.php?id=' + sub.job_id);
            const d  = await r.json();
            if      (d.status === 'done')                     { clearInterval(timer); resolve(d); }
            else if (d.status === 'error' || d.status === 'timeout') { clearInterval(timer); reject(new Error(d.result || 'Node error')); }
            else setStatus('Node is generating your image…');
          } catch(_) {}
        }, POLL_MS);
      });

      removeEl(typId);
      const imgs = result.result_images || [];
      appendImageMsg('assistant', result.result || 'Here is your generated image:', imgs, result.model);
      await memApi({ action: 'save_message', session_id: currentSessionId, role: 'user',      content: '🎨 ' + prompt });
      await memApi({ action: 'save_message', session_id: currentSessionId, role: 'assistant', content: (result.result || '[image]') + (imgs.length ? ' [+image]' : '') });
      setStatus('Ready · Credits active · <a href="/dashboard/billing.php">Manage</a>');

    } catch(err) {
      removeEl(typId);
      appendMsg('assistant', '⚠ ' + err.message, null, true);
      setStatus('Error · try again');
    }

    isWaiting = false; chatSendBtn.disabled = false; chatInput.focus();
    return;
  }

  /* ── FILE UNDERSTANDING MODE ── */
  if (files.length > 0 && prompt) {
    if (isWaiting) return;
    isWaiting = true; chatSendBtn.disabled = true;
    if (!currentSessionId) await createSession();

    appendMsgWithFiles('user', prompt, files);
    chatInput.value = ''; chatInput.style.height = 'auto';
    attachedFiles = []; renderFileChips();

    const typId = 'typ' + Date.now();
    appendTyping(typId);
    setStatus('Sending files to node…');

    try {
      const headers = { 'Content-Type': 'application/json' };
      if (API_KEY) headers['X-Api-Key'] = API_KEY;

      const res = await fetch('/api/vision.php', {
        method: 'POST', headers,
        body: JSON.stringify({
          prompt,
          files: files.map(f => ({ name: f.name, type: f.type, data: f.b64 })),
          model: modelSelect?.value || null,
        }),
      });
      const sub = await res.json();
      if (!res.ok) throw new Error(sub.error || 'Vision job failed');

      let polls = 0;
      const result = await new Promise((resolve, reject) => {
        const timer = setInterval(async () => {
          if (++polls > MAX_POLLS) { clearInterval(timer); reject(new Error('Timed out')); return; }
          try {
            const r = await fetch('/api/job.php?id=' + sub.job_id);
            const d = await r.json();
            if      (d.status === 'done')                     { clearInterval(timer); resolve(d); }
            else if (d.status === 'error' || d.status === 'timeout') { clearInterval(timer); reject(new Error(d.result || 'Node error')); }
            else setStatus('Node is reading your files…');
          } catch(_) {}
        }, POLL_MS);
      });

      removeEl(typId);
      const meta = [
        result.model      ? 'Model: ' + result.model      : null,
        result.tokens_out ? result.tokens_out + ' tokens'  : null,
        result.node_id    ? 'Node: ' + result.node_id.slice(0,8) : null,
      ].filter(Boolean).join(' · ');
      appendMsg('assistant', result.result, meta);
      await memApi({ action: 'save_message', session_id: currentSessionId, role: 'user',      content: prompt + ' [+' + files.length + ' file(s)]' });
      await memApi({ action: 'save_message', session_id: currentSessionId, role: 'assistant', content: result.result });
      setStatus('Ready · Credits active · <a href="/dashboard/billing.php">Manage</a>');

    } catch(err) {
      removeEl(typId);
      appendMsg('assistant', '⚠ ' + err.message, null, true);
      setStatus('Error · try again');
    }

    isWaiting = false; chatSendBtn.disabled = false; chatInput.focus();
    return;
  }

  /* ── NORMAL TEXT CHAT ── */
  if (!prompt || isWaiting) return;
  if (!currentSessionId) await createSession();
  isWaiting = true; chatSendBtn.disabled = true;

  await memApi({ action: 'save_message', session_id: currentSessionId, role: 'user', content: prompt });
  appendMsg('user', prompt);
  chatInput.value = ''; chatInput.style.height = 'auto';
  const typingId = 't' + Date.now();
  appendTyping(typingId);
  setStatus('Building context...');

  try {
    const ctx = await memApi({ action: 'get_context', session_id: currentSessionId });
    setStatus('Routing to a node...');
    const headers = { 'Content-Type': 'application/json' };
    if (API_KEY) headers['X-Api-Key'] = API_KEY;

    const res = await fetch('/api/infer.php', {
      method: 'POST', headers,
      body: JSON.stringify({ prompt, model: modelSelect.value || null, system: ctx?.system_prompt || '', messages: ctx?.messages || [] }),
    });
    const sub = await res.json();

    if (!res.ok) {
      removeEl(typingId);
      if (res.status === 429) { appendMsg('assistant', '⏱ Rate limit reached. Please wait a moment.', null, true); setStatus('Rate limited'); }
      else if (res.status === 402) { appendMsg('assistant', '🔒 Out of credits. <a href="/dashboard/billing.php" style="color:var(--accent)">Top up here</a>.', null, true, true); setStatus('Out of credits'); document.getElementById('creditPill').textContent='No credits'; document.getElementById('creditPill').className='chat-credit-pill empty'; }
      else { appendMsg('assistant', '⚠ ' + (sub.error || 'Failed to submit.'), null, true); setStatus('Error · Try again'); }
      isWaiting = false; chatSendBtn.disabled = false; return;
    }

    if (sub.model_note) {
      appendMsg('assistant', 'ℹ️ ' + sub.model_note, null, false, true);
    }

    setStatus('Waiting for a free node...');
    let polls = 0;
    const result = await new Promise((resolve, reject) => {
      const timer = setInterval(async () => {
        if (++polls > MAX_POLLS) { clearInterval(timer); reject(new Error('Timed out — node too slow.')); return; }
        try {
          const r = await fetch('/api/job.php?id=' + sub.job_id);
          const d = await r.json();
          if (d.status === 'done') { clearInterval(timer); resolve(d); }
          else if (d.status === 'error' || d.status === 'timeout') { clearInterval(timer); reject(new Error(d.result || 'Node error.')); }
          else setStatus({ pending:'Waiting for a free node...', claimed:'Node is thinking...', running:'Node is thinking...' }[d.status] || 'Processing...');
        } catch(_) {}
      }, POLL_MS);
    });

    removeEl(typingId);
    await memApi({ action: 'save_message', session_id: currentSessionId, role: 'assistant', content: result.result, job_id: result.job_id });

    const sess = sessions.find(s => s.id === currentSessionId);
    if (sess && sess.title === 'New conversation') {
      await refreshSessions();
      const updated = sessions.find(s => s.id === currentSessionId);
      if (updated) updateTopbar(updated.title);
    }

    const meta = [
      result.model      ? 'Model: ' + result.model : null,
      result.tokens_out ? result.tokens_out + ' tokens' : null,
      result.duration_ms ? (result.duration_ms/1000).toFixed(1) + 's' : null,
      result.node_id    ? 'Node: ' + result.node_id.slice(0,8) : null,
    ].filter(Boolean).join(' · ');

    appendMsg('assistant', result.result, meta);
    setStatus('Ready · Credits active · <a href="/dashboard/billing.php">Manage</a>');
  } catch(err) {
    removeEl(typingId);
    appendMsg('assistant', '⚠ ' + err.message, null, true);
    setStatus('Error · try again');
  }

  isWaiting = false; chatSendBtn.disabled = false; chatInput.focus();
};

/* ================================================================
   DOM HELPERS
   ================================================================ */
function updateTopbar(title) {
  const el = document.getElementById('chatTopTitle');
  if (el) el.textContent = title === 'New conversation' ? 'Chat with the Network' : title;
}
function hideSummary() { summaryBanner.style.display='none'; summaryText.textContent=''; }
function clearMessages() {
  messagesEl.innerHTML = `<div class="message assistant"><div class="message-bubble"><p>Hello, <?= htmlspecialchars(explode(' ', $user_name)[0]) ?>! Ask me anything, attach files, or generate images.</p><p class="message-meta">ChainMind Network · Ready</p></div></div>`;
}
async function memApi(body) {
  try { const r = await fetch(MEMORY_API, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body) }); return await r.json(); }
  catch(e) { console.warn('memApi error:', e); return null; }
}

function appendMsg(role, text, meta=null, isError=false, isHtml=false, doScroll=true) {
  const el = document.createElement('div'); el.className = 'message ' + role;
  const bubble = document.createElement('div'); bubble.className = 'message-bubble';
  if (isHtml)       bubble.innerHTML = '<p>' + text + '</p>';
  else if (isError) bubble.innerHTML = '<p style="color:var(--red)">' + esc(text) + '</p>';
  else              bubble.innerHTML = fmtText(text);
  if (meta) { const m=document.createElement('p'); m.className='message-meta'; m.textContent=meta; bubble.appendChild(m); }
  el.appendChild(bubble); messagesEl.appendChild(el);
  if (doScroll) messagesEl.scrollTop = messagesEl.scrollHeight;
}

function appendTyping(id) {
  const el=document.createElement('div'); el.className='message assistant'; el.id=id;
  el.innerHTML='<div class="message-bubble"><div class="typing-dots"><span></span><span></span><span></span></div></div>';
  messagesEl.appendChild(el); messagesEl.scrollTop=messagesEl.scrollHeight;
}

function appendImgGenStatus(id) {
  const el = document.createElement('div'); el.className='message assistant'; el.id=id;
  el.innerHTML=`<div class="message-bubble">
    <div class="img-gen-status"><div class="spin"></div><span>Generating your image on a node…</span></div>
  </div>`;
  messagesEl.appendChild(el); messagesEl.scrollTop=messagesEl.scrollHeight;
}

function appendImageMsg(role, text, imgs, model) {
  const el = document.createElement('div'); el.className = 'message ' + role;
  const bubble = document.createElement('div'); bubble.className = 'message-bubble';
  bubble.innerHTML = fmtText(text);
  if (imgs && imgs.length) {
    const grid = document.createElement('div'); grid.className = 'msg-image-grid';
    imgs.forEach(b64 => {
      const img = document.createElement('img');
      img.className = 'msg-image';
      img.src = 'data:image/png;base64,' + b64;
      img.alt = 'Generated image';
      img.title = 'Click to open full size';
      img.onclick = () => {
        const w = window.open('', '_blank');
        w.document.write('<body style="margin:0;background:#000"><img src="' + img.src + '" style="max-width:100%;display:block;margin:auto"></body>');
      };
      grid.appendChild(img);
    });
    bubble.appendChild(grid);
  }
  if (model) {
    const m = document.createElement('p'); m.className='message-meta';
    m.textContent = 'Model: ' + model; bubble.appendChild(m);
  }
  el.appendChild(bubble); messagesEl.appendChild(el);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function appendMsgWithFiles(role, text, files) {
  const el = document.createElement('div'); el.className = 'message ' + role;
  const bubble = document.createElement('div'); bubble.className = 'message-bubble';
  bubble.innerHTML = '<p>' + esc(text) + '</p>';
  if (files.length) {
    const chips = document.createElement('div');
    chips.className = 'file-chips'; chips.style.cssText = 'margin-top:.5rem';
    files.forEach(f => {
      chips.innerHTML += `<div class="file-chip ${f.isImage?'img-chip':''}"><span>${esc(f.name)}</span></div>`;
    });
    bubble.appendChild(chips);
  }
  el.appendChild(bubble); messagesEl.appendChild(el);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function removeEl(id) { const e=document.getElementById(id); if(e) e.remove(); }
function setStatus(msg) { if(chatStatus) chatStatus.innerHTML=msg; }
function fmtText(text) {
  if (!text) return '<p></p>';
  let s = esc(text);
  s = s.replace(/```(\w*)\n?([\s\S]*?)```/g, '<pre><code>$2</code></pre>');
  s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
  s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  s = s.split(/\n\n+/).map(p => '<p>'+p.replace(/\n/g,'<br>')+'</p>').join('');
  return s;
}
<?php endif; ?>

function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>

  <!-- ── CHAINMIND MOBILE JS ────────────────────────── -->
  <script>
  (function() {
    function cmToggle() {
      var sb = document.querySelector('.sidebar');
      var ov = document.getElementById('cmOverlay');
      var hb = document.getElementById('cmHamburger');
      if (sb) sb.classList.toggle('cm-open');
      if (ov) ov.classList.toggle('cm-show');
      if (hb) hb.classList.toggle('cm-open');
    }
    function cmClose() {
      var sb = document.querySelector('.sidebar');
      var ov = document.getElementById('cmOverlay');
      var hb = document.getElementById('cmHamburger');
      if (sb) sb.classList.remove('cm-open');
      if (ov) ov.classList.remove('cm-show');
      if (hb) hb.classList.remove('cm-open');
    }
    window.cmToggle = cmToggle;
    window.cmClose  = cmClose;
    document.addEventListener('DOMContentLoaded', function() {
      var links = document.querySelectorAll('.sidebar a');
      links.forEach(function(l) {
        l.addEventListener('click', function() {
          if (window.innerWidth <= 768) cmClose();
        });
      });
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') cmClose();
      });
    });
  })();
  </script>
  <!-- ── END MOBILE JS ──────────────────────────────── -->
  
</body>
</html>