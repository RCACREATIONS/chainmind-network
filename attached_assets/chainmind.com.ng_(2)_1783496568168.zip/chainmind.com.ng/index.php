<?php 
session_start();
$logged_in = isset($_SESSION['user_id']);
$is_admin  = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';

$live_nodes = 0; $live_jobs = 0; $total_jobs_done = 0;
try {
  require_once __DIR__.'/api/_helpers.php';
  $live_nodes      = (int)db()->query("SELECT COUNT(*) FROM nodes WHERE status='online'")->fetchColumn();
  $live_jobs       = (int)db()->query("SELECT COUNT(*) FROM jobs WHERE status IN('pending','processing')")->fetchColumn();
  $total_jobs_done = (int)db()->query("SELECT COUNT(*) FROM jobs WHERE status='done'")->fetchColumn();
} catch(\Throwable $e) {}

function get_visitor_ip(): string {
  $headers = ['HTTP_CF_CONNECTING_IP','HTTP_X_REAL_IP','HTTP_X_FORWARDED_FOR','HTTP_CLIENT_IP','REMOTE_ADDR'];
  foreach ($headers as $h) {
    if (!empty($_SERVER[$h])) {
      $ip = trim(explode(',', $_SERVER[$h])[0]);
      if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return $ip;
    }
  }
  return $_SERVER['REMOTE_ADDR'] ?? '';
}

function get_country_from_ip(string $ip): array {
  if (empty($ip)) return ['country' => '', 'countryCode' => ''];
  $url = 'http://ip-api.com/json/' . urlencode($ip) . '?fields=status,country,countryCode';
  $ctx = stream_context_create(['http' => ['timeout' => 3, 'ignore_errors' => true]]);
  try {
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw) {
      $data = json_decode($raw, true);
      if (!empty($data['status']) && $data['status'] === 'success') {
        return ['country' => $data['country'] ?? '', 'countryCode' => $data['countryCode'] ?? ''];
      }
    }
  } catch(\Throwable $e) {}
  return ['country' => '', 'countryCode' => ''];
}

$visitor_ip  = get_visitor_ip();
$geo         = get_country_from_ip($visitor_ip);
$is_nigeria  = ($geo['countryCode'] === 'NG');
$country     = $geo['country'];
$countryCode = $geo['countryCode'];

define('USD_TO_NGN', 1400);
define('NGN_TOKEN_RATE', 7);

$prices = $is_nigeria ? [
  'symbol'   => '&#8358;',
  'payg'     => number_format(5 * USD_TO_NGN),
  'pro'      => number_format(15 * USD_TO_NGN),
  'builder'  => number_format(40 * USD_TO_NGN),
  'ticker'   => '&#8358;7 / 1k tokens',
  'hero_min' => '&#8358;7',
  'footer'   => 'Pay with NGN (Paystack) &bull; Crypto (NOWPayments)',
  'flag'     => '&#127475;&#127468;',
  'geo_note' => "You're in Nigeria &#127475;&#127468; &mdash; prices shown in Naira. Crypto also accepted.",
] : [
  'symbol'   => '$',
  'payg'     => '5',
  'pro'      => '15',
  'builder'  => '40',
  'ticker'   => '$0.005 / 1k tokens',
  'hero_min' => '$0.005',
  'footer'   => 'Pay with USD cards (Flutterwave) &bull; Crypto (NOWPayments)',
  'flag'     => '&#127758;',
  'geo_note' => !empty($country) ? "Prices shown in USD for your region ({$country})." : '',
];

$canonical_url = 'https://chainmind.com.ng/';
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11291682357"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11291682357');
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NC3T6B56');</script>
<!-- End Google Tag Manager -->
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-QP1R08VS4N"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-QP1R08VS4N');
</script>

<!-- ================= SEO: PRIMARY TAGS ================= -->
<title>ChainMind &mdash; Decentralized AI Network | Cheap, Open, Community-Run AI Inference</title>
<meta name="description" content="ChainMind is a decentralized AI network that routes AI inference to community-owned GPUs worldwide. Run 300+ open AI models at up to 90% lower cost than OpenAI, Anthropic, or centralized cloud AI &mdash; with no vendor lock-in. Try the AI chat instantly, no signup required.">
<meta name="keywords" content="decentralized AI, decentralized AI network, decentralized intelligence network, distributed AI, AI infrastructure, open source AI models, cheap AI API, OpenAI alternative, GPU sharing network, earn crypto with GPU, AI compute marketplace, community AI, Web3 AI, blockchain AI network, AI inference API, run AI locally, decentralized compute, Akash alternative, Render Network alternative, io.net alternative">
<meta name="robots" content="index, follow, max-image-preview:large">
<link rel="canonical" href="<?=$canonical_url?>">

<!-- ================= SEO: OPEN GRAPH / SOCIAL ================= -->
<meta property="og:type" content="website">
<meta property="og:site_name" content="ChainMind">
<meta property="og:title" content="ChainMind &mdash; Decentralized AI Network | Cheap, Open, Community-Run AI">
<meta property="og:description" content="AI inference routed to community-owned GPUs worldwide. 300+ open models, 90% cheaper than Big Tech AI, no lock-in. Try it free right now.">
<meta property="og:url" content="<?=$canonical_url?>">
<meta property="og:image" content="https://chainmind.com.ng/og-image.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:locale" content="en_US">

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="ChainMind &mdash; Decentralized AI Network">
<meta name="twitter:description" content="Community-owned AI infrastructure. 300+ open models, 90% cheaper than centralized AI clouds. Try it free.">
<meta name="twitter:image" content="https://chainmind.com.ng/og-image.png">

<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.19.0/dist/tabler-icons.min.css">
<link rel="icon" type="image/png" href="ChatGPT_Image_Jun_2,_2026,_06_42_49_AM.png">

<!-- ================= SEO: STRUCTURED DATA (JSON-LD) ================= -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "ChainMind",
  "alternateName": "ChainMind Decentralized AI Network",
  "url": "https://chainmind.com.ng/",
  "logo": "https://chainmind.com.ng/ChatGPT_Image_Jun_2,_2026,_06_42_49_AM.png",
  "description": "ChainMind is a decentralized AI network (DIN) that routes AI inference jobs to community-owned GPU nodes worldwide instead of centralized data centers.",
  "email": "support@chainmind.com.ng",
  "sameAs": []
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": "ChainMind",
  "applicationCategory": "AI Infrastructure / Decentralized Compute",
  "operatingSystem": "Web, Windows, Linux, macOS",
  "description": "Decentralized AI network offering OpenAI-compatible inference across 300+ open-source models, powered by community-owned GPU nodes. Up to 90% cheaper than centralized AI clouds.",
  "offers": {
    "@type": "Offer",
    "price": "0",
    "priceCurrency": "USD",
    "description": "Free tier with bonus credits on signup; pay-as-you-go and subscription plans available."
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is a decentralized AI network?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "A decentralized AI network is an AI infrastructure model where inference jobs run on a distributed pool of independently owned computers instead of centralized data centers owned by a single company. ChainMind is an example: AI jobs are routed to community GPU nodes worldwide, and node operators are paid for the compute they provide."
      }
    },
    {
      "@type": "Question",
      "name": "How is ChainMind different from OpenAI or other centralized AI providers?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Centralized AI providers like OpenAI run inference on their own data centers and set their own pricing and usage policies. ChainMind routes the same kind of AI workloads to a decentralized network of community-owned GPUs, which typically lowers cost substantially and removes single-company control over the infrastructure."
      }
    },
    {
      "@type": "Question",
      "name": "Can I use ChainMind as a drop-in replacement for the OpenAI API?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. ChainMind offers an OpenAI-compatible API format, so most applications only need to change the base URL to start routing requests through the decentralized network instead."
      }
    },
    {
      "@type": "Question",
      "name": "How do node operators earn money on ChainMind?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Node operators install the ChainMind node app, which runs in the background and processes AI inference jobs using their GPU. Operators earn IQ tokens for completed jobs, which can be cashed out via crypto or bank transfer once a minimum threshold is reached."
      }
    },
    {
      "@type": "Question",
      "name": "Is ChainMind free to try?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Visitors can try the live AI chat directly on the homepage without creating an account, and new accounts receive bonus credits to continue using the network."
      }
    }
  ]
}
</script>

<style>
:root {
  --bg:      #07080f;
  --bg2:     #0b0d1c;
  --bg3:     #101228;
  --bg4:     #161935;
  --border:  #1e2040;
  --border2: #272a52;
  --border3: #323670;
  --text:    #eef0ff;
  --text2:   #c5c8f0;
  --muted:   #6b6f9e;
  --muted2:  #474b78;
  --purple:  #8b3cf7;
  --purple2: #6d28d9;
  --indigo:  #4f46e5;
  --accent:  #a78bfa;
  --accent2: #c4b5fd;
  --blue:    #60a5fa;
  --blue2:   #4f46e5;
  --neon:    #a78bfa;
  --grad:    linear-gradient(135deg, #8b3cf7, #4f46e5);
  --grad-soft: linear-gradient(135deg, rgba(139,60,247,.15), rgba(79,70,229,.08));
  --glow:    rgba(139, 60, 247, .35);
  --green:   #34d399;
  --green-bg: rgba(52, 211, 153, .12);
  --orange:  #fb923c;
  --orange-bg: rgba(251, 146, 60, .12);
  --red:     #f87171;
  --red-bg:  rgba(248, 113, 113, .12);
  --gold:    #f59e0b;
  --font:    'Plus Jakarta Sans', sans-serif;
  --display: 'Syne', sans-serif;
  --mono:    'JetBrains Mono', monospace;
  --r-sm: 8px;
  --r-md: 12px;
  --r-lg: 16px;
  --r-xl: 20px;
}

*, *::before, *::after { box-sizing:border-box; margin:0; padding:0 }
html { scroll-behavior:smooth }
body {
  background:var(--bg);
  color:var(--text);
  font-family:var(--font);
  min-height:100vh;
  overflow-x:hidden;
  line-height:1.6;
}

body::before {
  content:'';position:fixed;inset:0;pointer-events:none;z-index:0;
  background-image:radial-gradient(circle, #1e2440 1px, transparent 1px);
  background-size:28px 28px;
  opacity:.4;
}

.glow-orb {
  position:fixed;top:-200px;left:50%;transform:translateX(-50%);
  width:min(1000px, 100vw);height:700px;
  background:radial-gradient(ellipse at 50% 10%, rgba(124,58,255,.18) 0%, rgba(79,142,247,.08) 40%, transparent 70%);
  pointer-events:none;z-index:0;
}

.container { max-width:1080px;margin:0 auto;padding:0 1.25rem }
.grad-text { background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent; }
.eyebrow {
  font-family:var(--mono);font-size:.7rem;font-weight:600;letter-spacing:.14em;
  color:var(--purple);text-transform:uppercase;margin-bottom:.75rem;
  display:flex;align-items:center;gap:.5rem;
}
.eyebrow::before {
  content:'';display:inline-block;width:18px;height:2px;
  background:var(--grad);border-radius:2px;flex-shrink:0;
}
.section-title {
  font-family:var(--display);font-size:clamp(1.6rem,3.5vw,2.6rem);
  font-weight:800;letter-spacing:-1.5px;line-height:1.1;margin-bottom:1rem;
}
.section-sub { color:var(--text2);font-size:.97rem;max-width:520px;line-height:1.8 }
.divider { border:none;border-top:1px solid var(--border);margin:0 }

/* BUTTONS */
.btn {
  display:inline-flex;align-items:center;justify-content:center;gap:.4rem;
  padding:.5rem 1.15rem;border-radius:var(--r-sm);
  font-size:.85rem;font-weight:600;text-decoration:none;
  border:none;cursor:pointer;transition:all .15s;font-family:var(--font);
  letter-spacing:.01em;white-space:nowrap;
}
.btn-ghost { background:transparent;border:1px solid var(--border3);color:var(--text2); }
.btn-ghost:hover { border-color:var(--purple);color:var(--purple) }
.btn-solid { background:var(--grad);color:#fff;box-shadow:0 0 20px rgba(124,58,255,.35); }
.btn-solid:hover { box-shadow:0 0 30px rgba(124,58,255,.55);opacity:.92 }
.btn-lg { padding:.65rem 1.5rem;font-size:.95rem }
.btn-sm { padding:.35rem .85rem;font-size:.78rem }
.btn-outline-green { background:transparent;border:1px solid var(--green);color:var(--green); }
.btn-outline-green:hover { background:rgba(34,197,94,.1) }

/* LIVE DOT */
.live-dot {
  width:6px;height:6px;border-radius:50%;background:var(--green);
  display:inline-block;animation:blink 2s infinite;
  box-shadow:0 0 6px var(--green);flex-shrink:0;
}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.25}}

/* NAV */
nav {
  position:fixed;top:0;left:0;right:0;z-index:200;
  background:rgba(6,7,15,.88);backdrop-filter:blur(24px);
  border-bottom:1px solid var(--border2);
  height:60px;
  display:flex;align-items:center;
  padding:0 1.25rem;
  gap:1.5rem;
}
.nav-logo { display:flex;align-items:center;gap:.6rem;text-decoration:none;flex-shrink:0; }
.nav-logo img { height:28px;width:auto }
.nav-logo-text {
  font-family:var(--display);font-weight:800;font-size:1.05rem;
  background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;
  letter-spacing:-.5px;
}
.nav-links { display:flex;gap:.1rem;flex:1;margin-left:.25rem }
.nav-links a {
  color:var(--muted);text-decoration:none;font-size:.82rem;font-weight:500;
  padding:.4rem .7rem;border-radius:6px;transition:.15s;
}
.nav-links a:hover { color:var(--text);background:var(--bg3) }
.nav-right { display:flex;gap:.5rem;margin-left:auto;align-items:center;flex-shrink:0 }

.hamburger {
  display:none;flex-direction:column;gap:4px;cursor:pointer;
  padding:.4rem;border-radius:6px;border:none;background:transparent;
  margin-left:auto;
}
.hamburger span { display:block;width:20px;height:2px;background:var(--text2);border-radius:2px;transition:.25s; }
.hamburger.open span:nth-child(1){transform:translateY(6px) rotate(45deg)}
.hamburger.open span:nth-child(2){opacity:0;transform:scaleX(0)}
.hamburger.open span:nth-child(3){transform:translateY(-6px) rotate(-45deg)}
.mobile-menu {
  display:none;position:fixed;top:60px;left:0;right:0;z-index:199;
  background:rgba(6,7,15,.97);backdrop-filter:blur(24px);
  border-bottom:1px solid var(--border2);
  padding:1rem 1.25rem 1.5rem;
  flex-direction:column;gap:.5rem;
}
.mobile-menu.open { display:flex }
.mobile-menu a {
  color:var(--text2);text-decoration:none;font-size:.95rem;font-weight:500;
  padding:.75rem 1rem;border-radius:8px;transition:.15s;
  border:1px solid transparent;
}
.mobile-menu a:hover { color:var(--text);background:var(--bg3);border-color:var(--border2) }
.mobile-menu .m-divider { border:none;border-top:1px solid var(--border);margin:.25rem 0 }
.mobile-menu .m-btns { display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.25rem }

/* TICKER */
.ticker {
  background:var(--bg2);border-bottom:1px solid var(--border);
  padding:.45rem 1.25rem;font-size:.73rem;color:var(--muted);
  display:flex;gap:1.5rem;align-items:center;
  overflow-x:auto;white-space:nowrap;margin-top:60px;
  position:relative;z-index:1;
  scrollbar-width:none;
}
.ticker::-webkit-scrollbar{display:none}
.ticker strong { color:var(--text2);font-weight:600 }
.ticker-sep { color:var(--border3);flex-shrink:0 }

/* GEO BANNER */
.geo-banner {
  display:none;background:rgba(124,58,255,.08);
  border-bottom:1px solid rgba(124,58,255,.2);
  padding:.5rem 1.25rem;font-size:.75rem;color:var(--text2);
  text-align:center;position:relative;z-index:1;
}
.geo-banner.visible { display:block }

/* HERO */
.hero {
  display:flex;align-items:center;justify-content:center;
  text-align:center;padding:3.5rem 1.25rem 4rem;
  position:relative;z-index:1;
}
.hero-inner { max-width:900px;width:100% }
.hero-badge {
  display:inline-flex;align-items:center;gap:.5rem;
  padding:.35rem 1rem;border-radius:99px;
  background:rgba(124,58,255,.1);border:1px solid rgba(124,58,255,.3);
  color:var(--neon);font-size:.72rem;font-weight:600;
  margin-bottom:1.5rem;letter-spacing:.06em;font-family:var(--mono);
  text-transform:uppercase;
}
.hero h1 {
  font-family:var(--display);
  font-size:clamp(2rem,5.5vw,3.6rem);
  font-weight:800;letter-spacing:-2px;line-height:1.05;
  margin:0 auto 1.1rem;
}
.hero-sub {
  font-size:clamp(.92rem,1.8vw,1.05rem);color:var(--text2);max-width:600px;
  margin:0 auto 2rem;line-height:1.75;font-weight:400;
}

.din-label {
  display:inline-block;
  font-family:var(--mono);font-size:.65rem;font-weight:600;
  letter-spacing:.16em;text-transform:uppercase;
  background:rgba(79,142,247,.12);border:1px solid rgba(79,142,247,.25);
  color:var(--blue);padding:.2rem .6rem;border-radius:4px;
  margin-left:.45rem;vertical-align:middle;
}

/* stat bar */
.hero-stats {
  display:inline-flex;flex-wrap:wrap;
  border:1px solid var(--border2);border-radius:var(--r-lg);
  overflow:hidden;background:var(--bg2);
  box-shadow:0 0 40px rgba(124,58,255,.1);
  width:100%;max-width:640px;
  margin:0 auto;
}
.hero-stat {
  flex:1;min-width:120px;
  padding:.9rem 1.25rem;text-align:center;
  border-right:1px solid var(--border2);
  border-bottom:1px solid var(--border2);
}
.hero-stat:last-child { border-right:none }
.hero-stat strong {
  display:block;font-family:var(--mono);font-size:1.35rem;font-weight:600;
  letter-spacing:-1px;background:var(--grad);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
}
.hero-stat span {
  font-size:.65rem;color:var(--muted);letter-spacing:.07em;
  text-transform:uppercase;margin-top:.12rem;display:block;
}

/* HERO PROBLEM BANNER */
.hero-problem {
  display:inline-flex;align-items:center;gap:.5rem;
  background:rgba(249,115,22,.08);border:1px solid rgba(249,115,22,.25);
  color:var(--orange);font-size:.78rem;font-weight:600;
  padding:.3rem .9rem;border-radius:99px;margin-bottom:1.1rem;font-family:var(--mono);
}

/* HERO-EMBEDDED DEMO CHAT */
.hero-demo-wrap { max-width:680px;margin:0 auto 2rem; }
.hero-video-wrap { max-width:720px;margin:0 auto 2rem; }
.hero-video-frame {
  position:relative;width:100%;padding-top:56.25%;
  border-radius:14px;overflow:hidden;
  border:1px solid var(--border);
  box-shadow:0 20px 60px -20px rgba(0,0,0,.5);
}
.hero-video-frame iframe {
  position:absolute;inset:0;width:100%;height:100%;border:0;
}
.hero-demo-tag {
  display:flex;align-items:center;justify-content:center;gap:.5rem;
  font-family:var(--mono);font-size:.68rem;color:var(--green);
  text-transform:uppercase;letter-spacing:.08em;margin-bottom:.75rem;
}
.hero-secondary-link {
  margin-top:1.1rem;font-size:.8rem;color:var(--muted);
}
.hero-secondary-link a { color:var(--accent2);text-decoration:none;font-weight:600 }
.hero-secondary-link a:hover { text-decoration:underline }

/* WHAT IS DIN */
.din-section { padding:5rem 1.25rem;position:relative;z-index:1;background:var(--bg2); }
.din-grid {
  display:grid;grid-template-columns:1fr 1fr;gap:4rem;align-items:start;
  margin-top:2.5rem;
}
@media(max-width:720px){.din-grid{grid-template-columns:1fr;gap:2rem}}
.din-compare { display:flex;flex-direction:column;gap:.5rem; }
.din-row { display:grid;grid-template-columns:1fr 1fr;gap:.5rem; }
.din-cell {
  background:var(--bg3);border:1px solid var(--border2);border-radius:var(--r-md);
  padding:1rem 1.1rem;font-size:.83rem;
}
.din-cell.old { border-top:2px solid var(--red) }
.din-cell.new { border-top:2px solid var(--green) }
.din-cell .label {
  font-family:var(--mono);font-size:.62rem;font-weight:600;letter-spacing:.1em;
  text-transform:uppercase;margin-bottom:.4rem;
}
.din-cell.old .label { color:var(--red) }
.din-cell.new .label { color:var(--green) }
.din-cell p { color:var(--text2);line-height:1.5 }

/* WHO IS IT FOR */
.audience-section { padding:5rem 1.25rem;position:relative;z-index:1; }
.audience-grid {
  display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));
  gap:1.25rem;margin-top:2.5rem;
}
.audience-card {
  background:var(--bg2);border:1px solid var(--border2);border-radius:var(--r-xl);
  padding:1.75rem;transition:.2s;position:relative;overflow:hidden;
}
.audience-card::after {
  content:'';position:absolute;top:0;left:0;right:0;height:2px;
  background:var(--grad);opacity:0;transition:.2s;
}
.audience-card:hover { border-color:var(--border3);transform:translateY(-3px) }
.audience-card:hover::after { opacity:1 }
.aud-tag {
  font-family:var(--mono);font-size:.62rem;font-weight:600;letter-spacing:.1em;
  text-transform:uppercase;color:var(--muted);margin-bottom:.65rem;
  display:flex;align-items:center;gap:.4rem;
}
.aud-tag::before {
  content:'';width:8px;height:8px;border-radius:50%;background:var(--purple);
  display:inline-block;flex-shrink:0;
}
.audience-card h3 { font-family:var(--display);font-size:1rem;font-weight:700;margin-bottom:.5rem;letter-spacing:-.3px; }
.audience-card p { font-size:.84rem;color:var(--text2);line-height:1.7 }
.use-cases { display:flex;flex-wrap:wrap;gap:.35rem;margin-top:.9rem; }
.use-case {
  font-size:.7rem;font-family:var(--mono);font-weight:500;
  background:var(--bg3);border:1px solid var(--border);
  padding:.2rem .65rem;border-radius:99px;color:var(--text2);
}

/* FEATURES */
.features-section { padding:5rem 1.25rem;position:relative;z-index:1;background:var(--bg2); }
.feat-grid {
  display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));
  gap:1px;margin-top:2.5rem;
  border:1px solid var(--border2);border-radius:var(--r-xl);overflow:hidden;
  background:var(--border2);
  box-shadow:0 0 60px rgba(124,58,255,.08);
}
.feat-card {
  background:var(--bg2);padding:1.75rem;transition:.2s;position:relative;overflow:hidden;
}
.feat-card::before {
  content:'';position:absolute;top:0;left:0;right:0;height:1px;
  background:linear-gradient(90deg,transparent,rgba(124,58,255,.4),transparent);
  opacity:0;transition:.2s;
}
.feat-card:hover { background:var(--bg3) }
.feat-card:hover::before { opacity:1 }
.feat-icon {
  display:flex;
  align-items:center;
  justify-content:center;
  margin-bottom:.85rem;
  width:48px;height:48px;
  border-radius:12px;
  background:rgba(124,58,255,.1);
  border:1px solid rgba(124,58,255,.2);
  flex-shrink:0;
  color:var(--purple);
  font-size:22px;
}
.feat-card h3 { font-family:var(--display);font-size:.92rem;font-weight:700;margin-bottom:.4rem;letter-spacing:-.2px }
.feat-card p { font-size:.83rem;color:var(--text2);line-height:1.7 }

/* HOW IT WORKS */
.hiw-section { padding:5rem 1.25rem;position:relative;z-index:1 }
.steps-row {
  display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));
  gap:1.25rem;margin-top:2.5rem;
}
.step {
  padding:1.6rem;background:var(--bg2);
  border:1px solid var(--border2);border-radius:var(--r-lg);
  position:relative;overflow:hidden;transition:.2s;
}
.step:hover { border-color:var(--purple);transform:translateY(-2px) }
.step-num {
  font-family:var(--mono);font-size:2.2rem;font-weight:600;
  background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;
  line-height:1;margin-bottom:.8rem;letter-spacing:-2px;
}
.step h3 { font-family:var(--display);font-size:.9rem;font-weight:700;margin-bottom:.4rem }
.step p { font-size:.81rem;color:var(--text2);line-height:1.7 }

/* DEMO (shared styles used by both hero-embedded + anchor section) */
.demo-section { padding:5rem 1.25rem;background:var(--bg2);position:relative;z-index:1 }
.demo-wrap { max-width:680px;margin:0 auto; }
.demo-box {
  background:var(--bg3);border:1px solid var(--border2);border-radius:var(--r-xl);
  overflow:hidden;box-shadow:0 0 60px rgba(124,58,255,.12);
  text-align:left;
}
.demo-header {
  padding:.85rem 1.25rem;border-bottom:1px solid var(--border);
  display:flex;align-items:center;justify-content:space-between;gap:.75rem;
}
.demo-hd-left { display:flex;align-items:center;gap:.65rem;min-width:0 }
.demo-hd-left strong { font-size:.88rem;font-weight:600;font-family:var(--display) }
.demo-hd-left .sub { font-size:.72rem;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis }
.demo-pill {
  background:var(--bg2);border:1px solid var(--border2);border-radius:99px;
  padding:.2rem .85rem;font-size:.7rem;font-weight:600;color:var(--green);
  font-family:var(--mono);white-space:nowrap;flex-shrink:0;
}
.demo-msgs {
  height:300px;overflow-y:auto;padding:1.1rem 1.25rem;
  display:flex;flex-direction:column;gap:.85rem;
}
.demo-ai   { align-self:flex-start;max-width:85% }
.demo-user { align-self:flex-end;max-width:85% }
.demo-bubble { padding:10px 14px;border-radius:12px;font-size:.86rem;line-height:1.65; }
.demo-bubble-ai { background:var(--bg2);border:1px solid var(--border);border-bottom-left-radius:3px; }
.demo-bubble-user { background:rgba(124,58,255,.12);border:1px solid rgba(124,58,255,.25);border-bottom-right-radius:3px; }
.demo-meta { font-size:.62rem;color:var(--muted);margin-top:.35rem;font-family:var(--mono) }
.demo-input-area { padding:.85rem 1.1rem;border-top:1px solid var(--border) }
.demo-input-row {
  display:flex;align-items:flex-end;gap:.5rem;
  background:var(--bg2);border:1px solid var(--border2);border-radius:10px;
  padding:.5rem .6rem .5rem .85rem;transition:.15s;
}
.demo-input-row:focus-within { border-color:var(--purple) }
.demo-input-row textarea {
  flex:1;background:transparent;border:none;outline:none;
  color:var(--text);font-size:.86rem;font-family:var(--font);
  resize:none;line-height:1.5;max-height:100px;overflow-y:auto;
}
.demo-input-row textarea::placeholder { color:var(--muted) }
.demo-send {
  background:var(--grad);border:none;border-radius:7px;color:#fff;
  width:32px;height:32px;display:flex;align-items:center;justify-content:center;
  cursor:pointer;flex-shrink:0;transition:.15s;
  box-shadow:0 0 12px rgba(124,58,255,.4);
  font-size:16px;
}
.demo-send:hover { opacity:.85 }
.demo-send:disabled { background:var(--bg4);box-shadow:none;cursor:not-allowed;color:var(--muted) }
.demo-status { font-size:.67rem;color:var(--muted);margin-top:.4rem;text-align:center;font-family:var(--mono) }
.demo-wall { display:none;padding:2.5rem 1.5rem;text-align:center }
.demo-wall .wall-icon { font-size:2.5rem;margin-bottom:.75rem;display:block }
.demo-wall h3 { font-family:var(--display);font-size:1.2rem;font-weight:800;margin-bottom:.5rem;letter-spacing:-.5px }
.demo-wall p { color:var(--text2);font-size:.87rem;margin-bottom:1.5rem;line-height:1.7;max-width:340px;margin-left:auto;margin-right:auto }
.demo-wall-btns { display:flex;gap:.65rem;justify-content:center;flex-wrap:wrap }
.typing span {
  display:inline-block;width:5px;height:5px;border-radius:50%;
  background:var(--muted);animation:ty 1.2s infinite;margin:0 2px;
}
.typing span:nth-child(2){animation-delay:.2s}.typing span:nth-child(3){animation-delay:.4s}
@keyframes ty{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-6px)}}

/* PRICING */
.pricing-section { padding:5rem 1.25rem;position:relative;z-index:1 }
.pricing-note {
  background:rgba(79,142,247,.08);border:1px solid rgba(79,142,247,.2);
  border-radius:var(--r-md);padding:.75rem 1.25rem;margin-bottom:2rem;
  font-size:.82rem;color:var(--text2);display:flex;align-items:center;gap:.65rem;
}
.plans {
  display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));
  gap:1.25rem;
}
.plan {
  background:var(--bg2);border:1px solid var(--border2);
  border-radius:var(--r-xl);padding:1.75rem;position:relative;transition:.2s;
}
.plan:hover { border-color:var(--border3);transform:translateY(-2px) }
.plan.featured { border-color:var(--purple);background:var(--bg3);box-shadow:0 0 40px rgba(124,58,255,.15); }
.plan-badge {
  position:absolute;top:-12px;left:1.5rem;
  background:var(--grad);color:#fff;
  font-size:.63rem;font-weight:700;font-family:var(--mono);
  padding:.22rem .75rem;border-radius:99px;letter-spacing:.06em;text-transform:uppercase;
}
.plan-tier { font-family:var(--mono);font-size:.65rem;font-weight:600;letter-spacing:.12em;color:var(--muted);text-transform:uppercase;margin-bottom:.7rem; }
.plan-price { font-family:var(--display);font-size:2.6rem;font-weight:800;letter-spacing:-2px;line-height:1;margin-bottom:.15rem; }
.plan-price sup { font-size:1.2rem;font-weight:600;vertical-align:top;margin-top:.35rem;display:inline-block }
.plan-price sub { font-size:.85rem;font-weight:400;color:var(--muted);letter-spacing:0 }
.plan-crypto { font-size:.72rem;color:var(--muted);font-family:var(--mono);margin-bottom:.5rem; }
.plan-credits { font-size:.78rem;color:var(--green);margin-bottom:1.35rem;font-weight:500 }
.plan-feats { list-style:none;display:flex;flex-direction:column;gap:.5rem;margin-bottom:1.75rem }
.plan-feats li { font-size:.82rem;color:var(--text2);display:flex;align-items:flex-start;gap:.55rem;line-height:1.5; }
.plan-feats li::before { content:'&#8250;';color:var(--purple);font-weight:700;flex-shrink:0;font-family:var(--mono); }
.plan.featured .plan-feats li::before { content:'\2713';color:var(--blue) }
.plan-btn { display:block;text-align:center }
.pricing-footer { text-align:center;color:var(--muted);font-size:.77rem;margin-top:1.5rem;font-family:var(--mono);line-height:1.8; }

/* NODES SECTION */
.nodes-section { padding:5rem 1.25rem;background:var(--bg2);position:relative;z-index:1 }
.node-split {
  display:grid;grid-template-columns:1fr 1fr;gap:4rem;align-items:start;margin-top:2.5rem;
}
@media(max-width:760px){.node-split{grid-template-columns:1fr;gap:2rem}}
.earn-grid { display:grid;grid-template-columns:1fr 1fr;gap:.7rem }
.earn-card {
  background:var(--bg2);border:1px solid var(--border2);border-radius:var(--r-md);padding:1.2rem;
  transition:.2s;
}
.earn-card:hover { border-color:var(--purple) }
.earn-card span { font-family:var(--mono);font-size:.62rem;color:var(--muted);display:block;margin-bottom:.35rem;text-transform:uppercase;letter-spacing:.07em; }
.earn-card strong {
  font-family:var(--display);font-size:1.4rem;font-weight:800;letter-spacing:-.5px;
  background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;
}
.node-reqs { margin-top:1.5rem;display:flex;flex-direction:column;gap:.5rem; }
.node-req {
  display:flex;align-items:center;gap:.75rem;
  background:var(--bg3);border:1px solid var(--border);border-radius:8px;
  padding:.65rem .9rem;font-size:.82rem;color:var(--text2);
}
.node-req i { flex-shrink:0;font-size:18px; }

/* DIN EXPLAINER CALLOUT */
.din-callout {
  background:rgba(124,58,255,.06);
  border:1px solid rgba(124,58,255,.2);
  border-radius:var(--r-xl);
  padding:2rem 2.25rem;
  margin-top:3rem;
  display:grid;
  grid-template-columns:auto 1fr;
  gap:1.5rem;
  align-items:start;
}
@media(max-width:580px){.din-callout{grid-template-columns:1fr;padding:1.5rem}}
.din-callout .icon-big {
  display:flex;align-items:center;justify-content:center;
  width:48px;height:48px;border-radius:12px;
  background:rgba(124,58,255,.12);border:1px solid rgba(124,58,255,.2);
  font-size:22px;color:var(--purple);flex-shrink:0;
}
.din-callout .icon-big.gold { background:rgba(245,158,11,.12);border-color:rgba(245,158,11,.2);color:var(--gold); }
.din-callout h3 { font-family:var(--display);font-size:1.05rem;font-weight:800;letter-spacing:-.3px;margin-bottom:.5rem; }
.din-callout p { font-size:.87rem;color:var(--text2);line-height:1.75 }

/* FAQ (NEW — SEO) */
.faq-section { padding:5rem 1.25rem;position:relative;z-index:1; }
.faq-list { margin-top:2.5rem;display:flex;flex-direction:column;gap:.75rem; }
.faq-item {
  background:var(--bg2);border:1px solid var(--border2);border-radius:var(--r-lg);
  overflow:hidden;
}
.faq-q {
  width:100%;text-align:left;background:none;border:none;cursor:pointer;
  padding:1.1rem 1.4rem;display:flex;align-items:center;justify-content:space-between;
  gap:1rem;color:var(--text);font-family:var(--display);font-weight:700;font-size:.92rem;
}
.faq-q i { color:var(--purple);transition:.2s;flex-shrink:0 }
.faq-item.open .faq-q i { transform:rotate(45deg) }
.faq-a { max-height:0;overflow:hidden;transition:max-height .25s ease; }
.faq-item.open .faq-a { max-height:300px }
.faq-a p { padding:0 1.4rem 1.25rem;color:var(--text2);font-size:.85rem;line-height:1.8 }

/* CTA */
.cta-section {
  text-align:center;background:var(--bg2);padding:5rem 1.25rem;
  border-top:1px solid var(--border);border-bottom:1px solid var(--border);
  position:relative;overflow:hidden;z-index:1;
}
.cta-section::before {
  content:'';position:absolute;top:-150px;left:50%;transform:translateX(-50%);
  width:min(700px,100vw);height:400px;
  background:radial-gradient(ellipse,rgba(124,58,255,.14),transparent 65%);
  pointer-events:none;
}
.cta-btns { display:flex;gap:.75rem;justify-content:center;flex-wrap:wrap;margin-top:2rem }

/* FOOTER */
footer {
  background:var(--bg2);border-top:1px solid var(--border);
  padding:1.75rem 1.25rem;
  display:flex;align-items:center;justify-content:space-between;
  flex-wrap:wrap;gap:1rem;position:relative;z-index:1;
}
.foot-logo { display:flex;align-items:center;gap:.5rem;font-family:var(--display);font-weight:800;font-size:.92rem; }
.foot-logo img { height:22px;width:auto }
.foot-logo span { background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent; }
.foot-links { display:flex;gap:1.25rem;flex-wrap:wrap }
.foot-links a { color:var(--muted);text-decoration:none;font-size:.8rem;transition:.15s }
.foot-links a:hover { color:var(--text) }
.foot-copy { color:var(--muted);font-size:.76rem;font-family:var(--mono) }

::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--border3);border-radius:4px}

/* SCROLL REVEAL */
.reveal { opacity:0;transform:translateY(22px);transition:opacity .6s ease, transform .6s ease; }
.reveal.visible { opacity:1;transform:none }

/* FLOW DIAGRAM */
.flow-diagram { display:flex;flex-direction:column;gap:1.5rem;margin-top:2rem }
.flow-nodes { display:flex;align-items:center;justify-content:center;gap:.5rem;flex-wrap:wrap; }
.flow-node {
  display:flex;flex-direction:column;align-items:center;gap:.4rem;cursor:pointer;
  padding:.75rem 1rem;border-radius:var(--r-md);border:1px solid var(--border2);
  background:var(--bg2);transition:.2s;min-width:80px;
}
.flow-node:hover { border-color:var(--purple);transform:translateY(-2px) }
.flow-node.active { border-color:var(--purple);background:rgba(124,58,255,.1);box-shadow:0 0 20px rgba(124,58,255,.2) }
.flow-node-icon {
  width:40px;height:40px;border-radius:10px;background:var(--bg3);border:1px solid var(--border2);
  display:flex;align-items:center;justify-content:center;color:var(--text2);font-size:20px;
}
.flow-node.active .flow-node-icon { background:rgba(124,58,255,.15);border-color:rgba(124,58,255,.3);color:var(--purple) }
.flow-node-label { font-family:var(--mono);font-size:.62rem;font-weight:600;letter-spacing:.08em;color:var(--muted);text-transform:uppercase }
.flow-node.active .flow-node-label { color:var(--purple) }
.flow-arrow { color:var(--border3);display:flex;align-items:center;position:relative }
.flow-arrow.active { color:var(--purple) }
.flow-panels { position:relative;min-height:160px }
.flow-panel { display:none;background:var(--bg2);border:1px solid var(--border2);border-radius:var(--r-xl);padding:1.75rem;position:relative }
.flow-panel.active { display:block;animation:fadeSlide .3s ease }
@keyframes fadeSlide { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:none} }
.flow-panel-num { font-family:var(--mono);font-size:.65rem;font-weight:700;letter-spacing:.12em;color:var(--purple);text-transform:uppercase;margin-bottom:.5rem }
.flow-panel h3 { font-family:var(--display);font-size:1.05rem;font-weight:800;margin-bottom:.5rem;letter-spacing:-.3px }
.flow-panel p { color:var(--text2);font-size:.87rem;line-height:1.7 }
.flow-tag { display:inline-flex;align-items:center;gap:.3rem;margin-top:.85rem;font-family:var(--mono);font-size:.67rem;color:var(--green);background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.2);padding:.2rem .65rem;border-radius:99px }
.flow-progress-wrap { height:3px;background:var(--border);border-radius:99px;margin-top:1.25rem;overflow:hidden }
.flow-progress-bar { height:100%;width:0%;background:var(--grad);border-radius:99px;transition:width .1s linear }

/* GPU CALC */
.gpu-calc select:focus { outline:none;border-color:var(--purple) }

/* MOBILE RESPONSIVE */
@media(max-width:820px){
  .nav-links { display:none }
  .hamburger { display:flex }
  .nav-right { display:none }
  .hero h1 { letter-spacing:-1.5px }
  .hero-stat { min-width:50%;border-bottom:1px solid var(--border2) }
  .hero-stat:nth-last-child(-n+2) { border-bottom:none }
}
@media(max-width:480px){
  .hero { padding:3rem 1rem 3rem }
  .hero h1 { font-size:1.9rem;letter-spacing:-1px }
  .hero-stats { width:100% }
  .hero-stat { min-width:50% }
  .earn-grid { grid-template-columns:1fr }
  .din-row { grid-template-columns:1fr }
  footer { flex-direction:column;text-align:center }
  .foot-links { justify-content:center }
  .plans { grid-template-columns:1fr }
  .steps-row { grid-template-columns:1fr 1fr }
  .demo-msgs { height:260px }
}
@media(max-width:360px){
  .steps-row { grid-template-columns:1fr }
}

/* FOOTER GRID RESPONSIVE */
@media(max-width:768px) {
  .footer-grid { grid-template-columns:1fr 1fr !important }
}
@media(max-width:480px) {
  .footer-grid { grid-template-columns:1fr !important }
  .flow-nodes { gap:.25rem }
  .flow-node { min-width:60px;padding:.5rem .6rem }
  .flow-arrow svg { width:20px }
}
</style>
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NC3T6B56"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="glow-orb"></div>

<!-- NAV -->
<nav>
  <a class="nav-logo" href="/">
    <img src="ChatGPT_Image_Jun_2,_2026,_06_42_49_AM.png" alt="ChainMind &mdash; Decentralized AI Network logo">
    <span class="nav-logo-text">ChainMind</span>
  </a>
  <div class="nav-links">
    <a href="#what-is-din">What is a DIN?</a>
    <a href="#who-its-for">Who's it for</a>
    <a href="#demo">Try it</a>
    <a href="#pricing">Pricing</a>
    <a href="#nodes">Earn</a>
    <a href="#faq">FAQ</a>
    <a href="/docs.php">Docs</a>
    <a href="/blog/">Blog</a>
  </div>
  <div class="nav-right">
    <?php if($logged_in): ?>
      <?php if($is_admin): ?><a class="btn btn-ghost btn-sm" href="/admin/">Admin</a><?php endif; ?>
      <a class="btn btn-solid" href="/dashboard/">Dashboard</a>
    <?php else: ?>
      <a class="btn btn-ghost" href="/auth/login.php">Sign in</a>
      <a class="btn btn-solid" href="/auth/register.php">Get started free</a>
    <?php endif; ?>
  </div>
  <button class="hamburger" id="hamburger" onclick="toggleMenu()" aria-label="Menu">
    <span></span><span></span><span></span>
  </button>
</nav>

<!-- MOBILE MENU -->
<div class="mobile-menu" id="mobileMenu">
  <a href="#what-is-din" onclick="closeMenu()">What is a DIN?</a>
  <a href="#who-its-for" onclick="closeMenu()">Who's it for</a>
  <a href="#demo" onclick="closeMenu()">Try it live</a>
  <a href="#pricing" onclick="closeMenu()">Pricing</a>
  <a href="#nodes" onclick="closeMenu()">Earn as a node</a>
  <a href="#faq" onclick="closeMenu()">FAQ</a>
  <a href="/docs.php" onclick="closeMenu()">API Docs</a>
  <a href="/blog/" onclick="closeMenu()">Blog</a>
  <hr class="m-divider">
  <div class="m-btns">
    <?php if($logged_in): ?>
      <a class="btn btn-solid" href="/dashboard/">Dashboard</a>
    <?php else: ?>
      <a class="btn btn-ghost" href="/auth/login.php">Sign in</a>
      <a class="btn btn-solid" href="/auth/register.php">Get started free &rarr;</a>
    <?php endif; ?>
  </div>
</div>

<!-- TICKER -->
<div class="ticker">
  <span style="display:flex;align-items:center;gap:.35rem"><span class="live-dot"></span><strong>Network Live</strong></span>
  <span class="ticker-sep">&middot;</span>
  <span><strong id="ticker-nodes"><?=$live_nodes?></strong> nodes online</span>
  <span class="ticker-sep">&middot;</span>
  <span><strong><?=$live_jobs?></strong> jobs running</span>
  <span class="ticker-sep">&middot;</span>
  <span><strong><?=number_format($total_jobs_done)?></strong> jobs completed</span>
  <span class="ticker-sep">&middot;</span>
  <span id="ticker-price">From <?=htmlspecialchars($prices['ticker'])?></span>
</div>

<!-- GEO BANNER -->
<?php if($is_nigeria): ?>
<div class="geo-banner visible" id="geo-banner">
  &#127475;&#127468; Hey Nigeria! Prices below are in Naira. You can also pay with crypto.
  <a href="#pricing" style="color:var(--purple);font-weight:600;margin-left:.35rem">See plans &rarr;</a>
</div>
<?php elseif(!empty($country)): ?>
<div class="geo-banner visible" id="geo-banner" style="background:rgba(79,142,247,.06);border-bottom-color:rgba(79,142,247,.18)">
  &#127758; Prices shown in USD for <?=htmlspecialchars($country)?>. Pay with card or crypto.
</div>
<?php else: ?>
<div class="geo-banner" id="geo-banner"></div>
<?php endif; ?>

<!-- HERO (now contains the live demo chat directly) -->
<section class="hero" id="home">
  <div class="hero-inner">
    <div class="hero-badge">
      <span class="live-dot" style="width:7px;height:7px"></span>
      Decentralized Intelligence Network <span class="din-label">DIN</span>
    </div>

    <div class="hero-problem">
      <i class="ti ti-alert-triangle" style="font-size:14px" aria-hidden="true"></i>
      Big Tech AI costs 10&times; too much &mdash; and they own everything.
    </div>

    <h1>
      <span class="grad-text">Decentralized AI</span><br>
      that belongs to everyone.
    </h1>

    <p class="hero-sub">
      ChainMind is a decentralized AI network that routes your AI jobs to real people's computers worldwide &mdash; not giant data centers.
      <strong style="color:var(--text)">90% cheaper. No lock-in. Community-owned.</strong>
    </p>

    <!-- MOTION GRAPHIC — short explainer video -->
    <div class="hero-video-wrap">
      <div class="hero-video-frame">
        <iframe src="https://www.youtube.com/embed/Lqj7prLBeaM?rel=0"
                title="ChainMind — Decentralized AI Network"
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen></iframe>
      </div>
    </div>

    <!-- LIVE DEMO CHAT — moved into hero so visitors can try it immediately -->
    <div class="hero-demo-wrap" id="demo">
      <div class="hero-demo-tag">
        <span class="live-dot" style="width:7px;height:7px"></span>
        Talk to the network right now &mdash; no signup needed
      </div>
      <div class="demo-box">
        <div id="demo-chat-inner">
          <div class="demo-header">
            <div class="demo-hd-left">
              <span class="live-dot" style="width:8px;height:8px;flex-shrink:0"></span>
              <div>
                <strong>ChainMind Network</strong>
                <div class="sub">Community node &mdash; No cloud involved</div>
              </div>
            </div>
            <div class="demo-pill"><i class="ti ti-bolt" style="font-size:11px" aria-hidden="true"></i> Live</div>
          </div>
          <div class="demo-msgs" id="demo-messages">
            <div class="demo-ai">
              <div class="demo-bubble demo-bubble-ai">
                <p>Hey! I'm ChainMind &mdash; running on a community node somewhere in the world right now. No data center, no big tech. Just someone's computer doing useful work. Ask me anything.</p>
                <div class="demo-meta">ChainMind Network &mdash; Ready</div>
              </div>
            </div>
          </div>
          <div class="demo-input-area">
            <div class="demo-input-row">
              <textarea id="demoInput" rows="1" placeholder="Ask me anything... (Enter to send, Shift+Enter for newline)"></textarea>
              <button class="demo-send" id="demoSendBtn" onclick="demoSend()" aria-label="Send message">
                <i class="ti ti-send" aria-hidden="true"></i>
              </button>
            </div>
            <div class="demo-status" id="demoStatus">Ready &mdash; no account needed</div>
          </div>
        </div>
        <div class="demo-wall" id="demo-wall">
          <span class="wall-icon">&#128274;</span>
          <h3>Continue the conversation</h3>
          <p>Create a free account and get 30 credits &mdash; that's roughly 100,000 tokens. More than enough to get started. No card required.</p>
          <div class="demo-wall-btns">
            <a class="btn btn-solid btn-lg" href="/auth/register.php">Create free account &rarr;</a>
            <a class="btn btn-ghost btn-lg" href="/auth/login.php">Sign in</a>
          </div>
        </div>
      </div>
      <div class="hero-secondary-link">
        Want full access from the start? <a href="/auth/register.php">Sign up free &rarr;</a>
      </div>
    </div>

    <div class="hero-stats" id="hero-stats">
      <div class="hero-stat"><strong id="stat-nodes"><?=$live_nodes?></strong><span>Nodes online</span></div>
      <div class="hero-stat"><strong>300+</strong><span>AI models</span></div>
      <div class="hero-stat"><strong>~1s</strong><span>avg response</span></div>
      <div class="hero-stat" id="hero-stat-price"><strong><?=htmlspecialchars($prices['hero_min'])?></strong><span>per 1k tokens</span></div>
    </div>

    <div style="margin-top:2rem;width:100%;max-width:640px;margin-left:auto;margin-right:auto">
      <canvas id="netGraph" width="640" height="180" style="width:100%;height:auto;border-radius:12px;opacity:.8;display:block"></canvas>
    </div>
  </div>
</section>
<hr class="divider">

<!-- WHAT IS A DIN -->
<section id="what-is-din" class="din-section">
  <div class="container reveal">
    <div class="eyebrow">What is ChainMind?</div>
    <h2 class="section-title">Not a chatbot. Not a cloud service.<br>A <span class="grad-text">Decentralized AI Network.</span></h2>
    <p class="section-sub">Think of it like Uber &mdash; but instead of cars, it's compute power. Instead of rides, it's AI inference. And instead of Uber taking the cut, you keep it.</p>

    <div class="din-grid">
      <div>
        <p style="font-size:.9rem;color:var(--text2);line-height:1.85;margin-bottom:1.5rem">
          Today, every AI query you run on ChatGPT, Claude, or Gemini goes through a handful of massive data centers owned by trillion-dollar companies. They control the infrastructure, the pricing, and what questions you're even allowed to ask.
        </p>
        <p style="font-size:.9rem;color:var(--text2);line-height:1.85;margin-bottom:1.5rem">
          ChainMind is different. As a decentralized AI network, your AI job gets routed to one of thousands of community-owned compute nodes &mdash; desktops, workstations, dedicated rigs &mdash; run by real people all over the world. The job runs, the result comes back, and the node operator earns crypto.
        </p>
        <p style="font-size:.9rem;color:var(--text2);line-height:1.85">
          No AWS. No Google Cloud. No data center. Just a peer-to-peer intelligence network that anyone can use &mdash; and anyone can power.
        </p>

        <div class="din-callout">
          <div class="icon-big">
            <i class="ti ti-network" aria-hidden="true"></i>
          </div>
          <div>
            <h3>Why decentralized AI matters</h3>
            <p>When AI is centralized, it can be censored, overpriced, or shut down overnight. When it's decentralized, it belongs to everyone. ChainMind is building the infrastructure for a future where intelligence is a public utility &mdash; not a private product.</p>
          </div>
        </div>
      </div>

      <div>
        <p style="font-family:var(--mono);font-size:.68rem;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:.75rem">Centralized AI vs ChainMind</p>
        <div class="din-compare">
          <div class="din-row">
            <div class="din-cell old"><div class="label">Centralized AI</div><p>Pay $0.06/1k tokens to a big cloud</p></div>
            <div class="din-cell new"><div class="label">ChainMind</div><p>Pay $0.005/1k tokens to the network</p></div>
          </div>
          <div class="din-row">
            <div class="din-cell old"><div class="label">Centralized AI</div><p>Your data passes through their servers &mdash; always</p></div>
            <div class="din-cell new"><div class="label">ChainMind</div><p>Jobs are ephemeral. No persistent data logging by default</p></div>
          </div>
          <div class="din-row">
            <div class="din-cell old"><div class="label">Centralized AI</div><p>They can ban your account or change the model anytime</p></div>
            <div class="din-cell new"><div class="label">ChainMind</div><p>Open-source models. Network stays up as long as nodes do</p></div>
          </div>
          <div class="din-row">
            <div class="din-cell old"><div class="label">Centralized AI</div><p>Idle machines worldwide sit doing nothing</p></div>
            <div class="din-cell new"><div class="label">ChainMind</div><p>Every idle machine becomes productive infrastructure</p></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<hr class="divider">

<!-- WHO IT'S FOR -->
<section id="who-its-for" class="audience-section">
  <div class="container reveal">
    <div class="eyebrow">Who it's for</div>
    <h2 class="section-title">Builders, businesses, individuals &mdash; and the people who power it all.</h2>
    <p class="section-sub">ChainMind isn't a single product. It's decentralized AI infrastructure. Here's what that means for you specifically.</p>

    <div class="audience-grid">
      <div class="audience-card">
        <div class="aud-tag">Founders &amp; Startups</div>
        <h3>Build AI products without the AI bill</h3>
        <p>You're building something real. You don't need to hand 60% of your AI spend to OpenAI. ChainMind gives you the same API format, 90% cheaper, with no vendor lock-in.</p>
        <div class="use-cases">
          <span class="use-case">AI SaaS</span>
          <span class="use-case">Chatbots</span>
          <span class="use-case">Content tools</span>
          <span class="use-case">Automation</span>
        </div>
      </div>

      <div class="audience-card">
        <div class="aud-tag">Enterprises &amp; Teams</div>
        <h3>Deploy AI at scale without the data center</h3>
        <p>Run hundreds of thousands of AI jobs a day through a single API key. Multiple keys for different teams. Full usage logs. Pay monthly or by credit. Works with any existing codebase.</p>
        <div class="use-cases">
          <span class="use-case">API integration</span>
          <span class="use-case">Team access controls</span>
          <span class="use-case">High volume</span>
        </div>
      </div>

      <div class="audience-card">
        <div class="aud-tag">Developers</div>
        <h3>One URL swap. Infinite models.</h3>
        <p>Already using OpenAI's SDK? Change the base URL, keep your API key format. Instantly access Llama 3, Mistral, Phi-3, DeepSeek, Qwen, and 300+ open models. No new SDKs to learn.</p>
        <div class="use-cases">
          <span class="use-case">OpenAI-compatible</span>
          <span class="use-case">300+ models</span>
          <span class="use-case">Streaming</span>
          <span class="use-case">REST API</span>
        </div>
      </div>

      <div class="audience-card">
        <div class="aud-tag">Individuals &amp; Creators</div>
        <h3>AI that doesn't cost a subscription</h3>
        <p>Need AI for writing, research, coding help, or creative work? Sign up, grab 30 free credits, and use the chat interface. Pay only when you run out. No monthly fee required.</p>
        <div class="use-cases">
          <span class="use-case">Chat interface</span>
          <span class="use-case">No subscription</span>
          <span class="use-case">Pay as you go</span>
        </div>
      </div>

      <div class="audience-card">
        <div class="aud-tag">GPU / Node Operators</div>
        <h3>Your hardware earns while you sleep</h3>
        <p>Got a gaming PC with an RTX card? A server sitting idle? Download the ChainMind node app, connect to the network, and earn IQ tokens every time your GPU processes an AI job. Real money. Passive income.</p>
        <div class="use-cases">
          <span class="use-case">Earn IQ tokens</span>
          <span class="use-case">Crypto payout</span>
          <span class="use-case">Bank cashout</span>
          <span class="use-case">Runs in background</span>
        </div>
      </div>

      <div class="audience-card" style="border-color:rgba(124,58,255,.25);background:rgba(124,58,255,.04)">
        <div class="aud-tag" style="color:var(--purple)">Web3 / Crypto Native</div>
        <h3>Real utility. Real token economy.</h3>
        <p>IQ tokens aren't speculative &mdash; they represent real GPU work done. Operators earn IQ for compute provided. Users can pay with crypto. The network runs as a decentralized compute market.</p>
        <div class="use-cases">
          <span class="use-case">IQ token</span>
          <span class="use-case">Crypto payments</span>
          <span class="use-case">Real utility</span>
        </div>
      </div>
    </div>
  </div>
</section>
<hr class="divider">

<!-- FEATURES -->
<section id="features" class="features-section">
  <div class="container reveal">
    <div class="eyebrow">Platform features</div>
    <h2 class="section-title">Everything you need to run AI &mdash; nothing you don't</h2>
    <p class="section-sub">No PhD required. No servers to manage. Just an API key and a prompt.</p>

    <div class="feat-grid">
      <div class="feat-card">
        <div class="feat-icon" aria-hidden="true"><i class="ti ti-code"></i></div>
        <h3>Drop-in replacement for OpenAI</h3>
        <p>Already using GPT-4? Change one line of code &mdash; the base URL. Keep your existing app architecture. Costs 90% less with the same JSON format.</p>
      </div>
      <div class="feat-card">
        <div class="feat-icon" aria-hidden="true"><i class="ti ti-brain"></i></div>
        <h3>300+ open-source models</h3>
        <p>Llama 3, Mistral, Phi-3, DeepSeek, Qwen, Falcon and hundreds more. Nodes register which models they support. You pick one or let the network route to the best available.</p>
      </div>
      <div class="feat-card">
        <div class="feat-icon" aria-hidden="true"><i class="ti ti-key"></i></div>
        <h3>API keys with spending limits</h3>
        <p>Create separate keys per project, client, or team member. Set hard credit caps on each. Revoke instantly. Full usage breakdown by key, model, and date.</p>
      </div>
      <div class="feat-card">
        <div class="feat-icon" aria-hidden="true"><i class="ti ti-credit-card"></i></div>
        <h3>Pay your way</h3>
        <p>NGN via Paystack, USD cards via Flutterwave, or any major crypto via NOWPayments. Auto top-up keeps your balance full so you never get interrupted mid-project.</p>
      </div>
      <div class="feat-card">
        <div class="feat-icon" aria-hidden="true"><i class="ti ti-shield-check"></i></div>
        <h3>Fault-tolerant by design</h3>
        <p>No single node can take down the network. If a node drops mid-job, the job reroutes automatically to the next available machine. The DIN stays up.</p>
      </div>
      <div class="feat-card">
        <div class="feat-icon" aria-hidden="true"><i class="ti ti-layout-dashboard"></i></div>
        <h3>Full visibility dashboard</h3>
        <p>Every token, every inference, every naira or dollar. See exactly what you spent, which model you used, and how long each job took. No surprise bills.</p>
      </div>
    </div>
  </div>
</section>
<hr class="divider">

<!-- MOTION ADS TEASER -->
<style>
.ma-section-grid{display:grid;grid-template-columns:1fr 1fr;gap:2rem;align-items:start;max-width:900px;margin:2.5rem auto 0}
.ma-selects-row{display:grid;grid-template-columns:1fr 1fr;gap:.65rem}
.ma-sel{background:var(--bg3);border:1px solid var(--border2);color:var(--text);border-radius:10px;padding:.6rem .8rem;font-size:.84rem;font-family:var(--font);outline:none;width:100%}
.ma-inp{width:100%;background:var(--bg3);border:1px solid var(--border2);color:var(--text);border-radius:10px;padding:.6rem .9rem;font-size:.87rem;font-family:var(--font);outline:none;box-sizing:border-box;transition:border-color .18s}
.ma-inp:focus,.ma-sel:focus{border-color:rgba(139,60,247,.5)}
.ma-gen-btn{width:100%;padding:.75rem;background:linear-gradient(135deg,#7c3aff,#4f46e5);border:none;border-radius:11px;color:#fff;font-size:.9rem;font-weight:700;font-family:var(--font);cursor:pointer;box-shadow:0 4px 20px rgba(124,58,255,.35);transition:opacity .18s}
.ma-gen-btn:hover{opacity:.88}
@media(max-width:768px){
  .ma-section-grid{grid-template-columns:1fr;gap:1.5rem;margin-top:2rem}
  .ma-selects-row{grid-template-columns:1fr 1fr}
}
@media(max-width:480px){
  .ma-selects-row{grid-template-columns:1fr}
}
</style>
<section id="motion-ads" class="features-section" style="padding-top:0">
  <div class="container reveal">
    <div class="eyebrow">New Feature</div>
    <h2 class="section-title">AI-powered Motion Ads &mdash; for your business</h2>
    <p class="section-sub">Upload your product image, describe your brand, and let ChainMind's GPU network generate a professional motion advertisement video in minutes. No editor. No agency. No subscription.</p>

    <div class="ma-section-grid">

      <!-- Left: feature cards -->
      <div style="display:flex;flex-direction:column;gap:1.1rem">
        <div class="feat-card" style="margin:0">
          <div class="feat-icon" aria-hidden="true"><i class="ti ti-video"></i></div>
          <h3>Video ads generated by AI</h3>
          <p>Describe your product, pick a tone, and receive a motion ad video rendered by community GPU nodes on the network.</p>
        </div>
        <div class="feat-card" style="margin:0">
          <div class="feat-icon" aria-hidden="true"><i class="ti ti-upload"></i></div>
          <h3>Upload your own product image</h3>
          <p>Provide a logo or product photo. ChainMind incorporates it into the generated ad so your brand identity stays front and centre.</p>
        </div>
        <div class="feat-card" style="margin:0">
          <div class="feat-icon" aria-hidden="true"><i class="ti ti-coins"></i></div>
          <h3>Pay per generation &mdash; 50 credits</h3>
          <p>No monthly plan. Each motion ad costs 50 credits. Buy what you need, when you need it.</p>
        </div>
      </div>

      <!-- Right: interactive preview / sign-up wall -->
      <div>
        <div id="maTeaser" style="background:var(--bg2);border:1px solid var(--border2);border-radius:18px;overflow:hidden">

          <!-- Form (triggers wall on submit) -->
          <div id="maTeaserForm" style="padding:1.5rem;border-bottom:1px solid var(--border)">
            <div style="font-size:.72rem;font-weight:700;letter-spacing:.1em;color:var(--muted);text-transform:uppercase;margin-bottom:1rem">Try Motion Ads</div>
            <div style="display:flex;flex-direction:column;gap:.75rem">
              <input class="ma-inp" type="text" placeholder="Business name" maxlength="80">
              <input class="ma-inp" type="text" placeholder="Product / service" maxlength="80">
              <div class="ma-selects-row">
                <select class="ma-sel">
                  <option>Friendly</option><option>Energetic</option><option>Professional</option><option>Luxury</option>
                </select>
                <select class="ma-sel">
                  <option>15 seconds</option><option>30 seconds</option><option>60 seconds</option>
                </select>
              </div>
              <button class="ma-gen-btn" onclick="maTeaserSubmit(event)">
                Generate Motion Ad &rarr;
              </button>
            </div>
          </div>

          <!-- Sign-up wall (shown after button click) -->
          <div id="maTeaserWall" style="display:none;padding:1.75rem;flex-direction:column;align-items:center;gap:1rem;text-align:center">
            <div style="width:52px;height:52px;background:rgba(139,60,247,.12);border:1px solid rgba(139,60,247,.3);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.4rem;flex-shrink:0">🎬</div>
            <div>
              <div style="font-size:1rem;font-weight:800;letter-spacing:-.02em;margin-bottom:.4rem">Sign up to generate ads</div>
              <p style="color:var(--muted);font-size:.84rem;line-height:1.6;margin:0">Motion Ads requires a free ChainMind account. Sign up in under 30 seconds &mdash; no credit card needed.</p>
            </div>
            <div style="display:flex;gap:.75rem;flex-wrap:wrap;justify-content:center">
              <a href="/auth/register.php" style="display:inline-block;padding:.65rem 1.5rem;background:linear-gradient(135deg,#7c3aff,#4f46e5);color:#fff;border-radius:10px;font-weight:700;text-decoration:none;font-size:.88rem;box-shadow:0 4px 18px rgba(124,58,255,.35)">Create free account</a>
              <a href="/auth/login.php" style="display:inline-block;padding:.65rem 1.25rem;background:transparent;border:1px solid var(--border2);color:var(--text2);border-radius:10px;font-weight:600;text-decoration:none;font-size:.88rem">Sign in</a>
            </div>
          </div>
        </div>

        <p style="font-size:.74rem;color:var(--muted2);text-align:center;margin-top:.85rem">
          Already have an account? <a href="/dashboard/?tab=motion-ads" style="color:var(--muted);text-decoration:underline">Go to your dashboard &rarr;</a>
        </p>
      </div>
    </div>
  </div>
</section>
<hr class="divider">

<script>
function maTeaserSubmit(e) {
  e.preventDefault();
  var form = document.getElementById('maTeaserForm');
  var wall = document.getElementById('maTeaserWall');
  if (form) form.style.display = 'none';
  if (wall) { wall.style.display = 'flex'; wall.style.flexDirection = 'column'; }
}
</script>

<!-- HOW IT WORKS -->
<section id="how-it-works" class="hiw-section">
  <div class="container reveal">
    <div class="eyebrow">How it actually works</div>
    <h2 class="section-title">From prompt to answer in under a second</h2>
    <p class="section-sub">Click any step &mdash; or watch it auto-play. Four things happen every time you send a message.</p>

    <div class="flow-diagram">
      <div class="flow-nodes">
        <div class="flow-node active" onclick="selectStep(0,true)" id="fn0">
          <div class="flow-node-icon"><i class="ti ti-user" aria-hidden="true"></i></div>
          <div class="flow-node-label">You</div>
        </div>
        <div class="flow-arrow" id="fa0">
          <svg width="40" height="12" viewBox="0 0 40 12"><path d="M0 6h34M28 1l8 5-8 5" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
        </div>
        <div class="flow-node" onclick="selectStep(1,true)" id="fn1">
          <div class="flow-node-icon"><i class="ti ti-router" aria-hidden="true"></i></div>
          <div class="flow-node-label">Router</div>
        </div>
        <div class="flow-arrow" id="fa1">
          <svg width="40" height="12" viewBox="0 0 40 12"><path d="M0 6h34M28 1l8 5-8 5" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
        </div>
        <div class="flow-node" onclick="selectStep(2,true)" id="fn2">
          <div class="flow-node-icon"><i class="ti ti-cpu" aria-hidden="true"></i></div>
          <div class="flow-node-label">Node</div>
        </div>
        <div class="flow-arrow" id="fa2">
          <svg width="40" height="12" viewBox="0 0 40 12"><path d="M0 6h34M28 1l8 5-8 5" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
        </div>
        <div class="flow-node" onclick="selectStep(3,true)" id="fn3">
          <div class="flow-node-icon"><i class="ti ti-cash" aria-hidden="true"></i></div>
          <div class="flow-node-label">Payout</div>
        </div>
      </div>

      <div class="flow-panels">
        <div class="flow-panel active" id="fp0">
          <div class="flow-panel-num">01</div>
          <h3>Your prompt hits the router</h3>
          <p>Your API call or chat message arrives at ChainMind's job router. No code changes on your end &mdash; just swap the base URL and everything else stays the same.</p>
          <div class="flow-tag">&asymp;0ms &mdash; instant dispatch</div>
        </div>
        <div class="flow-panel" id="fp1">
          <div class="flow-panel-num">02</div>
          <h3>Best available node is selected</h3>
          <p>The router scans thousands of online nodes and picks the one with your model loaded, shortest queue, and best latency to you. Smart matching in milliseconds.</p>
          <div class="flow-tag">&asymp;50ms &mdash; smart routing</div>
        </div>
        <div class="flow-panel" id="fp2">
          <div class="flow-panel-num">03</div>
          <h3>A real person's computer runs the AI</h3>
          <p>Someone's desktop, workstation, or server &mdash; anywhere in the world &mdash; runs the model on their GPU. No AWS. No Google Cloud. Just real community compute.</p>
          <div class="flow-tag">&asymp;700ms &mdash; GPU inference</div>
        </div>
        <div class="flow-panel" id="fp3">
          <div class="flow-panel-num">04</div>
          <h3>Answer back. Everyone gets paid.</h3>
          <p>The result streams back to you. Your credits are deducted. The node operator earns IQ tokens instantly. No invoices, no delays, no middleman taking the cut.</p>
          <div class="flow-tag">&asymp;50ms &mdash; result &amp; reward</div>
        </div>
      </div>
    </div>

    <div class="flow-progress-wrap">
      <div class="flow-progress-bar" id="flowProgressBar"></div>
    </div>
    <p style="text-align:center;font-size:.72rem;color:var(--muted);margin-top:.4rem;font-family:var(--mono)">Auto-advancing &bull; click any step to pause</p>
  </div>
</section>
<hr class="divider">

<!-- PRICING -->
<section id="pricing" class="pricing-section">
  <div class="container reveal">
    <div class="eyebrow">Pricing</div>
    <h2 class="section-title">Pay for what you use. Nothing more.</h2>
    <p class="section-sub">Credits never expire. Buy once and use them forever. Subscribe for volume savings.</p>

    <div class="pricing-note" id="pricing-geo-note" <?= empty($prices['geo_note']) ? 'style="display:none"' : '' ?>>
      <span><?=$prices['flag']?></span>
      <span><?=htmlspecialchars($prices['geo_note'])?></span>
    </div>

    <div style="background:var(--bg2);border:1px solid var(--border2);border-radius:var(--r-lg);padding:1.25rem;margin-bottom:1.75rem;display:flex;flex-wrap:wrap;gap:.75rem;align-items:center">
      <span style="display:flex;align-items:center;gap:.4rem;font-family:var(--mono);font-size:.72rem;color:var(--muted);white-space:nowrap">
        <i class="ti ti-calculator" style="font-size:14px" aria-hidden="true"></i> How many tokens?
      </span>
      <input id="token-input" type="number" min="0" placeholder="e.g. 1000000" oninput="calcPrice()"
        style="flex:1;min-width:140px;background:var(--bg3);border:1px solid var(--border2);color:var(--text);padding:.5rem .85rem;border-radius:8px;font-size:.85rem;font-family:var(--mono)">
      <div id="calc-result" style="font-size:.82rem;color:var(--text2);flex:100%"></div>
    </div>

    <div class="plans" id="plans-container">
    <?php
    $sym  = $prices['symbol'];
    $crypto_tag = '<div class="plan-crypto"><i class="ti ti-currency-bitcoin" style="font-size:12px;vertical-align:-1px"></i> Also pay with crypto (BTC, ETH, USDT&hellip;)</div>';
    $rate_note = $is_nigeria ? '&#8358;1,400 = 1,000 credits' : '1,000 credits = $1';
    ?>

    <div class="plan">
      <div class="plan-tier">Pay as you go</div>
      <div class="plan-price"><sup><?=$sym?></sup><?=$prices['payg']?> <sub>one-time</sub></div>
      <?=$crypto_tag?>
      <div class="plan-credits">5,000 credits &asymp; 1 million tokens</div>
      <ul class="plan-feats">
        <li><?=$rate_note?></li>
        <li>Credits never expire</li>
        <li>All 300+ models included</li>
        <li>No monthly commitment</li>
      </ul>
      <a class="btn btn-ghost btn-lg plan-btn" href="/auth/register.php">Buy credits</a>
    </div>

    <div class="plan featured">
      <div class="plan-badge">MOST POPULAR</div>
      <div class="plan-tier">Pro</div>
      <div class="plan-price"><sup><?=$sym?></sup><?=$prices['pro']?> <sub>/month</sub></div>
      <?=$crypto_tag?>
      <div class="plan-credits">20,000 credits/month &mdash; saves you 25%</div>
      <ul class="plan-feats">
        <li>20k credits every month</li>
        <li>Priority job routing</li>
        <li>All models included</li>
        <li>Unused credits roll over</li>
        <li>Email support</li>
      </ul>
      <a class="btn btn-solid btn-lg plan-btn" href="/auth/register.php">Subscribe</a>
    </div>

    <div class="plan">
      <div class="plan-tier">Builder</div>
      <div class="plan-price"><sup><?=$sym?></sup><?=$prices['builder']?> <sub>/month</sub></div>
      <?=$crypto_tag?>
      <div class="plan-credits">60,000 credits/month &mdash; saves you 33%</div>
      <ul class="plan-feats">
        <li>60k credits every month</li>
        <li>Top priority queue</li>
        <li>All models included</li>
        <li>Rollover credits</li>
        <li>Dedicated support</li>
      </ul>
      <a class="btn btn-ghost btn-lg plan-btn" href="/auth/register.php">Subscribe</a>
    </div>
    </div>

    <p class="pricing-footer" id="pricing-footer">
      <?=htmlspecialchars($prices['footer'])?>
    </p>
  </div>
</section>
<hr class="divider">

<!-- NODES -->
<section id="nodes" class="nodes-section">
  <div class="container reveal">
    <div class="eyebrow">For node operators</div>
    <h2 class="section-title">Your gaming PC is sitting idle.<br>Make it <span class="grad-text">earn.</span></h2>
    <p class="section-sub">While you sleep, browse, or watch YouTube &mdash; your GPU can be processing AI jobs and earning you IQ tokens.</p>

    <div class="node-split">
      <div>
        <p style="color:var(--text2);line-height:1.85;margin-bottom:1.1rem;font-size:.9rem">
          Download the ChainMind node app. It runs quietly in your system tray, listens for jobs from the network, and processes them on your GPU. No technical setup. No coding required.
        </p>
        <p style="color:var(--text2);line-height:1.85;margin-bottom:1.1rem;font-size:.9rem">
          Every AI job you complete earns you IQ tokens. IQ is pegged at $0.01 each. Hit 10 IQ and cash out to your crypto wallet or bank account. Your PC was already on. Now it's generating income.
        </p>
        <p style="color:var(--text2);line-height:1.85;margin-bottom:1.75rem;font-size:.9rem">
          The more powerful your GPU, the faster you process, the more you earn. But even a mid-range card makes money doing nothing else.
        </p>
        <a class="btn btn-outline-green btn-lg" href="/auth/register.php?role=node">
          <i class="ti ti-server" aria-hidden="true"></i> Register as a node operator &rarr;
        </a>

        <div class="gpu-calc" style="margin-top:1.5rem">
          <div style="font-family:var(--mono);font-size:.65rem;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:.6rem;display:flex;align-items:center;gap:.4rem">
            <i class="ti ti-chart-bar" style="font-size:13px" aria-hidden="true"></i> GPU Earnings Calculator
          </div>
          <select id="gpuSelect" onchange="calcEarnings()" style="width:100%;background:var(--bg3);border:1px solid var(--border2);color:var(--text);padding:.6rem .9rem;border-radius:8px;font-size:.85rem;font-family:var(--font);margin-bottom:.75rem;cursor:pointer">
            <option value="1060">GTX 1060 (6GB)</option>
            <option value="2080">RTX 2080 (8GB)</option>
            <option value="3070">RTX 3070 (8GB)</option>
            <option value="3080" selected>RTX 3080 (10GB)</option>
            <option value="3090">RTX 3090 (24GB)</option>
            <option value="4080">RTX 4080 (16GB)</option>
            <option value="4090">RTX 4090 (24GB)</option>
            <option value="rx6700">AMD RX 6700 XT</option>
            <option value="rx7900">AMD RX 7900 XTX</option>
          </select>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:.5rem">
            <div style="background:var(--bg3);border:1px solid var(--border2);border-radius:8px;padding:.9rem;text-align:center">
              <div style="font-size:.65rem;color:var(--muted);font-family:var(--mono);text-transform:uppercase;letter-spacing:.08em;margin-bottom:.3rem">Per day</div>
              <div id="calc-day" style="font-family:var(--display);font-size:1.3rem;font-weight:800;background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent">$2.50</div>
            </div>
            <div style="background:var(--bg3);border:1px solid var(--border2);border-radius:8px;padding:.9rem;text-align:center">
              <div style="font-size:.65rem;color:var(--muted);font-family:var(--mono);text-transform:uppercase;letter-spacing:.08em;margin-bottom:.3rem">Per month</div>
              <div id="calc-month" style="font-family:var(--display);font-size:1.3rem;font-weight:800;color:var(--green)">$75</div>
            </div>
          </div>
          <div id="calc-ngn" style="text-align:center;font-size:.75rem;color:var(--muted);margin-top:.45rem;font-family:var(--mono)">&asymp; &#8358;105,000 / month at current rate</div>
          <p style="font-size:.72rem;color:var(--muted);margin-top:.5rem;line-height:1.5">* Estimates based on average network utilisation (50%). Higher during peak hours.</p>
        </div>

        <div class="node-reqs">
          <div class="node-req">
            <i class="ti ti-brand-windows" style="color:var(--blue)" aria-hidden="true"></i>
            Windows / Linux / macOS
          </div>
          <div class="node-req">
            <i class="ti ti-device-desktop-analytics" style="color:var(--purple)" aria-hidden="true"></i>
            Any NVIDIA/AMD GPU (GTX 1060+ recommended)
          </div>
          <div class="node-req">
            <i class="ti ti-wifi" style="color:var(--green)" aria-hidden="true"></i>
            Stable internet connection
          </div>
          <div class="node-req">
            <i class="ti ti-player-play" style="color:var(--muted)" aria-hidden="true"></i>
            Runs in background &mdash; no interruption to your normal use
          </div>
        </div>
      </div>

      <div>
        <div class="earn-grid">
          <div class="earn-card">
            <span>IQ per 1M tokens</span>
            <strong>1,000 IQ</strong>
          </div>
          <div class="earn-card">
            <span>IQ token value</span>
            <strong>$0.01 / IQ</strong>
          </div>
          <div class="earn-card">
            <span>Min cashout</span>
            <strong>10 IQ</strong>
          </div>
          <div class="earn-card">
            <span>Payout methods</span>
            <strong>Crypto + Bank</strong>
          </div>
        </div>

        <div class="din-callout" style="margin-top:1.25rem">
          <div class="icon-big gold">
            <i class="ti ti-coin" aria-hidden="true"></i>
          </div>
          <div>
            <h3>What could I realistically earn?</h3>
            <p style="font-size:.83rem;color:var(--text2);line-height:1.7">An RTX 3080 processing ~500k tokens/day would earn roughly <strong style="color:var(--green)">$2.50/day</strong> &mdash; $75/month passively. Higher-end GPUs and busier network hours earn more. Early operators benefit from a growing user base.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<hr class="divider">

<!-- FAQ — targets long-tail / "People Also Ask" SEO for decentralized AI + competitor terms -->
<section id="faq" class="faq-section">
  <div class="container reveal">
    <div class="eyebrow">Frequently asked</div>
    <h2 class="section-title">Decentralized AI, explained</h2>
    <p class="section-sub">The questions people search before trying a decentralized AI network like ChainMind.</p>

    <div class="faq-list">
      <div class="faq-item open">
        <button class="faq-q" onclick="toggleFaq(this)">
          What is a decentralized AI network?
          <i class="ti ti-plus" aria-hidden="true"></i>
        </button>
        <div class="faq-a">
          <p>A decentralized AI network runs AI inference across a distributed pool of independently owned computers instead of a single company's data centers. ChainMind routes jobs to community GPU nodes worldwide, and the people running those nodes get paid for the compute they provide.</p>
        </div>
      </div>
      <div class="faq-item">
        <button class="faq-q" onclick="toggleFaq(this)">
          How is ChainMind different from OpenAI or other centralized AI providers?
          <i class="ti ti-plus" aria-hidden="true"></i>
        </button>
        <div class="faq-a">
          <p>Centralized providers like OpenAI, Anthropic, or Google run inference in their own data centers and set their own pricing and policies. ChainMind routes the same kind of workloads through a decentralized network of community-owned GPUs, which usually means lower cost and no single company controlling the infrastructure.</p>
        </div>
      </div>
      <div class="faq-item">
        <button class="faq-q" onclick="toggleFaq(this)">
          Can I use ChainMind as a drop-in replacement for the OpenAI API?
          <i class="ti ti-plus" aria-hidden="true"></i>
        </button>
        <div class="faq-a">
          <p>Yes. ChainMind uses an OpenAI-compatible API format, so most applications only need to change the base URL to start routing requests through the decentralized network instead of a centralized cloud.</p>
        </div>
      </div>
      <div class="faq-item">
        <button class="faq-q" onclick="toggleFaq(this)">
          How do node operators earn money on ChainMind?
          <i class="ti ti-plus" aria-hidden="true"></i>
        </button>
        <div class="faq-a">
          <p>Node operators run the ChainMind node app in the background, which processes AI inference jobs using their GPU. Each completed job earns IQ tokens, which can be cashed out through crypto or bank transfer once a minimum balance is reached.</p>
        </div>
      </div>
      <div class="faq-item">
        <button class="faq-q" onclick="toggleFaq(this)">
          Is ChainMind free to try?
          <i class="ti ti-plus" aria-hidden="true"></i>
        </button>
        <div class="faq-a">
          <p>Yes &mdash; you can try the live AI chat right on the homepage without creating an account. New accounts also receive bonus credits to keep using the network.</p>
        </div>
      </div>
      <div class="faq-item">
        <button class="faq-q" onclick="toggleFaq(this)">
          What models can I run on a decentralized AI network like ChainMind?
          <i class="ti ti-plus" aria-hidden="true"></i>
        </button>
        <div class="faq-a">
          <p>ChainMind supports 300+ open-source models including Llama 3, Mistral, Phi-3, DeepSeek, Qwen, and Falcon. Node operators register which models their hardware supports, and the router picks the best available match for each job.</p>
        </div>
      </div>
    </div>
  </div>
</section>
<hr class="divider">

<!-- CTA -->
<section class="cta-section">
  <div class="container reveal">
    <div class="eyebrow">Get started</div>
    <h2 class="section-title" style="max-width:640px;margin:0 auto .9rem">
      First AI inference in under 5 minutes.<br>First 30 credits on us.
    </h2>
    <p class="section-sub" style="text-align:center;margin:0 auto;max-width:460px">
      Sign up, grab your API key, send your first prompt. No credit card required. Cancel nothing &mdash; there's nothing to cancel.
    </p>
    <div class="cta-btns">
      <a class="btn btn-solid btn-lg" href="/auth/register.php">
        <i class="ti ti-rocket" aria-hidden="true"></i> Create free account
      </a>
      <a class="btn btn-ghost btn-lg" href="/auth/login.php">Sign in</a>
    </div>
  </div>
</section>

<!-- FOOTER -->
<!-- ============================================================
     ChainMind — footer.php
     Include this file at the bottom of every page:
       <?php include __DIR__.'/footer.php'; ?>
     ============================================================ -->

<footer style="background:var(--bg2);border-top:1px solid var(--border);padding:3rem 1.25rem 1.5rem;position:relative;z-index:1">
  <div class="container">
    <div class="footer-grid" style="display:grid;grid-template-columns:2fr 1fr 1fr 1fr 1fr;gap:2rem;margin-bottom:2.5rem">

      <!-- Brand -->
      <div>
        <div class="foot-logo" style="margin-bottom:.75rem">
          <img src="ChatGPT_Image_Jun_2,_2026,_06_42_49_AM.png" alt="ChainMind" style="height:26px;width:auto">
          <span>ChainMind</span>
        </div>
        <p style="color:var(--muted);font-size:.8rem;line-height:1.7;max-width:220px">
          Community-owned decentralized AI infrastructure. Cheap inference for users, passive income for node operators.
        </p>
        <div style="margin-top:1rem">
          <a href="mailto:support@chainmind.com.ng" style="font-size:.75rem;color:var(--muted);text-decoration:none;display:inline-flex;align-items:center;gap:.4rem">
            <i class="ti ti-mail" style="font-size:14px" aria-hidden="true"></i>
            support@chainmind.com.ng
          </a>
        </div>
      </div>

      <!-- Product -->
      <div>
        <div style="font-family:var(--mono);font-size:.63rem;font-weight:700;letter-spacing:.12em;color:var(--muted);text-transform:uppercase;margin-bottom:.9rem">Product</div>
        <div style="display:flex;flex-direction:column;gap:.55rem">
          <a href="/auth/register.php"  class="foot-link">Get started free</a>
          <a href="/#pricing"           class="foot-link">Pricing</a>
          <a href="/#features"          class="foot-link">Features</a>
          <a href="/dashboard/"         class="foot-link">Dashboard</a>
          <a href="/chat/"              class="foot-link">AI Chat</a>
        </div>
      </div>

      <!-- Developers -->
      <div>
        <div style="font-family:var(--mono);font-size:.63rem;font-weight:700;letter-spacing:.12em;color:var(--muted);text-transform:uppercase;margin-bottom:.9rem">Developers</div>
        <div style="display:flex;flex-direction:column;gap:.55rem">
          <a href="/docs.php"                class="foot-link">API Docs</a>
          <a href="/docs.php#quickstart"     class="foot-link">Quickstart</a>
          <a href="/docs.php#openai-compat"  class="foot-link">OpenAI Compat</a>
          <a href="/docs.php#models"         class="foot-link">Models list</a>
          <a href="/docs.php#errors"         class="foot-link">Error codes</a>
        </div>
      </div>

      <!-- Node Operators -->
      <div>
        <div style="font-family:var(--mono);font-size:.63rem;font-weight:700;letter-spacing:.12em;color:var(--muted);text-transform:uppercase;margin-bottom:.9rem">Node Operators</div>
        <div style="display:flex;flex-direction:column;gap:.55rem">
          <a href="/auth/register.php?role=node"   class="foot-link">Register as operator</a>
          <a href="/#nodes"                         class="foot-link">How earning works</a>
          <a href="/dashboard/node-download.php"    class="foot-link">Download node app</a>
          <a href="/dashboard/node-earnings.php"    class="foot-link">Track earnings</a>
        </div>
      </div>

      <!-- Company -->
      <div>
        <div style="font-family:var(--mono);font-size:.63rem;font-weight:700;letter-spacing:.12em;color:var(--muted);text-transform:uppercase;margin-bottom:.9rem">Company</div>
        <div style="display:flex;flex-direction:column;gap:.55rem">
          <a href="/#what-is-din"               class="foot-link">About ChainMind</a>
          <a href="mailto:support@chainmind.com.ng" class="foot-link">Contact</a>
          <a href="/privacy.php"                class="foot-link">Privacy Policy</a>
          <a href="/terms.php"                  class="foot-link">Terms of Service</a>
          <a href="/refund.php"                 class="foot-link">Refund Policy</a>
          <a href="/aup.php"                    class="foot-link">Acceptable Use</a>
          <a href="/cookies.php"                class="foot-link">Cookie Policy</a>
        </div>
      </div>

    </div><!-- /footer-grid -->

    <div style="border-top:1px solid var(--border);padding-top:1.25rem;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.75rem">
      <div class="foot-copy">&copy; <?=date('Y')?> ChainMind &bull; chainmind.com.ng</div>
      <div style="display:flex;gap:1.25rem;align-items:center;flex-wrap:wrap">
        <a href="/privacy.php"  style="font-size:.72rem;color:var(--muted);text-decoration:none;transition:.15s" onmouseover="this.style.color='var(--text2)'" onmouseout="this.style.color='var(--muted)'">Privacy</a>
        <a href="/terms.php"    style="font-size:.72rem;color:var(--muted);text-decoration:none;transition:.15s" onmouseover="this.style.color='var(--text2)'" onmouseout="this.style.color='var(--muted)'">Terms</a>
        <a href="/refund.php"   style="font-size:.72rem;color:var(--muted);text-decoration:none;transition:.15s" onmouseover="this.style.color='var(--text2)'" onmouseout="this.style.color='var(--muted)'">Refunds</a>
        <a href="/aup.php"      style="font-size:.72rem;color:var(--muted);text-decoration:none;transition:.15s" onmouseover="this.style.color='var(--text2)'" onmouseout="this.style.color='var(--muted)'">AUP</a>
        <a href="/cookies.php"  style="font-size:.72rem;color:var(--muted);text-decoration:none;transition:.15s" onmouseover="this.style.color='var(--text2)'" onmouseout="this.style.color='var(--muted)'">Cookies</a>
        <span style="font-size:.72rem;color:var(--muted);font-family:var(--mono);display:flex;align-items:center;gap:.4rem">
          <span class="live-dot" style="width:5px;height:5px"></span>
          Network live
        </span>
      </div>
    </div>
  </div>
</footer>

<style>
.foot-link{
  color:var(--text2);
  text-decoration:none;
  font-size:.82rem;
  transition:color .15s;
}
.foot-link:hover{color:var(--text)}
</style>
<script>
/* ANIMATED NETWORK GRAPH */
(function(){
  const canvas = document.getElementById('netGraph');
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  const NODES = 22;
  const nodes = Array.from({length: NODES}, () => ({
    x: 30 + Math.random() * (W - 60),
    y: 20 + Math.random() * (H - 40),
    vx: (Math.random() - 0.5) * 0.4,
    vy: (Math.random() - 0.5) * 0.4,
    r: 3 + Math.random() * 3,
    pulse: Math.random() * Math.PI * 2,
    active: Math.random() > 0.35,
  }));
  const edges = [];
  for(let i = 0; i < nodes.length; i++) {
    for(let j = i+1; j < nodes.length; j++) {
      const dx = nodes[i].x - nodes[j].x;
      const dy = nodes[i].y - nodes[j].y;
      if(Math.sqrt(dx*dx + dy*dy) < 160) edges.push({a: i, b: j});
    }
  }
  const packets = [];
  function spawnPacket() {
    const e = edges[Math.floor(Math.random() * edges.length)];
    if(nodes[e.a].active && nodes[e.b].active)
      packets.push({ edge: edges.indexOf(e), t: 0, speed: 0.008 + Math.random() * 0.012, color: Math.random() > 0.5 ? '#7c3aff' : '#4f8ef7' });
    setTimeout(spawnPacket, packets.length < 8 ? 600 + Math.random() * 1200 : 1500 + Math.random() * 2000);
  }
  setTimeout(spawnPacket, 500);
  function draw() {
    ctx.clearRect(0, 0, W, H);
    nodes.forEach(n => {
      n.x += n.vx; n.y += n.vy;
      if(n.x < 20 || n.x > W-20) n.vx *= -1;
      if(n.y < 10 || n.y > H-10) n.vy *= -1;
      n.pulse += 0.04;
    });
    edges.forEach(e => {
      const a = nodes[e.a], b = nodes[e.b];
      ctx.strokeStyle = `rgba(124,58,255,${a.active && b.active ? 0.18 : 0.06})`;
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    });
    packets.forEach((p, i) => {
      p.t += p.speed;
      if(p.t >= 1) { packets.splice(i, 1); return; }
      const e = edges[p.edge];
      const a = nodes[e.a], b = nodes[e.b];
      const x = a.x + (b.x - a.x) * p.t, y = a.y + (b.y - a.y) * p.t;
      ctx.beginPath(); ctx.arc(x, y, 3.5, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      ctx.shadowBlur = 8; ctx.shadowColor = p.color;
      ctx.fill(); ctx.shadowBlur = 0;
    });
    nodes.forEach(n => {
      const glow = n.active ? (0.6 + 0.4 * Math.sin(n.pulse)) : 0;
      if(n.active) {
        ctx.beginPath(); ctx.arc(n.x, n.y, n.r + 5, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(124,58,255,${glow * 0.12})`; ctx.fill();
      }
      ctx.beginPath(); ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
      ctx.fillStyle = n.active ? `rgba(124,58,255,${0.7 + 0.3 * Math.sin(n.pulse)})` : 'rgba(90,96,128,0.4)';
      ctx.fill();
    });
    requestAnimationFrame(draw);
  }
  draw();
})();

/* INTERACTIVE FLOW DIAGRAM */
let flowStep = 0, flowTimer = null, flowPaused = false;
const FLOW_DURATION = 3000;
function selectStep(i, manual) {
  if(manual) { flowPaused = true; clearTimeout(flowTimer); }
  flowStep = i;
  document.querySelectorAll('.flow-node').forEach((n,j) => n.classList.toggle('active', j===i));
  document.querySelectorAll('.flow-panel').forEach((p,j) => p.classList.toggle('active', j===i));
  document.querySelectorAll('.flow-arrow').forEach((a,j) => a.classList.toggle('active', j<i));
  const bar = document.getElementById('flowProgressBar');
  if(bar) { bar.style.transition='none'; bar.style.width='0%'; setTimeout(()=>{ bar.style.transition='width '+FLOW_DURATION+'ms linear'; bar.style.width='100%'; }, 30); }
  if(manual) { flowTimer = setTimeout(()=>{ flowPaused=false; advanceFlow(); }, FLOW_DURATION + 1000); }
}
function advanceFlow() {
  if(flowPaused) return;
  flowStep = (flowStep + 1) % 4;
  selectStep(flowStep, false);
  flowTimer = setTimeout(advanceFlow, FLOW_DURATION);
}
setTimeout(() => { selectStep(0, false); flowTimer = setTimeout(advanceFlow, FLOW_DURATION); }, 1200);

/* GPU EARNINGS CALCULATOR */
const GPU_TOKENS_PER_DAY = {
  '1060':350000,'2080':700000,'3070':900000,'3080':1200000,
  '3090':1800000,'4080':2200000,'4090':3500000,'rx6700':800000,'rx7900':2000000,
};
const IQ_PER_1M = 1000, IQ_VAL = 0.01;
window.calcEarnings = function() {
  const sel = document.getElementById('gpuSelect'); if(!sel) return;
  const tpd = GPU_TOKENS_PER_DAY[sel.value] || 500000;
  const usdDay = (tpd / 1000000) * IQ_PER_1M * IQ_VAL;
  const usdMonth = usdDay * 30;
  document.getElementById('calc-day').textContent = '$' + usdDay.toFixed(2);
  document.getElementById('calc-month').textContent = '$' + Math.round(usdMonth);
  document.getElementById('calc-ngn').textContent = '\u2248 \u20a6' + Math.round(usdMonth * 1400).toLocaleString() + ' / month at current rate';
};
setTimeout(calcEarnings, 100);

/* PRICING CALCULATOR */
window.calcPrice = function() {
  const input = document.getElementById('token-input'); if(!input) return;
  const tokens = parseInt(input.value.replace(/[^0-9]/g,'')) || 0;
  const usd = (tokens / 1000) * 0.005;
  const gptUsd = (tokens / 1000) * 0.06;
  const el = document.getElementById('calc-result');
  if(el) el.innerHTML = tokens > 0
    ? `<strong style="color:var(--green)">${tokens.toLocaleString()} tokens</strong> = <strong>$${usd.toFixed(4)}</strong> on ChainMind vs <span style="color:var(--red)">$${gptUsd.toFixed(4)}</span> on OpenAI &mdash; you save <strong style="color:var(--green)">${Math.round((1-usd/gptUsd)*100)}%</strong>`
    : '';
};

/* FAQ ACCORDION */
function toggleFaq(btn){
  const item = btn.closest('.faq-item');
  const wasOpen = item.classList.contains('open');
  document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
  if(!wasOpen) item.classList.add('open');
}

/* MOBILE MENU */
function toggleMenu(){
  const h=document.getElementById('hamburger'), m=document.getElementById('mobileMenu');
  h.classList.toggle('open'); m.classList.toggle('open');
}
function closeMenu(){
  document.getElementById('hamburger').classList.remove('open');
  document.getElementById('mobileMenu').classList.remove('open');
}
document.addEventListener('click', e=>{
  const h=document.getElementById('hamburger'), m=document.getElementById('mobileMenu');
  if(h && m && !h.contains(e.target) && !m.contains(e.target)) closeMenu();
});

/* GEO */
const GEO = {
  countryCode: <?=json_encode($countryCode)?>,
  country:     <?=json_encode($country)?>,
  isNigeria:   <?=$is_nigeria ? 'true' : 'false'?>,
};

/* DEMO CHAT — limit is enforced silently, no visible countdown.
   Wall appears immediately once the limit is hit, with no prior warning. */
(function(){
  const POLL=1500, MAX_POLLS=80, MAX_FREE=3;
  let used = parseInt(sessionStorage.getItem('cm_demo')||'0');
  const $ = id => document.getElementById(id);
  const msgs=$('demo-messages'), inp=$('demoInput'), btn=$('demoSendBtn'),
        status=$('demoStatus');
  function wall(){
    const inner=$('demo-chat-inner'), w=$('demo-wall');
    if(inner) inner.style.display='none';
    if(w) w.style.display='block';
  }
  function addMsg(role, html, meta){
    const w=document.createElement('div');
    w.className=role==='user'?'demo-user':'demo-ai';
    w.innerHTML=`<div class="demo-bubble demo-bubble-${role==='user'?'user':'ai'}">${html}${meta?`<div class="demo-meta">${meta}</div>`:''}</div>`;
    msgs.appendChild(w); msgs.scrollTop=msgs.scrollHeight; return w;
  }
  function typing(){ return addMsg('ai','<div class="typing"><span></span><span></span><span></span></div>') }
  function fmt(t){
    if(!t) return '<p></p>';
    let s=t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    s=s.replace(/```[\w]*\n?([\s\S]*?)```/g,'<pre style="background:var(--bg);border:1px solid var(--border);border-radius:7px;padding:10px;overflow-x:auto;font-family:var(--mono);font-size:.78rem;margin:.4rem 0"><code>$1</code></pre>');
    s=s.replace(/`([^`]+)`/g,'<code style="background:var(--bg);padding:1px 5px;border-radius:4px;font-family:var(--mono);font-size:.82rem">$1</code>');
    s=s.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>');
    return s.split(/\n\n+/).map(p=>'<p>'+p.replace(/\n/g,'<br>')+'</p>').join('');
  }
  if(inp){
    inp.addEventListener('input',()=>{ inp.style.height='auto'; inp.style.height=Math.min(inp.scrollHeight,100)+'px' });
    inp.addEventListener('keydown',e=>{ if(e.key==='Enter'&&!e.shiftKey){ e.preventDefault(); demoSend(); } });
  }
  window.demoSend = async function(){
    if(!inp||btn.disabled) return;
    const prompt=inp.value.trim(); if(!prompt) return;
    if(used>=MAX_FREE){ wall(); return; }
    used++; sessionStorage.setItem('cm_demo',used);
    addMsg('user','<p>'+prompt.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')+'</p>');
    inp.value=''; inp.style.height='auto';
    let t=typing();
    status.textContent='Finding a node\u2026'; btn.disabled=true;
    try{
      const r=await fetch('/api/infer.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt,model:null,system:''})});
      const s=await r.json();
      if(!r.ok){
        t.remove();
        addMsg('ai','<p style="color:var(--orange)">\u26a0 '+(r.status===429?'Network busy \u2014 try again in a second.':(s.error||'Something went wrong.'))+'</p>');
        status.textContent='Error \u2014 Try again'; btn.disabled=false;
        used--; sessionStorage.setItem('cm_demo',used); return;
      }
      if(s.model_note){
        t.remove();
        addMsg('ai','<p style="color:var(--muted);font-size:.85rem">\u2139\ufe0f '+s.model_note+'</p>');
        t=typing();
      }
      status.textContent='Node is thinking\u2026'; let polls=0;
      const res=await new Promise((resolve,reject)=>{
        const ti=setInterval(async()=>{
          if(++polls>MAX_POLLS){ clearInterval(ti); reject(new Error('Node timed out. Try again.')); return; }
          try{
            const rv=await fetch('/api/job.php?id='+s.job_id);
            const d=await rv.json();
            if(d.status==='done'){ clearInterval(ti); resolve(d); }
            else if(d.status==='error'||d.status==='timeout'){ clearInterval(ti); reject(new Error(d.result||'Node hit an error.')); }
            else status.textContent=d.status==='claimed'?'Node is thinking\u2026':'Processing\u2026';
          }catch(_){}
        },POLL);
      });
      t.remove();
      const meta=[res.model?'Model: '+res.model:null,res.tokens_out?res.tokens_out+' tokens':null,res.duration_ms?(res.duration_ms/1000).toFixed(1)+'s':null].filter(Boolean).join(' \u2014 ');
      addMsg('ai',fmt(res.result),meta);
      if(used>=MAX_FREE){
        /* limit reached — show the wall now, immediately, no advance warning */
        inp.disabled=true; btn.disabled=true;
        status.textContent='';
        wall();
      } else {
        status.textContent='Ready';
        btn.disabled=false;
      }
    }catch(e){
      t.remove();
      addMsg('ai','<p style="color:var(--orange)">\u26a0 '+e.message+'</p>');
      status.textContent='Error \u2014 try again';
      used--; sessionStorage.setItem('cm_demo',used);
      btn.disabled=false;
    }
  };
})();

/* LIVE NODE COUNT POLL */
setInterval(async()=>{
  try{
    const r=await fetch('/api/stats.php'); const d=await r.json();
    const n=d?.network?.online_nodes||0;
    ['stat-nodes','ticker-nodes'].forEach(id=>{ const e=document.getElementById(id); if(e) e.textContent=n; });
  }catch(_){}
},30000);

/* SCROLL REVEAL */
const observer=new IntersectionObserver(entries=>{
  entries.forEach(e=>{ if(e.isIntersecting) e.target.classList.add('visible'); });
},{threshold:.08});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));
</script>
</body>
</html>