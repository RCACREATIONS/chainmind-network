<?php
session_start();
require_once __DIR__ . '/../api/_helpers.php';
if (!isset($_SESSION['user_id'])) { header('Location: /auth/login.php?next=/dashboard/api-keys.php'); exit; }

$user_id   = (int)$_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';
$user_email= $_SESSION['user_email'] ?? '';
$flash = '';

// ── Detect whether migration v2 has been applied ─────────
function v2_migrated(): bool {
    static $done = null;
    if ($done !== null) return $done;
    try {
        $r = db()->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='api_keys' AND COLUMN_NAME='rate_limit_rpm'");
        $r->execute();
        $done = (int)$r->fetchColumn() > 0;
    } catch (\Throwable $e) { $done = false; }
    return $done;
}

function usage_table_exists(): bool {
    static $done = null;
    if ($done !== null) return $done;
    try {
        $r = db()->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='api_key_usage'");
        $r->execute();
        $done = (int)$r->fetchColumn() > 0;
    } catch (\Throwable $e) { $done = false; }
    return $done;
}

// ── Network Status helpers ────────────────────────────────
function get_online_nodes(): array {
    try {
        $stmt = db()->prepare("
            SELECT id, name, tier, models, reputation, jobs_done, status, last_seen
            FROM nodes
            WHERE status = 'online'
              AND last_seen >= NOW() - INTERVAL 5 MINUTE
            ORDER BY reputation DESC, jobs_done DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (\Throwable $e) {
        return [];
    }
}

function get_all_available_models(array $nodes): array {
    $models = [];
    foreach ($nodes as $node) {
        if (empty($node['models'])) continue;
        $decoded = json_decode($node['models'], true);
        if (is_array($decoded)) {
            foreach ($decoded as $m) { $m = trim($m); if ($m) $models[$m] = ($models[$m] ?? 0) + 1; }
        } else {
            foreach (explode(',', $node['models']) as $m) { $m = trim($m); if ($m) $models[$m] = ($models[$m] ?? 0) + 1; }
        }
    }
    arsort($models);
    return $models;
}

// ── Handle form posts ────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $label = substr(trim($_POST['label'] ?? 'Default'), 0, 100) ?: 'Default';
        $cnt = db()->prepare('SELECT COUNT(*) FROM api_keys WHERE user_id=? AND is_active=1');
        $cnt->execute([$user_id]);
        if ((int)$cnt->fetchColumn() >= 5) {
            $flash = '<div class="flash err">You can have at most 5 active API keys. Revoke one first.</div>';
        } else {
            $new_key = 'cm-' . bin2hex(random_bytes(20));
            if (v2_migrated()) {
                $exp_days  = (int)($_POST['expires_days'] ?? 0);
                $expires_at = $exp_days > 0 ? date('Y-m-d H:i:s', time() + $exp_days * 86400) : null;
                db()->prepare(
                    'INSERT INTO api_keys (api_key,owner_name,owner_email,user_id,label,expires_at,is_active)
                     VALUES(?,?,?,?,?,?,1)'
                )->execute([$new_key, $user_name, $user_email, $user_id, $label, $expires_at]);
            } else {
                db()->prepare(
                    'INSERT INTO api_keys (api_key,owner_name,owner_email,user_id,label) VALUES(?,?,?,?,?)'
                )->execute([$new_key, $user_name, $user_email, $user_id, $label]);
            }
            $kid = (int)db()->lastInsertId();
            db()->prepare('INSERT INTO credits (api_key_id,balance) VALUES(?,30) ON DUPLICATE KEY UPDATE balance=balance')
                ->execute([$kid]);
            $flash = '<div class="flash ok">&#10003; New API key created:&nbsp;<code style="font-family:monospace;word-break:break-all">'
                . htmlspecialchars($new_key) . '</code><br>Save this — it will not be shown again.</div>';
        }

    } elseif ($action === 'revoke') {
        $kid = (int)($_POST['key_id'] ?? 0);
        db()->prepare('UPDATE api_keys SET is_active=0 WHERE id=? AND user_id=?')->execute([$kid, $user_id]);
        $flash = '<div class="flash ok">&#10003; API key revoked.</div>';

    } elseif ($action === 'update_label') {
        $kid   = (int)($_POST['key_id'] ?? 0);
        $label = substr(trim($_POST['label'] ?? ''), 0, 100);
        if ($label) db()->prepare('UPDATE api_keys SET label=? WHERE id=? AND user_id=?')->execute([$label, $kid, $user_id]);
        $flash = '<div class="flash ok">&#10003; Label updated.</div>';
    }
}

// ── Load keys ─────────────────────────────────────────────
$keys = [];
try {
    if (v2_migrated()) {
        $stmt = db()->prepare("
            SELECT k.*,
                   COALESCE(c.balance,0) AS balance,
                   COALESCE(u.total_calls,0)   AS total_calls,
                   COALESCE(u.total_credits,0) AS total_credits_used,
                   COALESCE(u.total_tokens,0)  AS total_tokens,
                   u.last_call
            FROM api_keys k
            LEFT JOIN credits c ON c.api_key_id=k.id
            " . (usage_table_exists() ? "LEFT JOIN (
                SELECT api_key_id,
                       COUNT(*)                  AS total_calls,
                       SUM(credits_used)         AS total_credits,
                       SUM(tokens_in+tokens_out) AS total_tokens,
                       MAX(created_at)           AS last_call
                FROM api_key_usage GROUP BY api_key_id
            ) u ON u.api_key_id=k.id" : "") . "
            WHERE k.user_id=? ORDER BY k.id ASC
        ");
        $stmt->execute([$user_id]);
        $keys = $stmt->fetchAll();
    } else {
        $stmt = db()->prepare('SELECT k.*, COALESCE(c.balance,0) AS balance
            FROM api_keys k LEFT JOIN credits c ON c.api_key_id=k.id
            WHERE k.user_id=? ORDER BY k.id ASC');
        $stmt->execute([$user_id]);
        $keys = $stmt->fetchAll();
    }
} catch (\Throwable $e) {
    try {
        $stmt = db()->prepare('SELECT * FROM api_keys WHERE user_id=? ORDER BY id ASC');
        $stmt->execute([$user_id]);
        $keys = $stmt->fetchAll();
    } catch (\Throwable $e2) { $keys = []; }
}

// ── Per-key usage (last 7 days) ───────────────────────────
function key_usage(int $kid): array {
    if (!usage_table_exists()) return [];
    try {
        $stmt = db()->prepare("
            SELECT DATE(created_at) AS d, COUNT(*) AS calls, SUM(credits_used) AS cred
            FROM api_key_usage WHERE api_key_id=? AND created_at >= NOW()-INTERVAL 7 DAY
            GROUP BY DATE(created_at) ORDER BY d ASC
        ");
        $stmt->execute([$kid]);
        return $stmt->fetchAll();
    } catch (\Throwable $e) { return []; }
}

// ── Load network data ────────────────────────────────────
$online_nodes  = get_online_nodes();
$avail_models  = get_all_available_models($online_nodes);
$node_count    = count($online_nodes);
$model_count   = count($avail_models);
$total_jobs    = array_sum(array_column($online_nodes, 'jobs_done'));

$v2 = v2_migrated();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><title>API Keys — ChainMind</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap">
<link rel="icon" type="image/png" href="../ChatGPT Image Jun 2, 2026, 06_43_57 AM.png">
<style>
:root{
  --bg:#07080f;--bg2:#0b0d1c;--bg3:#101228;--bg4:#161935;
  --border:#1e2040;--border2:#272a52;--border3:#323670;
  --text:#eef0ff;--text2:#c5c8f0;--muted:#6b6f9e;--muted2:#474b78;
  --purple-1:#8b3cf7;--purple-2:#6d28d9;--violet:#7c3aed;--indigo:#4f46e5;
  --accent:#a78bfa;--accent-2:#c4b5fd;--accent2:#c4b5fd;
  --blue:#60a5fa;--glow:rgba(139,60,247,.35);
  --green:#34d399;--green-bg:rgba(52,211,153,.12);--green-bd:rgba(52,211,153,.35);
  --orange:#fb923c;--orange-bg:rgba(251,146,60,.12);
  --red:#f87171;--red-bg:rgba(248,113,113,.12);--gold:#f59e0b;
  --grad:linear-gradient(135deg,#8b3cf7,#4f46e5);
  --grad-soft:linear-gradient(135deg,rgba(139,60,247,.15),rgba(79,70,229,.08));
  --font:'Plus Jakarta Sans',system-ui,sans-serif;
  --display:'Syne',sans-serif;
  --mono:'JetBrains Mono',monospace;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{background:var(--bg);color:var(--text);font-family:var(--font);display:flex;min-height:100vh;font-size:15px;}
body::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");pointer-events:none;z-index:0;opacity:.5;}
.sidebar{width:240px;background:var(--bg2);border-right:1px solid var(--border);padding:1.75rem 1.25rem;display:flex;flex-direction:column;gap:.2rem;flex-shrink:0;min-height:100vh;position:relative;z-index:10;}
.sidebar::after{content:'';position:absolute;top:0;right:0;bottom:0;width:1px;background:linear-gradient(to bottom,transparent,rgba(139,60,247,.4) 30%,rgba(79,70,229,.3) 70%,transparent);pointer-events:none;}
.sidebar-logo{display:flex;align-items:center;gap:.7rem;margin-bottom:2rem;padding-left:.25rem;text-decoration:none;}
.logo-mark{width:36px;height:36px;background:var(--grad);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:.9rem;font-weight:800;color:#fff;box-shadow:0 0 20px var(--glow);flex-shrink:0;}
.logo-text{font-size:1.1rem;font-weight:800;letter-spacing:-.02em;}
.logo-text .chain{color:var(--accent2);}.logo-text .mind{color:var(--text);}
.ss{font-size:.68rem;font-weight:700;letter-spacing:.1em;color:var(--muted2);text-transform:uppercase;padding:.6rem .75rem .3rem;}
.sidebar a{display:flex;align-items:center;gap:.65rem;padding:.6rem .85rem;border-radius:10px;color:var(--muted);text-decoration:none;font-size:.88rem;font-weight:500;transition:all .18s;position:relative;}
.sidebar a svg{opacity:.6;flex-shrink:0;}
.sidebar a:hover{background:var(--bg3);color:var(--text2);}.sidebar a:hover svg{opacity:1;}
.sidebar a.active{background:linear-gradient(135deg,rgba(139,60,247,.18),rgba(79,70,229,.1));color:var(--accent2);border:1px solid rgba(139,60,247,.25);}
.sidebar a.active svg{opacity:1;}.sidebar a.active::before{content:'';position:absolute;left:0;top:20%;bottom:20%;width:3px;background:var(--grad);border-radius:0 3px 3px 0;}
hr.sd{border:none;border-top:1px solid var(--border);margin:.6rem 0;}
.main{flex:1;padding:2.25rem 2.5rem;overflow-x:hidden;position:relative;z-index:1;}
h1{font-family:'Syne',sans-serif;font-size:1.65rem;font-weight:800;letter-spacing:-.03em;margin-bottom:.35rem;}
.page-sub{color:var(--muted);font-size:.88rem;margin-bottom:2rem;}
.card{background:var(--bg3);border:1px solid var(--border);border-radius:14px;overflow:hidden;margin-bottom:1.5rem;}
.card-header{padding:1.1rem 1.4rem;border-bottom:1px solid var(--border);background:rgba(255,255,255,.01);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;}
.card-header h2{font-size:.92rem;font-weight:700;}
.card-body{padding:1.4rem;}
table{width:100%;border-collapse:collapse;font-size:.82rem;}
th{text-align:left;padding:.65rem 1rem;color:var(--muted);border-bottom:1px solid var(--border);font-size:.72rem;font-weight:600;text-transform:uppercase;letter-spacing:.06em;}
td{padding:.65rem 1rem;border-bottom:1px solid var(--border);color:var(--text2);}
tr:last-child td{border-bottom:none;}tr:hover td{background:rgba(255,255,255,.018);}
.badge{display:inline-flex;align-items:center;gap:.3rem;padding:.18rem .55rem;border-radius:20px;font-size:.7rem;font-weight:700;}
.b-active,.b-confirmed{background:var(--green-bg);color:var(--green);border:1px solid rgba(52,211,153,.25);}
.b-pending{background:var(--orange-bg);color:var(--orange);border:1px solid rgba(251,146,60,.25);}
.b-inactive,.b-failed{background:var(--red-bg);color:var(--red);border:1px solid rgba(248,113,113,.25);}
.b-warning{background:var(--orange-bg);color:var(--orange);border:1px solid rgba(251,146,60,.25);}
label{display:block;font-size:.8rem;color:var(--muted);margin:.75rem 0 .3rem;}
input[type=text],input[type=email],input[type=password],input[type=number],select,textarea{width:100%;padding:.65rem .9rem;border-radius:10px;border:1px solid var(--border2);background:var(--bg2);color:var(--text);font-family:var(--font);font-size:.88rem;outline:none;transition:.18s;}
input:focus,select:focus,textarea:focus{border-color:rgba(139,60,247,.5);box-shadow:0 0 0 3px rgba(139,60,247,.1);}
.btn{display:inline-flex;align-items:center;gap:.45rem;padding:.65rem 1.3rem;border-radius:10px;font-size:.88rem;font-weight:700;text-decoration:none;border:none;cursor:pointer;transition:.2s;font-family:var(--font);}
.btn-primary{background:var(--grad);color:#fff;box-shadow:0 4px 18px var(--glow);}.btn-primary:hover{opacity:.9;transform:translateY(-1px);}
.btn-ghost{background:transparent;border:1px solid var(--border2);color:var(--text2);}.btn-ghost:hover{border-color:var(--accent);color:var(--accent);}
.btn-danger{background:var(--red-bg);border:1px solid rgba(248,113,113,.3);color:var(--red);}.btn-danger:hover{background:rgba(248,113,113,.2);}
.btn-sm{padding:.4rem .85rem;font-size:.8rem;}
.flash{padding:.95rem 1.2rem;border-radius:12px;margin-bottom:1.25rem;font-size:.85rem;}
.flash.ok{background:var(--green-bg);border:1px solid rgba(52,211,153,.3);color:var(--green);}
.flash.err{background:var(--red-bg);border:1px solid rgba(248,113,113,.3);color:var(--red);}
.fld-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem;}
.key-meta{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:.65rem;padding:0 1.4rem 1.1rem;}
.km{background:var(--bg2);border:1px solid var(--border);border-radius:10px;padding:.7rem .9rem;}
.km .kl{font-size:.68rem;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);margin-bottom:.2rem;}
.km .kv{font-size:1.05rem;font-weight:700;}
/* rep bar */
.rep-bar{flex:1;max-width:70px;height:5px;border-radius:10px;background:var(--bg2);overflow:hidden;}
.rep-fill{height:100%;border-radius:10px;transition:width .5s;}
/* pulse */
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
.dot-pulse{width:7px;height:7px;border-radius:50%;background:var(--green);box-shadow:0 0 8px var(--green);animation:pulse 2s infinite;display:inline-block;}
/* section label */
.section-label{display:flex;align-items:center;gap:.5rem;margin:1.8rem 0 .9rem;font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted2);}
.section-label::after{content:'';flex:1;height:1px;background:var(--border);}
/* mobile */
.cm-mobile-bar{display:none;position:fixed;top:0;left:0;right:0;height:54px;z-index:9000;background:var(--bg2);border-bottom:1px solid var(--border);align-items:center;justify-content:space-between;padding:0 1rem;gap:.75rem;}
.cm-mobile-bar .cm-mob-logo{display:flex;align-items:center;gap:.55rem;text-decoration:none;}
.cm-hamburger{width:42px;height:42px;border-radius:9px;background:transparent;border:1px solid var(--border2);color:var(--text2);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;cursor:pointer;flex-shrink:0;transition:border-color .18s,color .18s;}
.cm-hamburger:hover{border-color:var(--accent);color:var(--accent);}
.cm-hamburger span{display:block;width:20px;height:2px;background:currentColor;border-radius:2px;transition:transform .25s,opacity .2s;}
.cm-hamburger.cm-open span:nth-child(1){transform:translateY(7px) rotate(45deg);}
.cm-hamburger.cm-open span:nth-child(2){opacity:0;transform:scaleX(0);}
.cm-hamburger.cm-open span:nth-child(3){transform:translateY(-7px) rotate(-45deg);}
.cm-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);backdrop-filter:blur(4px);z-index:8900;}
.cm-overlay.cm-show{display:block;}
::-webkit-scrollbar{width:5px;height:5px;}::-webkit-scrollbar-track{background:transparent;}::-webkit-scrollbar-thumb{background:var(--border2);border-radius:10px;}::-webkit-scrollbar-thumb:hover{background:rgba(139,60,247,.4);}
@media(max-width:768px){
  .cm-mobile-bar{display:flex!important;}
  body{padding-top:54px!important;}
  .sidebar{display:flex!important;flex-direction:column!important;position:fixed!important;top:0!important;left:0!important;bottom:0!important;width:270px!important;min-height:100vh!important;z-index:9500!important;transform:translateX(-100%)!important;transition:transform .28s cubic-bezier(.4,0,.2,1)!important;overflow-y:auto!important;overflow-x:hidden!important;}
  .sidebar.cm-open{transform:translateX(0)!important;box-shadow:4px 0 40px rgba(0,0,0,.6)!important;}
  .main{overflow-x:hidden;padding:1.25rem 1rem!important;}
  .fld-row{grid-template-columns:1fr!important;}
  .key-meta{grid-template-columns:1fr 1fr!important;}
  table{min-width:500px;}
  .card{overflow-x:auto;}
}
</style>
</head>
<body>

<div class="cm-mobile-bar" id="cmBar">
  <a href="/dashboard/" class="cm-mob-logo">
    <div style="width:32px;height:32px;background:linear-gradient(135deg,#8b3cf7,#4f46e5);border-radius:9px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.85rem;color:#fff;flex-shrink:0;box-shadow:0 0 14px rgba(139,60,247,.5)">CM</div>
    <div style="font-size:1rem;font-weight:800;letter-spacing:-.02em"><span style="color:#c4b5fd">Chain</span><span style="color:#eef0ff">Mind</span></div>
  </a>
  <button class="cm-hamburger" id="cmHamburger" onclick="cmToggle()" aria-label="Toggle navigation">
    <span></span><span></span><span></span>
  </button>
</div>
<div class="cm-overlay" id="cmOverlay" onclick="cmClose()"></div>

<nav class="sidebar">
  <a href="/dashboard/" class="sidebar-logo">
    <div class="logo-mark">CM</div>
    <div class="logo-text"><span class="chain">Chain</span><span class="mind">Mind</span></div>
  </a>
  <div class="ss">Account</div>
  <a href="/dashboard/"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>Overview</a>
  <a href="/dashboard/?tab=chat"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>Chat</a>
  <a href="/dashboard/billing.php"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>Billing</a>
  <a href="/dashboard/api-keys.php" class="active"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.78 7.78 5.5 5.5 0 017.78-7.78l1.06-1.06a2 2 0 012.83 0l1.06 1.06a2 2 0 010 2.83z"/></svg>API Keys</a>
  <a href="/dashboard/node-earnings.php"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>Node Earnings</a>
  <hr class="sd">
  <div class="ss">Tools</div>
  <a href="/dashboard/profile.php"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Profile</a>
  <a href="/dashboard/notifications.php"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>Notifications</a>
  <a href="/dashboard/support.php"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>Support</a>
  <hr class="sd">
  <div class="ss">Node</div>
  <a href="/dashboard/node-settings.php"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>Node Settings</a>
  <a href="/dashboard/node-download.php"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>Download Guide</a>
  <hr class="sd">
  <a href="/"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></svg>Home</a>
  <a href="/docs.php"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14,2 14,8 20,8"/></svg>API Docs</a>
  <a href="/auth/logout.php" style="margin-top:auto;color:var(--muted)"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16,17 21,12 16,7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>Sign out</a>
</nav>

<div class="main">
  <h1>API Keys</h1>
  <p class="page-sub">Manage your API keys for programmatic access to ChainMind.</p>

  <?= $flash ?>

  <?php if (!$v2): ?>
  <div style="padding:.9rem 1.2rem;border-radius:12px;margin-bottom:1.25rem;background:rgba(251,146,60,.1);border:1px solid rgba(251,146,60,.25);color:#fb923c;font-size:.85rem">
    ⚡ <strong>Upgrade available:</strong> Run <a href="/migrate_v2.php?key=chainmind_migrate_2026" style="color:#fb923c;text-decoration:underline">migrate_v2.php</a> to unlock rate limits, credit quotas, expiry dates, and per-key analytics.
  </div>
  <?php endif; ?>

  <!-- ══════════════════════════════════════════════════
       NETWORK STATUS
       ══════════════════════════════════════════════════ -->

  <!-- Live network banner -->
  <div style="display:flex;align-items:center;gap:.6rem;margin-bottom:1.5rem;padding:.8rem 1.2rem;
              background:linear-gradient(135deg,rgba(52,211,153,.07),rgba(79,70,229,.05));
              border:1px solid rgba(52,211,153,.18);border-radius:12px;flex-wrap:wrap">
    <span style="display:inline-flex;align-items:center;gap:.45rem;font-size:.82rem;font-weight:700;color:var(--green)">
      <span class="dot-pulse"></span>
      <?= $node_count ?> node<?= $node_count !== 1 ? 's' : '' ?> online
    </span>
    <span style="color:var(--border3)">·</span>
    <span style="font-size:.82rem;color:var(--text2)">
      <strong style="color:var(--accent2)"><?= $model_count ?></strong> models available
    </span>
    <span style="color:var(--border3)">·</span>
    <span style="font-size:.82rem;color:var(--muted)"><?= number_format($total_jobs) ?> total jobs processed</span>
    <span style="margin-left:auto;font-size:.7rem;color:var(--muted2);display:flex;align-items:center;gap:.3rem">
      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg>
      Live — refreshes on page load
    </span>
  </div>

  <!-- Available models -->
  <?php if ($avail_models): ?>
  <div class="card" style="margin-bottom:1.5rem">
    <div class="card-header">
      <h2 style="display:flex;align-items:center;gap:.45rem">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
        Available Models
      </h2>
      <span style="font-size:.75rem;color:var(--muted)">Served by online nodes right now — use these in your API calls</span>
    </div>
    <div style="padding:1.1rem 1.4rem;display:flex;flex-wrap:wrap;gap:.5rem">
      <?php foreach ($avail_models as $model => $cnt):
        $ml = strtolower($model);
        [$col,$bg,$bd] = match(true) {
          str_contains($ml,'gpt') || str_contains($ml,'openai')    => ['#34d399','rgba(52,211,153,.1)','rgba(52,211,153,.25)'],
          str_contains($ml,'mistral') || str_contains($ml,'mix')   => ['#60a5fa','rgba(96,165,250,.1)','rgba(96,165,250,.25)'],
          str_contains($ml,'llama') || str_contains($ml,'meta')    => ['#fb923c','rgba(251,146,60,.1)','rgba(251,146,60,.25)'],
          str_contains($ml,'claude') || str_contains($ml,'anth')   => ['#f472b6','rgba(244,114,182,.1)','rgba(244,114,182,.25)'],
          str_contains($ml,'gemini') || str_contains($ml,'palm')   => ['#facc15','rgba(250,204,21,.1)','rgba(250,204,21,.25)'],
          str_contains($ml,'qwen') || str_contains($ml,'alibaba')  => ['#e879f9','rgba(232,121,249,.1)','rgba(232,121,249,.25)'],
          str_contains($ml,'deepseek')                             => ['#38bdf8','rgba(56,189,248,.1)','rgba(56,189,248,.25)'],
          default => ['#a78bfa','rgba(167,139,250,.1)','rgba(167,139,250,.25)'],
        };
      ?>
      <span title="Supported by <?= $cnt ?> node<?= $cnt>1?'s':'' ?>"
            onclick="copyModel('<?= htmlspecialchars($model, ENT_QUOTES) ?>',this)"
            style="display:inline-flex;align-items:center;gap:.35rem;padding:.35rem .8rem;border-radius:20px;
                   font-size:.78rem;font-weight:600;cursor:pointer;user-select:none;transition:transform .15s,opacity .15s;
                   background:<?= $bg ?>;color:<?= $col ?>;border:1px solid <?= $bd ?>">
        <span style="width:6px;height:6px;border-radius:50%;background:<?= $col ?>;flex-shrink:0"></span>
        <?= htmlspecialchars($model) ?>
        <span style="opacity:.55;font-size:.67rem"><?= $cnt ?>×</span>
      </span>
      <?php endforeach; ?>
    </div>
    <div style="padding:.5rem 1.4rem .9rem;font-size:.73rem;color:var(--muted2)">
      💡 Click any model to copy its name &nbsp;·&nbsp; <strong style="color:var(--muted)">×N</strong> = number of nodes serving it
    </div>
  </div>
  <?php endif; ?>

  <!-- Online nodes table -->
  <div class="card" style="margin-bottom:2rem">
    <div class="card-header">
      <h2 style="display:flex;align-items:center;gap:.45rem">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="var(--green)" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 010 20M12 2a15.3 15.3 0 000 20"/></svg>
        Online Nodes
        <span style="font-size:.75rem;font-weight:500;color:var(--muted)">(<?= $node_count ?>)</span>
      </h2>
      <span style="font-size:.75rem;color:var(--muted)">Nodes active within the last 5 minutes</span>
    </div>

    <?php if (empty($online_nodes)): ?>
    <div style="padding:3rem;text-align:center;color:var(--muted)">
      <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"
           style="opacity:.25;margin-bottom:.85rem;display:block;margin-left:auto;margin-right:auto">
        <circle cx="12" cy="12" r="10"/><path d="M4.93 4.93l14.14 14.14"/>
      </svg>
      <div style="font-size:.9rem;font-weight:600;margin-bottom:.3rem">No nodes online right now</div>
      <div style="font-size:.8rem">Jobs will queue and process when nodes come online.</div>
    </div>
    <?php else: ?>
    <div style="overflow-x:auto">
    <table>
      <thead><tr>
        <th>Node</th>
        <th>Tier</th>
        <th>Models</th>
        <th>Reputation</th>
        <th>Jobs Done</th>
        <th>Last Seen</th>
        <th>Status</th>
      </tr></thead>
      <tbody>
      <?php foreach ($online_nodes as $node):
        // Parse models
        $node_models = [];
        if (!empty($node['models'])) {
            $dec = json_decode($node['models'], true);
            $node_models = is_array($dec) ? $dec : array_map('trim', explode(',', $node['models']));
            $node_models = array_filter($node_models);
        }
        // Tier color
        $tier = strtolower($node['tier'] ?? 'basic');
        [$tc,$tbg,$tbd] = match(true) {
            str_contains($tier,'enterprise') => ['#f472b6','rgba(244,114,182,.12)','rgba(244,114,182,.3)'],
            str_contains($tier,'pro')        => ['#f59e0b','rgba(245,158,11,.12)','rgba(245,158,11,.3)'],
            str_contains($tier,'premium')    => ['#a78bfa','rgba(167,139,250,.12)','rgba(167,139,250,.3)'],
            default                          => ['#60a5fa','rgba(96,165,250,.1)','rgba(96,165,250,.25)'],
        };
        // Reputation
        $rep = (int)($node['reputation'] ?? 0);
        $rc  = $rep >= 90 ? 'var(--green)' : ($rep >= 60 ? 'var(--orange)' : 'var(--red)');
        // Last seen relative
        $ls  = $node['last_seen'] ? (time() - strtotime($node['last_seen'])) : null;
        $lstr = match(true) {
            $ls === null    => '—',
            $ls < 60        => $ls . 's ago',
            $ls < 3600      => floor($ls/60) . 'm ago',
            default         => floor($ls/3600) . 'h ago',
        };
      ?>
      <tr>
        <td>
          <div style="font-weight:600;font-size:.85rem;color:var(--text)"><?= htmlspecialchars($node['name']) ?></div>
          <div style="font-size:.7rem;color:var(--muted2);margin-top:.1rem">Node #<?= (int)$node['id'] ?></div>
        </td>
        <td>
          <span class="badge" style="background:<?= $tbg ?>;color:<?= $tc ?>;border:1px solid <?= $tbd ?>">
            <?= htmlspecialchars(ucfirst($node['tier'] ?? 'Basic')) ?>
          </span>
        </td>
        <td>
          <div style="display:flex;flex-wrap:wrap;gap:.28rem;max-width:260px">
            <?php foreach (array_slice($node_models, 0, 5) as $m): ?>
            <span style="padding:.13rem .45rem;border-radius:5px;font-size:.68rem;font-weight:600;
                         background:var(--bg2);color:var(--accent2);border:1px solid var(--border2)">
              <?= htmlspecialchars(trim($m)) ?>
            </span>
            <?php endforeach; ?>
            <?php if (count($node_models) > 5): ?>
            <span style="font-size:.68rem;color:var(--muted);padding:.13rem .3rem;align-self:center">
              +<?= count($node_models)-5 ?> more
            </span>
            <?php endif; ?>
            <?php if (empty($node_models)): ?>
            <span style="font-size:.72rem;color:var(--muted)">—</span>
            <?php endif; ?>
          </div>
        </td>
        <td>
          <div style="display:flex;align-items:center;gap:.5rem">
            <div class="rep-bar">
              <div class="rep-fill" style="width:<?= min(100,$rep) ?>%;background:<?= $rc ?>"></div>
            </div>
            <span style="font-size:.8rem;font-weight:700;color:<?= $rc ?>"><?= $rep ?>%</span>
          </div>
        </td>
        <td style="font-weight:600;color:var(--text2)"><?= number_format((int)$node['jobs_done']) ?></td>
        <td style="font-size:.78rem;color:var(--muted)"><?= htmlspecialchars($lstr) ?></td>
        <td>
          <span class="badge b-active">
            <span class="dot-pulse" style="width:5px;height:5px;box-shadow:none"></span>
            Online
          </span>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
    <?php endif; ?>
  </div>

  <!-- ══════════════════════════════════════════════════
       YOUR API KEYS (existing section)
       ══════════════════════════════════════════════════ -->
  <div class="section-label">Your API Keys</div>

  <!-- Create key -->
  <div class="card">
    <div class="card-header"><h2>Create New API Key</h2></div>
    <div class="card-body">
      <form method="POST">
        <input type="hidden" name="action" value="create">
        <div class="fld-row">
          <div>
            <label>Label <span style="color:var(--muted)">(optional)</span></label>
            <input type="text" name="label" placeholder="e.g. Production, Mobile App…" maxlength="100">
          </div>
          <?php if ($v2): ?>
          <div>
            <label>Auto-expire <span style="color:var(--muted)">(days, blank = never)</span></label>
            <input type="number" name="expires_days" min="1" max="3650" placeholder="e.g. 30, 90, 365">
          </div>
          <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary" style="margin-top:1rem">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Generate Key
        </button>
      </form>
    </div>
  </div>

  <!-- OpenAI Usage card -->
  <div class="card" style="border-color:rgba(139,60,247,.25)">
    <div class="card-header"><h2 style="color:var(--accent2)">OpenAI-Compatible Usage</h2></div>
    <div class="card-body">
      <div style="background:var(--bg);border:1px solid var(--border2);border-radius:10px;padding:1rem;font-family:var(--mono);font-size:.8rem;color:var(--accent);overflow-x:auto">
POST /api/v1/chat/completions<br>
Authorization: Bearer cm-your-key-here<br>
Content-Type: application/json<br>
<br>
{"model":"mistral","messages":[{"role":"user","content":"Hello!"}]}</div>
      <p style="margin-top:.85rem;font-size:.8rem;color:var(--muted)">Drop-in replacement for OpenAI in any AI SDK — set <code style="font-family:var(--mono);color:var(--accent2)">base_url="https://chainmind.com.ng/api/v1"</code></p>
    </div>
  </div>

  <!-- Keys table -->
  <div class="card">
    <div class="card-header"><h2>Your API Keys (<?= count($keys) ?>)</h2></div>
    <div style="overflow-x:auto">
    <table>
      <thead><tr>
        <th>Label</th><th>API Key</th><th>Credits</th><th>Jobs</th><th>Last Used</th><th>Status</th><th>Actions</th>
      </tr></thead>
      <tbody>
      <?php foreach ($keys as $k):
        $balance  = (int)($k['balance'] ?? 0);
        $is_exp   = $v2 && !empty($k['expires_at']) && strtotime($k['expires_at']) < time();
        $exp_soon = $v2 && !empty($k['expires_at']) && !$is_exp && strtotime($k['expires_at']) < time()+7*86400;
        $active   = $k['is_active'] && !$is_exp;
      ?>
      <tr>
        <td>
          <form method="POST" style="display:flex;align-items:center;gap:.4rem">
            <input type="hidden" name="action" value="update_label">
            <input type="hidden" name="key_id" value="<?= $k['id'] ?>">
            <input type="text" name="label" value="<?= htmlspecialchars($k['label']??'Default') ?>"
                   style="padding:.3rem .55rem;font-size:.79rem;width:110px">
            <button type="submit" class="btn btn-ghost btn-sm">✓</button>
          </form>
          <?php if ($exp_soon): ?><div style="font-size:.7rem;color:var(--orange);margin-top:.2rem">⚠ Expires <?= date('M j', strtotime($k['expires_at'])) ?></div><?php endif; ?>
          <?php if ($is_exp): ?><div style="font-size:.7rem;color:var(--red);margin-top:.2rem">Expired <?= date('M j', strtotime($k['expires_at'])) ?></div><?php endif; ?>
        </td>
        <td>
          <div style="display:flex;align-items:center;gap:.4rem;flex-wrap:wrap">
            <code style="font-size:.77rem;color:var(--accent2);background:var(--bg2);padding:.2rem .5rem;border-radius:5px;border:1px solid var(--border2)"><?= htmlspecialchars(substr($k['api_key'],0,20)) ?>…</code>
            <button class="btn btn-ghost btn-sm" onclick="cpKey('<?= htmlspecialchars($k['api_key']) ?>',this)">Copy</button>
          </div>
        </td>
        <td style="color:var(--green);font-weight:700"><?= number_format($balance) ?></td>
        <td><?= number_format((int)($k['total_jobs'] ?? $k['total_calls'] ?? 0)) ?></td>
        <td style="font-size:.78rem;color:var(--muted)"><?= ($k['last_used']??$k['last_call']??null) ? substr($k['last_used']??$k['last_call'],0,10) : '—' ?></td>
        <td>
          <span class="badge <?= $active?'b-active':'b-inactive' ?>"><?= $active?'Active':($is_exp?'Expired':'Revoked') ?></span>
          <?php if ($v2 && !empty($k['rate_limit_rpm'])): ?><span class="badge" style="background:rgba(96,165,250,.1);color:#60a5fa;border:1px solid rgba(96,165,250,.2);margin-left:.3rem"><?= (int)$k['rate_limit_rpm'] ?>/m</span><?php endif; ?>
        </td>
        <td>
          <?php if ($active): ?>
          <form method="POST" style="display:inline" onsubmit="return confirm('Revoke this key?')">
            <input type="hidden" name="action" value="revoke">
            <input type="hidden" name="key_id" value="<?= $k['id'] ?>">
            <button type="submit" class="btn btn-danger btn-sm">Revoke</button>
          </form>
          <?php else: ?><span style="font-size:.78rem;color:var(--muted)">Revoked</span><?php endif; ?>
        </td>
      </tr>

      <?php if ($v2): ?>
      <tr style="background:rgba(255,255,255,.012)">
        <td colspan="7" style="padding:.6rem 1rem">
          <div class="key-meta" style="padding:0">
            <div class="km">
              <div class="kl">Rate Limit</div>
              <div class="kv"><?= (int)($k['rate_limit_rpm']??60) ?><span style="font-size:.72rem;color:var(--muted)"> rpm</span></div>
            </div>
            <div class="km">
              <div class="kl">Allowed Models</div>
              <div class="kv" style="font-size:.78rem"><?php
                $mdls = $k['allowed_models'] ? json_decode($k['allowed_models'],true) : null;
                echo $mdls ? htmlspecialchars(implode(', ', $mdls)) : 'All';
              ?></div>
            </div>
            <div class="km">
              <div class="kl">Expires</div>
              <div class="kv" style="font-size:.82rem"><?= !empty($k['expires_at']) ? date('M j, Y', strtotime($k['expires_at'])) : 'Never' ?></div>
            </div>
            <?php if (usage_table_exists()): $usage = key_usage((int)$k['id']); if ($usage): ?>
            <div class="km" style="grid-column:span 2">
              <div class="kl">Last 7 days</div>
              <div style="font-size:.78rem;color:var(--text2)">
                <?php foreach ($usage as $u): ?>
                <span><?= $u['d'] ?>: <strong><?= $u['calls'] ?></strong> calls</span>&nbsp;
                <?php endforeach; ?>
              </div>
            </div>
            <?php endif; endif; ?>
          </div>
        </td>
      </tr>
      <?php endif; ?>

      <?php endforeach; ?>
      <?php if (empty($keys)): ?>
      <tr><td colspan="7" style="text-align:center;padding:2rem;color:var(--muted)">No API keys yet. Create one above.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
    </div>
  </div>
</div><!-- /main -->

<script>
function cpKey(k,b){
  navigator.clipboard.writeText(k).then(function(){
    var o=b.textContent;b.textContent='✓ Copied';b.style.color='var(--green)';
    setTimeout(function(){b.textContent=o;b.style.color='';},2000);
  }).catch(function(){
    var t=document.createElement('textarea');t.value=k;
    document.body.appendChild(t);t.select();document.execCommand('copy');document.body.removeChild(t);
    var o=b.textContent;b.textContent='✓ Copied';b.style.color='var(--green)';
    setTimeout(function(){b.textContent=o;b.style.color='';},2000);
  });
}
function copyModel(m,el){
  navigator.clipboard.writeText(m).then(function(){
    var orig=el.style.opacity;
    el.style.transform='scale(.93)';el.style.opacity='.7';
    setTimeout(function(){el.style.transform='';el.style.opacity=orig||'1';},300);
  }).catch(function(){});
}
(function(){
  function cmToggle(){var sb=document.querySelector('.sidebar'),ov=document.getElementById('cmOverlay'),hb=document.getElementById('cmHamburger');if(sb)sb.classList.toggle('cm-open');if(ov)ov.classList.toggle('cm-show');if(hb)hb.classList.toggle('cm-open');}
  function cmClose(){var sb=document.querySelector('.sidebar'),ov=document.getElementById('cmOverlay'),hb=document.getElementById('cmHamburger');if(sb)sb.classList.remove('cm-open');if(ov)ov.classList.remove('cm-show');if(hb)hb.classList.remove('cm-open');}
  window.cmToggle=cmToggle;window.cmClose=cmClose;
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('.sidebar a').forEach(function(l){l.addEventListener('click',function(){if(window.innerWidth<=768)cmClose();});});
    document.addEventListener('keydown',function(e){if(e.key==='Escape')cmClose();});
  });
})();
</script>
</body>
</html>