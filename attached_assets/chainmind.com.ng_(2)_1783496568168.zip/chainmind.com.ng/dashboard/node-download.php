<?php
// ============================================================
// ChainMind  Node Download & Setup Page (first-login)
// Upload to: dashboard/node-download.php
// ============================================================
ob_start();
session_start();
require_once __DIR__ . '/../api/_helpers.php';

if (!isset($_SESSION['user_id'])) { header('Location: /auth/login.php?next=/dashboard/node-download.php'); exit; }

$user_id    = (int)$_SESSION['user_id'];
$user_name  = $_SESSION['user_name'] ?? 'Node Operator';
$user_email = $_SESSION['user_email'] ?? '';

// Mark first_login done (idempotent)
try {
    db()->prepare('UPDATE users SET first_login = 0 WHERE id = ?')->execute([$user_id]);
} catch (Throwable $e) { /* non-fatal */ }

// Fetch this user's node record
$node = null;
try {
    $stmt = db()->prepare('SELECT * FROM nodes WHERE user_id = ? ORDER BY linked_at DESC LIMIT 1');
    $stmt->execute([$user_id]);
    $node = $stmt->fetch();
} catch (Throwable $e) { $node = null; }

// The global node_secret from config
$node_secret = defined('NODE_SECRET') ? NODE_SECRET : 'see .htaccess NODE_SECRET';

// ── Fetch latest release manifest ────────────────────────────────────────────
$release = null;
$release_error = '';

if (
    !isset($_SESSION['_release_cache']) ||
    !isset($_SESSION['_release_cache_ts']) ||
    (time() - $_SESSION['_release_cache_ts']) > 600
) {
    $manifest_url = 'https://chainmind.com.ng/api/release/latest.json';

    $ch = curl_init($manifest_url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 8,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 3,
        CURLOPT_USERAGENT      => 'ChainMind-Dashboard/1.0',
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER     => ['Accept: application/json'],
    ]);
    $raw      = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($raw !== false && $httpCode === 200) {
        $decoded = json_decode($raw, true);
        if (is_array($decoded) && isset($decoded['version'])) {
            $_SESSION['_release_cache']    = $decoded;
            $_SESSION['_release_cache_ts'] = time();
            $release = $decoded;
        } else {
            $release_error = 'Could not parse release manifest.';
        }
    } else {
        $release_error = 'Could not fetch release info. Showing fallback links.';
    }
} else {
    $release = $_SESSION['_release_cache'];
}

// ── Build download URLs (fall back to hardcoded if manifest fails) ────────────
$version      = $release['version']               ?? '1.2.9';
$changelog    = $release['changelog']             ?? "https://github.com/RCACREATIONS/chainmind-network/releases/tag/v{$version}";
$win_url      = $release['assets']['windows_x64'] ?? "https://github.com/RCACREATIONS/chainmind-network/releases/download/v{$version}/ChainMind-Node-windows-x64.exe";
$mac_url      = $release['assets']['macos_arm64'] ?? "https://github.com/RCACREATIONS/chainmind-network/releases/download/v{$version}/ChainMind-Node-macos-arm64.zip";
$linux_url    = $release['assets']['linux_x64']   ?? "https://github.com/RCACREATIONS/chainmind-network/releases/download/v{$version}/ChainMind-Node-linux-x64";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><title>Get Started — Download Your Node · ChainMind</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap">
<link rel="icon" type="image/png" href="../ChatGPT Image Jun 2, 2026, 06_43_57 AM.png">
<style>
:root{
  --bg:#07080f;
  --bg2:#0c0d1a;
  --bg3:#111228;
  --bg4:#161830;
  --border:#1e2040;
  --border2:#272a52;
  --text:#eef0ff;
  --text2:#c5c8f0;
  --muted:#6b6f9e;
  --muted2:#4a4e7a;
  --purple-1:#8b3cf7;
  --purple-2:#6d28d9;
  --violet:#7c3aed;
  --indigo:#4f46e5;
  --accent:#a78bfa;
  --accent-2:#c4b5fd;
  --green:#34d399;
  --green-bg:rgba(52,211,153,.12);
  --orange:#fb923c;
  --orange-bg:rgba(251,146,60,.12);
  --red:#f87171;
  --red-bg:rgba(248,113,113,.12);
  --grad:linear-gradient(135deg,var(--purple-1),var(--indigo));
  --grad-soft:linear-gradient(135deg,rgba(139,60,247,.15),rgba(79,70,229,.08));
  --glow:rgba(139,60,247,.35);
}
*{box-sizing:border-box;margin:0;padding:0;}
body{background:var(--bg);color:var(--text);font-family:'Plus Jakarta Sans',system-ui,sans-serif;display:flex;min-height:100vh;}
body::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");opacity:.45;pointer-events:none;z-index:0;}
.sidebar{width:240px;background:var(--bg2);border-right:1px solid var(--border);padding:1.75rem 1.25rem;display:flex;flex-direction:column;gap:.2rem;flex-shrink:0;min-height:100vh;position:relative;z-index:10;}
.sidebar::after{content:'';position:absolute;top:0;right:0;bottom:0;width:1px;background:linear-gradient(to bottom,transparent,rgba(139,60,247,.4) 30%,rgba(79,70,229,.3) 70%,transparent);}
.sidebar-logo{display:flex;align-items:center;gap:.7rem;margin-bottom:2rem;padding-left:.25rem;text-decoration:none;}
.logo-mark{width:36px;height:36px;background:var(--grad);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:.9rem;font-weight:800;color:#fff;box-shadow:0 0 20px var(--glow);flex-shrink:0;}
.logo-text{font-size:1.1rem;font-weight:800;letter-spacing:-.02em;}
.logo-text .chain{color:var(--accent-2);}.logo-text .mind{color:var(--text);}
.sidebar a{display:flex;align-items:center;gap:.65rem;padding:.6rem .85rem;border-radius:10px;color:var(--muted);text-decoration:none;font-size:.88rem;font-weight:500;transition:.18s;position:relative;}
.sidebar a svg{opacity:.6;flex-shrink:0;}
.sidebar a:hover{background:var(--bg3);color:var(--text2);}
.sidebar a.active{background:linear-gradient(135deg,rgba(139,60,247,.18),rgba(79,70,229,.1));border:1px solid rgba(139,60,247,.25);color:var(--accent-2);}
.sidebar a.active::before{content:'';position:absolute;left:0;top:20%;bottom:20%;width:3px;border-radius:0 3px 3px 0;background:var(--grad);}
.sidebar a:hover svg,.sidebar a.active svg{opacity:1;}
hr.sd{border:none;border-top:1px solid var(--border);margin:.6rem 0;}
.ss{font-size:.68rem;font-weight:700;letter-spacing:.1em;color:var(--muted2);text-transform:uppercase;padding:.6rem .75rem .3rem;}
.main{flex:1;padding:2.25rem 2.5rem;max-width:1000px;overflow-x:hidden;position:relative;z-index:1;}
h1{font-size:1.65rem;font-weight:800;letter-spacing:-.03em;margin-bottom:.35rem;}
h2{font-size:1rem;font-weight:700;margin-bottom:.9rem;}
.page-sub{color:var(--muted);font-size:.88rem;margin-bottom:2rem;}
.hero{background:var(--grad-soft);border:1px solid rgba(139,60,247,.25);border-radius:16px;padding:2rem;text-align:center;margin-bottom:1.75rem;position:relative;overflow:hidden;}
.hero::before{content:'';position:absolute;inset:0;background:radial-gradient(circle at top right,rgba(139,60,247,.15),transparent 60%);pointer-events:none;}
.badge{display:inline-flex;align-items:center;gap:.35rem;padding:.22rem .7rem;border-radius:999px;background:var(--green-bg);border:1px solid rgba(52,211,153,.25);color:var(--green);font-size:.72rem;font-weight:700;}
.version-badge{display:inline-flex;align-items:center;gap:.35rem;padding:.22rem .7rem;border-radius:999px;background:rgba(139,60,247,.15);border:1px solid rgba(139,60,247,.3);color:var(--accent);font-size:.72rem;font-weight:700;margin-left:.5rem;text-decoration:none;}
.version-badge:hover{background:rgba(139,60,247,.25);}
.card{background:var(--bg3);border:1px solid var(--border);border-radius:14px;padding:1.5rem;margin-bottom:1.5rem;transition:.2s;}
.card:hover{border-color:var(--border2);}
.card h2{color:var(--accent-2);}
.secret-box{background:var(--bg2);border:1px solid rgba(139,60,247,.35);border-radius:12px;padding:1rem 1.25rem;font-family:'JetBrains Mono',monospace;color:var(--accent);display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;margin:.9rem 0;}
.copy-btn{background:var(--grad);border:none;color:#fff;border-radius:8px;padding:.45rem .9rem;cursor:pointer;font-size:.8rem;font-weight:700;transition:.18s;box-shadow:0 4px 15px var(--glow);}
.copy-btn:hover{opacity:.9;transform:translateY(-1px);}
.steps{counter-reset:step;list-style:none;}
.steps li{counter-increment:step;display:flex;gap:1rem;margin-bottom:1rem;color:var(--text2);line-height:1.7;font-size:.88rem;}
.steps li::before{content:counter(step);width:1.9rem;height:1.9rem;min-width:1.9rem;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.8rem;font-weight:800;color:#fff;background:var(--grad);box-shadow:0 0 15px var(--glow);}
code{background:var(--bg);border:1px solid var(--border2);border-radius:5px;padding:.15rem .45rem;font-size:.82rem;color:var(--accent);font-family:'JetBrains Mono',monospace;}
.btn{display:inline-flex;align-items:center;gap:.45rem;padding:.65rem 1.3rem;border-radius:10px;font-size:.88rem;font-weight:700;text-decoration:none;border:none;cursor:pointer;transition:.2s;}
.btn-green{background:var(--green);color:#07120d;}
.btn-green:hover{opacity:.9;}
.btn-accent{background:var(--grad);color:#fff;box-shadow:0 4px 18px var(--glow);}
.btn-accent:hover{transform:translateY(-2px);}
.btn-ghost{background:transparent;border:1px solid var(--border2);color:var(--muted);}
.btn-ghost:hover{border-color:var(--accent);color:var(--accent);}
.warning-box{background:var(--orange-bg);border:1px solid rgba(251,146,60,.25);border-radius:10px;padding:.95rem 1rem;color:var(--orange);font-size:.83rem;margin:.9rem 0;}
.error-box{background:var(--red-bg);border:1px solid rgba(248,113,113,.2);border-radius:10px;padding:.75rem 1rem;color:var(--red);font-size:.8rem;margin-bottom:1rem;}
.info-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:.85rem;margin-bottom:1rem;}
.info-item{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:1rem;transition:.18s;}
.info-item:hover{border-color:rgba(139,60,247,.3);}
.info-label{font-size:.7rem;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;margin-bottom:.35rem;}
.info-val{font-size:.95rem;font-weight:700;color:var(--text);}
::-webkit-scrollbar{width:5px;}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:20px;}
::-webkit-scrollbar-thumb:hover{background:rgba(139,60,247,.4);}


  /* =========================================================
     CHAINMIND MOBILE PATCH — appended, nothing removed above
     ========================================================= */

  /* Mobile top bar */
  .cm-mobile-bar {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0;
    height: 54px;
    z-index: 9000;
    background: var(--bg2, #0b0d1c);
    border-bottom: 1px solid var(--border, #1e2040);
    align-items: center;
    justify-content: space-between;
    padding: 0 1rem;
    gap: .75rem;
  }
  .cm-mobile-bar .cm-mob-logo {
    display: flex; align-items: center; gap: .55rem; text-decoration: none;
  }
  .cm-hamburger {
    width: 42px; height: 42px;
    border-radius: 9px;
    background: transparent;
    border: 1px solid var(--border2, #272a52);
    color: var(--text2, #c5c8f0);
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    gap: 5px; cursor: pointer; flex-shrink: 0;
    transition: border-color .18s, color .18s;
  }
  .cm-hamburger:hover { border-color: var(--accent, #a78bfa); color: var(--accent, #a78bfa); }
  .cm-hamburger span {
    display: block; width: 20px; height: 2px;
    background: currentColor; border-radius: 2px;
    transition: transform .25s, opacity .2s;
  }
  .cm-hamburger.cm-open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
  .cm-hamburger.cm-open span:nth-child(2) { opacity: 0; transform: scaleX(0); }
  .cm-hamburger.cm-open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

  /* Overlay */
  .cm-overlay {
    display: none;
    position: fixed; inset: 0;
    background: rgba(0,0,0,.65);
    backdrop-filter: blur(4px);
    z-index: 8900;
  }
  .cm-overlay.cm-show { display: block; }

  @media (max-width: 768px) {

    /* Show the mobile bar */
    .cm-mobile-bar { display: flex !important; }

    /* Push body content below the bar */
    body { padding-top: 54px !important; }

    /* Turn sidebar into a slide-in drawer */
    .sidebar {
      display: flex !important;          /* override any display:none from original CSS */
      flex-direction: column !important;
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      bottom: 0 !important;
      width: 270px !important;
      min-height: 100vh !important;
      z-index: 9500 !important;
      transform: translateX(-100%) !important;
      transition: transform .28s cubic-bezier(.4, 0, .2, 1) !important;
      overflow-y: auto !important;
      overflow-x: hidden !important;
      /* keep original background/border */
    }
    .sidebar.cm-open {
      transform: translateX(0) !important;
      box-shadow: 4px 0 40px rgba(0,0,0,.6) !important;
    }

    /* Main content fills full width */
    .main { overflow-x: hidden; }

    /* Stats grid: 2 columns on mobile */
    .stats { grid-template-columns: repeat(2, 1fr) !important; }

    /* Tabs: horizontal scroll */
    .tabs {
      overflow-x: auto !important;
      -webkit-overflow-scrolling: touch;
      scrollbar-width: none;
      flex-wrap: nowrap !important;
      padding-left: 1rem !important;
      padding-right: 1rem !important;
    }
    .tabs::-webkit-scrollbar { display: none; }
    .tab-btn { white-space: nowrap; }

    /* Tables: horizontal scroll wrapper */
    .card { overflow-x: auto; }
    table { min-width: 480px; }

    /* Overview padding */
    .overview-scroll { padding: 1.25rem 1rem !important; }

    /* Page header sizing */
    h1 { font-size: 1.3rem !important; }

    /* Reduce main padding */
    .main { padding: 1.25rem 1rem !important; }

    /* Collapse multi-col form rows */
    .fld-row { grid-template-columns: 1fr !important; }

    /* Payment method grids */
    .pay-methods { grid-template-columns: 1fr !important; }
    .info-grid { grid-template-columns: 1fr 1fr !important; }

    /* Hide chat sidebar on small screens */
    .chat-sidebar { display: none !important; }
    .chat-panel { flex-direction: column !important; }

    /* Input area */
    .input-area { padding: .75rem 1rem 1rem !important; }
  }

  @media (max-width: 480px) {
    .stats { grid-template-columns: 1fr 1fr !important; }
    .stat-card .sc-value,
    .stat .val { font-size: 1.4rem !important; }
    .page-header .greeting-line { font-size: 1.2rem !important; }
    .overview-scroll { padding: 1rem .85rem !important; }
  }
  </style>
</head>
<body>

  <!-- ── CHAINMIND MOBILE TOPBAR ───────────────────── -->
  <div class="cm-mobile-bar" id="cmBar">
    <a href="/dashboard/" class="cm-mob-logo">
      <div style="width:32px;height:32px;background:linear-gradient(135deg,#8b3cf7,#4f46e5);border-radius:9px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.85rem;color:#fff;flex-shrink:0;box-shadow:0 0 14px rgba(139,60,247,.5)">CM</div>
      <div style="font-size:1rem;font-weight:800;letter-spacing:-.02em"><span style="color:#c4b5fd">Chain</span><span style="color:#eef0ff">Mind</span></div>
    </a>
    <button class="cm-hamburger" id="cmHamburger" onclick="cmToggle()" aria-label="Toggle navigation">
      <span></span><span></span><span></span>
    </button>
  </div>
  <div class="cm-overlay" id="cmOverlay" onclick="cmClose()"></div>
  <!-- ── END MOBILE TOPBAR ─────────────────────────── -->
  
<nav class="sidebar">
  <a href="/dashboard/" class="sidebar-logo">
    <div class="logo-mark">CM</div>
    <div class="logo-text"><span class="chain">Chain</span><span class="mind">Mind</span></div>
  </a>
  <div class="ss">Account</div>
  <a href="/dashboard/">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>Overview</a>
  <a href="/dashboard/?tab=chat">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>Chat</a>
  <a href="/dashboard/billing.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>Billing</a>
  <a href="/dashboard/api-keys.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.78 7.78 5.5 5.5 0 017.78-7.78l1.06-1.06a2 2 0 012.83 0l1.06 1.06a2 2 0 010 2.83z"/></svg>API Keys</a>
  <a href="/dashboard/node-earnings.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>Node Earnings</a>
  <hr class="sd">
  <div class="ss">Tools</div>
  <a href="/dashboard/profile.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Profile</a>
  <a href="/dashboard/notifications.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>Notifications</a>
  <a href="/dashboard/support.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>Support</a>
  <hr class="sd">
  <div class="ss">Node</div>
  <a href="/dashboard/node-settings.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>Node Settings</a>
  <a href="/dashboard/node-download.php" class="active">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>Download Guide</a>
  <hr class="sd">
  <a href="/">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></svg>Home</a>
  <a href="/docs.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14,2 14,8 20,8"/></svg>API Docs</a>
  <a href="/auth/logout.php" style="margin-top:auto;color:var(--muted)">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16,17 21,12 16,7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>Sign out</a>
</nav>

<div class="main">

  <!-- Hero -->
  <div class="hero">
    <div style="font-size:3rem;margin-bottom:1rem">&#9881;</div>
    <span class="badge">First-time setup</span>
    <?php if (!$release_error): ?>
      <a href="<?= htmlspecialchars($changelog) ?>" target="_blank" class="version-badge">
        v<?= htmlspecialchars($version) ?> latest
      </a>
    <?php endif; ?>
    <h1 style="margin:.75rem 0 .35rem;font-size:1.6rem">
      Welcome to ChainMind, <?= htmlspecialchars($user_name) ?>!
    </h1>
    <p style="color:var(--muted);font-size:.9rem;max-width:540px;margin:0 auto">
      You're one step away from joining the decentralised AI network and earning IQ tokens.
      Follow the steps below to get your node running.
    </p>
  </div>

  <?php if ($release_error): ?>
  <div class="error-box">
    ⚠ <?= htmlspecialchars($release_error) ?> Download links below may be slightly out of date.
  </div>
  <?php endif; ?>

  <!-- Step 1: Download -->
  <div class="card">
    <h2>① Download ChainMind Node</h2>

    <p style="color:var(--muted);font-size:.85rem;margin-bottom:1.25rem">
      Download the version that matches your operating system. Once installed,
      launch the ChainMind Node application and follow the onboarding wizard to
      connect your node to the network.
    </p>

    <div class="info-grid">
      <div class="info-item">
        <div class="info-label">Version</div>
        <div class="info-val">
          v<?= htmlspecialchars($version) ?>
          <?php if (!$release_error): ?>
            <span style="font-size:.7rem;color:var(--green);font-weight:600;margin-left:.3rem">● live</span>
          <?php endif; ?>
        </div>
      </div>
      <div class="info-item">
        <div class="info-label">Platforms</div>
        <div class="info-val">Windows · macOS · Linux</div>
      </div>
      <div class="info-item">
        <div class="info-label">Requires</div>
        <div class="info-val">Ollama</div>
      </div>
      <div class="info-item">
        <div class="info-label">Changelog</div>
        <div class="info-val">
          <a href="<?= htmlspecialchars($changelog) ?>" target="_blank"
             style="color:var(--accent);font-size:.85rem;text-decoration:none">
            View release notes ↗
          </a>
        </div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:1rem;margin-top:1rem;">

      <!-- Windows -->
      <div style="background:var(--bg2);border:1px solid var(--border2);border-radius:12px;padding:1rem;">
        <h3 style="margin:0 0 .4rem 0;">🪟 Windows</h3>
        <p style="color:var(--muted);font-size:.82rem;margin-bottom:1rem;">Windows 10 / 11 · 64-bit</p>
        <a href="<?= htmlspecialchars($win_url) ?>"
           class="btn btn-accent"
           style="width:100%;justify-content:center;">
          ⬇ Download .exe
        </a>
      </div>

      <!-- macOS -->
      <div style="background:var(--bg2);border:1px solid var(--border2);border-radius:12px;padding:1rem;">
        <h3 style="margin:0 0 .4rem 0;">🍎 macOS</h3>
        <p style="color:var(--muted);font-size:.82rem;margin-bottom:1rem;">Apple Silicon (M1 / M2 / M3 / M4)</p>
        <a href="<?= htmlspecialchars($mac_url) ?>"
           class="btn btn-accent"
           style="width:100%;justify-content:center;">
          ⬇ Download .zip
        </a>
      </div>

      <!-- Linux -->
      <div style="background:var(--bg2);border:1px solid var(--border2);border-radius:12px;padding:1rem;">
        <h3 style="margin:0 0 .4rem 0;">🐧 Linux</h3>
        <p style="color:var(--muted);font-size:.82rem;margin-bottom:1rem;">x64 · Ubuntu 20.04+</p>
        <a href="<?= htmlspecialchars($linux_url) ?>"
           class="btn btn-accent"
           style="width:100%;justify-content:center;">
          ⬇ Download Binary
        </a>
      </div>

    </div>

    <div style="margin-top:1rem;">
      <a href="https://ollama.ai/download" target="_blank" class="btn btn-ghost">
        Get Ollama First →
      </a>
    </div>
  </div>

  <!-- Step 2: Node Secret -->
  <div class="card">
    <h2>② Your Node Secret</h2>
    <p style="color:var(--muted);font-size:.85rem;margin-bottom:.5rem">
      After downloading and launching the ChainMind Node application, the onboarding
      wizard will ask for your <strong>Node Secret</strong>.
    </p>
    <div class="warning-box">
      ⚠ Keep this secret private. Anyone with access to it can register a node under your account.
    </div>
    <div class="secret-box">
      <span id="node-secret" style="flex:1"><?= htmlspecialchars($node_secret) ?></span>
      <button class="copy-btn" onclick="copySecret()">⎘ Copy</button>
    </div>
    <p style="color:var(--muted);font-size:.82rem;margin-top:.75rem"><strong>What to do next:</strong></p>
    <ol style="margin:0 0 0 1.2rem;color:var(--text2);line-height:1.7;font-size:.88rem">
      <li>Download and run the ChainMind Node application above.</li>
      <li>Complete the onboarding steps in the wizard.</li>
      <li>When prompted for your <strong>Node Secret</strong>, paste the value above.</li>
      <li>Continue setup and start your node.</li>
    </ol>
  </div>

  <!-- Step 3: Setup -->
  <div class="card">
    <h2>③ Set up and run the node</h2>
    <ol class="steps">
      <li>
        <div>
          <strong>Install Ollama</strong> if you haven't already. Download from
          <a href="https://ollama.ai/download" target="_blank" style="color:var(--accent)">ollama.ai/download</a>
          and run the installer. Then open a terminal and run:<br>
          <code>ollama pull tinyllama</code>
        </div>
      </li>
      <li>
        <div>
          <strong>Run the installer</strong> — double-click the downloaded file and follow the prompts.
          On Linux, mark it executable first: <code>chmod +x ChainMind-Node-linux-x64</code>
        </div>
      </li>
      <li>
        <div>
          <strong>Paste your Node Secret</strong> when the onboarding wizard asks for it (copied from Step ② above).
          This connects your node to your ChainMind account so you earn IQ under your name.
        </div>
      </li>
      <li>
        <div>
          <strong>Your node is live.</strong> It will appear on the network, start receiving AI jobs,
          and begin earning IQ tokens. A system-tray icon shows live stats.
        </div>
      </li>
      <li>
        <div>
          <strong>Link to this dashboard</strong> — go to
          <a href="/dashboard/node-settings.php" style="color:var(--accent)">Node Settings</a>
          and use the pairing token to see live earnings, job history, and IQ here.
        </div>
      </li>
    </ol>
  </div>

  <!-- Step 4: Earnings -->
  <div class="card">
    <h2>④ How earning IQ works</h2>
    <ol class="steps">
      <li><div><strong>Your node receives AI jobs</strong> from the ChainMind network — users send prompts, your GPU processes them with Ollama.</div></li>
      <li><div><strong>You earn IQ tokens</strong> for every completed job. The amount depends on tokens generated and job complexity.</div></li>
      <li><div><strong>View your earnings</strong> in real-time from <a href="/dashboard/node-earnings.php" style="color:var(--accent)">Node Earnings</a>.</div></li>
      <li><div><strong>Withdraw IQ</strong> to crypto or fiat from the earnings page once you hit the minimum threshold (10 IQ = $0.10).</div></li>
    </ol>
  </div>

  <!-- CTA -->
  <div style="text-align:center;padding:1rem 0 2rem">
    <a href="/dashboard/" class="btn btn-green" style="font-size:1rem;padding:.75rem 2rem">
      ✓ I've set it up — take me to the dashboard →
    </a>
    <br><br>
    <a href="/dashboard/node-settings.php" style="color:var(--muted);font-size:.83rem;text-decoration:none">
      Or go to Node Settings to link your running node
    </a>
  </div>

</div><!-- /main -->

<script>
function copySecret() {
  const s = document.getElementById('node-secret').textContent.trim();
  navigator.clipboard.writeText(s).then(() => {
    const btn = document.querySelector('.copy-btn');
    btn.textContent = '✓ Copied!';
    setTimeout(() => btn.textContent = '⎘ Copy', 2500);
  });
}
</script>

  <!-- ── CHAINMIND MOBILE JS ────────────────────────── -->
  <script>
  (function() {
    function cmToggle() {
      var sb = document.querySelector('.sidebar');
      var ov = document.getElementById('cmOverlay');
      var hb = document.getElementById('cmHamburger');
      if (sb) sb.classList.toggle('cm-open');
      if (ov) ov.classList.toggle('cm-show');
      if (hb) hb.classList.toggle('cm-open');
    }
    function cmClose() {
      var sb = document.querySelector('.sidebar');
      var ov = document.getElementById('cmOverlay');
      var hb = document.getElementById('cmHamburger');
      if (sb) sb.classList.remove('cm-open');
      if (ov) ov.classList.remove('cm-show');
      if (hb) hb.classList.remove('cm-open');
    }
    window.cmToggle = cmToggle;
    window.cmClose  = cmClose;
    document.addEventListener('DOMContentLoaded', function() {
      // Close sidebar when any sidebar link is tapped on mobile
      var links = document.querySelectorAll('.sidebar a');
      links.forEach(function(l) {
        l.addEventListener('click', function() {
          if (window.innerWidth <= 768) cmClose();
        });
      });
      // Close on Escape key
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') cmClose();
      });
    });
  })();
  </script>
  <!-- ── END MOBILE JS ──────────────────────────────── -->
  
</body>
</html>
<?php ob_end_flush(); ?>