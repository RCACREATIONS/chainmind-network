<?php
session_start();
require_once __DIR__ . '/../api/_helpers.php';
require_once __DIR__ . '/../api/billing/credits.php';

if (!isset($_SESSION['user_id'])) { header('Location: /auth/login.php?next=/dashboard/billing.php'); exit; }

$user_id = (int)$_SESSION['user_id'];
$is_admin = ($_SESSION['user_role'] ?? '') === 'admin';

$key_row = db()->prepare('SELECT * FROM api_keys WHERE user_id = ? AND is_active = 1 LIMIT 1');
$key_row->execute([$user_id]); $key_row = $key_row->fetch();
$api_key_id = $key_row ? (int)$key_row['id'] : 0;
$balance = $api_key_id ? credits_get($api_key_id) : 0;

$sub = null;
if ($api_key_id) {
    $sq = db()->prepare('SELECT * FROM subscriptions WHERE api_key_id = ? AND status = "active" ORDER BY id DESC LIMIT 1');
    $sq->execute([$api_key_id]); $sub = $sq->fetch();
}
$payments = [];
if ($api_key_id) {
    $pq = db()->prepare('SELECT * FROM payments WHERE api_key_id = ? ORDER BY created_at DESC LIMIT 30');
    $pq->execute([$api_key_id]); $payments = $pq->fetchAll();
}
$deductions = [];
if ($api_key_id) {
    $dq = db()->prepare(
        'SELECT d.*, j.model FROM credit_deductions d LEFT JOIN jobs j ON j.id = d.job_id
         WHERE d.api_key_id = ? ORDER BY d.created_at DESC LIMIT 20'
    );
    $dq->execute([$api_key_id]); $deductions = $dq->fetchAll();
}
$flash = '';
if (isset($_GET['payment'])) {
    $p = $_GET['payment'];
    $flash = $p === 'success'
        ? '<div class="flash ok">&#10003; Payment confirmed! Credits have been added to your account.</div>'
        : '<div class="flash err">&#9888; Payment Payment ' . htmlspecialchars($p) . '. No credits were added.</div>';
}
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><title>Billing — ChainMind</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap">
<link rel="icon" type="image/png" href="../ChatGPT Image Jun 2, 2026, 06_43_57 AM.png">
<style>
:root {
  --bg:        #07080f;
  --bg2:       #0b0d1c;
  --bg3:       #101228;
  --bg4:       #161935;
  --border:    #1e2040;
  --border2:   #272a52;
  --border3:   #323670;

  --text:      #eef0ff;
  --text2:     #c5c8f0;
  --muted:     #6b6f9e;
  --muted2:    #474b78;

  --purple:    #8b3cf7;
  --purple-1:  #8b3cf7;
  --purple-2:  #6d28d9;
  --purple2:   #6d28d9;
  --violet:    #7c3aed;
  --indigo:    #4f46e5;
  --accent:    #a78bfa;
  --accent-2:  #c4b5fd;
  --accent2:   #c4b5fd;
  --blue:      #60a5fa;
  --neon:      #a78bfa;
  --glow:      rgba(139, 60, 247, .35);

  --green:     #34d399;
  --green-bg:  rgba(52, 211, 153, .12);
  --green-bd:  rgba(52, 211, 153, .35);
  --orange:    #fb923c;
  --orange-bg: rgba(251, 146, 60, .12);
  --red:       #f87171;
  --red-bg:    rgba(248, 113, 113, .12);
  --gold:      #f59e0b;

  --grad:      linear-gradient(135deg, var(--purple-1), var(--indigo));
  --grad-soft: linear-gradient(135deg, rgba(139,60,247,.15), rgba(79,70,229,.08));

  --font:    'Plus Jakarta Sans', system-ui, sans-serif;
  --display: 'Syne', sans-serif;
  --mono:    'JetBrains Mono', monospace;

  --r-sm: 8px;
  --r-md: 12px;
  --r-lg: 16px;
  --r-xl: 20px;
}

*{
  box-sizing:border-box;
  margin:0;
  padding:0;
}

body{
  background:var(--bg);
  color:var(--text);
  font-family:var(--font);
  display:flex;
  min-height:100vh;
}

/* Noise */
body::before{
  content:'';
  position:fixed;
  inset:0;
  background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
  opacity:.45;
  pointer-events:none;
  z-index:0;
}


/* ─── LOGO MARK ─── */
.sidebar-logo {
  display: flex;
  align-items: center;
  gap: .65rem;
  margin-bottom: 2rem;
  padding-left: .15rem;
  text-decoration: none;
}
.logo-mark {
  width: 34px;
  height: 34px;
  background: var(--grad);
  border-radius: 9px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--display);
  font-size: 1rem;
  font-weight: 800;
  color: #fff;
  box-shadow: 0 0 18px var(--glow);
  flex-shrink: 0;
  letter-spacing: -.5px;
}
.logo-text {
  font-family: var(--display);
  font-size: 1.05rem;
  font-weight: 800;
  letter-spacing: -.03em;
  line-height: 1;
}
.logo-text .chain { color: var(--accent2); }
.logo-text .mind  { color: var(--text); }

/* SIDEBAR */
.sidebar{
  width:240px;
  background:var(--bg2);
  border-right:1px solid var(--border);
  padding:1.75rem 1.25rem;
  display:flex;
  flex-direction:column;
  gap:.2rem;
  flex-shrink:0;
  min-height:100vh;
  position:relative;
  z-index:10;
}

.sidebar::after{
  content:'';
  position:absolute;
  top:0;
  right:0;
  bottom:0;
  width:1px;
  background:linear-gradient(
      to bottom,
      transparent,
      rgba(139,60,247,.4) 30%,
      rgba(79,70,229,.3) 70%,
      transparent
  );
}

.sidebar-logo{
  font-size:1.1rem;
  font-weight:800;
  margin-bottom:2rem;
  padding-left:.25rem;
  letter-spacing:-.02em;
}

.sidebar-logo span{
  background:var(--grad);
  -webkit-background-clip:text;
  -webkit-text-fill-color:transparent;
}

.ss{
  font-size:.68rem;
  font-weight:700;
  letter-spacing:.1em;
  text-transform:uppercase;
  color:var(--muted2);
  padding:.6rem .75rem .3rem;
}

.sidebar a{
  display:flex;
  align-items:center;
  gap:.65rem;
  padding:.6rem .85rem;
  border-radius:10px;
  text-decoration:none;
  color:var(--muted);
  font-size:.88rem;
  font-weight:500;
  transition:.18s;
  position:relative;
}

.sidebar a svg{
  opacity:.6;
  flex-shrink:0;
}

.sidebar a:hover{
  background:var(--bg3);
  color:var(--text2);
}

.sidebar a.active{
  background:linear-gradient(
      135deg,
      rgba(139,60,247,.18),
      rgba(79,70,229,.1)
  );
  border:1px solid rgba(139,60,247,.25);
  color:var(--accent2);
}

.sidebar a.active::before{
  content:'';
  position:absolute;
  left:0;
  top:20%;
  bottom:20%;
  width:3px;
  background:var(--grad);
  border-radius:0 3px 3px 0;
}

.sidebar a:hover svg,
.sidebar a.active svg{
  opacity:1;
}

hr.sd{
  border:none;
  border-top:1px solid var(--border);
  margin:.6rem 0;
}

/* MAIN */
.main{
  flex:1;
  padding:2.25rem 2.5rem;
  overflow-x:hidden;
  max-width:1100px;
  position:relative;
  z-index:1;
}

h1{
  font-size:1.65rem;
  font-weight:800;
  letter-spacing:-.03em;
  margin-bottom:1.75rem;
}

/* ALERTS */
.flash{
  padding:.95rem 1.2rem;
  border-radius:12px;
  margin-bottom:1.25rem;
  font-size:.85rem;
}

.flash.ok{
  background:var(--green-bg);
  border:1px solid rgba(52,211,153,.3);
  color:var(--green);
}

.flash.err{
  background:var(--red-bg);
  border:1px solid rgba(248,113,113,.3);
  color:var(--red);
}

/* STATS */
.stats{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(180px,1fr));
  gap:1rem;
  margin-bottom:1.75rem;
}

.stat{
  background:var(--bg3);
  border:1px solid var(--border);
  border-radius:14px;
  padding:1.4rem 1.25rem;
  transition:.2s;
  position:relative;
  overflow:hidden;
}

.stat:hover{
  border-color:var(--border2);
  transform:translateY(-2px);
}

.stat::before{
  content:'';
  position:absolute;
  top:0;
  left:0;
  right:0;
  height:2px;
  background:var(--grad);
  opacity:0;
  transition:.2s;
}

.stat:hover::before{
  opacity:1;
}

.stat .lbl{
  font-size:.73rem;
  color:var(--muted);
  font-weight:600;
  text-transform:uppercase;
  letter-spacing:.06em;
  margin-bottom:.45rem;
}

.stat .val{
  font-size:1.8rem;
  font-weight:800;
  letter-spacing:-.03em;
}

.stat.ok .val{
  color:var(--green);
}

/* SUBSCRIPTION BOX */
.sub-box{
  background:rgba(52,211,153,.05);
  border:1px solid rgba(52,211,153,.25);
  border-radius:14px;
  padding:1.25rem 1.4rem;
  margin-bottom:1.5rem;
}

.sub-box h3{
  color:var(--green);
  font-size:.95rem;
  font-weight:700;
  margin-bottom:.35rem;
}

.sub-box p{
  color:var(--muted);
  font-size:.82rem;
}

/* BUTTON */
.btn{
  display:inline-flex;
  align-items:center;
  gap:.5rem;
  padding:.65rem 1.4rem;
  border-radius:10px;
  text-decoration:none;
  font-size:.88rem;
  font-weight:700;
  color:#fff;
  background:var(--grad);
  box-shadow:0 4px 20px var(--glow);
  transition:.2s;
  margin-bottom:1.5rem;
}

.btn:hover{
  opacity:.9;
  transform:translateY(-2px);
  box-shadow:0 8px 28px var(--glow);
}

/* CARD */
.card{
  background:var(--bg3);
  border:1px solid var(--border);
  border-radius:14px;
  overflow:hidden;
  margin-bottom:1.5rem;
}

.card-header{
  padding:1.1rem 1.4rem;
  border-bottom:1px solid var(--border);
  background:rgba(255,255,255,.01);
  display:flex;
  justify-content:space-between;
  align-items:center;
}

.card-header h2{
  font-size:.92rem;
  font-weight:700;
}

table{
  width:100%;
  border-collapse:collapse;
  font-size:.82rem;
}

th{
  text-align:left;
  padding:.65rem 1rem;
  color:var(--muted);
  border-bottom:1px solid var(--border);
  font-size:.72rem;
  font-weight:600;
  text-transform:uppercase;
  letter-spacing:.06em;
}

td{
  padding:.65rem 1rem;
  border-bottom:1px solid var(--border);
  color:var(--text2);
}

tr:last-child td{
  border-bottom:none;
}

tr:hover td{
  background:rgba(255,255,255,.018);
}

/* STATUS BADGES */
.badge{
  display:inline-flex;
  align-items:center;
  gap:.3rem;
  padding:.18rem .55rem;
  border-radius:20px;
  font-size:.7rem;
  font-weight:700;
}

.b-confirmed{
  background:var(--green-bg);
  color:var(--green);
  border:1px solid rgba(52,211,153,.25);
}

.b-pending{
  background:var(--orange-bg);
  color:var(--orange);
  border:1px solid rgba(251,146,60,.25);
}

.b-failed{
  background:var(--red-bg);
  color:var(--red);
  border:1px solid rgba(248,113,113,.25);
}

.muted{
  color:var(--muted);
  font-size:.78rem;
}

/* Scrollbar */
::-webkit-scrollbar{
  width:5px;
}

::-webkit-scrollbar-thumb{
  background:var(--border2);
  border-radius:20px;
}

::-webkit-scrollbar-thumb:hover{
  background:rgba(139,60,247,.4);
}


  /* =========================================================
     CHAINMIND MOBILE PATCH — appended, nothing removed above
     ========================================================= */

  /* Mobile top bar */
  .cm-mobile-bar {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0;
    height: 54px;
    z-index: 9000;
    background: var(--bg2, #0b0d1c);
    border-bottom: 1px solid var(--border, #1e2040);
    align-items: center;
    justify-content: space-between;
    padding: 0 1rem;
    gap: .75rem;
  }
  .cm-mobile-bar .cm-mob-logo {
    display: flex; align-items: center; gap: .55rem; text-decoration: none;
  }
  .cm-hamburger {
    width: 42px; height: 42px;
    border-radius: 9px;
    background: transparent;
    border: 1px solid var(--border2, #272a52);
    color: var(--text2, #c5c8f0);
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    gap: 5px; cursor: pointer; flex-shrink: 0;
    transition: border-color .18s, color .18s;
  }
  .cm-hamburger:hover { border-color: var(--accent, #a78bfa); color: var(--accent, #a78bfa); }
  .cm-hamburger span {
    display: block; width: 20px; height: 2px;
    background: currentColor; border-radius: 2px;
    transition: transform .25s, opacity .2s;
  }
  .cm-hamburger.cm-open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
  .cm-hamburger.cm-open span:nth-child(2) { opacity: 0; transform: scaleX(0); }
  .cm-hamburger.cm-open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

  /* Overlay */
  .cm-overlay {
    display: none;
    position: fixed; inset: 0;
    background: rgba(0,0,0,.65);
    backdrop-filter: blur(4px);
    z-index: 8900;
  }
  .cm-overlay.cm-show { display: block; }

  @media (max-width: 768px) {

    /* Show the mobile bar */
    .cm-mobile-bar { display: flex !important; }

    /* Push body content below the bar */
    body { padding-top: 54px !important; }

    /* Turn sidebar into a slide-in drawer */
    .sidebar {
      display: flex !important;          /* override any display:none from original CSS */
      flex-direction: column !important;
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      bottom: 0 !important;
      width: 270px !important;
      min-height: 100vh !important;
      z-index: 9500 !important;
      transform: translateX(-100%) !important;
      transition: transform .28s cubic-bezier(.4, 0, .2, 1) !important;
      overflow-y: auto !important;
      overflow-x: hidden !important;
      /* keep original background/border */
    }
    .sidebar.cm-open {
      transform: translateX(0) !important;
      box-shadow: 4px 0 40px rgba(0,0,0,.6) !important;
    }

    /* Main content fills full width */
    .main { overflow-x: hidden; }

    /* Stats grid: 2 columns on mobile */
    .stats { grid-template-columns: repeat(2, 1fr) !important; }

    /* Tabs: horizontal scroll */
    .tabs {
      overflow-x: auto !important;
      -webkit-overflow-scrolling: touch;
      scrollbar-width: none;
      flex-wrap: nowrap !important;
      padding-left: 1rem !important;
      padding-right: 1rem !important;
    }
    .tabs::-webkit-scrollbar { display: none; }
    .tab-btn { white-space: nowrap; }

    /* Tables: horizontal scroll wrapper */
    .card { overflow-x: auto; }
    table { min-width: 480px; }

    /* Overview padding */
    .overview-scroll { padding: 1.25rem 1rem !important; }

    /* Page header sizing */
    h1 { font-size: 1.3rem !important; }

    /* Reduce main padding */
    .main { padding: 1.25rem 1rem !important; }

    /* Collapse multi-col form rows */
    .fld-row { grid-template-columns: 1fr !important; }

    /* Payment method grids */
    .pay-methods { grid-template-columns: 1fr !important; }
    .info-grid { grid-template-columns: 1fr 1fr !important; }

    /* Hide chat sidebar on small screens */
    .chat-sidebar { display: none !important; }
    .chat-panel { flex-direction: column !important; }

    /* Input area */
    .input-area { padding: .75rem 1rem 1rem !important; }
  }

  @media (max-width: 480px) {
    .stats { grid-template-columns: 1fr 1fr !important; }
    .stat-card .sc-value,
    .stat .val { font-size: 1.4rem !important; }
    .page-header .greeting-line { font-size: 1.2rem !important; }
    .overview-scroll { padding: 1rem .85rem !important; }
  }
  </style></head><body>

  <!-- ── CHAINMIND MOBILE TOPBAR ───────────────────── -->
  <div class="cm-mobile-bar" id="cmBar">
    <a href="/dashboard/" class="cm-mob-logo">
      <div style="width:32px;height:32px;background:linear-gradient(135deg,#8b3cf7,#4f46e5);border-radius:9px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.85rem;color:#fff;flex-shrink:0;box-shadow:0 0 14px rgba(139,60,247,.5)">CM</div>
      <div style="font-size:1rem;font-weight:800;letter-spacing:-.02em"><span style="color:#c4b5fd">Chain</span><span style="color:#eef0ff">Mind</span></div>
    </a>
    <button class="cm-hamburger" id="cmHamburger" onclick="cmToggle()" aria-label="Toggle navigation">
      <span></span><span></span><span></span>
    </button>
  </div>
  <div class="cm-overlay" id="cmOverlay" onclick="cmClose()"></div>
  <!-- ── END MOBILE TOPBAR ─────────────────────────── -->
  
<nav class="sidebar">
    <div class="sidebar-logo">
    <div class="logo-mark">C</div>
    <div class="logo-text"><span class="chain">Chain</span><span class="mind">Mind</span></div>
  </div>
    <div class="ss">Account</div>
  <a href="/dashboard/"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
    Overview
  </a>
      <a href="/dashboard/?tab=chat">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
    Chat
  </a>
  <a href="/dashboard/billing.php" class="active"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
    Billing
  </a>
  <a href="/dashboard/node-earnings.php"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
    Node Earnings
  </a>
   <hr class="sd">
     <a href="/"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></svg>
    Home
  </a>
   <a href="/docs.php">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14,2 14,8 20,8"/></svg>
    API Docs
  </a>
    <hr class="sd">
    <?php if ($is_admin): ?><div class="ss">Admin</div>
  <a href="/admin/"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
    Admin Panel
  </a>
    <hr class="sd">
    <?php endif; ?>

   <a href="/dashboard/node-settings.php"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
      Settings
    </a>
  <a href="/dashboard/node-download.php">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
    Download Guide
  </a>
  
    <!-- ── NEW PAGES ─────────────────────────────── -->
    <hr class="sd">
    <div class="ss">More</div>
    <a href="/dashboard/profile.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      Profile
    </a>
    <a href="/dashboard/api-keys.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.78 7.78 5.5 5.5 0 017.78-7.78l1.06-1.06a2 2 0 012.83 0l1.06 1.06a2 2 0 010 2.83z"/></svg>
      API Keys
    </a>
    <a href="/dashboard/notifications.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
      Notifications
    </a>
    <a href="/dashboard/support.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
      Support
    </a>
    <!-- ── END NEW PAGES ──────────────────────────── -->
  
  <a href="/auth/logout.php"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16,17 21,12 16,7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
    Sign out
  </a>
  </nav>
<div class="main">
  <h1 style="font-family:var(--display);letter-spacing:-.03em">Billing</h1>
  <?= $flash ?>
  <div class="stats">
    <div class="stat ok"><div class="lbl">Credit Balance</div><div class="val"><?= number_format($balance) ?></div></div>
    <div class="stat"><div class="lbl">&#8776; USD Value</div><div class="val">$<?= number_format($balance / CREDITS_PER_USD, 4) ?></div></div>
    <div class="stat"><div class="lbl">1 USD</div><div class="val"><?= number_format(CREDITS_PER_USD) ?> cr</div></div>
    <div class="stat"><div class="lbl">Jobs run</div><div class="val"><?= number_format($key_row['total_jobs'] ?? 0) ?></div></div>
  </div>
  <?php if ($sub): ?>
  <div class="sub-box">
    <h3>✅ <?= ucfirst($sub['plan']) ?> Plan — Active</h3>
    <p><?= number_format($sub['credits_month']) ?> credits/month · $<?= number_format($sub['price_usd'], 2) ?>/month · Renews <?= $sub['renews_at'] ?> · via <?= ucfirst($sub['provider']) ?></p>
  </div>
  <?php endif; ?>
  <a class="btn" href="/api/billing/buy-credits.php">+ Buy Credits / Subscribe</a>

  <div class="card">
    <div class="card-header"><h2>Payment History</h2></div>
    <table>
      <thead><tr><th>Date</th><th>Provider</th><th>USD</th><th>Credits</th><th>Status</th><th>Reference</th></tr></thead>
      <tbody>
      <?php foreach ($payments as $p): ?>
      <tr>
        <td><?= substr($p['created_at'], 0, 10) ?></td>
        <td><?= ucfirst($p['provider']) ?></td>
        <td>$<?= number_format($p['amount_usd'], 2) ?></td>
        <td><?= $p['credits_added'] > 0 ? '+' . number_format($p['credits_added']) : '—' ?></td>
        <td><span class="badge b-<?= $p['status'] ?>"><?= $p['status'] ?></span></td>
        <td class="muted"><?= htmlspecialchars(substr($p['provider_ref'], 0, 24)) ?>&</td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($payments)): ?><tr><td colspan="6" style="text-align:center;padding:1.5rem;color:var(--muted)">No payments yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="card">
    <div class="card-header"><h2>Recent Deductions (by Job)</h2></div>
    <table>
      <thead><tr><th>Date</th><th>Job ID</th><th>Model</th><th>Credits used</th></tr></thead>
      <tbody>
      <?php foreach ($deductions as $d): ?>
      <tr>
        <td><?= substr($d['created_at'], 0, 10) ?></td>
        <td class="muted"><?= substr($d['job_id'], 0, 14) ?>&</td>
        <td><?= htmlspecialchars($d['model'] ?? '—') ?></td>
        <td style="color:#f85149">-<?= number_format($d['amount']) ?></td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($deductions)): ?><tr><td colspan="4" style="text-align:center;padding:1.5rem;color:var(--muted)">No deductions yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

  <!-- ── CHAINMIND MOBILE JS ────────────────────────── -->
  <script>
  (function() {
    function cmToggle() {
      var sb = document.querySelector('.sidebar');
      var ov = document.getElementById('cmOverlay');
      var hb = document.getElementById('cmHamburger');
      if (sb) sb.classList.toggle('cm-open');
      if (ov) ov.classList.toggle('cm-show');
      if (hb) hb.classList.toggle('cm-open');
    }
    function cmClose() {
      var sb = document.querySelector('.sidebar');
      var ov = document.getElementById('cmOverlay');
      var hb = document.getElementById('cmHamburger');
      if (sb) sb.classList.remove('cm-open');
      if (ov) ov.classList.remove('cm-show');
      if (hb) hb.classList.remove('cm-open');
    }
    window.cmToggle = cmToggle;
    window.cmClose  = cmClose;
    document.addEventListener('DOMContentLoaded', function() {
      // Close sidebar when any sidebar link is tapped on mobile
      var links = document.querySelectorAll('.sidebar a');
      links.forEach(function(l) {
        l.addEventListener('click', function() {
          if (window.innerWidth <= 768) cmClose();
        });
      });
      // Close on Escape key
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') cmClose();
      });
    });
  })();
  </script>
  <!-- ── END MOBILE JS ──────────────────────────────── -->
  
</body></html>
