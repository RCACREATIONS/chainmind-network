<?php
// ============================================================
// ChainMind  Node Settings & Connection Page
// Upload to: dashboard/node-settings.php
// ============================================================
session_start();
require_once __DIR__ . '/../api/_helpers.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /auth/login.php?next=/dashboard/node-settings.php');
    exit;
}

$user_id    = (int)$_SESSION['user_id'];
$user_name  = $_SESSION['user_name'] ?? 'User';
$user_email = $_SESSION['user_email'] ?? '';

// ── Fetch all nodes linked to this user ──────────────────────
$nodes = db()->prepare(
    'SELECT n.*,
            COALESCE(
              (SELECT SUM(iq_amount)
               FROM withdrawals w
               WHERE w.node_id = n.id AND w.status != "rejected"),
            0) AS committed_iq
     FROM nodes n
     WHERE n.user_id = ?
     ORDER BY n.linked_at DESC'
);
$nodes->execute([$user_id]);
$nodes = $nodes->fetchAll();

// ── Generate a fresh pairing token (10-min expiry) ───────────
// Purge stale tokens for this user + any globally expired ones
db()->prepare(
    'DELETE FROM pairing_tokens
     WHERE user_id = ? OR expires_at < NOW()'
)->execute([$user_id]);

$link_token = bin2hex(random_bytes(24)); // 48-char hex

db()->prepare(
    'INSERT INTO pairing_tokens (token, user_id, expires_at)
     VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE))'
)->execute([$link_token, $user_id]);

$central_url = 'https://chainmind.com.ng';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Node Settings · ChainMind</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap">
<link rel="icon" type="image/png" href="../ChatGPT Image Jun 2, 2026, 06_43_57 AM.png">
<style>
:root {
  --bg:        #07080f;
  --bg2:       #0b0d1c;
  --bg3:       #101228;
  --bg4:       #161935;
  --border:    #1e2040;
  --border2:   #272a52;
  --border3:   #323670;

  --text:      #eef0ff;
  --text2:     #c5c8f0;
  --muted:     #6b6f9e;
  --muted2:    #474b78;

  --purple:    #8b3cf7;
  --purple-1:  #8b3cf7;
  --purple-2:  #6d28d9;
  --purple2:   #6d28d9;
  --violet:    #7c3aed;
  --indigo:    #4f46e5;
  --accent:    #a78bfa;
  --accent-2:  #c4b5fd;
  --accent2:   #c4b5fd;
  --blue:      #60a5fa;
  --neon:      #a78bfa;
  --glow:      rgba(139, 60, 247, .35);

  --green:     #34d399;
  --green-bg:  rgba(52, 211, 153, .12);
  --green-bd:  rgba(52, 211, 153, .35);
  --orange:    #fb923c;
  --orange-bg: rgba(251, 146, 60, .12);
  --red:       #f87171;
  --red-bg:    rgba(248, 113, 113, .12);
  --gold:      #f59e0b;

  --grad:      linear-gradient(135deg, var(--purple-1), var(--indigo));
  --grad-soft: linear-gradient(135deg, rgba(139,60,247,.15), rgba(79,70,229,.08));

  --font:    'Plus Jakarta Sans', system-ui, sans-serif;
  --display: 'Syne', sans-serif;
  --mono:    'JetBrains Mono', monospace;

  --r-sm: 8px;
  --r-md: 12px;
  --r-lg: 16px;
  --r-xl: 20px;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  background: var(--bg);
  color: var(--text);
  font-family: var(--font);
  display: flex;
  min-height: 100vh;
  position: relative;
}

body::before {
  content: '';
  position: fixed;
  inset: 0;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
  opacity: .5;
  pointer-events: none;
  z-index: 0;
}

/* ─── SIDEBAR ──────────────────────────────────────────────── */
.sidebar {
  width: 240px;
  background: var(--bg2);
  border-right: 1px solid var(--border);
  padding: 1.75rem 1.25rem;
  display: flex;
  flex-direction: column;
  gap: .2rem;
  flex-shrink: 0;
  min-height: 100vh;
  position: relative;
  z-index: 10;
}

.sidebar::after {
  content: '';
  position: absolute;
  top: 0; right: 0; bottom: 0;
  width: 1px;
  background: linear-gradient(to bottom, transparent, rgba(139,60,247,.4) 30%, rgba(79,70,229,.3) 70%, transparent);
}

.sidebar-logo {
  display: flex;
  align-items: center;
  gap: .65rem;
  margin-bottom: 2rem;
  padding-left: .15rem;
  text-decoration: none;
}

.logo-mark {
  width: 34px;
  height: 34px;
  background: var(--grad);
  border-radius: 9px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--display);
  font-size: 1rem;
  font-weight: 800;
  color: #fff;
  box-shadow: 0 0 18px var(--glow);
  flex-shrink: 0;
  letter-spacing: -.5px;
}

.logo-text { font-family: var(--display); font-size: 1.05rem; font-weight: 800; letter-spacing: -.03em; line-height: 1; }
.logo-text .chain { color: var(--accent2); }
.logo-text .mind  { color: var(--text); }

.ss {
  font-size: .68rem;
  font-weight: 700;
  letter-spacing: .1em;
  color: var(--muted2);
  text-transform: uppercase;
  padding: .6rem .75rem .3rem;
  margin-top: .5rem;
}

.sidebar a {
  display: flex;
  align-items: center;
  gap: .65rem;
  padding: .6rem .85rem;
  border-radius: 10px;
  color: var(--muted);
  text-decoration: none;
  font-size: .88rem;
  font-weight: 500;
  transition: all .18s ease;
  position: relative;
}

.sidebar a svg { opacity: .6; flex-shrink: 0; transition: opacity .18s; }
.sidebar a:hover { background: var(--bg3); color: var(--text2); }
.sidebar a:hover svg { opacity: 1; }

.sidebar a.active {
  background: linear-gradient(135deg, rgba(139,60,247,.18), rgba(79,70,229,.1));
  border: 1px solid rgba(139,60,247,.25);
  color: var(--accent2);
}

.sidebar a.active::before {
  content: '';
  position: absolute;
  left: 0; top: 20%; bottom: 20%;
  width: 3px;
  background: var(--grad);
  border-radius: 0 3px 3px 0;
}

.sidebar a.active svg { opacity: 1; }

hr.sd { border: none; border-top: 1px solid var(--border); margin: .6rem 0; }

/* ─── MAIN ─────────────────────────────────────────────────── */
.main {
  flex: 1;
  padding: 2.25rem 2.5rem;
  overflow-x: hidden;
  position: relative;
  z-index: 1;
  max-width: 900px;
}

h1 { font-size: 1.55rem; font-weight: 800; letter-spacing: -.03em; margin-bottom: .25rem; }
h2 { font-size: 1rem; font-weight: 700; letter-spacing: -.01em; margin-bottom: .75rem; }
.page-sub { color: var(--muted); font-size: .88rem; margin-bottom: 2rem; }

/* ─── CARDS ─────────────────────────────────────────────────── */
.card {
  background: var(--bg3);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  transition: border-color .2s;
}

.card:hover { border-color: var(--border2); }

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  padding-bottom: .75rem;
  border-bottom: 1px solid var(--border);
}

/* ─── BADGES ────────────────────────────────────────────────── */
.badge {
  display: inline-flex;
  align-items: center;
  gap: .3rem;
  padding: .18rem .55rem;
  border-radius: 20px;
  font-size: .7rem;
  font-weight: 700;
  letter-spacing: .03em;
}

.b-online  { background: var(--green-bg); color: var(--green); border: 1px solid rgba(52,211,153,.25); }
.b-offline { background: rgba(255,255,255,.05); color: var(--muted); border: 1px solid var(--border2); }
.b-busy    { background: rgba(139,60,247,.15); color: var(--accent); border: 1px solid rgba(139,60,247,.25); }

/* ─── NODE GRID ─────────────────────────────────────────────── */
.node-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 1rem;
  margin-bottom: 1rem;
}

.ng-item {
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: .9rem;
}

.ng-label { font-size: .72rem; color: var(--muted); text-transform: uppercase; letter-spacing: .04em; margin-bottom: .3rem; }
.ng-val   { font-size: 1rem; font-weight: 700; color: var(--text); }
.ng-val.green  { color: var(--green); }
.ng-val.orange { color: var(--orange); }

/* ─── TOKEN BOX ─────────────────────────────────────────────── */
.token-box {
  background: var(--bg2);
  border: 1px solid var(--border2);
  border-radius: 10px;
  padding: .85rem 1rem;
  font-family: var(--mono);
  font-size: .82rem;
  color: var(--accent);
  word-break: break-all;
  display: flex;
  align-items: center;
  gap: .75rem;
  flex-wrap: wrap;
  margin: .75rem 0;
}

.copy-btn {
  background: rgba(139,60,247,.15);
  border: 1px solid rgba(139,60,247,.3);
  color: var(--accent);
  border-radius: 7px;
  padding: .35rem .8rem;
  cursor: pointer;
  font-size: .78rem;
  font-weight: 600;
  transition: .18s;
  white-space: nowrap;
}

.copy-btn:hover { background: rgba(139,60,247,.28); border-color: rgba(139,60,247,.5); }

/* ─── BUTTONS ───────────────────────────────────────────────── */
.btn {
  display: inline-flex;
  align-items: center;
  gap: .45rem;
  padding: .65rem 1.25rem;
  border-radius: 10px;
  font-size: .88rem;
  font-weight: 700;
  cursor: pointer;
  border: none;
  text-decoration: none;
  transition: .18s;
}

.btn-primary { background: var(--grad); color: #fff; box-shadow: 0 4px 18px var(--glow); }
.btn-primary:hover { transform: translateY(-2px); }

.btn-danger { background: var(--red-bg); color: var(--red); border: 1px solid rgba(248,113,113,.3); }
.btn-danger:hover { background: rgba(248,113,113,.25); }

.btn-ghost { background: transparent; border: 1px solid var(--border2); color: var(--muted); }
.btn-ghost:hover { color: var(--text); border-color: rgba(139,60,247,.35); }

/* ─── INFO / MESSAGE BOXES ──────────────────────────────────── */
.info-box {
  background: var(--grad-soft);
  border: 1px solid rgba(139,60,247,.25);
  border-radius: 10px;
  padding: 1rem 1.15rem;
  color: var(--text2);
  margin: .75rem 0;
  font-size: .87rem;
}

.msg { padding: .7rem .95rem; border-radius: 8px; font-size: .83rem; margin: .5rem 0; display: none; }
.msg.show { display: block; }
.msg-ok  { background: var(--green-bg); border: 1px solid rgba(52,211,153,.25); color: var(--green); }
.msg-err { background: var(--red-bg);   border: 1px solid rgba(248,113,113,.25); color: var(--red); }

/* ─── TABLE ─────────────────────────────────────────────────── */
table { width: 100%; border-collapse: collapse; font-size: .82rem; }
th { text-align: left; padding: .65rem .9rem; color: var(--muted); border-bottom: 1px solid var(--border); font-size: .72rem; text-transform: uppercase; letter-spacing: .06em; }
td { padding: .65rem .9rem; border-bottom: 1px solid var(--border); color: var(--text2); }
tr:hover td { background: rgba(255,255,255,.018); }
tr:last-child td { border-bottom: none; }

code {
  background: var(--bg2);
  color: var(--accent);
  border: 1px solid var(--border2);
  padding: .12rem .4rem;
  border-radius: 4px;
  font-family: var(--mono);
  font-size: .82em;
}

.timer { color: var(--orange); font-size: .75rem; font-family: var(--mono); }
.timer.expired { color: var(--red); }

.no-nodes { text-align: center; padding: 2.5rem; color: var(--muted); }

/* ─── STEPS LIST ────────────────────────────────────────────── */
ol.steps {
  padding-left: 1.35rem;
  display: flex;
  flex-direction: column;
  gap: .55rem;
  color: var(--text2);
  font-size: .86rem;
  line-height: 1.6;
}

ol.steps li::marker { color: var(--muted2); }

/* ─── SPINNING LOADER ───────────────────────────────────────── */
@keyframes spin { to { transform: rotate(360deg); } }
.spin { display: inline-block; animation: spin .7s linear infinite; }


  /* =========================================================
     CHAINMIND MOBILE PATCH — appended, nothing removed above
     ========================================================= */

  /* Mobile top bar */
  .cm-mobile-bar {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0;
    height: 54px;
    z-index: 9000;
    background: var(--bg2, #0b0d1c);
    border-bottom: 1px solid var(--border, #1e2040);
    align-items: center;
    justify-content: space-between;
    padding: 0 1rem;
    gap: .75rem;
  }
  .cm-mobile-bar .cm-mob-logo {
    display: flex; align-items: center; gap: .55rem; text-decoration: none;
  }
  .cm-hamburger {
    width: 42px; height: 42px;
    border-radius: 9px;
    background: transparent;
    border: 1px solid var(--border2, #272a52);
    color: var(--text2, #c5c8f0);
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    gap: 5px; cursor: pointer; flex-shrink: 0;
    transition: border-color .18s, color .18s;
  }
  .cm-hamburger:hover { border-color: var(--accent, #a78bfa); color: var(--accent, #a78bfa); }
  .cm-hamburger span {
    display: block; width: 20px; height: 2px;
    background: currentColor; border-radius: 2px;
    transition: transform .25s, opacity .2s;
  }
  .cm-hamburger.cm-open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
  .cm-hamburger.cm-open span:nth-child(2) { opacity: 0; transform: scaleX(0); }
  .cm-hamburger.cm-open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

  /* Overlay */
  .cm-overlay {
    display: none;
    position: fixed; inset: 0;
    background: rgba(0,0,0,.65);
    backdrop-filter: blur(4px);
    z-index: 8900;
  }
  .cm-overlay.cm-show { display: block; }

  @media (max-width: 768px) {

    /* Show the mobile bar */
    .cm-mobile-bar { display: flex !important; }

    /* Push body content below the bar */
    body { padding-top: 54px !important; }

    /* Turn sidebar into a slide-in drawer */
    .sidebar {
      display: flex !important;          /* override any display:none from original CSS */
      flex-direction: column !important;
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      bottom: 0 !important;
      width: 270px !important;
      min-height: 100vh !important;
      z-index: 9500 !important;
      transform: translateX(-100%) !important;
      transition: transform .28s cubic-bezier(.4, 0, .2, 1) !important;
      overflow-y: auto !important;
      overflow-x: hidden !important;
      /* keep original background/border */
    }
    .sidebar.cm-open {
      transform: translateX(0) !important;
      box-shadow: 4px 0 40px rgba(0,0,0,.6) !important;
    }

    /* Main content fills full width */
    .main { overflow-x: hidden; }

    /* Stats grid: 2 columns on mobile */
    .stats { grid-template-columns: repeat(2, 1fr) !important; }

    /* Tabs: horizontal scroll */
    .tabs {
      overflow-x: auto !important;
      -webkit-overflow-scrolling: touch;
      scrollbar-width: none;
      flex-wrap: nowrap !important;
      padding-left: 1rem !important;
      padding-right: 1rem !important;
    }
    .tabs::-webkit-scrollbar { display: none; }
    .tab-btn { white-space: nowrap; }

    /* Tables: horizontal scroll wrapper */
    .card { overflow-x: auto; }
    table { min-width: 480px; }

    /* Overview padding */
    .overview-scroll { padding: 1.25rem 1rem !important; }

    /* Page header sizing */
    h1 { font-size: 1.3rem !important; }

    /* Reduce main padding */
    .main { padding: 1.25rem 1rem !important; }

    /* Collapse multi-col form rows */
    .fld-row { grid-template-columns: 1fr !important; }

    /* Payment method grids */
    .pay-methods { grid-template-columns: 1fr !important; }
    .info-grid { grid-template-columns: 1fr 1fr !important; }

    /* Hide chat sidebar on small screens */
    .chat-sidebar { display: none !important; }
    .chat-panel { flex-direction: column !important; }

    /* Input area */
    .input-area { padding: .75rem 1rem 1rem !important; }
  }

  @media (max-width: 480px) {
    .stats { grid-template-columns: 1fr 1fr !important; }
    .stat-card .sc-value,
    .stat .val { font-size: 1.4rem !important; }
    .page-header .greeting-line { font-size: 1.2rem !important; }
    .overview-scroll { padding: 1rem .85rem !important; }
  }
  </style>
</head>
<body>

  <!-- ── CHAINMIND MOBILE TOPBAR ───────────────────── -->
  <div class="cm-mobile-bar" id="cmBar">
    <a href="/dashboard/" class="cm-mob-logo">
      <div style="width:32px;height:32px;background:linear-gradient(135deg,#8b3cf7,#4f46e5);border-radius:9px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.85rem;color:#fff;flex-shrink:0;box-shadow:0 0 14px rgba(139,60,247,.5)">CM</div>
      <div style="font-size:1rem;font-weight:800;letter-spacing:-.02em"><span style="color:#c4b5fd">Chain</span><span style="color:#eef0ff">Mind</span></div>
    </a>
    <button class="cm-hamburger" id="cmHamburger" onclick="cmToggle()" aria-label="Toggle navigation">
      <span></span><span></span><span></span>
    </button>
  </div>
  <div class="cm-overlay" id="cmOverlay" onclick="cmClose()"></div>
  <!-- ── END MOBILE TOPBAR ─────────────────────────── -->
  

<div class="sidebar">
  <a href="/dashboard/" class="sidebar-logo">
    <div class="logo-mark">CM</div>
    <div class="logo-text"><span class="chain">Chain</span><span class="mind">Mind</span></div>
  </a>
  <div class="ss">Account</div>
  <a href="/dashboard/">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>Overview</a>
  <a href="/dashboard/?tab=chat">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>Chat</a>
  <a href="/dashboard/billing.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>Billing</a>
  <a href="/dashboard/api-keys.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.78 7.78 5.5 5.5 0 017.78-7.78l1.06-1.06a2 2 0 012.83 0l1.06 1.06a2 2 0 010 2.83z"/></svg>API Keys</a>
  <a href="/dashboard/node-earnings.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>Node Earnings</a>
  <hr class="sd">
  <div class="ss">Tools</div>
  <a href="/dashboard/profile.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Profile</a>
  <a href="/dashboard/notifications.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>Notifications</a>
  <a href="/dashboard/support.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>Support</a>
  <hr class="sd">
  <div class="ss">Node</div>
  <a href="/dashboard/node-settings.php" class="active">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>Node Settings</a>
  <a href="/dashboard/node-download.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>Download Guide</a>
  <hr class="sd">
  <a href="/">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></svg>Home</a>
  <a href="/docs.php">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14,2 14,8 20,8"/></svg>API Docs</a>
  <a href="/auth/logout.php" style="margin-top:auto;color:var(--muted)">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16,17 21,12 16,7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>Sign out</a>
</div>

<!-- ═══════════════════════ MAIN ════════════════════════════════ -->
<div class="main">
  <h1>Node Settings</h1>
  <p class="page-sub">Link your node software to this web account and manage your connected nodes.</p>

  <!-- ── LINKED NODES ── -->
  <?php if (!empty($nodes)): ?>
    <?php foreach ($nodes as $nd):
      $avail_iq = max(0, (float)$nd['iq_earned'] - (float)$nd['committed_iq']);
      $models   = json_decode($nd['models'] ?? '[]', true) ?: [];
      $idle_sec = $nd['last_seen'] ? (time() - strtotime($nd['last_seen'])) : null;
      $idle_min = $idle_sec !== null ? (int)($idle_sec / 60) : null;
      $status   = htmlspecialchars($nd['status']);
    ?>
    <div class="card">
      <div class="card-header">
        <div style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap">
          <h2 style="margin:0"><?= htmlspecialchars($nd['name']) ?></h2>
          <span class="badge b-<?= $status ?>"><?= $status ?></span>
          <span style="font-size:.72rem;color:var(--muted);font-weight:600;letter-spacing:.04em"><?= strtoupper($nd['tier']) ?></span>
        </div>
        <button class="btn btn-danger" onclick="unlinkNode('<?= htmlspecialchars($nd['id']) ?>')">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          Unlink
        </button>
      </div>

      <div class="node-grid">
        <div class="ng-item">
          <div class="ng-label">Node ID</div>
          <div class="ng-val" style="font-size:.72rem;font-family:var(--mono);color:var(--muted)"><?= htmlspecialchars(substr($nd['id'], 0, 16)) ?>…</div>
        </div>
        <div class="ng-item">
          <div class="ng-label">IQ Earned</div>
          <div class="ng-val green"><?= number_format($nd['iq_earned'], 4) ?> IQ</div>
        </div>
        <div class="ng-item">
          <div class="ng-label">Available IQ</div>
          <div class="ng-val green"><?= number_format($avail_iq, 4) ?> IQ</div>
        </div>
        <div class="ng-item">
          <div class="ng-label">Jobs Done</div>
          <div class="ng-val"><?= number_format($nd['jobs_done']) ?></div>
        </div>
        <div class="ng-item">
          <div class="ng-label">Reputation</div>
          <div class="ng-val"><?= number_format($nd['reputation'], 1) ?></div>
        </div>
        <div class="ng-item">
          <div class="ng-label">Last Seen</div>
          <div class="ng-val <?= $idle_min !== null && $idle_min < 2 ? 'green' : 'orange' ?>">
            <?php
              if ($idle_min === null) echo '—';
              elseif ($idle_min < 1)  echo 'Just now';
              else                    echo "{$idle_min}m ago";
            ?>
          </div>
        </div>
      </div>

      <?php if (!empty($models)): ?>
      <div style="margin:.5rem 0 .75rem;font-size:.78rem;color:var(--muted)">
        Models:&nbsp;
        <?php foreach ($models as $m): ?>
          <code><?= htmlspecialchars($m) ?></code>&nbsp;
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <?php if ($nd['url']): ?>
      <div style="font-size:.78rem;color:var(--muted);margin-bottom:.5rem">
        Public URL: <code><?= htmlspecialchars($nd['url']) ?></code>
      </div>
      <?php endif; ?>

      <div style="margin-top:1rem;display:flex;gap:.5rem;flex-wrap:wrap">
        <a href="/dashboard/node-earnings.php" class="btn btn-primary">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
          View Earnings &amp; Withdraw
        </a>
        <a href="/dashboard/node-earnings.php?node_id=<?= urlencode($nd['id']) ?>" class="btn btn-ghost">
          Full Stats
        </a>
      </div>
    </div>
    <?php endforeach; ?>
  <?php else: ?>
  <div class="card">
    <div class="no-nodes">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" style="opacity:.25;margin-bottom:.75rem"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
      <div style="font-weight:700;margin-bottom:.35rem">No nodes linked yet</div>
      <div style="font-size:.85rem">Follow the steps below to link your node software to this account.</div>
    </div>
  </div>
  <?php endif; ?>

  <!-- ── LINK NEW NODE ── -->
  <div class="card">
    <h2>Link a Node to This Account</h2>
    <p style="color:var(--muted);font-size:.85rem;margin-bottom:1rem">
      Generate a one-time token, then paste it into your node dashboard to pair it with this account.
      The token expires in <strong>10 minutes</strong>.
    </p>

    <div class="info-box">
      Your pairing token is valid for 10 minutes.
      Time remaining: <span id="token-timer" class="timer"></span>
    </div>

    <div class="token-box">
      <span id="link-token" style="flex:1"><?= htmlspecialchars($link_token) ?></span>
      <button class="copy-btn" id="copy-btn" onclick="copyToken()">⌘ Copy</button>
    </div>

    <ol class="steps">
      <li>Copy the token above.</li>
      <li>Open your <strong>node dashboard</strong> (usually <code>http://localhost:8501</code>).</li>
      <li>Go to <strong>⚙ Settings → Link Web Account</strong>.</li>
      <li>Paste the token and click <strong>Link Account</strong>.</li>
      <li>Refresh this page — your node will appear above.</li>
    </ol>

    <div style="margin-top:1.25rem;display:flex;gap:.5rem;flex-wrap:wrap;align-items:center">
      <button class="btn btn-ghost" id="refresh-btn" onclick="refreshToken()">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>
        New Token
      </button>
      <button class="btn btn-primary" onclick="location.reload()">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 102.13-9.36L1 10"/></svg>
        Refresh Page
      </button>
    </div>
    <div id="refresh-msg" class="msg"></div>
  </div>

  <!-- ── HOW IT WORKS ── -->
  <div class="card" style="padding:1.25rem">
    <h2>How Node Linking Works</h2>
    <ol class="steps">
      <li>Your node software runs locally (or on a server) and earns IQ tokens by processing AI jobs from the ChainMind network.</li>
      <li>Linking connects your node's earnings to this web account so you can see real-time stats and request withdrawals here.</li>
      <li>Your node's data (jobs, IQ, reputation) updates every 30 seconds via heartbeat.</li>
      <li>Withdrawals are managed from the <a href="/dashboard/node-earnings.php" style="color:var(--accent)">Earnings page</a>.</li>
    </ol>
  </div>
</div><!-- /main -->

<script>
// ── Copy token ──────────────────────────────────────────────
function copyToken() {
  const token = document.getElementById('link-token').textContent.trim();
  navigator.clipboard.writeText(token).then(() => {
    const btn = document.getElementById('copy-btn');
    btn.textContent = '✓ Copied!';
    setTimeout(() => btn.textContent = '⌘ Copy', 2500);
  });
}

// ── Countdown timer (10 min from page load) ─────────────────
let secsLeft = 600;
const timerEl = document.getElementById('token-timer');

function updateTimer() {
  if (secsLeft <= 0) {
    timerEl.textContent = '⚠ Expired — generate a new token';
    timerEl.classList.add('expired');
    return;
  }
  const m = Math.floor(secsLeft / 60);
  const s = secsLeft % 60;
  timerEl.textContent = `${m}:${s.toString().padStart(2, '0')}`;
  secsLeft--;
}

updateTimer();
setInterval(updateTimer, 1000);

// ── Refresh token (AJAX) ────────────────────────────────────
async function refreshToken() {
  const btn = document.getElementById('refresh-btn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spin">↻</span> Generating…';

  try {
    const r = await fetch('/api/node/link.php', { method: 'POST' });
    const d = await r.json();

    if (d.token) {
      document.getElementById('link-token').textContent = d.token;
      secsLeft = 600;
      timerEl.classList.remove('expired');
      showMsg('refresh-msg', '✓ New token generated. You have 10 minutes.', true);
    } else {
      showMsg('refresh-msg', '✗ ' + (d.error || 'Failed to generate token.'), false);
    }
  } catch (e) {
    showMsg('refresh-msg', '✗ Network error. Please try again.', false);
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg> New Token';
  }
}

// ── Unlink node ─────────────────────────────────────────────
async function unlinkNode(nodeId) {
  if (!confirm('Unlink this node? Its earnings history stays but it will no longer show in your account.')) return;

  try {
    const r = await fetch('/api/node/unlink.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ node_id: nodeId }),
    });
    const d = await r.json();
    if (d.unlinked) {
      location.reload();
    } else {
      alert('Error: ' + (d.error || 'Unknown error'));
    }
  } catch (e) {
    alert('Network error. Please try again.');
  }
}

// ── Helper ──────────────────────────────────────────────────
function showMsg(id, text, ok) {
  const el = document.getElementById(id);
  el.className = 'msg show ' + (ok ? 'msg-ok' : 'msg-err');
  el.textContent = text;
  // Auto-hide success after 5s
  if (ok) setTimeout(() => { el.classList.remove('show'); }, 5000);
}
</script>

  <!-- ── CHAINMIND MOBILE JS ────────────────────────── -->
  <script>
  (function() {
    function cmToggle() {
      var sb = document.querySelector('.sidebar');
      var ov = document.getElementById('cmOverlay');
      var hb = document.getElementById('cmHamburger');
      if (sb) sb.classList.toggle('cm-open');
      if (ov) ov.classList.toggle('cm-show');
      if (hb) hb.classList.toggle('cm-open');
    }
    function cmClose() {
      var sb = document.querySelector('.sidebar');
      var ov = document.getElementById('cmOverlay');
      var hb = document.getElementById('cmHamburger');
      if (sb) sb.classList.remove('cm-open');
      if (ov) ov.classList.remove('cm-show');
      if (hb) hb.classList.remove('cm-open');
    }
    window.cmToggle = cmToggle;
    window.cmClose  = cmClose;
    document.addEventListener('DOMContentLoaded', function() {
      // Close sidebar when any sidebar link is tapped on mobile
      var links = document.querySelectorAll('.sidebar a');
      links.forEach(function(l) {
        l.addEventListener('click', function() {
          if (window.innerWidth <= 768) cmClose();
        });
      });
      // Close on Escape key
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') cmClose();
      });
    });
  })();
  </script>
  <!-- ── END MOBILE JS ──────────────────────────────── -->
  
</body>
</html>