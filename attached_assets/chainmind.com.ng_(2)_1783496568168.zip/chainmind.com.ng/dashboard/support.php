<?php
  session_start();
  require_once __DIR__ . '/../api/_helpers.php';
  if (!isset($_SESSION['user_id'])) { header('Location: /auth/login.php?next=/dashboard/support.php'); exit; }
  $user_id = (int)$_SESSION['user_id'];
  $user_email = $_SESSION['user_email'] ?? '';
  $flash = '';
  if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['subject'])) {
      $subject = trim($_POST['subject']??''); $message = trim($_POST['message']??''); $category=$_POST['category']??'general';
      if ($subject && $message) {
          try { db()->prepare('INSERT INTO support_tickets (user_id,subject,message,category,status,created_at) VALUES (?,?,?,?,?,NOW())')->execute([$user_id,$subject,$message,$category,'open']); } catch(Throwable $e){}
          $flash = '<div class="flash ok">&#10003; Ticket submitted! We&#8217;ll reply to '.htmlspecialchars($user_email).' within 24 hours.</div>';
      } else { $flash = '<div class="flash err">&#9888; Please fill in both subject and message.</div>'; }
  }
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta charset="UTF-8"><title>Support — ChainMind</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap">
  <link rel="icon" type="image/png" href="../ChatGPT Image Jun 2, 2026, 06_43_57 AM.png">
  <style>
  
  :root{
    --bg:#07080f;--bg2:#0b0d1c;--bg3:#101228;--bg4:#161935;
    --border:#1e2040;--border2:#272a52;--border3:#323670;
    --text:#eef0ff;--text2:#c5c8f0;--muted:#6b6f9e;--muted2:#474b78;
    --purple-1:#8b3cf7;--purple-2:#6d28d9;--violet:#7c3aed;--indigo:#4f46e5;
    --accent:#a78bfa;--accent-2:#c4b5fd;--accent2:#c4b5fd;
    --blue:#60a5fa;--glow:rgba(139,60,247,.35);
    --green:#34d399;--green-bg:rgba(52,211,153,.12);--green-bd:rgba(52,211,153,.35);
    --orange:#fb923c;--orange-bg:rgba(251,146,60,.12);
    --red:#f87171;--red-bg:rgba(248,113,113,.12);--gold:#f59e0b;
    --grad:linear-gradient(135deg,#8b3cf7,#4f46e5);
    --grad-soft:linear-gradient(135deg,rgba(139,60,247,.15),rgba(79,70,229,.08));
    --font:'Plus Jakarta Sans',system-ui,sans-serif;
    --display:'Syne',sans-serif;
    --mono:'JetBrains Mono',monospace;
  }
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
  body{background:var(--bg);color:var(--text);font-family:var(--font);display:flex;min-height:100vh;font-size:15px;}
  body::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");pointer-events:none;z-index:0;opacity:.5;}
  .sidebar{width:240px;background:var(--bg2);border-right:1px solid var(--border);padding:1.75rem 1.25rem;display:flex;flex-direction:column;gap:.2rem;flex-shrink:0;min-height:100vh;position:relative;z-index:10;}
  .sidebar::after{content:'';position:absolute;top:0;right:0;bottom:0;width:1px;background:linear-gradient(to bottom,transparent,rgba(139,60,247,.4) 30%,rgba(79,70,229,.3) 70%,transparent);pointer-events:none;}
  .sidebar-logo{display:flex;align-items:center;gap:.7rem;margin-bottom:2rem;padding-left:.25rem;text-decoration:none;}
  .logo-mark{width:36px;height:36px;background:var(--grad);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:.9rem;font-weight:800;color:#fff;box-shadow:0 0 20px var(--glow);flex-shrink:0;}
  .logo-text{font-size:1.1rem;font-weight:800;letter-spacing:-.02em;}
  .logo-text .chain{color:var(--accent2);}.logo-text .mind{color:var(--text);}
  .ss{font-size:.68rem;font-weight:700;letter-spacing:.1em;color:var(--muted2);text-transform:uppercase;padding:.6rem .75rem .3rem;}
  .sidebar a{display:flex;align-items:center;gap:.65rem;padding:.6rem .85rem;border-radius:10px;color:var(--muted);text-decoration:none;font-size:.88rem;font-weight:500;transition:all .18s;position:relative;}
  .sidebar a svg{opacity:.6;flex-shrink:0;}
  .sidebar a:hover{background:var(--bg3);color:var(--text2);}.sidebar a:hover svg{opacity:1;}
  .sidebar a.active{background:linear-gradient(135deg,rgba(139,60,247,.18),rgba(79,70,229,.1));color:var(--accent2);border:1px solid rgba(139,60,247,.25);}
  .sidebar a.active svg{opacity:1;}.sidebar a.active::before{content:'';position:absolute;left:0;top:20%;bottom:20%;width:3px;background:var(--grad);border-radius:0 3px 3px 0;}
  hr.sd{border:none;border-top:1px solid var(--border);margin:.6rem 0;}
  .main{flex:1;padding:2.25rem 2.5rem;overflow-x:hidden;position:relative;z-index:1;}
  h1{font-family:'Syne',sans-serif;font-size:1.65rem;font-weight:800;letter-spacing:-.03em;margin-bottom:.35rem;}
  .page-sub{color:var(--muted);font-size:.88rem;margin-bottom:2rem;}
  .card{background:var(--bg3);border:1px solid var(--border);border-radius:14px;overflow:hidden;margin-bottom:1.5rem;}
  .card-header{padding:1.1rem 1.4rem;border-bottom:1px solid var(--border);background:rgba(255,255,255,.01);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;}
  .card-header h2{font-size:.92rem;font-weight:700;}
  .card-body{padding:1.4rem;}
  table{width:100%;border-collapse:collapse;font-size:.82rem;}
  th{text-align:left;padding:.65rem 1rem;color:var(--muted);border-bottom:1px solid var(--border);font-size:.72rem;font-weight:600;text-transform:uppercase;letter-spacing:.06em;}
  td{padding:.65rem 1rem;border-bottom:1px solid var(--border);color:var(--text2);}
  tr:last-child td{border-bottom:none;}tr:hover td{background:rgba(255,255,255,.018);}
  .badge{display:inline-flex;align-items:center;gap:.3rem;padding:.18rem .55rem;border-radius:20px;font-size:.7rem;font-weight:700;}
  .b-active,.b-confirmed{background:var(--green-bg);color:var(--green);border:1px solid rgba(52,211,153,.25);}
  .b-pending{background:var(--orange-bg);color:var(--orange);border:1px solid rgba(251,146,60,.25);}
  .b-inactive,.b-failed{background:var(--red-bg);color:var(--red);border:1px solid rgba(248,113,113,.25);}
  label{display:block;font-size:.8rem;color:var(--muted);margin:.75rem 0 .3rem;}
  input[type=text],input[type=email],input[type=password],input[type=number],select,textarea{width:100%;padding:.65rem .9rem;border-radius:10px;border:1px solid var(--border2);background:var(--bg2);color:var(--text);font-family:var(--font);font-size:.88rem;outline:none;transition:.18s;}
  input:focus,select:focus,textarea:focus{border-color:rgba(139,60,247,.5);box-shadow:0 0 0 3px rgba(139,60,247,.1);}
  .btn{display:inline-flex;align-items:center;gap:.45rem;padding:.65rem 1.3rem;border-radius:10px;font-size:.88rem;font-weight:700;text-decoration:none;border:none;cursor:pointer;transition:.2s;font-family:var(--font);}
  .btn-primary{background:var(--grad);color:#fff;box-shadow:0 4px 18px var(--glow);}.btn-primary:hover{opacity:.9;transform:translateY(-1px);}
  .btn-ghost{background:transparent;border:1px solid var(--border2);color:var(--text2);}.btn-ghost:hover{border-color:var(--accent);color:var(--accent);}
  .btn-danger{background:var(--red-bg);border:1px solid rgba(248,113,113,.3);color:var(--red);}.btn-danger:hover{background:rgba(248,113,113,.2);}
  .btn-sm{padding:.4rem .85rem;font-size:.8rem;}
  .flash{padding:.95rem 1.2rem;border-radius:12px;margin-bottom:1.25rem;font-size:.85rem;}
  .flash.ok{background:var(--green-bg);border:1px solid rgba(52,211,153,.3);color:var(--green);}
  .flash.err{background:var(--red-bg);border:1px solid rgba(248,113,113,.3);color:var(--red);}
  .fld-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem;}
  .stats{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:1rem;margin-bottom:1.75rem;}
  .stat-card{background:var(--bg3);border:1px solid var(--border);border-radius:14px;padding:1.4rem 1.25rem;transition:.2s;}
  .stat-card:hover{border-color:var(--border2);transform:translateY(-2px);}
  .stat-card .sc-label{font-size:.73rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);margin-bottom:.4rem;}
  .stat-card .sc-value{font-size:1.75rem;font-weight:800;letter-spacing:-.03em;line-height:1;}
  .sc-icon{width:36px;height:36px;border-radius:9px;display:flex;align-items:center;justify-content:center;margin-bottom:.85rem;}
  .sc-purple{background:rgba(139,60,247,.15);color:var(--accent);}
  .sc-green{background:var(--green-bg);color:var(--green);}
  .sc-orange{background:var(--orange-bg);color:var(--orange);}
  .sc-blue{background:rgba(99,179,237,.12);color:#63b3ed;}
  .sc-ok .sc-value{color:var(--green);}
  .sc-purple-val .sc-value{color:var(--accent2);}
  /* ── Mobile topbar ─────────────────────────────────── */
  .cm-mobile-bar{display:none;position:fixed;top:0;left:0;right:0;height:54px;z-index:9000;background:var(--bg2);border-bottom:1px solid var(--border);align-items:center;justify-content:space-between;padding:0 1rem;gap:.75rem;}
  .cm-mobile-bar .cm-mob-logo{display:flex;align-items:center;gap:.55rem;text-decoration:none;}
  .cm-hamburger{width:42px;height:42px;border-radius:9px;background:transparent;border:1px solid var(--border2);color:var(--text2);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;cursor:pointer;flex-shrink:0;transition:border-color .18s,color .18s;}
  .cm-hamburger:hover{border-color:var(--accent);color:var(--accent);}
  .cm-hamburger span{display:block;width:20px;height:2px;background:currentColor;border-radius:2px;transition:transform .25s,opacity .2s;}
  .cm-hamburger.cm-open span:nth-child(1){transform:translateY(7px) rotate(45deg);}
  .cm-hamburger.cm-open span:nth-child(2){opacity:0;transform:scaleX(0);}
  .cm-hamburger.cm-open span:nth-child(3){transform:translateY(-7px) rotate(-45deg);}
  .cm-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);backdrop-filter:blur(4px);z-index:8900;}
  .cm-overlay.cm-show{display:block;}
  ::-webkit-scrollbar{width:5px;height:5px;}::-webkit-scrollbar-track{background:transparent;}::-webkit-scrollbar-thumb{background:var(--border2);border-radius:10px;}::-webkit-scrollbar-thumb:hover{background:rgba(139,60,247,.4);}
  /* ── Responsive ─────────────────────────────────────── */
  @media(max-width:768px){
    .cm-mobile-bar{display:flex!important;}
    body{padding-top:54px!important;}
    .sidebar{display:flex!important;flex-direction:column!important;position:fixed!important;top:0!important;left:0!important;bottom:0!important;width:270px!important;min-height:100vh!important;z-index:9500!important;transform:translateX(-100%)!important;transition:transform .28s cubic-bezier(.4,0,.2,1)!important;overflow-y:auto!important;overflow-x:hidden!important;}
    .sidebar.cm-open{transform:translateX(0)!important;box-shadow:4px 0 40px rgba(0,0,0,.6)!important;}
    .main{overflow-x:hidden;padding:1.25rem 1rem!important;}
    .stats{grid-template-columns:repeat(2,1fr)!important;}
    .tabs{overflow-x:auto!important;-webkit-overflow-scrolling:touch;scrollbar-width:none;flex-wrap:nowrap!important;padding-left:1rem!important;padding-right:1rem!important;}
    .tabs::-webkit-scrollbar{display:none;}
    .tab-btn{white-space:nowrap;}
    .card{overflow-x:auto;}
    table{min-width:480px;}
    .overview-scroll{padding:1.25rem 1rem!important;}
    h1{font-size:1.3rem!important;}
    .fld-row{grid-template-columns:1fr!important;}
    .pay-methods{grid-template-columns:1fr!important;}
    .info-grid{grid-template-columns:1fr 1fr!important;}
    .chat-sidebar{display:none!important;}
    .chat-panel{flex-direction:column!important;}
    .input-area{padding:.75rem 1rem 1rem!important;}
  }
  @media(max-width:480px){
    .stats{grid-template-columns:1fr 1fr!important;}
    .stat-card .sc-value,.stat .val{font-size:1.4rem!important;}
  }
  
  
  </style>
  </head>
  <style>
  .faq-item{border-bottom:1px solid var(--border);}.faq-item:last-child{border-bottom:none;}
  .faq-q{padding:1rem 1.4rem;font-size:.9rem;font-weight:600;cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:1rem;color:var(--text2);transition:color .15s;user-select:none;}
  .faq-q:hover{color:var(--text);}.faq-q svg{flex-shrink:0;transition:transform .2s;}
  .faq-item.open .faq-q svg{transform:rotate(180deg);}
  .faq-a{display:none;padding:0 1.4rem 1rem;font-size:.87rem;color:var(--muted);line-height:1.7;}
  .faq-a a{color:var(--accent);text-decoration:none;}
  .faq-item.open .faq-a{display:block;}
  .contact-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:1rem;margin-bottom:1.5rem;}
  .contact-card{background:var(--bg3);border:1px solid var(--border);border-radius:14px;padding:1.4rem;display:flex;flex-direction:column;gap:.65rem;transition:.2s;text-decoration:none;}
  .contact-card:hover{border-color:rgba(139,60,247,.35);transform:translateY(-2px);}
  .contact-card h3{font-size:.92rem;font-weight:700;color:var(--text);}
  .contact-card p{font-size:.8rem;color:var(--muted);line-height:1.5;}
  .contact-card .cc-link{font-size:.82rem;font-weight:700;color:var(--accent);margin-top:auto;}
  @media(max-width:600px){.contact-grid{grid-template-columns:1fr 1fr;}}
  </style>
  <body>
  
  <div class="cm-mobile-bar" id="cmBar">
    <a href="/dashboard/" class="cm-mob-logo">
      <div style="width:32px;height:32px;background:linear-gradient(135deg,#8b3cf7,#4f46e5);border-radius:9px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.85rem;color:#fff;flex-shrink:0;box-shadow:0 0 14px rgba(139,60,247,.5)">CM</div>
      <div style="font-size:1rem;font-weight:800;letter-spacing:-.02em"><span style="color:#c4b5fd">Chain</span><span style="color:#eef0ff">Mind</span></div>
    </a>
    <button class="cm-hamburger" id="cmHamburger" onclick="cmToggle()" aria-label="Toggle navigation">
      <span></span><span></span><span></span>
    </button>
  </div>
  <div class="cm-overlay" id="cmOverlay" onclick="cmClose()"></div>
  <nav class="sidebar">
    <a href="/dashboard/" class="sidebar-logo">
      <div class="logo-mark">CM</div>
      <div class="logo-text"><span class="chain">Chain</span><span class="mind">Mind</span></div>
    </a>
    <div class="ss">Account</div>
    <a href="/dashboard/" >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>Overview</a>
    <a href="/dashboard/?tab=chat">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>Chat</a>
    <a href="/dashboard/billing.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>Billing</a>
    <a href="/dashboard/api-keys.php" >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.78 7.78 5.5 5.5 0 017.78-7.78l1.06-1.06a2 2 0 012.83 0l1.06 1.06a2 2 0 010 2.83z"/></svg>API Keys</a>
    <a href="/dashboard/node-earnings.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>Node Earnings</a>
    <hr class="sd">
    <div class="ss">Tools</div>
    <a href="/dashboard/profile.php" >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Profile</a>
    <a href="/dashboard/notifications.php" >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>Notifications</a>
    <a href="/dashboard/support.php" class="active">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>Support</a>
    <hr class="sd">
    <div class="ss">Node</div>
    <a href="/dashboard/node-settings.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>Node Settings</a>
    <a href="/dashboard/node-download.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>Download Guide</a>
    <hr class="sd">
    <a href="/">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></svg>Home</a>
    <a href="/docs.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14,2 14,8 20,8"/></svg>API Docs</a>
    <a href="/auth/logout.php" style="margin-top:auto;color:var(--muted)">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16,17 21,12 16,7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>Sign out</a>
  </nav>
  <div class="main">
    <h1>Help &amp; Support</h1>
    <p class="page-sub">Get help with your account, billing, API, and nodes.</p>
    <?= $flash ?>

    <div class="contact-grid">
      <a href="mailto:support@chainmind.com.ng" class="contact-card"><div style="font-size:1.6rem">📧</div><h3>Email Support</h3><p>We respond within 24 hours.</p><span class="cc-link">support@chainmind.com.ng →</span></a>
      <a href="/docs.php" class="contact-card"><div style="font-size:1.6rem">📚</div><h3>Documentation</h3><p>Full API reference and integration guides.</p><span class="cc-link">Read the docs →</span></a>
      <a href="https://t.me/chainmindng" target="_blank" class="contact-card"><div style="font-size:1.6rem">💬</div><h3>Community</h3><p>Join the Telegram community for real-time help.</p><span class="cc-link">Join community →</span></a>
      <a href="/dashboard/?tab=chat" class="contact-card"><div style="font-size:1.6rem">🤖</div><h3>Ask ChainMind AI</h3><p>Get instant answers from the AI chat.</p><span class="cc-link">Open chat →</span></a>
    </div>

    <div class="card">
      <div class="card-header"><h2>Submit a Support Ticket</h2></div>
      <div class="card-body">
        <form method="POST">
          <div class="fld-row">
            <div><label>Category</label><select name="category"><option value="billing">Billing &amp; Credits</option><option value="api">API &amp; Integration</option><option value="node">Node Setup &amp; Earnings</option><option value="account">Account &amp; Login</option><option value="bug">Bug Report</option><option value="general" selected>General Question</option></select></div>
            <div><label>Subject</label><input type="text" name="subject" placeholder="Brief description of your issue" required></div>
          </div>
          <div style="margin-top:.5rem"><label>Message</label><textarea name="message" rows="5" placeholder="Describe your issue in detail — include any error messages, your API key label, steps to reproduce, etc." required></textarea></div>
          <div style="margin-top:1.25rem;display:flex;align-items:center;gap:.75rem;flex-wrap:wrap">
            <button type="submit" class="btn btn-primary"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>Send Ticket</button>
            <span style="font-size:.78rem;color:var(--muted)">Reply to <strong><?= htmlspecialchars($user_email) ?></strong> within 24 hours.</span>
          </div>
        </form>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><h2>Frequently Asked Questions</h2></div>
      <div id="faqList">
      <?php
      $faqs=[
        ['How do credits work?','Credits are consumed when you run inference jobs via the API or chat. 1 USD = '.(defined('CREDITS_PER_USD')?number_format(CREDITS_PER_USD):'1,000').' credits. View exact usage on the <a href="/dashboard/billing.php">Billing page</a>.'],
        ['How do I get my API key?','Your API key is on the <a href="/dashboard/">Dashboard overview</a>. Include it as <code>X-Api-Key</code> on every POST to <code>/api/infer.php</code>. Manage all keys on the <a href="/dashboard/api-keys.php">API Keys page</a>.'],
        ['Why is my API key not working?','Check: (1) key is active and not revoked, (2) you have sufficient credits, (3) header is <code>X-Api-Key: your-key</code>. If issues persist, <a href="mailto:support@chainmind.com.ng">email support</a>.'],
        ['How do I run a node and earn IQ?','Download the ChainMind Node from the <a href="/dashboard/node-download.php">Download Guide</a>, install Ollama, and complete the onboarding wizard. Your node earns IQ for every AI job it processes.'],
        ['How do I withdraw my IQ earnings?','Go to <a href="/dashboard/node-earnings.php">Node Earnings</a> and click "Request Withdrawal". Min withdrawal is 10 IQ. Pay via USDT (TRC-20) or bank transfer. Processing takes 1–3 business days.'],
        ['I paid but credits weren&#8217;t added — what do I do?','Check the <a href="/dashboard/billing.php">Billing page</a>. Crypto payments can take 10–30 minutes. If it shows "confirmed" but credits are missing after 1 hour, contact support with your payment reference.'],
        ['How do I cancel my subscription?','Go to <a href="/dashboard/billing.php">Billing</a> and click "Manage Subscription", or email <a href="mailto:support@chainmind.com.ng">support@chainmind.com.ng</a>. Cancellations take effect at the end of the billing period.'],
      ];
      foreach ($faqs as $i=>[$q,$a]):
      ?><div class="faq-item" id="faq-<?= $i ?>"><div class="faq-q" onclick="faqToggle(<?= $i ?>)"><span><?= htmlspecialchars($q) ?></span><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg></div><div class="faq-a"><?= $a ?></div></div><?php endforeach; ?>
      </div>
    </div>

    <div class="card" style="border-color:rgba(52,211,153,.2)">
      <div class="card-header"><h2>System Status</h2></div>
      <div class="card-body">
        <?php foreach (['API Inference Endpoint','ChainMind Network','Billing & Payments','Dashboard'] as $item): ?>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:.55rem 0;border-bottom:1px solid var(--border)">
          <span style="font-size:.87rem;color:var(--text2)"><?= htmlspecialchars($item) ?></span>
          <span style="display:flex;align-items:center;gap:.4rem;font-size:.78rem;font-weight:700;color:var(--green)"><span style="width:7px;height:7px;border-radius:50%;background:var(--green);box-shadow:0 0 6px rgba(52,211,153,.6)"></span>Operational</span>
        </div>
        <?php endforeach; ?>
        <p style="font-size:.78rem;color:var(--muted);margin-top:1rem">For real-time status: <a href="https://chainmind.com.ng/status" target="_blank" style="color:var(--accent)">chainmind.com.ng/status ↗</a></p>
      </div>
    </div>
  </div>
  <script>function faqToggle(i){var el=document.getElementById('faq-'+i);if(el)el.classList.toggle('open');}</script>
  
  <script>
  (function(){
    function cmToggle(){var sb=document.querySelector('.sidebar'),ov=document.getElementById('cmOverlay'),hb=document.getElementById('cmHamburger');if(sb)sb.classList.toggle('cm-open');if(ov)ov.classList.toggle('cm-show');if(hb)hb.classList.toggle('cm-open');}
    function cmClose(){var sb=document.querySelector('.sidebar'),ov=document.getElementById('cmOverlay'),hb=document.getElementById('cmHamburger');if(sb)sb.classList.remove('cm-open');if(ov)ov.classList.remove('cm-show');if(hb)hb.classList.remove('cm-open');}
    window.cmToggle=cmToggle;window.cmClose=cmClose;
    document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('.sidebar a').forEach(function(l){l.addEventListener('click',function(){if(window.innerWidth<=768)cmClose();});});document.addEventListener('keydown',function(e){if(e.key==='Escape')cmClose();});});
  })();
  </script>
  </body>
  </html>