<?php
  session_start();
  require_once __DIR__ . '/../api/_helpers.php';
  if (!isset($_SESSION['user_id'])) { header('Location: /auth/login.php?next=/dashboard/profile.php'); exit; }
  $user_id = (int)$_SESSION['user_id'];
  $user_name = $_SESSION['user_name'] ?? 'User';
  $user_email = $_SESSION['user_email'] ?? '';
  $is_admin = ($_SESSION['user_role'] ?? '') === 'admin';
  $flash = '';
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      if (($_POST['action'] ?? '') === 'update_name') {
          $n = trim($_POST['name'] ?? '');
          if ($n && mb_strlen($n) <= 100) {
              db()->prepare('UPDATE users SET name=? WHERE id=?')->execute([$n, $user_id]);
              $_SESSION['user_name'] = $n; $user_name = $n;
              $flash = '<div class="flash ok">&#10003; Name updated.</div>';
          } else { $flash = '<div class="flash err">&#9888; Name must be 1–100 characters.</div>'; }
      }
      if (($_POST['action'] ?? '') === 'change_password') {
          $cur = $_POST['current_password'] ?? ''; $new = $_POST['new_password'] ?? ''; $con = $_POST['confirm_password'] ?? '';
          // Google users must verify via OAuth instead of current password
          $urow_check = db()->prepare('SELECT * FROM users WHERE id=? LIMIT 1'); $urow_check->execute([$user_id]); $urow_check=$urow_check->fetch();
          $is_guser = !empty($urow_check['google_id']);
          if ($is_guser) {
              // Check if Google pw_change session is set (granted by google-callback.php)
              $gv_ok = isset($_SESSION['pw_google_verified']) && (time() - $_SESSION['pw_google_verified'] < 300);
              if (!$gv_ok) {
                  // Redirect to Google verify — callback will return here
                  header('Location: /auth/google-verify-pw.php'); exit;
              }
              // Google verified — allow password change without current password
              if (!$new||!$con) { $flash = '<div class="flash err">&#9888; New password required.</div>'; }
              elseif ($new !== $con) { $flash = '<div class="flash err">&#9888; Passwords do not match.</div>'; }
              elseif (strlen($new) < 8) { $flash = '<div class="flash err">&#9888; Min 8 characters.</div>'; }
              else {
                  db()->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($new,PASSWORD_BCRYPT),$user_id]);
                  unset($_SESSION['pw_google_verified']);
                  $flash = '<div class="flash ok">&#10003; Password changed via Google verification.</div>';
              }
          } else {
              if (!$cur||!$new||!$con) { $flash = '<div class="flash err">&#9888; All fields required.</div>'; }
              elseif ($new !== $con) { $flash = '<div class="flash err">&#9888; Passwords do not match.</div>'; }
              elseif (strlen($new) < 8) { $flash = '<div class="flash err">&#9888; Min 8 characters.</div>'; }
              else {
                  $row = db()->prepare('SELECT password_hash FROM users WHERE id=?'); $row->execute([$user_id]); $row=$row->fetch();
                  if ($row && password_verify($cur, $row['password_hash'])) {
                      db()->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($new,PASSWORD_BCRYPT),$user_id]);
                      $flash = '<div class="flash ok">&#10003; Password changed.</div>';
                  } else { $flash = '<div class="flash err">&#9888; Current password incorrect.</div>'; }
              }
          }
      }
  }
  $urow = db()->prepare('SELECT * FROM users WHERE id=? LIMIT 1'); $urow->execute([$user_id]); $urow=$urow->fetch();
  $email_verified = (bool)(int)($urow['email_verified'] ?? 0);
  $is_google_user = !empty($urow['google_id']);
  $created_at = $urow['created_at'] ?? 'Unknown';
  $user_role = $urow['role'] ?? 'user';
  $key_count = db()->prepare('SELECT COUNT(*) FROM api_keys WHERE user_id=? AND is_active=1'); $key_count->execute([$user_id]); $key_count=(int)$key_count->fetchColumn();
  $total_jobs = db()->prepare('SELECT COALESCE(SUM(total_jobs),0) FROM api_keys WHERE user_id=?'); $total_jobs->execute([$user_id]); $total_jobs=(int)$total_jobs->fetchColumn();
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta charset="UTF-8"><title>Profile — ChainMind</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap">
  <link rel="icon" type="image/png" href="../ChatGPT Image Jun 2, 2026, 06_43_57 AM.png">
  <style>
  
  :root{
    --bg:#07080f;--bg2:#0b0d1c;--bg3:#101228;--bg4:#161935;
    --border:#1e2040;--border2:#272a52;--border3:#323670;
    --text:#eef0ff;--text2:#c5c8f0;--muted:#6b6f9e;--muted2:#474b78;
    --purple-1:#8b3cf7;--purple-2:#6d28d9;--violet:#7c3aed;--indigo:#4f46e5;
    --accent:#a78bfa;--accent-2:#c4b5fd;--accent2:#c4b5fd;
    --blue:#60a5fa;--glow:rgba(139,60,247,.35);
    --green:#34d399;--green-bg:rgba(52,211,153,.12);--green-bd:rgba(52,211,153,.35);
    --orange:#fb923c;--orange-bg:rgba(251,146,60,.12);
    --red:#f87171;--red-bg:rgba(248,113,113,.12);--gold:#f59e0b;
    --grad:linear-gradient(135deg,#8b3cf7,#4f46e5);
    --grad-soft:linear-gradient(135deg,rgba(139,60,247,.15),rgba(79,70,229,.08));
    --font:'Plus Jakarta Sans',system-ui,sans-serif;
    --display:'Syne',sans-serif;
    --mono:'JetBrains Mono',monospace;
  }
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
  body{background:var(--bg);color:var(--text);font-family:var(--font);display:flex;min-height:100vh;font-size:15px;}
  body::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");pointer-events:none;z-index:0;opacity:.5;}
  .sidebar{width:240px;background:var(--bg2);border-right:1px solid var(--border);padding:1.75rem 1.25rem;display:flex;flex-direction:column;gap:.2rem;flex-shrink:0;min-height:100vh;position:relative;z-index:10;}
  .sidebar::after{content:'';position:absolute;top:0;right:0;bottom:0;width:1px;background:linear-gradient(to bottom,transparent,rgba(139,60,247,.4) 30%,rgba(79,70,229,.3) 70%,transparent);pointer-events:none;}
  .sidebar-logo{display:flex;align-items:center;gap:.7rem;margin-bottom:2rem;padding-left:.25rem;text-decoration:none;}
  .logo-mark{width:36px;height:36px;background:var(--grad);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:.9rem;font-weight:800;color:#fff;box-shadow:0 0 20px var(--glow);flex-shrink:0;}
  .logo-text{font-size:1.1rem;font-weight:800;letter-spacing:-.02em;}
  .logo-text .chain{color:var(--accent2);}.logo-text .mind{color:var(--text);}
  .ss{font-size:.68rem;font-weight:700;letter-spacing:.1em;color:var(--muted2);text-transform:uppercase;padding:.6rem .75rem .3rem;}
  .sidebar a{display:flex;align-items:center;gap:.65rem;padding:.6rem .85rem;border-radius:10px;color:var(--muted);text-decoration:none;font-size:.88rem;font-weight:500;transition:all .18s;position:relative;}
  .sidebar a svg{opacity:.6;flex-shrink:0;}
  .sidebar a:hover{background:var(--bg3);color:var(--text2);}.sidebar a:hover svg{opacity:1;}
  .sidebar a.active{background:linear-gradient(135deg,rgba(139,60,247,.18),rgba(79,70,229,.1));color:var(--accent2);border:1px solid rgba(139,60,247,.25);}
  .sidebar a.active svg{opacity:1;}.sidebar a.active::before{content:'';position:absolute;left:0;top:20%;bottom:20%;width:3px;background:var(--grad);border-radius:0 3px 3px 0;}
  hr.sd{border:none;border-top:1px solid var(--border);margin:.6rem 0;}
  .main{flex:1;padding:2.25rem 2.5rem;overflow-x:hidden;position:relative;z-index:1;}
  h1{font-family:'Syne',sans-serif;font-size:1.65rem;font-weight:800;letter-spacing:-.03em;margin-bottom:.35rem;}
  .page-sub{color:var(--muted);font-size:.88rem;margin-bottom:2rem;}
  .card{background:var(--bg3);border:1px solid var(--border);border-radius:14px;overflow:hidden;margin-bottom:1.5rem;}
  .card-header{padding:1.1rem 1.4rem;border-bottom:1px solid var(--border);background:rgba(255,255,255,.01);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;}
  .card-header h2{font-size:.92rem;font-weight:700;}
  .card-body{padding:1.4rem;}
  table{width:100%;border-collapse:collapse;font-size:.82rem;}
  th{text-align:left;padding:.65rem 1rem;color:var(--muted);border-bottom:1px solid var(--border);font-size:.72rem;font-weight:600;text-transform:uppercase;letter-spacing:.06em;}
  td{padding:.65rem 1rem;border-bottom:1px solid var(--border);color:var(--text2);}
  tr:last-child td{border-bottom:none;}tr:hover td{background:rgba(255,255,255,.018);}
  .badge{display:inline-flex;align-items:center;gap:.3rem;padding:.18rem .55rem;border-radius:20px;font-size:.7rem;font-weight:700;}
  .b-active,.b-confirmed{background:var(--green-bg);color:var(--green);border:1px solid rgba(52,211,153,.25);}
  .b-pending{background:var(--orange-bg);color:var(--orange);border:1px solid rgba(251,146,60,.25);}
  .b-inactive,.b-failed{background:var(--red-bg);color:var(--red);border:1px solid rgba(248,113,113,.25);}
  label{display:block;font-size:.8rem;color:var(--muted);margin:.75rem 0 .3rem;}
  input[type=text],input[type=email],input[type=password],input[type=number],select,textarea{width:100%;padding:.65rem .9rem;border-radius:10px;border:1px solid var(--border2);background:var(--bg2);color:var(--text);font-family:var(--font);font-size:.88rem;outline:none;transition:.18s;}
  input:focus,select:focus,textarea:focus{border-color:rgba(139,60,247,.5);box-shadow:0 0 0 3px rgba(139,60,247,.1);}
  .btn{display:inline-flex;align-items:center;gap:.45rem;padding:.65rem 1.3rem;border-radius:10px;font-size:.88rem;font-weight:700;text-decoration:none;border:none;cursor:pointer;transition:.2s;font-family:var(--font);}
  .btn-primary{background:var(--grad);color:#fff;box-shadow:0 4px 18px var(--glow);}.btn-primary:hover{opacity:.9;transform:translateY(-1px);}
  .btn-ghost{background:transparent;border:1px solid var(--border2);color:var(--text2);}.btn-ghost:hover{border-color:var(--accent);color:var(--accent);}
  .btn-danger{background:var(--red-bg);border:1px solid rgba(248,113,113,.3);color:var(--red);}.btn-danger:hover{background:rgba(248,113,113,.2);}
  .btn-sm{padding:.4rem .85rem;font-size:.8rem;}
  .flash{padding:.95rem 1.2rem;border-radius:12px;margin-bottom:1.25rem;font-size:.85rem;}
  .flash.ok{background:var(--green-bg);border:1px solid rgba(52,211,153,.3);color:var(--green);}
  .flash.err{background:var(--red-bg);border:1px solid rgba(248,113,113,.3);color:var(--red);}
  .fld-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem;}
  .stats{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:1rem;margin-bottom:1.75rem;}
  .stat-card{background:var(--bg3);border:1px solid var(--border);border-radius:14px;padding:1.4rem 1.25rem;transition:.2s;}
  .stat-card:hover{border-color:var(--border2);transform:translateY(-2px);}
  .stat-card .sc-label{font-size:.73rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);margin-bottom:.4rem;}
  .stat-card .sc-value{font-size:1.75rem;font-weight:800;letter-spacing:-.03em;line-height:1;}
  .sc-icon{width:36px;height:36px;border-radius:9px;display:flex;align-items:center;justify-content:center;margin-bottom:.85rem;}
  .sc-purple{background:rgba(139,60,247,.15);color:var(--accent);}
  .sc-green{background:var(--green-bg);color:var(--green);}
  .sc-orange{background:var(--orange-bg);color:var(--orange);}
  .sc-blue{background:rgba(99,179,237,.12);color:#63b3ed;}
  .sc-ok .sc-value{color:var(--green);}
  .sc-purple-val .sc-value{color:var(--accent2);}
  /* ── Mobile topbar ─────────────────────────────────── */
  .cm-mobile-bar{display:none;position:fixed;top:0;left:0;right:0;height:54px;z-index:9000;background:var(--bg2);border-bottom:1px solid var(--border);align-items:center;justify-content:space-between;padding:0 1rem;gap:.75rem;}
  .cm-mobile-bar .cm-mob-logo{display:flex;align-items:center;gap:.55rem;text-decoration:none;}
  .cm-hamburger{width:42px;height:42px;border-radius:9px;background:transparent;border:1px solid var(--border2);color:var(--text2);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;cursor:pointer;flex-shrink:0;transition:border-color .18s,color .18s;}
  .cm-hamburger:hover{border-color:var(--accent);color:var(--accent);}
  .cm-hamburger span{display:block;width:20px;height:2px;background:currentColor;border-radius:2px;transition:transform .25s,opacity .2s;}
  .cm-hamburger.cm-open span:nth-child(1){transform:translateY(7px) rotate(45deg);}
  .cm-hamburger.cm-open span:nth-child(2){opacity:0;transform:scaleX(0);}
  .cm-hamburger.cm-open span:nth-child(3){transform:translateY(-7px) rotate(-45deg);}
  .cm-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);backdrop-filter:blur(4px);z-index:8900;}
  .cm-overlay.cm-show{display:block;}
  ::-webkit-scrollbar{width:5px;height:5px;}::-webkit-scrollbar-track{background:transparent;}::-webkit-scrollbar-thumb{background:var(--border2);border-radius:10px;}::-webkit-scrollbar-thumb:hover{background:rgba(139,60,247,.4);}
  /* ── Responsive ─────────────────────────────────────── */
  @media(max-width:768px){
    .cm-mobile-bar{display:flex!important;}
    body{padding-top:54px!important;}
    .sidebar{display:flex!important;flex-direction:column!important;position:fixed!important;top:0!important;left:0!important;bottom:0!important;width:270px!important;min-height:100vh!important;z-index:9500!important;transform:translateX(-100%)!important;transition:transform .28s cubic-bezier(.4,0,.2,1)!important;overflow-y:auto!important;overflow-x:hidden!important;}
    .sidebar.cm-open{transform:translateX(0)!important;box-shadow:4px 0 40px rgba(0,0,0,.6)!important;}
    .main{overflow-x:hidden;padding:1.25rem 1rem!important;}
    .stats{grid-template-columns:repeat(2,1fr)!important;}
    .tabs{overflow-x:auto!important;-webkit-overflow-scrolling:touch;scrollbar-width:none;flex-wrap:nowrap!important;padding-left:1rem!important;padding-right:1rem!important;}
    .tabs::-webkit-scrollbar{display:none;}
    .tab-btn{white-space:nowrap;}
    .card{overflow-x:auto;}
    table{min-width:480px;}
    .overview-scroll{padding:1.25rem 1rem!important;}
    h1{font-size:1.3rem!important;}
    .fld-row{grid-template-columns:1fr!important;}
    .pay-methods{grid-template-columns:1fr!important;}
    .info-grid{grid-template-columns:1fr 1fr!important;}
    .chat-sidebar{display:none!important;}
    .chat-panel{flex-direction:column!important;}
    .input-area{padding:.75rem 1rem 1rem!important;}
  }
  @media(max-width:480px){
    .stats{grid-template-columns:1fr 1fr!important;}
    .stat-card .sc-value,.stat .val{font-size:1.4rem!important;}
  }
  
  
  </style>
  </head>
  <body>
  
  <div class="cm-mobile-bar" id="cmBar">
    <a href="/dashboard/" class="cm-mob-logo">
      <div style="width:32px;height:32px;background:linear-gradient(135deg,#8b3cf7,#4f46e5);border-radius:9px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.85rem;color:#fff;flex-shrink:0;box-shadow:0 0 14px rgba(139,60,247,.5)">CM</div>
      <div style="font-size:1rem;font-weight:800;letter-spacing:-.02em"><span style="color:#c4b5fd">Chain</span><span style="color:#eef0ff">Mind</span></div>
    </a>
    <button class="cm-hamburger" id="cmHamburger" onclick="cmToggle()" aria-label="Toggle navigation">
      <span></span><span></span><span></span>
    </button>
  </div>
  <div class="cm-overlay" id="cmOverlay" onclick="cmClose()"></div>
  <nav class="sidebar">
    <a href="/dashboard/" class="sidebar-logo">
      <div class="logo-mark">CM</div>
      <div class="logo-text"><span class="chain">Chain</span><span class="mind">Mind</span></div>
    </a>

    <div class="ss">Account</div>
    <a href="/dashboard/" >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>
      Overview
    </a>
    <a href="/dashboard/?tab=chat" >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
      Chat
    </a>
    <a href="/dashboard/billing.php" >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
      Billing
    </a>
    <a href="/dashboard/api-keys.php" >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.78 7.78 5.5 5.5 0 017.78-7.78l1.06-1.06a2 2 0 012.83 0l1.06 1.06a2 2 0 010 2.83z"/></svg>
      API Keys
    </a>
    <a href="/dashboard/node-earnings.php" >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
      Node Earnings
    </a>

    <hr class="sd">
    <div class="ss">Tools</div>
    <a href="/dashboard/profile.php" class="active">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      Profile
    </a>
    <a href="/dashboard/notifications.php" >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
      Notifications
    </a>
    <a href="/dashboard/support.php" >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
      Support
    </a>

    <hr class="sd">
    <div class="ss">Node</div>
    <a href="/dashboard/node-settings.php" >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
      Node Settings
    </a>
    <a href="/dashboard/node-download.php" >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
      Download Guide
    </a>

    <hr class="sd">
    <a href="/">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></svg>
      Home
    </a>
    <a href="/docs.php">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14,2 14,8 20,8"/></svg>
      API Docs
    </a>
    <a href="/auth/logout.php" style="margin-top:auto;color:var(--muted)">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16,17 21,12 16,7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      Sign out
    </a>
  </nav>
  <div class="main">
    <h1>Account Profile</h1>
    <p class="page-sub">Manage your account details and security settings.</p>
    <?= $flash ?>
    <div class="stats">
      <div class="stat-card sc-purple-val">
        <div class="sc-icon sc-purple"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
        <div class="sc-label">Account Type</div><div class="sc-value" style="font-size:1.2rem"><?= ucfirst(htmlspecialchars($user_role)) ?></div>
      </div>
      <div class="stat-card sc-ok">
        <div class="sc-icon sc-green"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.78 7.78 5.5 5.5 0 017.78-7.78l1.06-1.06a2 2 0 012.83 0l1.06 1.06a2 2 0 010 2.83z"/></svg></div>
        <div class="sc-label">API Keys</div><div class="sc-value"><?= $key_count ?></div>
      </div>
      <div class="stat-card">
        <div class="sc-icon sc-blue"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg></div>
        <div class="sc-label">Total Jobs</div><div class="sc-value"><?= number_format($total_jobs) ?></div>
      </div>
      <div class="stat-card <?= $email_verified?'sc-ok':'' ?>">
        <div class="sc-icon <?= $email_verified?'sc-green':'sc-orange' ?>"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div>
        <div class="sc-label">Email</div><div class="sc-value" style="font-size:1.1rem"><?= $email_verified?'Verified':'Unverified' ?></div>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><h2>Personal Information</h2></div>
      <div class="card-body">
        <form method="POST">
          <input type="hidden" name="action" value="update_name">
          <div class="fld-row">
            <div><label>Full Name</label><input type="text" name="name" value="<?= htmlspecialchars($user_name) ?>" required></div>
            <div><label>Email Address</label><input type="email" value="<?= htmlspecialchars($user_email) ?>" disabled style="opacity:.6;cursor:not-allowed"></div>
          </div>
          <div class="fld-row" style="margin-top:.5rem">
            <div><label>Role</label><input type="text" value="<?= ucfirst(htmlspecialchars($user_role)) ?>" disabled style="opacity:.6;cursor:not-allowed"></div>
            <div><label>Member Since</label><input type="text" value="<?= substr($created_at,0,10) ?>" disabled style="opacity:.6;cursor:not-allowed"></div>
          </div>
          <div style="margin-top:1.25rem"><button type="submit" class="btn btn-primary"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/></svg>Save Changes</button></div>
        </form>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><h2>Change Password</h2></div>
      <div class="card-body">
        <form method="POST">
          <input type="hidden" name="action" value="change_password">
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1rem" class="fld-row">
            <div><?php if (!empty($is_google_user)): ?>
            <div style="background:rgba(99,179,237,.08);border:1px solid rgba(99,179,237,.2);border-radius:10px;padding:1rem 1.1rem;margin-bottom:1rem;font-size:.85rem;color:#60a5fa;">
              &#128279; Your account uses <strong>Google Sign-In</strong>. Click below to verify with Google before changing your password.
            </div>
            <a href="/auth/google-verify-pw.php" class="btn btn-ghost" style="display:inline-flex;align-items:center;gap:.5rem;margin-bottom:1rem;">
              <svg width="16" height="16" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.31-8.16 2.31-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/><path fill="none" d="M0 0h48v48H0z"/></svg>
              Verify with Google
            </a>
            <?php if (!empty($_SESSION['pw_google_verified']) && (time()-$_SESSION['pw_google_verified'])<300): ?>
            <div style="background:rgba(52,211,153,.08);border:1px solid rgba(52,211,153,.25);border-radius:8px;padding:.6rem .9rem;margin-bottom:.75rem;font-size:.82rem;color:#34d399;">&#10003; Google verified — set your new password below.</div>
            <?php endif; ?>
            <?php else: ?>
            <label>Current Password</label>
            <input type="password" name="current_password" placeholder="Your current password" autocomplete="current-password">
            <?php endif; ?></div>
            <div><label>New Password</label><input type="password" name="new_password" placeholder="Min 8 chars" required></div>
            <div><label>Confirm New</label><input type="password" name="confirm_password" required></div>
          </div>
          <div style="margin-top:1.25rem"><button type="submit" class="btn btn-primary"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>Update Password</button></div>
        </form>
      </div>
    </div>
    <?php if (!$email_verified): ?>
    <div class="card" style="border-color:rgba(251,146,60,.3)">
      <div class="card-header"><h2 style="color:var(--orange)">⚠ Email Not Verified</h2></div>
      <div class="card-body">
        <p style="font-size:.87rem;color:var(--text2);margin-bottom:1rem">Verify <strong><?= htmlspecialchars($user_email) ?></strong> to secure your account.</p>
        <a href="/api/auth/resend-verification.php?redirect=1" class="btn btn-ghost" style="border-color:rgba(251,146,60,.4);color:var(--orange)">Resend Verification Email</a>
      </div>
    </div>
    <?php endif; ?>
    <div class="card" style="border-color:rgba(248,113,113,.25)">
      <div class="card-header"><h2 style="color:var(--red)">Danger Zone</h2></div>
      <div class="card-body">
        <p style="font-size:.87rem;color:var(--muted);margin-bottom:1rem">Permanently delete your account and all data. This cannot be undone.</p>
        <a href="mailto:support@chainmind.com.ng?subject=Account+Deletion+Request" class="btn btn-danger"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg>Request Account Deletion</a>
      </div>
    </div>
  </div>
  
  <script>
  (function(){
    function cmToggle(){
      var sb=document.querySelector('.sidebar'),ov=document.getElementById('cmOverlay'),hb=document.getElementById('cmHamburger');
      if(sb)sb.classList.toggle('cm-open');
      if(ov)ov.classList.toggle('cm-show');
      if(hb)hb.classList.toggle('cm-open');
    }
    function cmClose(){
      var sb=document.querySelector('.sidebar'),ov=document.getElementById('cmOverlay'),hb=document.getElementById('cmHamburger');
      if(sb)sb.classList.remove('cm-open');
      if(ov)ov.classList.remove('cm-show');
      if(hb)hb.classList.remove('cm-open');
    }
    window.cmToggle=cmToggle;window.cmClose=cmClose;
    document.addEventListener('DOMContentLoaded',function(){
      document.querySelectorAll('.sidebar a').forEach(function(l){l.addEventListener('click',function(){if(window.innerWidth<=768)cmClose();});});
      document.addEventListener('keydown',function(e){if(e.key==='Escape')cmClose();});
    });
  })();
  </script>
  </body>
  </html>