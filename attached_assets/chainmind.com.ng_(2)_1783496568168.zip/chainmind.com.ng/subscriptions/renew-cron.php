<?php
// ============================================================
// ChainMind  Subscription Renewal Cron
// Run daily via cPanel cron:
// 0 0 * * * php /home/agbaieke/public_html/subscriptions/renew-cron.php >> /dev/null 2>&1
// ============================================================
define('CRON_MODE', true);
require_once __DIR__ . '/../api/_helpers.php';
require_once __DIR__ . '/../api/billing/credits.php';

$due = db()->query(
    'SELECT s.*, k.owner_email, k.id AS key_id
     FROM subscriptions s
     JOIN api_keys k ON k.id = s.api_key_id
     WHERE s.status = "active" AND s.renews_at <= NOW()'
)->fetchAll();

foreach ($due as $sub) {
    // Add monthly credits
    credits_add((int)$sub['key_id'], (int)$sub['credits_month']);

    // Push renews_at forward by 1 month
    db()->prepare(
        'UPDATE subscriptions SET renews_at = DATE_ADD(renews_at, INTERVAL 1 MONTH) WHERE id = ?'
    )->execute([$sub['id']]);

    error_log("[renew-cron] Renewed plan={$sub['plan']} for api_key_id={$sub['key_id']} (+{$sub['credits_month']} credits)");
}

echo date('Y-m-d H:i:s') . "  renewed " . count($due) . " subscription(s)\n";
