<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>API Documentation — ChainMind</title>
<meta name="description" content="ChainMind Network API documentation. Drop-in OpenAI replacement. 300+ models. $0.005 per 1k tokens.">
<link rel="icon" href="/assets/favicon.ico" type="image/x-icon">
<style>
  :root {
    --bg:      #0d0f14;
    --bg2:     #12151c;
    --bg3:     #1a1e28;
    --border:  #1f2535;
    --text:    #e8eaf0;
    --text2:   #8b93a8;
    --accent:  #6c8cff;
    --accent2: #a78bfa;
    --green:   #22c55e;
    --red:     #ef4444;
    --yellow:  #facc15;
    --mono:    'JetBrains Mono','Fira Code',monospace;
  }
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  html { scroll-behavior: smooth; }
  body { background: var(--bg); color: var(--text); font-family: 'Inter',system-ui,sans-serif; font-size: 15px; line-height: 1.7; display: flex; flex-direction: column; min-height: 100vh; }
  a { color: var(--accent); text-decoration: none; }
  a:hover { text-decoration: underline; }
  code { font-family: var(--mono); background: var(--bg3); border: 1px solid var(--border); border-radius: 5px; padding: 2px 7px; font-size: .82em; color: #c9d1d9; }
  pre { font-family: var(--mono); background: var(--bg3); border: 1px solid var(--border); border-radius: 8px; padding: 1.25rem 1.5rem; overflow-x: auto; margin: 1.25rem 0; font-size: .82rem; line-height: 1.65; position: relative; }
  pre .lang { position: absolute; top: .5rem; right: .75rem; font-size: .7rem; color: var(--text2); }
  table { width: 100%; border-collapse: collapse; margin: 1.25rem 0; font-size: .875rem; }
  th, td { padding: .6rem 1rem; border: 1px solid var(--border); text-align: left; vertical-align: top; }
  th { background: var(--bg3); color: var(--text); font-weight: 600; }
  td { color: var(--text2); }
  td:first-child { color: var(--text); font-family: var(--mono); font-size: .8rem; }
  h1 { font-size: 2rem; font-weight: 800; }
  h2 { font-size: 1.35rem; font-weight: 700; margin: 2.75rem 0 .75rem; color: var(--text); padding-top: .25rem; }
  h3 { font-size: 1.05rem; font-weight: 600; margin: 1.75rem 0 .5rem; color: var(--accent2); }
  p { color: var(--text2); margin-bottom: .85rem; }
  ul, ol { color: var(--text2); padding-left: 1.5rem; margin-bottom: 1rem; }
  li { margin-bottom: .4rem; }
  strong { color: var(--text); }

  /* TOP NAV */
  .top-nav { background: var(--bg2); border-bottom: 1px solid var(--border); padding: .875rem 1.5rem; display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; z-index: 100; }
  .top-nav .logo { display: flex; align-items: center; gap: .6rem; font-weight: 700; font-size: 1.1rem; color: var(--text); }
  .top-nav .logo span { color: var(--accent); }
  .top-nav nav a { color: var(--text2); font-size: .875rem; margin-left: 1.25rem; }
  .top-nav nav a:hover { color: var(--accent); text-decoration: none; }
  .top-nav .btn { background: var(--accent); color: #fff; padding: .4rem .9rem; border-radius: 6px; font-size: .8rem; font-weight: 600; margin-left: 1.25rem; }
  .top-nav .btn:hover { text-decoration: none; opacity: .9; }

  /* LAYOUT */
  .docs-layout { display: flex; flex: 1; }

  /* SIDEBAR */
  .sidebar { width: 240px; min-width: 240px; border-right: 1px solid var(--border); padding: 1.5rem 0; position: sticky; top: 57px; height: calc(100vh - 57px); overflow-y: auto; background: var(--bg2); }
  .sidebar-section { font-size: .7rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; color: var(--text2); padding: 1rem 1.25rem .4rem; }
  .sidebar a { display: block; padding: .45rem 1.25rem; color: var(--text2); font-size: .85rem; border-left: 2px solid transparent; }
  .sidebar a:hover, .sidebar a.active { color: var(--accent); border-left-color: var(--accent); background: rgba(108,140,255,.06); text-decoration: none; }

  /* CONTENT */
  .docs-content { flex: 1; max-width: 860px; padding: 3rem 2.5rem 5rem; }
  .docs-content > section { border-bottom: 1px solid var(--border); padding-bottom: 2rem; margin-bottom: 2rem; }
  .docs-content > section:last-child { border-bottom: none; }

  .badge { display: inline-block; padding: 2px 10px; border-radius: 100px; font-size: .7rem; font-weight: 700; letter-spacing: .04em; }
  .badge-get    { background: rgba(34,197,94,.12);  color: var(--green); border: 1px solid rgba(34,197,94,.25); }
  .badge-post   { background: rgba(108,140,255,.12); color: var(--accent); border: 1px solid rgba(108,140,255,.25); }
  .endpoint { display: flex; align-items: center; gap: .75rem; background: var(--bg3); border: 1px solid var(--border); border-radius: 8px; padding: .75rem 1.25rem; margin: .75rem 0; }
  .endpoint code { background: none; border: none; padding: 0; font-size: .875rem; color: var(--text); }

  .param-table td:nth-child(2) { color: var(--accent2); font-family: var(--mono); font-size: .78rem; }
  .param-table td:nth-child(3) { color: var(--yellow); font-family: var(--mono); font-size: .75rem; }

  .notice { background: var(--bg3); border-left: 3px solid var(--accent); padding: 1rem 1.25rem; border-radius: 0 8px 8px 0; margin: 1.25rem 0; }
  .notice p { margin: 0; font-size: .875rem; }
  .notice.warn { border-left-color: var(--yellow); }
  .notice.warn p { color: #fde68a; }

  /* ERROR TABLE */
  .err-code { color: var(--red) !important; }

  /* FOOTER */
  footer { background: var(--bg2); border-top: 1px solid var(--border); padding: 1.5rem; text-align: center; }
  footer p { color: var(--text2); font-size: .8rem; }
  footer a { color: var(--text2); margin: 0 .5rem; }

  @media(max-width:768px){
    .sidebar { display: none; }
    .docs-content { padding: 1.5rem 1rem 4rem; }
  }
</style>
</head>
<body>

<header class="top-nav">
  <a class="logo" href="/">
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="#6c8cff" stroke-width="1.5"/><path d="M8 12h8M12 8v8" stroke="#6c8cff" stroke-width="1.5" stroke-linecap="round"/></svg>
    Chain<span>Mind</span>
  </a>
  <nav>
    <a href="/">Home</a>
    <a href="/#pricing">Pricing</a>
    <a href="/chat/">AI Chat</a>
    <a href="/dashboard/">Dashboard</a>
    <a href="/auth/register.php" class="btn">Get API Key</a>
  </nav>
</header>

<div class="docs-layout">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sidebar-section">Getting Started</div>
    <a href="#quickstart">Quickstart</a>
    <a href="#authentication">Authentication</a>
    <a href="#base-url">Base URL</a>
    <a href="#credits">Credits &amp; Billing</a>

    <div class="sidebar-section">API Reference</div>
    <a href="#chat-completions">Chat Completions</a>
    <a href="#completions">Completions</a>
    <a href="#embeddings">Embeddings</a>
    <a href="#models">Models</a>

    <div class="sidebar-section">OpenAI Compat</div>
    <a href="#openai-compat">Overview</a>
    <a href="#openai-python">Python SDK</a>
    <a href="#openai-node">Node.js SDK</a>
    <a href="#openai-curl">cURL</a>

    <div class="sidebar-section">Errors &amp; Limits</div>
    <a href="#errors">Error Codes</a>
    <a href="#rate-limits">Rate Limits</a>

    <div class="sidebar-section">Node Operators</div>
    <a href="#node-api">Node API</a>
    <a href="#node-earnings">Earnings</a>

    <div class="sidebar-section">Resources</div>
    <a href="#model-catalog">Full Model Catalog</a>
    <a href="#faq">FAQ</a>
  </aside>

  <!-- MAIN CONTENT -->
  <main class="docs-content">

    <!-- INTRO -->
    <section id="intro">
      <h1>API Documentation</h1>
      <p style="font-size:1.05rem;color:var(--text);margin-top:.5rem">Decentralized AI inference · OpenAI-compatible · 300+ open models · from <strong>$0.005 / 1k tokens</strong></p>
      <p>ChainMind provides a fully OpenAI-compatible REST API backed by a community network of GPU nodes. Drop it in anywhere you use OpenAI and your code works unchanged.</p>
      <div class="notice"><p><strong>Base URL:</strong> <code>https://api.chainmind.com.ng/v1</code></p></div>
    </section>

    <!-- QUICKSTART -->
    <section id="quickstart">
      <h2>Quickstart</h2>
      <p>Get your first response in under 60 seconds.</p>

      <h3>1. Get an API key</h3>
      <p><a href="/auth/register.php">Sign up free</a> — you get <strong>500 credits</strong> on signup (~100k tokens). Find your key in the <a href="/dashboard/">Dashboard</a> under API Keys.</p>

      <h3>2. Send a request</h3>
      <pre><code class="lang">bash</code>curl https://api.chainmind.com.ng/v1/chat/completions \
  -H "Authorization: Bearer cm_YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "llama3.1:8b",
    "messages": [
      {"role": "user", "content": "Explain blockchain in one sentence."}
    ]
  }'</pre>

      <h3>3. Streaming</h3>
      <pre><code class="lang">bash</code>curl https://api.chainmind.com.ng/v1/chat/completions \
  -H "Authorization: Bearer cm_YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "llama3.1:8b",
    "stream": true,
    "messages": [{"role": "user", "content": "Write a haiku about GPUs"}]
  }'</pre>
    </section>

    <!-- AUTHENTICATION -->
    <section id="authentication">
      <h2>Authentication</h2>
      <p>All API requests require a Bearer token in the <code>Authorization</code> header:</p>
      <pre>Authorization: Bearer cm_YOUR_API_KEY</pre>
      <p>Keys start with <code>cm_</code>. Create, rotate, and revoke keys from the <a href="/dashboard/">Dashboard → API Keys</a>. You can set a <strong>credit cap</strong> per key so a runaway script can't drain your balance.</p>
      <div class="notice warn"><p>Never embed your API key in client-side JavaScript or public repositories. Treat it like a password.</p></div>
    </section>

    <!-- BASE URL -->
    <section id="base-url">
      <h2>Base URL</h2>
      <pre>https://api.chainmind.com.ng/v1</pre>
      <p>All endpoints are HTTPS only. HTTP requests are redirected to HTTPS.</p>
    </section>

    <!-- CREDITS -->
    <section id="credits">
      <h2>Credits &amp; Billing</h2>
      <table>
        <tr><th>Item</th><th>Rate</th></tr>
        <tr><td>Credits to USD</td><td>1,000 credits = $1.00 USD</td></tr>
        <tr><td>Price per 1k tokens</td><td>~5 credits ($0.005)</td></tr>
        <tr><td>Free signup bonus</td><td>500 credits (~100k tokens)</td></tr>
        <tr><td>Pay-as-you-go</td><td>$5 → 5,000 credits</td></tr>
        <tr><td>Pro plan</td><td>$15/mo → 20,000 credits/mo</td></tr>
        <tr><td>Builder plan</td><td>$40/mo → 60,000 credits/mo</td></tr>
      </table>
      <p>Credits are deducted per request based on total tokens (prompt + completion). Check your balance anytime from <a href="/dashboard/">Dashboard → Credits</a> or via the API header <code>X-Credits-Remaining</code> returned on every response.</p>
    </section>

    <!-- CHAT COMPLETIONS -->
    <section id="chat-completions">
      <h2>Chat Completions</h2>
      <div class="endpoint"><span class="badge badge-post">POST</span><code>/v1/chat/completions</code></div>
      <p>Generate a response to a conversation. 100% compatible with the OpenAI Chat Completions API format.</p>

      <h3>Request body</h3>
      <table class="param-table">
        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
        <tr><td>model</td><td>string</td><td>required</td><td>Model ID. See <a href="#model-catalog">Model Catalog</a>. e.g. <code>llama3.1:8b</code></td></tr>
        <tr><td>messages</td><td>array</td><td>required</td><td>Array of message objects: <code>{"role":"user","content":"..."}</code>. Roles: <code>system</code>, <code>user</code>, <code>assistant</code></td></tr>
        <tr><td>stream</td><td>boolean</td><td>optional</td><td><code>true</code> to receive Server-Sent Events. Default: <code>false</code></td></tr>
        <tr><td>temperature</td><td>number</td><td>optional</td><td>0.0–2.0. Controls randomness. Default: <code>0.7</code></td></tr>
        <tr><td>max_tokens</td><td>integer</td><td>optional</td><td>Maximum tokens in the response. Default depends on model.</td></tr>
        <tr><td>top_p</td><td>number</td><td>optional</td><td>Nucleus sampling. Default: <code>1.0</code></td></tr>
        <tr><td>stop</td><td>string/array</td><td>optional</td><td>Stop sequences</td></tr>
        <tr><td>user</td><td>string</td><td>optional</td><td>Unique end-user ID for abuse detection</td></tr>
      </table>

      <h3>Example request</h3>
      <pre><code class="lang">json</code>{
  "model": "llama3.1:8b",
  "temperature": 0.5,
  "max_tokens": 512,
  "messages": [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user",   "content": "Summarise the Nigerian constitution in 3 bullet points."}
  ]
}</pre>

      <h3>Example response</h3>
      <pre><code class="lang">json</code>{
  "id": "chatcmpl-abc123",
  "object": "chat.completion",
  "created": 1717200000,
  "model": "llama3.1:8b",
  "choices": [{
    "index": 0,
    "message": {
      "role": "assistant",
      "content": "..."
    },
    "finish_reason": "stop"
  }],
  "usage": {
    "prompt_tokens": 38,
    "completion_tokens": 124,
    "total_tokens": 162
  }
}</pre>

      <h3>Streaming response</h3>
      <p>When <code>stream: true</code>, responses are sent as Server-Sent Events:</p>
      <pre><code class="lang">text/event-stream</code>data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","choices":[{"delta":{"content":"Hello"},"index":0}]}

data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","choices":[{"delta":{"content":" world"},"index":0}]}

data: [DONE]</pre>
    </section>

    <!-- COMPLETIONS -->
    <section id="completions">
      <h2>Completions (Legacy)</h2>
      <div class="endpoint"><span class="badge badge-post">POST</span><code>/v1/completions</code></div>
      <p>Raw text completion. Most new applications should use <a href="#chat-completions">Chat Completions</a> instead.</p>

      <h3>Request body</h3>
      <table class="param-table">
        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
        <tr><td>model</td><td>string</td><td>required</td><td>Model ID</td></tr>
        <tr><td>prompt</td><td>string</td><td>required</td><td>Input text to complete</td></tr>
        <tr><td>max_tokens</td><td>integer</td><td>optional</td><td>Max tokens to generate. Default: 256</td></tr>
        <tr><td>temperature</td><td>number</td><td>optional</td><td>0.0–2.0. Default: 0.7</td></tr>
        <tr><td>stream</td><td>boolean</td><td>optional</td><td>Stream tokens. Default: false</td></tr>
      </table>

      <pre><code class="lang">bash</code>curl https://api.chainmind.com.ng/v1/completions \
  -H "Authorization: Bearer cm_YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"mistral","prompt":"The capital of Nigeria is","max_tokens":20}'</pre>
    </section>

    <!-- EMBEDDINGS -->
    <section id="embeddings">
      <h2>Embeddings</h2>
      <div class="endpoint"><span class="badge badge-post">POST</span><code>/v1/embeddings</code></div>
      <p>Generate vector embeddings for semantic search, classification, and similarity tasks.</p>

      <table class="param-table">
        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
        <tr><td>model</td><td>string</td><td>required</td><td>Use <code>nomic-embed-text</code> or <code>mxbai-embed-large</code></td></tr>
        <tr><td>input</td><td>string/array</td><td>required</td><td>String or array of strings to embed</td></tr>
      </table>

      <pre><code class="lang">bash</code>curl https://api.chainmind.com.ng/v1/embeddings \
  -H "Authorization: Bearer cm_YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"nomic-embed-text","input":"ChainMind is a decentralized AI network"}'</pre>

      <h3>Response</h3>
      <pre><code class="lang">json</code>{
  "object": "list",
  "data": [{
    "object": "embedding",
    "embedding": [0.0023, -0.0142, ...],
    "index": 0
  }],
  "model": "nomic-embed-text",
  "usage": {"prompt_tokens": 9, "total_tokens": 9}
}</pre>
    </section>

    <!-- MODELS -->
    <section id="models">
      <h2>List Models</h2>
      <div class="endpoint"><span class="badge badge-get">GET</span><code>/v1/models</code></div>
      <p>Returns all models currently available on the network.</p>

      <pre><code class="lang">bash</code>curl https://api.chainmind.com.ng/v1/models \
  -H "Authorization: Bearer cm_YOUR_API_KEY"</pre>

      <h3>Response</h3>
      <pre><code class="lang">json</code>{
  "object": "list",
  "data": [
    {"id":"llama3.1:8b",   "object":"model","owned_by":"meta"},
    {"id":"llama3.1:70b",  "object":"model","owned_by":"meta"},
    {"id":"mistral",       "object":"model","owned_by":"mistral"},
    {"id":"deepseek-coder","object":"model","owned_by":"deepseek"},
    ...
  ]
}</pre>
    </section>

    <!-- OPENAI COMPAT -->
    <section id="openai-compat">
      <h2>OpenAI Compatibility</h2>
      <p>ChainMind implements the full OpenAI v1 API surface. Change <strong>two things</strong> in your existing code and it works:</p>
      <ul>
        <li><code>base_url</code> → <code>https://api.chainmind.com.ng/v1</code></li>
        <li><code>api_key</code> → your ChainMind key (<code>cm_...</code>)</li>
      </ul>
      <p>Same JSON schema. Same streaming format. Same error codes. Same SDK support.</p>
    </section>

    <section id="openai-python">
      <h2>Python SDK Example</h2>
      <pre><code class="lang">python</code>from openai import OpenAI

client = OpenAI(
    base_url="https://api.chainmind.com.ng/v1",
    api_key="cm_YOUR_API_KEY"
)

# Non-streaming
response = client.chat.completions.create(
    model="llama3.1:8b",
    messages=[{"role": "user", "content": "What is the Lagos Stock Exchange?"}]
)
print(response.choices[0].message.content)

# Streaming
stream = client.chat.completions.create(
    model="mistral",
    stream=True,
    messages=[{"role": "user", "content": "Write a Python function to parse JSON"}]
)
for chunk in stream:
    print(chunk.choices[0].delta.content or "", end="", flush=True)</pre>
    </section>

    <section id="openai-node">
      <h2>Node.js SDK Example</h2>
      <pre><code class="lang">javascript</code>import OpenAI from "openai";

const client = new OpenAI({
  baseURL: "https://api.chainmind.com.ng/v1",
  apiKey: "cm_YOUR_API_KEY",
});

// Chat completion
const response = await client.chat.completions.create({
  model: "llama3.1:8b",
  messages: [{ role: "user", content: "Explain proof-of-stake." }],
});
console.log(response.choices[0].message.content);

// Streaming
const stream = await client.chat.completions.create({
  model: "llama3.1:8b",
  stream: true,
  messages: [{ role: "user", content: "Give me a bedtime story." }],
});
for await (const chunk of stream) {
  process.stdout.write(chunk.choices[0]?.delta?.content || "");
}</pre>
    </section>

    <section id="openai-curl">
      <h2>cURL Examples</h2>
      <h3>Chat completion</h3>
      <pre><code class="lang">bash</code>curl https://api.chainmind.com.ng/v1/chat/completions \
  -H "Authorization: Bearer cm_YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "llama3.1:8b",
    "messages": [{"role":"user","content":"Hello!"}]
  }'</pre>

      <h3>List models</h3>
      <pre><code class="lang">bash</code>curl https://api.chainmind.com.ng/v1/models \
  -H "Authorization: Bearer cm_YOUR_API_KEY"</pre>

      <h3>Embeddings</h3>
      <pre><code class="lang">bash</code>curl https://api.chainmind.com.ng/v1/embeddings \
  -H "Authorization: Bearer cm_YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"nomic-embed-text","input":"Hello world"}'</pre>
    </section>

    <!-- ERRORS -->
    <section id="errors">
      <h2>Error Codes</h2>
      <p>Errors follow the standard OpenAI error format:</p>
      <pre><code class="lang">json</code>{
  "error": {
    "message": "Invalid API key",
    "type": "authentication_error",
    "code": "invalid_api_key"
  }
}</pre>

      <table>
        <tr><th>HTTP Status</th><th>Type</th><th>Meaning</th></tr>
        <tr><td class="err-code">400</td><td>invalid_request_error</td><td>Malformed request or missing required parameter</td></tr>
        <tr><td class="err-code">401</td><td>authentication_error</td><td>Missing or invalid API key</td></tr>
        <tr><td class="err-code">402</td><td>insufficient_credits</td><td>Your account has run out of credits. <a href="/dashboard/">Top up here.</a></td></tr>
        <tr><td class="err-code">403</td><td>permission_error</td><td>Your key does not have permission for this operation or credit cap reached</td></tr>
        <tr><td class="err-code">404</td><td>not_found_error</td><td>Model not found or endpoint does not exist</td></tr>
        <tr><td class="err-code">429</td><td>rate_limit_error</td><td>Too many requests. Back off and retry.</td></tr>
        <tr><td class="err-code">500</td><td>server_error</td><td>Internal server error. Retry after a few seconds.</td></tr>
        <tr><td class="err-code">503</td><td>no_nodes_available</td><td>No nodes currently available for the requested model. Try a different model or retry shortly.</td></tr>
      </table>

      <h3>Retry strategy</h3>
      <p>For <code>429</code> and <code>503</code> errors, implement exponential backoff: wait 1s, 2s, 4s, 8s between retries. Most <code>503</code> errors resolve within 30 seconds as the router finds a free node.</p>
    </section>

    <!-- RATE LIMITS -->
    <section id="rate-limits">
      <h2>Rate Limits</h2>
      <table>
        <tr><th>Plan</th><th>Requests / min</th><th>Tokens / min</th></tr>
        <tr><td>Free (500 credits)</td><td>10</td><td>10,000</td></tr>
        <tr><td>Pay-as-you-go</td><td>30</td><td>50,000</td></tr>
        <tr><td>Pro</td><td>60</td><td>200,000</td></tr>
        <tr><td>Builder</td><td>120</td><td>500,000</td></tr>
      </table>
      <p>Rate limit headers are returned on every response:</p>
      <pre>X-RateLimit-Limit-Requests: 60
X-RateLimit-Remaining-Requests: 57
X-RateLimit-Reset-Requests: 2025-06-01T12:00:30Z</pre>
    </section>

    <!-- NODE API -->
    <section id="node-api">
      <h2>Node API (Operators)</h2>
      <p>The local FastAPI server runs on port <strong>8000</strong> on each operator's machine. These endpoints are called by the ChainMind central server — you don't call them directly in production.</p>

      <div class="endpoint"><span class="badge badge-get">GET</span><code>http://localhost:8000/health</code></div>
      <p>Health check — returns node status, version, uptime, and GPU info.</p>

      <div class="endpoint"><span class="badge badge-post">POST</span><code>http://localhost:8000/infer</code></div>
      <p>Submit a local inference job directly to your node (useful for testing).</p>
      <pre><code class="lang">json</code>{
  "prompt": "Hello!",
  "model": "tinyllama"
}</pre>

      <div class="endpoint"><span class="badge badge-get">GET</span><code>http://localhost:8000/tasks/{task_id}</code></div>
      <p>Poll for the result of an async inference task.</p>

      <div class="endpoint"><span class="badge badge-get">GET</span><code>http://localhost:8000/models</code></div>
      <p>List models currently installed and available on this node.</p>
    </section>

    <!-- EARNINGS -->
    <section id="node-earnings">
      <h2>Node Earnings</h2>
      <table>
        <tr><th>Metric</th><th>Value</th></tr>
        <tr><td>IQ earned per 1M tokens processed</td><td>1,000 IQ</td></tr>
        <tr><td>IQ to USD</td><td>100 IQ = $1.00 USD</td></tr>
        <tr><td>Minimum cashout</td><td>10 IQ</td></tr>
        <tr><td>Payout methods</td><td>Crypto wallet, NGN bank account</td></tr>
      </table>
      <p>Track earnings in real time in the <a href="/dashboard/node-earnings.php">Node Earnings</a> dashboard tab. Payouts are processed manually on request; automated payouts coming in a future release.</p>

      <h3>Tier multipliers</h3>
      <table>
        <tr><th>Node tier</th><th>VRAM</th><th>Multiplier</th></tr>
        <tr><td>Standard</td><td>&lt; 8 GB</td><td>1×</td></tr>
        <tr><td>Pro</td><td>8–16 GB</td><td>1.5×</td></tr>
        <tr><td>Ultra</td><td>&gt; 16 GB</td><td>2×</td></tr>
      </table>
    </section>

    <!-- MODEL CATALOG -->
    <section id="model-catalog">
      <h2>Full Model Catalog</h2>
      <p>All models use their Ollama tag as the model ID in the API.</p>

      <h3>General Purpose</h3>
      <table>
        <tr><th>Model ID</th><th>Parameters</th><th>Context</th><th>Best for</th></tr>
        <tr><td>llama3.1:8b</td><td>8B</td><td>128k</td><td>Fast, high-quality general tasks</td></tr>
        <tr><td>llama3.1:70b</td><td>70B</td><td>128k</td><td>Complex reasoning, best quality</td></tr>
        <tr><td>llama3.2:3b</td><td>3B</td><td>128k</td><td>Ultra-fast, light tasks</td></tr>
        <tr><td>mistral</td><td>7B</td><td>32k</td><td>Balanced speed and quality</td></tr>
        <tr><td>mixtral:8x7b</td><td>47B MoE</td><td>32k</td><td>High throughput mixture-of-experts</td></tr>
      </table>

      <h3>Coding</h3>
      <table>
        <tr><th>Model ID</th><th>Parameters</th><th>Best for</th></tr>
        <tr><td>deepseek-coder</td><td>6.7B</td><td>Code generation and review</td></tr>
        <tr><td>codellama</td><td>7B</td><td>Code completion, infill</td></tr>
        <tr><td>qwen2.5-coder</td><td>7B</td><td>Multi-language coding tasks</td></tr>
      </table>

      <h3>Compact / Edge</h3>
      <table>
        <tr><th>Model ID</th><th>Parameters</th><th>Best for</th></tr>
        <tr><td>qwen2:0.5b</td><td>0.5B</td><td>Minimum-latency tasks</td></tr>
        <tr><td>tinyllama</td><td>1.1B</td><td>Testing, low-spec nodes</td></tr>
        <tr><td>phi3:mini</td><td>3.8B</td><td>Small but capable</td></tr>
      </table>

      <h3>Embeddings</h3>
      <table>
        <tr><th>Model ID</th><th>Dimensions</th><th>Best for</th></tr>
        <tr><td>nomic-embed-text</td><td>768</td><td>Semantic search, RAG</td></tr>
        <tr><td>mxbai-embed-large</td><td>1024</td><td>High-accuracy retrieval</td></tr>
      </table>

      <h3>Vision</h3>
      <table>
        <tr><th>Model ID</th><th>Best for</th></tr>
        <tr><td>llava</td><td>Image understanding and captioning</td></tr>
        <tr><td>bakllava</td><td>Multimodal chat</td></tr>
      </table>

      <p>Full list via API: <code>GET /v1/models</code> or <code>curl https://api.chainmind.com.ng/v1/models</code></p>
    </section>

    <!-- FAQ -->
    <section id="faq">
      <h2>FAQ</h2>

      <h3>Is ChainMind really OpenAI-compatible?</h3>
      <p>Yes. The request and response schema matches OpenAI's v1 API exactly. Change your <code>base_url</code> and <code>api_key</code> — nothing else needs to change.</p>

      <h3>What happens if the node processing my job goes offline?</h3>
      <p>The router detects the failure and reassigns the job to another available node automatically. From your application, it appears as normal latency or, in rare cases, a <code>503</code> error you can retry.</p>

      <h3>Are my prompts private?</h3>
      <p>Jobs are routed to nodes ephemerally. The node processes your prompt in memory and returns the result — it does not store prompt content. Our <a href="/privacy.php">Privacy Policy</a> details what metadata we log.</p>

      <h3>What currencies do you accept?</h3>
      <p>NGN via Paystack, USD/cards via Flutterwave, and BTC/ETH/USDT via NOWPayments.</p>

      <h3>Can I run multiple API keys?</h3>
      <p>Yes. Create up to 20 keys per account from the Dashboard. Each key can have its own credit cap and label.</p>

      <h3>How do I report a bug or security issue?</h3>
      <p>Email <a href="mailto:security@chainmind.com.ng">security@chainmind.com.ng</a> for security issues. For bugs, open an issue on <a href="https://github.com/RCACREATIONS/chainmind-network/issues" target="_blank" rel="noopener">GitHub</a>.</p>
    </section>

  </main>
</div>

<footer>
  <p>
    &copy; <?= date('Y') ?> ChainMind Network — RCA Creations, Lagos, Nigeria &nbsp;|&nbsp;
    <a href="/privacy.php">Privacy</a>
    <a href="/terms.php">Terms</a>
    <a href="/refund.php">Refunds</a>
    <a href="/aup.php">Acceptable Use</a>
    <a href="/cookies.php">Cookies</a>
    <a href="mailto:support@chainmind.com.ng">Support</a>
  </p>
</footer>

<script>
// Highlight active sidebar link on scroll
const sections = document.querySelectorAll('section[id]');
const links = document.querySelectorAll('.sidebar a');
const observer = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      links.forEach(l => l.classList.remove('active'));
      const active = document.querySelector('.sidebar a[href="#'+e.target.id+'"]');
      if (active) active.classList.add('active');
    }
  });
}, {rootMargin: '-20% 0px -75% 0px'});
sections.forEach(s => observer.observe(s));
</script>

</body>
</html>