ChainMind Motion Ad — Sound Effects Library
============================================

Place .mp3 files in each subdirectory. Nodes download and cache them
automatically when rendering motion ads.

Free commercial-use sound effects: https://mixkit.co/free-sound-effects/
(no account needed)

Categories:
  whoosh/  — transition whoosh sounds
  pop/     — text/logo pop-in sounds
  chime/   — CTA reveal / highlight
  swipe/   — slide transition sounds
  impact/  — price/offer reveal

The node fetches /api/sfx-manifest.php once and caches files locally.
