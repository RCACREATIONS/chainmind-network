<?php
// GET /api/sfx-manifest.php
// Returns a JSON list of all sound effect files available for motion ad rendering.
// Nodes fetch this once and cache the files locally.
//
// Response:
// {
//   "base_url": "https://chainmind.com.ng/assets/sfx",
//   "categories": {
//     "whoosh": ["whoosh_1.mp3", "whoosh_2.mp3"],
//     "pop":    ["pop_1.mp3"],
//     ...
//   }
// }

require_once __DIR__ . '/_helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') json_err('GET only', 405);

$sfx_base = __DIR__ . '/../assets/sfx';
$categories = ['whoosh', 'pop', 'chime', 'swipe', 'impact'];
$manifest = [];

foreach ($categories as $cat) {
    $dir = $sfx_base . '/' . $cat;
    $files = [];
    if (is_dir($dir)) {
        foreach (glob($dir . '/*.mp3') as $f) {
            $files[] = basename($f);
        }
        sort($files);
    }
    $manifest[$cat] = $files;
}

// Determine public base URL
$scheme   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host     = $_SERVER['HTTP_HOST'] ?? 'chainmind.com.ng';
$base_url = $scheme . '://' . $host . '/assets/sfx';

json_ok([
    'base_url'   => $base_url,
    'categories' => $manifest,
]);
