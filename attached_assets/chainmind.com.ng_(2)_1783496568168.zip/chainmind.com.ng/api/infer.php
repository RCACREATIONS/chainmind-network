<?php
require_once __DIR__ . '/_helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST only', 405);

// ── Rate limiting (anonymous users) ──────────────────────────────────────────
$is_anonymous = empty($_SERVER['HTTP_X_API_KEY'] ?? '');
if ($is_anonymous) {
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP']
        ?? $_SERVER['HTTP_X_FORWARDED_FOR']
        ?? $_SERVER['REMOTE_ADDR']
        ?? 'unknown';

    $ip = trim(explode(',', $ip)[0]);

    $window = 60;
    $limit  = 10;
    $key    = 'rl:' . md5($ip);

    db()->exec("
        CREATE TABLE IF NOT EXISTS rate_limits (
            key_hash VARCHAR(64) PRIMARY KEY,
            count INT NOT NULL DEFAULT 1,
            window_start DATETIME NOT NULL
        )
    ");

    $row = db()->prepare("SELECT count, window_start FROM rate_limits WHERE key_hash = ?");
    $row->execute([$key]);
    $rl = $row->fetch();

    if ($rl) {
        $age = time() - strtotime($rl['window_start']);

        if ($age > $window) {
            db()->prepare("UPDATE rate_limits SET count=1, window_start=NOW() WHERE key_hash=?")
                ->execute([$key]);
        } else {
            if ((int)$rl['count'] >= $limit) {
                $retry = $window - $age;
                http_response_code(429);
                header('Retry-After: ' . $retry);
                echo json_encode([
                    'error' => "Rate limit exceeded. Try again in {$retry}s.",
                    'retry_after' => $retry
                ]);
                exit;
            }

            db()->prepare("UPDATE rate_limits SET count=count+1 WHERE key_hash=?")
                ->execute([$key]);
        }
    } else {
        db()->prepare("INSERT INTO rate_limits (key_hash, count, window_start) VALUES (?,1,NOW())")
            ->execute([$key]);
    }
}

$b = require_json_body();

$prompt   = trim($b['prompt'] ?? '');
if (!$prompt) json_err('prompt is required');
if (mb_strlen($prompt) > MAX_PROMPT_LENGTH)
    json_err('Prompt too long (max ' . MAX_PROMPT_LENGTH . ' chars)');

$model    = trim($b['model'] ?? '') ?: null;
$system   = trim($b['system'] ?? '');

// ── Model routing: only auto-detect from the prompt text when the client
// didn't already pick a model explicitly (e.g. via a dropdown). ──────────
$model_note = null;
if (!$model) {
    $routing    = resolve_model_request($prompt);
    $model      = $routing['model'];
    $model_note = $routing['note'];
}

// FIX: Accept conversation history from the dashboard chat memory system.
// The dashboard sends: messages:[{role:'user'|'assistant', content:'...'}]
// We store this as JSON so the node can use it for proper multi-turn context.
$messages = [];
if (!empty($b['messages']) && is_array($b['messages'])) {
    foreach ($b['messages'] as $m) {
        $role    = $m['role']    ?? '';
        $content = $m['content'] ?? '';
        if (in_array($role, ['user', 'assistant'], true) && $content) {
            $messages[] = ['role' => $role, 'content' => (string)$content];
        }
    }
}
$messages_json = !empty($messages) ? json_encode($messages) : null;

// ── API key detection ────────────────────────────────────────────────────────
$source     = 'webchat';
$api_key_id = null;

$key_header = $_SERVER['HTTP_X_API_KEY'] ?? '';
if ($key_header) {
    $keyRow     = validate_api_key();
    $source     = 'api';
    $api_key_id = $keyRow['id'];

    db()->prepare('UPDATE api_keys SET total_jobs = total_jobs + 1 WHERE id = ?')
        ->execute([$api_key_id]);
}

// ── Check nodes ──────────────────────────────────────────────────────────────
sweep_offline_nodes();
$online = db()->query("SELECT COUNT(*) FROM nodes WHERE status = 'online'")->fetchColumn();
if ($online == 0) json_err('No nodes online right now. Try again shortly.', 503);

// ── Skip credit check for internal summarisation calls ───────────────────────
$is_internal = ($_SERVER['HTTP_X_INTERNAL_SUMMARY'] ?? '') === '1';

// ── Ensure messages_context column exists ────────────────────────────────────
try {
    $q = db()->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'jobs' AND COLUMN_NAME = 'messages_context'");
    if ((int)$q->fetchColumn() === 0) {
        db()->exec("ALTER TABLE jobs ADD COLUMN messages_context JSON NULL");
    }
} catch (\Throwable $e) {
    error_log('[schema] Could not add messages_context column: ' . $e->getMessage());
}

// ── Also ensure job_type / image_params columns ──────────────────────────────
ensure_jobs_columns();

// ── Credit check ─────────────────────────────────────────────────────────────
require_once __DIR__ . '/billing/credits.php';

if ($api_key_id && !$is_internal) {
    $est_model  = $model ?? 'default';
    $est_tokens = 2000;

    $job_cost = calc_job_cost($est_model, $est_tokens);
    $balance  = credits_get($api_key_id);

    if ($balance < $job_cost) {
        json_err(
            'Insufficient credits. Balance: ' . $balance .
            ', required: ' . $job_cost .
            '. Top up at: https://chainmind.com.ng/dashboard/billing.php',
            402
        );
    }
}

// ── Queue the job ─────────────────────────────────────────────────────────────
$job_id = uuid4();

$stmt = db()->prepare("
    INSERT INTO jobs (id, prompt, model, system_prompt, messages_context, status, source, api_key_id, created_at)
    VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, NOW())
");

$stmt->execute([$job_id, $prompt, $model, $system, $messages_json, $source, $api_key_id]);

// ── Credit deduction ──────────────────────────────────────────────────────────
if ($api_key_id && !$is_internal && isset($job_cost)) {
    credits_deduct($api_key_id, $job_id, $job_cost);
}

json_ok([
    'job_id'     => $job_id,
    'status'     => 'pending',
    'poll_url'   => "/api/job.php?id=$job_id",
    'message'    => 'Job queued. Poll poll_url for result.',
    'model_note' => $model_note,
]);
