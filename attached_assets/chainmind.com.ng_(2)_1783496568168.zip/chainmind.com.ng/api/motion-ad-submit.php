<?php
// ============================================================
// ChainMind  Motion Ad Submit (Dashboard / Web UI)
// POST /api/motion-ad-submit.php
//
// Auth: PHP session (user must be logged in to dashboard)
// Content-Type: multipart/form-data
//
// Fields:
//   business_name  (required)
//   product        (required)
//   tagline        (optional, max 150 chars)
//   tone           (optional: friendly|energetic|professional|funny|luxury|urgent)
//   duration_s     (optional: 10-60, default 15)
//   product_image  (optional image file upload, max 10 MB)
//
// Returns: { ok:true, job_id:"...", poll:"/api/job.php?id=..." }
// ============================================================

session_start();
require_once __DIR__ . '/_helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST only', 405);
if (empty($_SESSION['user_id'])) json_err('Login required. Please sign in to your dashboard.', 401);

$user_id = (int)$_SESSION['user_id'];

// ── Get user's primary API key ────────────────────────────────
$kStmt = db()->prepare('SELECT id FROM api_keys WHERE user_id = ? AND is_active = 1 ORDER BY id ASC LIMIT 1');
$kStmt->execute([$user_id]);
$keyRow = $kStmt->fetch();
if (!$keyRow) json_err('No active API key found. Please visit your dashboard to set one up.', 400);
$api_key_id = (int)$keyRow['id'];

// ── Validate inputs ───────────────────────────────────────────
$business_name = trim($_POST['business_name'] ?? '');
$product       = trim($_POST['product']       ?? '');
$tagline       = substr(trim($_POST['tagline'] ?? ''), 0, 150);
$tone          = trim($_POST['tone']          ?? 'friendly');
$duration_s    = max(10, min(60, (int)($_POST['duration_s'] ?? 15)));

if (!$business_name) json_err('business_name is required');
if (!$product)       json_err('product is required');

$valid_tones = ['friendly','energetic','professional','funny','luxury','urgent'];
if (!in_array($tone, $valid_tones, true)) $tone = 'friendly';

// ── Handle optional product image upload ─────────────────────
$product_image_path = null;
if (!empty($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['product_image'];
    $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_img = ['jpg','jpeg','png','gif','webp'];
    $max_img_size = 10 * 1024 * 1024; // 10 MB

    if (!in_array($ext, $allowed_img, true)) {
        json_err('Unsupported image format. Use JPG, PNG, GIF, or WebP.', 400);
    }
    if ($file['size'] > $max_img_size) {
        json_err('Image file exceeds 10 MB limit.', 400);
    }

    $upload_dir = __DIR__ . '/../uploads/generated_ads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    $filename = 'product_' . bin2hex(random_bytes(8)) . '.' . $ext;
    $dest     = $upload_dir . $filename;

    if (move_uploaded_file($file['tmp_name'], $dest)) {
        $product_image_path = '/uploads/generated_ads/' . $filename;
    }
}

// ── Check a capable node is online ──────────────────────────
$capable_node = db()->query("
    SELECT id FROM nodes
    WHERE status = 'online'
      AND capabilities LIKE '%motion_ad%'
    LIMIT 1
")->fetch();
if (!$capable_node) json_err('No motion_ad capable node is online right now. Try again shortly.', 503);

// ── Check credits (50 per motion ad — more than a regular prompt) ────────
require_once __DIR__ . '/billing/credits.php';
$cost    = 50;
$balance = credits_get($api_key_id);
if ($balance < $cost) json_err("Insufficient credits. You have {$balance}, need {$cost}. Please top up your balance.", 402);

// ── Ensure required job columns exist ───────────────────────
ensure_jobs_columns();

// ── Queue the job ────────────────────────────────────────────
$job_id = bin2hex(random_bytes(16));

$image_params = json_encode([
    'business_name'      => $business_name,
    'product'            => $product,
    'tagline'            => $tagline,
    'tone'               => $tone,
    'duration_s'         => $duration_s,
    'product_image_path' => $product_image_path,
]);

db()->prepare("
    INSERT INTO jobs (id, user_id, api_key_id, prompt, model, job_type, image_params, status, source, created_at)
    VALUES (?, ?, ?, ?, 'motion_ad', 'motion_ad', ?, 'pending', 'dashboard', NOW())
")->execute([
    $job_id,
    $user_id,
    $api_key_id,
    encrypt_field("Motion ad: {$business_name} — {$product}"),
    $image_params,
]);

// ── Deduct credits atomically ─────────────────────────────────
credits_deduct($api_key_id, $job_id, $cost);

json_ok([
    'ok'              => true,
    'job_id'          => $job_id,
    'poll'            => "/api/job.php?id={$job_id}",
    'credits_charged' => $cost,
]);
