<?php
// GET /api/node/peers.php
// Returns all online nodes known to the central server.
// Used by nodes for central-assisted peer discovery.
//
// Headers: X-Node-Secret, X-Node-Id
//
// Returns:
// {
//   "peers": [
//     { "id": "...", "url": "...", "name": "...", "tier": "...", "models": [...], "status": "online" }
//   ],
//   "total": 3
// }

require_once __DIR__ . '/../_helpers.php';
cors();

validate_node_secret();
$node_id = get_node_id();

sweep_offline_nodes();

// Return all online nodes except the requester
$stmt = db()->prepare("
    SELECT id, url, name, tier, models, reputation, jobs_done, iq_earned, status, last_seen
    FROM nodes
    WHERE status = 'online'
      AND id != ?
      AND url != ''
    ORDER BY reputation DESC
    LIMIT 50
");
$stmt->execute([$node_id]);
$peers = $stmt->fetchAll();

// Parse models JSON for each peer
foreach ($peers as &$peer) {
    $peer['models'] = json_decode($peer['models'] ?? '[]', true) ?: [];
    $peer['reputation'] = (float)$peer['reputation'];
    $peer['jobs_done']  = (int)$peer['jobs_done'];
    $peer['iq_earned']  = (float)$peer['iq_earned'];
}

json_ok([
    'peers' => $peers,
    'total' => count($peers),
]);