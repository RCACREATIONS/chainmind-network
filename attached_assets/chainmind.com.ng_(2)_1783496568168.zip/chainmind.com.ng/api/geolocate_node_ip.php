<?php
/**
 * geolocate_node_ip.php
 * Place in /api/ alongside _helpers.php
 *
 * Uses cURL (not file_get_contents — blocked on most cPanel servers).
 * ip-api.com free tier: 45 req/min, no API key needed.
 */

function get_node_ip(): string {
    $candidates = [
        $_SERVER['HTTP_X_FORWARDED_FOR']  ?? '',
        $_SERVER['HTTP_CF_CONNECTING_IP'] ?? '',
        $_SERVER['HTTP_X_REAL_IP']        ?? '',
        $_SERVER['REMOTE_ADDR']           ?? '',
    ];
    foreach ($candidates as $raw) {
        foreach (explode(',', $raw) as $ip) {
            $ip = trim($ip);
            if ($ip && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return $ip;
            }
        }
    }
    return trim($_SERVER['REMOTE_ADDR'] ?? '');
}

function geolocate_node_ip(PDO $pdo, string $node_id, string $ip): void {
    if (!$ip) return;

    // Skip if IP hasn't changed since last geo lookup
    $cur = $pdo->prepare('SELECT ip FROM nodes WHERE id = ? LIMIT 1');
    $cur->execute([$node_id]);
    $row = $cur->fetch(PDO::FETCH_ASSOC);
    if ($row && $row['ip'] === $ip) return;

    // Always store the IP immediately, even if geo lookup fails
    $pdo->prepare('UPDATE nodes SET ip = ? WHERE id = ?')->execute([$ip, $node_id]);

    // ── cURL call to ip-api.com ───────────────────────────────────────────────
    $url = 'http://ip-api.com/json/' . urlencode($ip) . '?fields=status,lat,lon,country,city';

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 5,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_USERAGENT      => 'ChainMind/1.0',
        CURLOPT_SSL_VERIFYPEER => false, // ip-api.com is HTTP anyway
    ]);

    $body = curl_exec($ch);
    $err  = curl_error($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($err || $http !== 200 || !$body) {
        error_log("[geo] cURL failed for {$ip}: err={$err} http={$http}");
        return;
    }

    $geo = json_decode($body, true);
    if (!$geo || ($geo['status'] ?? '') !== 'success') {
        error_log("[geo] ip-api returned bad status for {$ip}: " . $body);
        return;
    }

    $pdo->prepare(
        'UPDATE nodes SET lat = ?, lng = ?, country = ?, city = ?, geo_at = NOW() WHERE id = ?'
    )->execute([
        $geo['lat']     ?? null,
        $geo['lon']     ?? null,
        $geo['country'] ?? null,
        $geo['city']    ?? null,
        $node_id,
    ]);

    error_log("[geo] Located node {$node_id}: {$ip} → " . ($geo['city'] ?? '?') . ', ' . ($geo['country'] ?? '?'));
}