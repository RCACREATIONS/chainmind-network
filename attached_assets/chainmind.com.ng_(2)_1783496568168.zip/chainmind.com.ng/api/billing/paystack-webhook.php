<?php
// ============================================================
// ChainMind  Paystack Webhook
// Upload to: api/billing/paystack-webhook.php
// Register in Paystack Dashboard � Settings � Webhooks
// URL: https://chainmind.com.ng/api/billing/paystack-webhook.php
// ============================================================
require_once __DIR__ . '/../../api/_helpers.php';
require_once __DIR__ . '/credits.php';

$raw = file_get_contents('php://input');

// Verify signature
$sig = $_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? '';
if (!hash_equals(hash_hmac('sha512', $raw, PAYSTACK_SECRET_KEY), $sig)) {
    http_response_code(401); exit('Bad signature');
}

$event = json_decode($raw, true);
if (!$event || $event['event'] !== 'charge.success') {
    http_response_code(200); echo 'ok'; exit;
}

$data     = $event['data'];
$ref      = $data['reference'] ?? '';
$status   = $data['status']    ?? '';
$amount_k = (int)($data['amount'] ?? 0);    // amount in kobo
$currency = $data['currency']  ?? 'NGN';

if ($status !== 'success' || !$ref) {
    http_response_code(200); echo 'ok'; exit;
}

// Convert to USD
$amount_usd = match($currency) {
    'NGN' => $amount_k / 100 / PLAN_NGN_RATE,
    'USD' => $amount_k / 100,
    default => $amount_k / 100 / PLAN_NGN_RATE,
};

// Find api_key_id from metadata or reference
$metadata   = $data['metadata'] ?? [];
$api_key_id = (int)($metadata['api_key_id'] ?? 0);
if (!$api_key_id) {
    // Fall back: look up by payment ref
    $api_key_id = api_key_id_by_ref('paystack', $ref);
}
if (!$api_key_id) {
    // Last resort: email match
    $email = $data['customer']['email'] ?? '';
    $api_key_id = api_key_id_by_email($email);
}
if (!$api_key_id) {
    error_log('[paystack-webhook] No api_key_id for ref=' . $ref);
    http_response_code(200); echo 'ok'; exit;
}

$credits = confirm_payment($api_key_id, 'paystack', $ref, $amount_usd, $event);
error_log("[paystack-webhook] Confirmed $ref � $credits credits for api_key_id=$api_key_id");

http_response_code(200); echo 'ok';
