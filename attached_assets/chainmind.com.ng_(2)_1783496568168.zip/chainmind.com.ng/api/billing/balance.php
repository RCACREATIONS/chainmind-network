<?php
// GET /api/billing/balance.php  returns credit balance + recent history
session_start();
require_once __DIR__ . '/../../api/_helpers.php';
require_once __DIR__ . '/credits.php';
cors();

// Auth
$api_key_header = $_SERVER['HTTP_X_API_KEY'] ?? null;
if ($api_key_header) {
    $api_key_id = validate_api_key($api_key_header);
} elseif (isset($_SESSION['user_id'])) {
    $row = db()->prepare('SELECT id FROM api_keys WHERE user_id = ? AND is_active = 1 LIMIT 1');
    $row->execute([$_SESSION['user_id']]); $r = $row->fetch();
    $api_key_id = $r ? (int)$r['id'] : null;
} else { json_err('Unauthorized', 401); }
if (!$api_key_id) json_err('Invalid API key', 401);

$balance = credits_get($api_key_id);

$hist = db()->prepare(
    'SELECT d.amount, d.job_id, d.created_at, j.model
     FROM credit_deductions d LEFT JOIN jobs j ON j.id = d.job_id
     WHERE d.api_key_id = ? ORDER BY d.created_at DESC LIMIT 20'
);
$hist->execute([$api_key_id]);

$sub = db()->prepare('SELECT plan, credits_month, renews_at FROM subscriptions WHERE api_key_id = ? AND status = "active" ORDER BY id DESC LIMIT 1');
$sub->execute([$api_key_id]); $sub = $sub->fetch();

json_ok([
    'balance'        => $balance,
    'balance_usd'    => round($balance / CREDITS_PER_USD, 6),
    'credits_per_usd'=> CREDITS_PER_USD,
    'subscription'   => $sub ?: null,
    'recent_deductions' => $hist->fetchAll(PDO::FETCH_ASSOC),
]);
