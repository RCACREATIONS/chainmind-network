<?php
// ============================================================
// ChainMind  NOWPayments IPN Webhook
// Upload to: api/billing/nowpayments-webhook.php
// Register in NOWPayments � Store Settings � IPN Secret Key
// IPN URL: https://chainmind.com.ng/api/billing/nowpayments-webhook.php
// ============================================================
require_once __DIR__ . '/../../api/_helpers.php';
require_once __DIR__ . '/credits.php';

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

// Verify IPN signature (HMAC-SHA512 of sorted JSON)
$sig = $_SERVER['HTTP_X_NOWPAYMENTS_SIG'] ?? '';
ksort($data);
$expected = hash_hmac('sha512', json_encode($data), NOWPAYMENTS_IPN_SECRET);
if (!hash_equals($expected, $sig)) {
    http_response_code(401); exit('Bad signature');
}

$status   = $data['payment_status'] ?? '';
$ref      = $data['order_id']       ?? '';    // our cm-xxx reference
$usd      = (float)($data['price_amount'] ?? 0);
$currency = $data['price_currency'] ?? 'usd';

// Only process confirmed/finished payments
if (!in_array($status, ['confirmed', 'finished'])) {
    http_response_code(200); echo 'ok'; exit;
}
if ($usd <= 0 || !$ref) {
    http_response_code(200); echo 'ok'; exit;
}

// price_amount is in the price_currency (usd by default)
$amount_usd = strtolower($currency) === 'usd' ? $usd : $usd; // already USD

$api_key_id = api_key_id_by_ref('nowpayments', $ref);
if (!$api_key_id) {
    error_log('[nowpayments-webhook] No api_key_id for ref=' . $ref);
    http_response_code(200); echo 'ok'; exit;
}

$credits = confirm_payment($api_key_id, 'nowpayments', $ref, $amount_usd, $data);
error_log("[nowpayments-webhook] Confirmed $ref � $credits credits for api_key_id=$api_key_id");

http_response_code(200); echo 'ok';
