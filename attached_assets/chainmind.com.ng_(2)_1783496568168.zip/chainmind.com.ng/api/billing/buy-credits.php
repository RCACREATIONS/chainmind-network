<?php
session_start();
require_once __DIR__ . '/../../api/_helpers.php';
require_once __DIR__ . '/credits.php';

// Auth
$api_key = $_GET['api_key'] ?? '';
if ($api_key) {
    $api_key_id = validate_api_key($api_key);
    $key_row = db()->prepare('SELECT * FROM api_keys WHERE id = ?');
    $key_row->execute([$api_key_id]); $key_row = $key_row->fetch();
} elseif (isset($_SESSION['user_id'])) {
    $key_row = db()->prepare('SELECT * FROM api_keys WHERE user_id = ? AND is_active = 1 LIMIT 1');
    $key_row->execute([$_SESSION['user_id']]); $key_row = $key_row->fetch();
    $api_key_id = $key_row ? (int)$key_row['id'] : null;
    $api_key = $key_row['api_key'] ?? '';
} else {
    header('Location: /auth/login.php?next=/dashboard/billing.php'); exit;
}
if (!$api_key_id || !$key_row) { http_response_code(401); die('Unauthorized'); }
$balance = credits_get($api_key_id);
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><title>Buy Credits  ChainMind</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0a0c10;color:#e6edf3;font-family:system-ui,sans-serif;min-height:100vh;padding:2rem 1rem}
.wrap{max-width:820px;margin:0 auto}
.back{color:#58a6ff;text-decoration:none;font-size:.85rem;display:inline-block;margin-bottom:1.5rem}
h1{font-size:1.4rem;font-weight:800;margin-bottom:.35rem}
.sub{color:#8b949e;font-size:.88rem;margin-bottom:2rem}
.balance-box{background:#1c2a1e;border:1px solid #238636;border-radius:10px;padding:1rem 1.25rem;margin-bottom:2rem;font-size:.88rem;color:#3fb950}
.section-title{font-size:1rem;font-weight:700;margin:.5rem 0 1rem}
.plans{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:1rem;margin-bottom:2.5rem}
.plan{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:1.5rem;cursor:pointer;transition:.15s}
.plan:hover{border-color:#58a6ff}.plan.sel{border-color:#58a6ff;background:#111827}
.plan-name{font-size:.8rem;color:#8b949e;margin-bottom:.25rem;font-weight:700;text-transform:uppercase}
.plan-price{font-size:1.8rem;font-weight:800;letter-spacing:-1px}
.plan-price span{font-size:.9rem;color:#8b949e}
.plan-credits{color:#3fb950;font-size:.82rem;margin:.2rem 0 .75rem}
.plan-feat{font-size:.78rem;color:#8b949e}
.amt-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(100px,1fr));gap:.65rem;margin-bottom:2rem}
.amt{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:.65rem;text-align:center;cursor:pointer;font-size:.9rem;font-weight:700}
.amt:hover{border-color:#58a6ff}.amt.sel{border-color:#58a6ff;background:#111827}
.amt span{display:block;font-size:.72rem;color:#8b949e;font-weight:400}
.providers{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:1rem;margin-bottom:2rem}
.provider{background:#161b22;border:1px solid #30363d;border-radius:10px;padding:1.25rem;cursor:pointer;text-align:center;transition:.15s}
.provider:hover{border-color:#58a6ff}
.provider .icon{font-size:1.6rem;margin-bottom:.35rem}
.provider h3{font-size:.88rem;font-weight:700}.provider p{font-size:.75rem;color:#8b949e}
.loading{display:none;color:#8b949e;font-size:.88rem;margin-top:.75rem}
.divider{border:none;border-top:1px solid #21262d;margin:2rem 0}
</style>
</head><body>
<div class="wrap">
  <a class="back" href="/dashboard/billing.php">� Back to billing</a>
  <h1>Buy Credits</h1>
  <p class="sub">Top up credits or subscribe to a monthly plan. 1 USD = <?= number_format(CREDITS_PER_USD) ?> credits.</p>
  <div class="balance-box">Current balance: <strong><?= number_format($balance) ?></strong> credits (H $<?= number_format($balance / CREDITS_PER_USD, 4) ?>)</div>

  <div class="section-title">Monthly Plans (Save up to 33%)</div>
  <div class="plans" id="plan-grid">
    <?php foreach (PLANS as $key => $p): ?>
    <div class="plan" id="plan-<?= $key ?>" onclick="selectPlan('<?= $key ?>', <?= $p['price_usd'] ?>)">
      <div class="plan-name"><?= $p['label'] ?></div>
      <div class="plan-price">$<?= (int)$p['price_usd'] ?> <span>/mo</span></div>
      <div class="plan-credits"><?= number_format($p['credits_month']) ?> credits/month</div>
      <div class="plan-feat">Auto-renews monthly � All models � Rollover</div>
    </div>
    <?php endforeach; ?>
  </div>

  <div class="divider"></div>
  <div class="section-title">One-time Top-up</div>
  <div class="amt-grid" id="amt-grid">
    <?php foreach ([5,10,20,50,100] as $amt): ?>
    <div class="amt" id="amt-<?= $amt ?>" onclick="selectAmt(<?= $amt ?>)">
      $<?= $amt ?><span><?= number_format($amt * CREDITS_PER_USD) ?> cr</span>
    </div>
    <?php endforeach; ?>
  </div>

  <div class="section-title">Choose Payment Method</div>
  <div class="providers">
    <div class="provider" onclick="pay('paystack')">
      <div class="icon"><�<�</div>
      <h3>Paystack</h3>
      <p>NGN card, bank, USSD</p>
    </div>
    <div class="provider" onclick="pay('nowpayments')">
      <div class="icon">�</div>
      <h3>Crypto</h3>
      <p>USDT, BTC, ETH, 300+ coins</p>
    </div>
    <div class="provider" onclick="pay('flutterwave')">
      <div class="icon">=�</div>
      <h3>Flutterwave</h3>
      <p>International cards, mobile money</p>
    </div>
  </div>
  <div class="loading" id="loading">= Connecting to payment gateway&</div>
</div>

<script>
let selectedAmt = 10;
let selectedPlan = null;

function selectAmt(v) {
  selectedAmt = v; selectedPlan = null;
  document.querySelectorAll('.amt').forEach(e => e.classList.toggle('sel', e.id === 'amt-'+v));
  document.querySelectorAll('.plan').forEach(e => e.classList.remove('sel'));
}
function selectPlan(key, price) {
  selectedPlan = key; selectedAmt = price;
  document.querySelectorAll('.plan').forEach(e => e.classList.toggle('sel', e.id === 'plan-'+key));
  document.querySelectorAll('.amt').forEach(e => e.classList.remove('sel'));
}
async function pay(provider) {
  document.getElementById('loading').style.display = 'block';
  const body = { provider, amount_usd: selectedAmt, type: selectedPlan ? 'subscription' : 'topup' };
  if (selectedPlan) body.plan = selectedPlan;
  const r = await fetch('/api/billing/initiate.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Api-Key': '<?= htmlspecialchars($api_key) ?>' },
    body: JSON.stringify(body),
  });
  const d = await r.json();
  document.getElementById('loading').style.display = 'none';
  if (d.checkout_url) window.location.href = d.checkout_url;
  else alert('Error: ' + (d.error || 'Could not start payment.'));
}
selectAmt(10);
</script>
</body></html>
