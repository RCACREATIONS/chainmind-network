<?php
require_once __DIR__ . '/../../api/_helpers.php';
require_once __DIR__ . '/credits.php';

$hash = $_SERVER['HTTP_VERIF_HASH'] ?? '';
if (!hash_equals(FLW_WEBHOOK_HASH, $hash)) { http_response_code(401); exit('Bad hash'); }

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

$event  = $data['event'] ?? '';
$status = $data['data']['status'] ?? '';
$ref    = $data['data']['tx_ref']  ?? '';
$amount = (float)($data['data']['amount'] ?? 0);
$curr   = $data['data']['currency'] ?? 'USD';

if ($event !== 'charge.completed' || $status !== 'successful' || !$ref) {
    http_response_code(200); echo 'ok'; exit;
}

$usd = strtoupper($curr) === 'NGN' ? $amount / PLAN_NGN_RATE : $amount;

$api_key_id = api_key_id_by_ref('flutterwave', $ref);
if (!$api_key_id) {
    $email = $data['data']['customer']['email'] ?? '';
    $api_key_id = api_key_id_by_email($email);
}
if (!$api_key_id) { http_response_code(200); echo 'ok'; exit; }

$credits = confirm_payment($api_key_id, 'flutterwave', $ref, $usd, $data);
error_log("[flutterwave-webhook] $ref � $credits credits for api_key_id=$api_key_id");

http_response_code(200); echo 'ok';
