<?php
// Flutterwave redirect callback (user returns here after payment)
require_once __DIR__ . '/../../api/_helpers.php';
require_once __DIR__ . '/credits.php';

$status = $_GET['status'] ?? '';
$tx_ref = $_GET['tx_ref'] ?? '';
$tx_id  = $_GET['transaction_id'] ?? '';

if ($status !== 'successful' || !$tx_ref) {
    header('Location: /dashboard/billing.php?payment=cancelled'); exit;
}

// Verify with Flutterwave API
$r = json_decode(file_get_contents(
    "https://api.flutterwave.com/v3/transactions/$tx_id/verify",
    false, stream_context_create(['http' => [
        'method' => 'GET',
        'header' => "Authorization: Bearer " . FLW_SECRET_KEY . "\r\n",
    ]])
), true);

if (($r['data']['status'] ?? '') !== 'successful') {
    header('Location: /dashboard/billing.php?payment=failed'); exit;
}

$amount_usd = (float)$r['data']['amount'];
$currency   = $r['data']['currency'] ?? 'USD';
if (strtoupper($currency) === 'NGN') $amount_usd /= PLAN_NGN_RATE;

$api_key_id = api_key_id_by_ref('flutterwave', $tx_ref);
if (!$api_key_id) {
    $email = $r['data']['customer']['email'] ?? '';
    $api_key_id = api_key_id_by_email($email);
}

if ($api_key_id) {
    confirm_payment($api_key_id, 'flutterwave', $tx_ref, $amount_usd, $r);
}

header('Location: /dashboard/billing.php?payment=success'); exit;
