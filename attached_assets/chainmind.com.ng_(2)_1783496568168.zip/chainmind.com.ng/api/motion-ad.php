<?php
// POST /api/motion-ad.php
// Submit a motion ad generation job.
//
// Auth: Bearer token (user API key)
// Body (JSON):
// {
//   "business_name": "Acme Corp",
//   "product":       "Widget Pro",
//   "tagline":       "Works every time",    // optional
//   "tone":          "energetic",           // optional: friendly|energetic|professional|funny|luxury|urgent
//   "duration_s":    15                     // optional: 10-60 seconds, default 15
// }
//
// Returns: { ok:true, job_id:"...", poll:"/api/job.php?id=..." }

require_once __DIR__ . '/_helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST only', 405);

$user = require_auth();
$b    = require_json_body();

// ── Validate input ───────────────────────────────────────────
$business_name = trim($b['business_name'] ?? '');
$product       = trim($b['product']       ?? '');
$tagline       = substr(trim($b['tagline'] ?? ''), 0, 150);
$tone          = trim($b['tone']          ?? 'friendly');
$duration_s    = max(10, min(60, (int)($b['duration_s'] ?? 15)));

if (!$business_name) json_err('business_name is required');
if (!$product)       json_err('product is required');

$valid_tones = ['friendly','energetic','professional','funny','luxury','urgent'];
if (!in_array($tone, $valid_tones, true)) $tone = 'friendly';

// ── Check a capable node is online ──────────────────────────
$capable_node = db()->query("
    SELECT id FROM nodes
    WHERE status = 'online'
      AND capabilities LIKE '%motion_ad%'
    LIMIT 1
")->fetch();
if (!$capable_node) json_err('No motion_ad capable node is online right now. Try again shortly.', 503);

// ── Deduct credits (50 per motion ad — more than a regular prompt) ──────
$cost = 50;
$bal  = db()->prepare("SELECT credits FROM users WHERE id = ?");
$bal->execute([$user['id']]);
$credits = (float)($bal->fetchColumn() ?? 0);
if ($credits < $cost) json_err("Insufficient credits. You have {$credits}, need {$cost}.", 402);

// ── Queue the job ────────────────────────────────────────────
$job_id = bin2hex(random_bytes(16));

// Ensure job_type column exists (graceful for older installs)
try {
    $jt = db()->prepare("SHOW COLUMNS FROM jobs LIKE 'job_type'");
    $jt->execute();
    if ($jt->rowCount() === 0) {
        db()->exec("ALTER TABLE jobs ADD COLUMN job_type VARCHAR(50) NOT NULL DEFAULT 'text'");
    }
} catch (\Throwable $e) { /* non-fatal */ }

// Ensure image_params column exists
try {
    $ip = db()->prepare("SHOW COLUMNS FROM jobs LIKE 'image_params'");
    $ip->execute();
    if ($ip->rowCount() === 0) {
        db()->exec("ALTER TABLE jobs ADD COLUMN image_params JSON NULL");
    }
} catch (\Throwable $e) { /* non-fatal */ }

$image_params = json_encode([
    'business_name' => $business_name,
    'product'       => $product,
    'tagline'       => $tagline,
    'tone'          => $tone,
    'duration_s'    => $duration_s,
]);

db()->prepare("
    INSERT INTO jobs (id, user_id, prompt, model, job_type, image_params, status, source, created_at)
    VALUES (?, ?, ?, 'motion_ad', 'motion_ad', ?, 'pending', 'api', NOW())
")->execute([
    $job_id,
    $user['id'],
    encrypt_field("Motion ad: {$business_name} — {$product}"),
    $image_params,
]);

// Deduct credits atomically
db()->prepare("UPDATE users SET credits = credits - ? WHERE id = ?")->execute([$cost, $user['id']]);

json_ok([
    'job_id'    => $job_id,
    'poll'      => "/api/job.php?id={$job_id}",
    'credits_charged' => $cost,
]);
