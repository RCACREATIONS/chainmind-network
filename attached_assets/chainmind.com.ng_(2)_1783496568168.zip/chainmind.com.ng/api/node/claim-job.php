<?php
// ============================================================
// ChainMind  Node Job Claim Endpoint
// POST /api/node/claim-job.php
//
// Returns job including messages_context for multi-turn chat.
// ============================================================

require_once __DIR__ . '/../_helpers.php';
cors();

if (!in_array($_SERVER['REQUEST_METHOD'], ['GET', 'POST'], true)) json_err('GET or POST only', 405);

validate_node_secret();
$node_id = get_node_id();

// ── Update capabilities + GPU info if provided ────────────────
$body = body();
if (!empty($body['capabilities'])) {
    db()->prepare("
        UPDATE nodes SET
            capabilities = ?,
            vram_gb      = ?,
            gpu_name     = ?
        WHERE id = ?
    ")->execute([
        $body['capabilities'],
        (float)($body['vram_gb'] ?? 0),
        substr(trim($body['gpu_name'] ?? ''), 0, 100),
        $node_id,
    ]);
}

// ── Parse node's supported job types from its capabilities ────
$capabilities_raw = $_SERVER['HTTP_X_NODE_CAPABILITIES'] ?? '';
$node_caps = array_map('trim', explode(',', $capabilities_raw));

$has_image_gen  = in_array('image_gen',  $node_caps, true);
$has_vision     = in_array('vision',     $node_caps, true);
$has_file_qa    = in_array('file_qa',    $node_caps, true);
$has_motion_ad  = in_array('motion_ad',  $node_caps, true);

$allowed_types = ["'text'"];
if ($has_image_gen)  $allowed_types[] = "'image_gen'";
if ($has_vision)     $allowed_types[] = "'vision'";
if ($has_file_qa || empty($capabilities_raw)) $allowed_types[] = "'file_qa'";
if ($has_motion_ad)  $allowed_types[] = "'motion_ad'";

$type_clause = empty($capabilities_raw)
    ? "1=1"
    : "job_type IN (" . implode(',', $allowed_types) . ")";

// ── Sweep timed-out jobs ──────────────────────────────────────
sweep_timeouts();

// ── Ensure messages_context column exists (graceful) ─────────
try {
    $q = db()->prepare("SHOW COLUMNS FROM jobs LIKE 'messages_context'");
    $q->execute();
    $has_msgs_col = $q->rowCount() > 0;
} catch (\Throwable $e) {
    $has_msgs_col = false;
}

$select_cols = "id, prompt, model, system_prompt, job_type, image_params, file_ids";
if ($has_msgs_col) $select_cols .= ", messages_context";

// ── Atomic claim ─────────────────────────────────────────────
try {
    db()->beginTransaction();

    $job = db()->prepare("
        SELECT {$select_cols}
        FROM jobs
        WHERE status = 'pending'
          AND {$type_clause}
        ORDER BY created_at ASC
        LIMIT 1
        FOR UPDATE
    ");
    $job->execute();
    $row = $job->fetch();

    if ($row) {
        db()->prepare("
            UPDATE jobs
            SET status = 'claimed', claimed_by = ?, claimed_at = NOW()
            WHERE id = ?
        ")->execute([$node_id, $row['id']]);
    }

    db()->commit();
} catch (Exception $e) {
    db()->rollBack();
    json_err('Database error: ' . $e->getMessage(), 500);
}

// Decode messages_context JSON for the node
$messages_context = null;
if ($row && !empty($row['messages_context'])) {
    $decoded = json_decode($row['messages_context'], true);
    if (is_array($decoded)) $messages_context = $decoded;
}

json_ok(['job' => $row ? [
    'id'               => $row['id'],
    'prompt'           => decrypt_field($row['prompt']),
    'model'            => $row['model'],
    'system_prompt'    => decrypt_field($row['system_prompt']),
    'messages_context' => $messages_context,   // FIX: send conversation history to node
    'job_type'         => $row['job_type'] ?? 'text',
    'image_params'     => $row['image_params'] ?? null,
    'file_ids'         => $row['file_ids'] ?? null,
] : null]);
