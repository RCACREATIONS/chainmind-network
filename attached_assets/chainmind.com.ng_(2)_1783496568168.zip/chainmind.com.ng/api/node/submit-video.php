<?php
// POST /api/node/submit-video.php
// Called by a node to upload the rendered MP4 for a motion_ad job.
// The node calls this first, then calls submit-result.php to mark done.
//
// Headers: X-Node-Secret, X-Node-Id
// Body: multipart/form-data
//   job_id  — the job UUID
//   video   — the MP4 file

require_once __DIR__ . '/../_helpers.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST only', 405);
validate_node_secret();
$node_id = get_node_id();

$job_id = trim($_POST['job_id'] ?? '');
if (!$job_id) json_err('job_id is required');

// ── Verify job belongs to this node ──────────────────────────
$job = db()->prepare("SELECT id, status FROM jobs WHERE id = ? AND claimed_by = ?");
$job->execute([$job_id, $node_id]);
$row = $job->fetch();
if (!$row) json_err('Job not found or not claimed by this node', 404);
if (!in_array($row['status'], ['claimed', 'running'], true)) json_err('Job is not in a claimable state', 409);

// ── Validate uploaded file ────────────────────────────────────
if (empty($_FILES['video']) || $_FILES['video']['error'] !== UPLOAD_ERR_OK) {
    json_err('video file upload failed (error code: ' . ($_FILES['video']['error'] ?? 'missing') . ')');
}

$tmp  = $_FILES['video']['tmp_name'];
$size = $_FILES['video']['size'];
$max  = 200 * 1024 * 1024; // 200 MB
if ($size > $max) json_err('Video exceeds 200 MB limit');

// Validate it's actually an MP4 (check ftyp box)
$fh = fopen($tmp, 'rb');
$magic = $fh ? fread($fh, 12) : '';
if ($fh) fclose($fh);
// MP4 ftyp box: bytes 4-7 == "ftyp" OR first 4 bytes indicate size then ftyp
if (strpos($magic, 'ftyp') === false && strpos($magic, 'mp42') === false && strpos($magic, 'isom') === false) {
    // Soft check — still allow if mime type is video/mp4
    $mime = mime_content_type($tmp);
    if (!in_array($mime, ['video/mp4', 'video/x-m4v', 'application/octet-stream'], true)) {
        json_err('Uploaded file does not appear to be an MP4');
    }
}

// ── Save file ────────────────────────────────────────────────
$upload_dir = __DIR__ . '/../../uploads/generated_ads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

$filename = 'ad_' . preg_replace('/[^a-f0-9]/', '', $job_id) . '_' . time() . '.mp4';
$dest     = $upload_dir . $filename;

if (!move_uploaded_file($tmp, $dest)) {
    json_err('Failed to save uploaded file', 500);
}

// ── Store URL in job row ──────────────────────────────────────
// Ensure result_video_url column exists
try {
    $vc = db()->prepare("SHOW COLUMNS FROM jobs LIKE 'result_video_url'");
    $vc->execute();
    if ($vc->rowCount() === 0) {
        db()->exec("ALTER TABLE jobs ADD COLUMN result_video_url VARCHAR(500) NULL");
    }
} catch (\Throwable $e) { /* non-fatal */ }

$video_url = '/uploads/generated_ads/' . $filename;
db()->prepare("UPDATE jobs SET result_video_url = ? WHERE id = ?")->execute([$video_url, $job_id]);

json_ok(['video_url' => $video_url, 'job_id' => $job_id]);
