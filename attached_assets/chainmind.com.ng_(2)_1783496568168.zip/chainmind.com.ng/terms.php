<?php
require_once __DIR__.'/_shared.php';
page_head('Terms of Service','ChainMind Terms of Service — your rights and responsibilities when using the platform.');
$updated = 'June 9, 2025';
?>

<main>
<div class="container">
  <div class="page-hero">
    <div class="eyebrow">Legal</div>
    <h1>Terms of Service</h1>
    <div class="meta">
      <span><i class="ti ti-calendar"></i> Effective: <?=$updated?></span>
      <span><i class="ti ti-map-pin"></i> Governing law: Nigeria</span>
    </div>
  </div>

  <div class="legal-body">

    <div class="callout">
      <p><strong>Please read carefully.</strong> By creating an account or using ChainMind services you agree to these Terms. If you do not agree, do not use the service.</p>
    </div>

    <div class="toc">
      <div class="toc-title">Contents</div>
      <ol>
        <li><a href="#acceptance">Acceptance of terms</a></li>
        <li><a href="#service">Description of service</a></li>
        <li><a href="#eligibility">Eligibility</a></li>
        <li><a href="#accounts">Accounts &amp; security</a></li>
        <li><a href="#credits-billing">Credits &amp; billing</a></li>
        <li><a href="#acceptable-use">Acceptable use</a></li>
        <li><a href="#node-operators">Node operators</a></li>
        <li><a href="#ip">Intellectual property</a></li>
        <li><a href="#warranties">Disclaimers &amp; warranties</a></li>
        <li><a href="#liability">Limitation of liability</a></li>
        <li><a href="#indemnity">Indemnification</a></li>
        <li><a href="#termination">Termination</a></li>
        <li><a href="#governing-law">Governing law &amp; disputes</a></li>
        <li><a href="#changes">Changes to terms</a></li>
        <li><a href="#contact">Contact</a></li>
      </ol>
    </div>

    <h2 id="acceptance">1. Acceptance of terms</h2>
    <p>These Terms of Service ("Terms") constitute a legally binding agreement between you ("User", "you") and ChainMind ("we", "us", "ChainMind") governing your access to and use of the chainmind.com.ng website, APIs, dashboard, AI chat interface, and any related services (collectively, "Services"). By registering for an account, accessing the API, or clicking "I agree", you confirm you have read, understood, and agree to be bound by these Terms and our <a href="/privacy.php">Privacy Policy</a>.</p>

    <h2 id="service">2. Description of service</h2>
    <p>ChainMind is a decentralised AI inference network that allows users to send requests to large language models ("LLMs") hosted on a network of independently operated compute nodes ("Nodes"). We do not host or own the underlying models in all cases; inference is distributed across the node network.</p>
    <p>We provide access to the Services on a credit-based, pay-as-you-go model. Availability is subject to network capacity and is not guaranteed to be uninterrupted.</p>

    <h2 id="eligibility">3. Eligibility</h2>
    <ul>
      <li>You must be at least 18 years old (or the age of majority in your jurisdiction, whichever is higher) to use ChainMind.</li>
      <li>By agreeing to these Terms, you represent that all information you provide is accurate and complete.</li>
      <li>Use of the Services is prohibited where doing so violates any applicable law or regulation.</li>
    </ul>

    <h2 id="accounts">4. Accounts &amp; security</h2>
    <ul>
      <li>You are responsible for maintaining the confidentiality of your API key(s) and account credentials.</li>
      <li>You are responsible for all activity that occurs under your account.</li>
      <li>You must notify us immediately at <a href="mailto:support@chainmind.com.ng">support@chainmind.com.ng</a> if you suspect unauthorised access.</li>
      <li>You may not share, sell, or transfer your account or API key to a third party.</li>
      <li>We reserve the right to terminate or suspend accounts that we reasonably believe have been compromised.</li>
    </ul>

    <h2 id="credits-billing">5. Credits &amp; billing</h2>
    <ul>
      <li>Access to paid inference is deducted from your prepaid credit balance in real time.</li>
      <li>Credits are non-expiring unless your account is inactive for more than 24 consecutive months.</li>
      <li>Prices are listed in USD and are subject to change with 14 days' notice.</li>
      <li>All payments are final unless otherwise covered by our <a href="/refund.php">Refund Policy</a>.</li>
      <li>ChainMind is not responsible for losses arising from incorrect API usage, runaway loops, or unintended high usage. You are solely responsible for monitoring your consumption.</li>
      <li>Free-tier credits, promotional credits, and trial credits have no monetary value and are not refundable or transferable.</li>
    </ul>

    <h2 id="acceptable-use">6. Acceptable use</h2>
    <p>You agree not to use the Services to:</p>
    <ul>
      <li>Generate content that is illegal, defamatory, obscene, or infringes any third-party rights.</li>
      <li>Produce or distribute child sexual abuse material (CSAM) or any content that exploits or harms minors.</li>
      <li>Create malware, cyberweapons, or tools designed to attack computer systems.</li>
      <li>Engage in phishing, spam, or deceptive practices.</li>
      <li>Generate non-consensual intimate imagery.</li>
      <li>Circumvent, reverse-engineer, or probe our systems for vulnerabilities without prior written authorisation.</li>
      <li>Resell API access without our prior written consent.</li>
      <li>Engage in any activity that violates our full <a href="/aup.php">Acceptable Use Policy</a>.</li>
    </ul>
    <p>Violation of this section may result in immediate account termination and may be reported to law enforcement.</p>

    <h2 id="node-operators">7. Node operators</h2>
    <p>If you register as a node operator, additional terms apply:</p>
    <ul>
      <li>You are responsible for ensuring your hardware meets published specifications and remains online.</li>
      <li>Earnings are calculated based on verified compute contributions and paid in accordance with the earnings schedule in your dashboard.</li>
      <li>We reserve the right to remove nodes from the network that do not meet performance, reliability, or security standards.</li>
      <li>You must not run modified node software that misreports compute capacity or tampers with inference results.</li>
      <li>You are responsible for all tax obligations arising from your earnings as a node operator. ChainMind does not withhold tax on operator payments.</li>
    </ul>

    <h2 id="ip">8. Intellectual property</h2>
    <p><strong>Our content:</strong> The ChainMind name, logo, website design, documentation, and software are our intellectual property and may not be reproduced without written permission.</p>
    <p><strong>Your content:</strong> You retain ownership of the prompts you submit and any outputs you receive. You grant us a limited licence to process your inputs and outputs solely to provide the Services.</p>
    <p><strong>Model outputs:</strong> AI-generated outputs may not be copyrightable in all jurisdictions. You are responsible for evaluating and complying with applicable laws regarding the use of AI-generated content.</p>

    <h2 id="warranties">9. Disclaimers &amp; warranties</h2>
    <p>THE SERVICES ARE PROVIDED "<strong>AS IS</strong>" AND "<strong>AS AVAILABLE</strong>" WITHOUT WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.</p>
    <p>We do not warrant that: (a) the Services will be uninterrupted or error-free; (b) outputs will be accurate, reliable, or suitable for any specific purpose; or (c) the network will meet any particular uptime SLA unless a separate written SLA agreement is in place.</p>

    <h2 id="liability">10. Limitation of liability</h2>
    <p>TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, CHAINMIND, ITS DIRECTORS, EMPLOYEES, AND AFFILIATES SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING LOSS OF PROFITS, DATA, OR GOODWILL, ARISING FROM YOUR USE OF OR INABILITY TO USE THE SERVICES.</p>
    <p>IN ALL CASES, OUR TOTAL CUMULATIVE LIABILITY TO YOU SHALL NOT EXCEED THE GREATER OF (A) THE AMOUNT YOU PAID TO CHAINMIND IN THE 12 MONTHS PRECEDING THE CLAIM, OR (B) USD 100.</p>

    <h2 id="indemnity">11. Indemnification</h2>
    <p>You agree to indemnify, defend, and hold harmless ChainMind and its officers, directors, employees, and agents from and against any claims, liabilities, damages, losses, and expenses (including reasonable legal fees) arising out of or in any way connected with: (a) your use of the Services in violation of these Terms; (b) your violation of any applicable law; or (c) any content you submit through the Services.</p>

    <h2 id="termination">12. Termination</h2>
    <p>We may suspend or terminate your account at any time, with or without notice, for conduct that we believe: (a) violates these Terms; (b) is harmful to us, other users, or third parties; or (c) is required by law.</p>
    <p>You may terminate your account at any time by emailing <a href="mailto:support@chainmind.com.ng">support@chainmind.com.ng</a>. Upon termination, any unused credits subject to our <a href="/refund.php">Refund Policy</a> may be eligible for a refund.</p>
    <p>Sections 8, 9, 10, 11, and 13 survive termination.</p>

    <h2 id="governing-law">13. Governing law &amp; disputes</h2>
    <p>These Terms are governed by the laws of the Federal Republic of Nigeria. Any dispute arising out of or in connection with these Terms shall first be attempted to be resolved by informal negotiation. If unresolved within 30 days, disputes shall be submitted to the exclusive jurisdiction of the courts of Lagos State, Nigeria.</p>

    <h2 id="changes">14. Changes to terms</h2>
    <p>We may update these Terms from time to time. Material changes will be communicated via email or a prominent notice on the website at least 14 days before they take effect. Your continued use of the Services after the effective date constitutes acceptance of the updated Terms.</p>

    <h2 id="contact">15. Contact</h2>
    <p>Legal notices and questions about these Terms: <a href="mailto:support@chainmind.com.ng">support@chainmind.com.ng</a></p>

  </div>
</div>
</main>

<?php page_foot(); ?>