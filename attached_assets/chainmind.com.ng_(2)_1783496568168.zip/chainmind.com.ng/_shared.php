<?php
// _shared.php — include at top of every legal/static page
// Usage: include __DIR__.'/../_shared.php';
//        page_head('Privacy Policy');
//        ...content...
//        page_foot();

function page_head(string $title, string $desc = '') {
  $site = 'ChainMind';
  $desc = $desc ?: 'Community-owned AI inference network — cheap AI for users, passive income for node operators.';
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=htmlspecialchars($title)?> — <?=$site?></title>
<meta name="description" content="<?=htmlspecialchars($desc)?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
<style>
:root{
  --bg:#0d0f14;--bg2:#12151c;--bg3:#181c26;
  --border:#1f2535;--border2:#2a3148;
  --text:#e8ecf5;--text2:#8b93a8;--muted:#4e566a;
  --accent:#4f7cff;--accent2:#7c5cff;--green:#22d37a;
  --mono:'JetBrains Mono',monospace;
  --sans:'Inter',system-ui,sans-serif;
  --radius:10px;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{background:var(--bg);color:var(--text);font-family:var(--sans);font-size:15px;line-height:1.7;-webkit-font-smoothing:antialiased}
a{color:var(--accent);text-decoration:none}
a:hover{text-decoration:underline}
.container{max-width:860px;margin:0 auto;padding:0 1.5rem}
.container--wide{max-width:1120px;margin:0 auto;padding:0 1.5rem}

/* ── NAV ── */
.topnav{background:var(--bg2);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:100;padding:.85rem 1.5rem;display:flex;align-items:center;justify-content:space-between}
.topnav-logo{display:flex;align-items:center;gap:.55rem;color:var(--text);font-weight:600;font-size:.95rem;text-decoration:none}
.topnav-logo img{height:22px;width:auto}
.topnav-links{display:flex;gap:1.5rem;align-items:center}
.topnav-links a{color:var(--text2);font-size:.83rem;text-decoration:none;transition:.15s}
.topnav-links a:hover{color:var(--text)}
.btn{display:inline-flex;align-items:center;gap:.4rem;padding:.45rem 1rem;border-radius:6px;font-size:.82rem;font-weight:500;cursor:pointer;transition:.15s;border:none;text-decoration:none}
.btn-primary{background:var(--accent);color:#fff}
.btn-primary:hover{background:#3d6aec;text-decoration:none}

/* ── HERO ── */
.page-hero{padding:4rem 0 2.5rem;border-bottom:1px solid var(--border)}
.page-hero .eyebrow{font-family:var(--mono);font-size:.65rem;font-weight:500;letter-spacing:.12em;text-transform:uppercase;color:var(--accent);margin-bottom:.75rem}
.page-hero h1{font-size:2rem;font-weight:600;line-height:1.25;margin-bottom:.75rem}
.page-hero .meta{font-size:.8rem;color:var(--muted);display:flex;gap:1.5rem;flex-wrap:wrap}
.page-hero .meta span{display:flex;align-items:center;gap:.35rem}

/* ── CONTENT ── */
.legal-body{padding:3rem 0 5rem}
.legal-body h2{font-size:1.15rem;font-weight:600;margin:2.5rem 0 .65rem;padding-top:.25rem;color:var(--text)}
.legal-body h3{font-size:.95rem;font-weight:600;margin:1.5rem 0 .4rem;color:var(--text2)}
.legal-body p{color:var(--text2);margin-bottom:.9rem;font-size:.9rem}
.legal-body ul,
.legal-body ol{color:var(--text2);font-size:.9rem;padding-left:1.4rem;margin-bottom:.9rem}
.legal-body li{margin-bottom:.35rem}
.legal-body strong{color:var(--text)}
.legal-body a{color:var(--accent)}
.divider{border:none;border-top:1px solid var(--border);margin:2rem 0}
.callout{background:var(--bg3);border:1px solid var(--border2);border-left:3px solid var(--accent);border-radius:var(--radius);padding:1rem 1.25rem;margin:1.5rem 0}
.callout p{margin:0;font-size:.85rem}
.toc{background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius);padding:1.25rem 1.5rem;margin:2rem 0}
.toc-title{font-family:var(--mono);font-size:.63rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);margin-bottom:.75rem}
.toc ol{padding-left:1.2rem;margin:0}
.toc li{margin-bottom:.3rem}
.toc a{color:var(--text2);font-size:.83rem;text-decoration:none}
.toc a:hover{color:var(--text)}

/* ── FOOTER ── */
.foot{background:var(--bg2);border-top:1px solid var(--border);padding:2rem 1.5rem;margin-top:auto}
.foot-inner{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.75rem;font-size:.78rem;color:var(--muted)}
.foot-inner a{color:var(--muted);text-decoration:none;transition:.15s}
.foot-inner a:hover{color:var(--text2)}
.live-dot{display:inline-block;width:5px;height:5px;border-radius:50%;background:var(--green);box-shadow:0 0 6px var(--green)}
</style>
</head>
<body>
<nav class="topnav container--wide">
  <a href="/" class="topnav-logo">
    <img src="/ChatGPT Image Jun 2, 2026, 06_43_57 AM.png" alt="ChainMind" onerror="this.style.display='none'">
    ChainMind
  </a>
  <div class="topnav-links">
    <a href="/#features">Features</a>
    <a href="/#pricing">Pricing</a>
    <a href="/docs.php">Docs</a>
    <a href="/auth/register.php" class="btn btn-primary">Get started</a>
  </div>
</nav>
<?php } // end page_head

function page_foot() { ?>
<footer class="foot">
  <div class="container foot-inner">
    <div>&copy; <?=date('Y')?> ChainMind &bull; chainmind.com.ng</div>
    <div style="display:flex;gap:1.25rem;flex-wrap:wrap">
      <a href="/privacy.php">Privacy</a>
      <a href="/terms.php">Terms</a>
      <a href="/refund.php">Refunds</a>
      <a href="/aup.php">AUP</a>
      <a href="/cookies.php">Cookies</a>
    </div>
    <span style="display:flex;align-items:center;gap:.4rem;font-family:var(--mono);font-size:.7rem">
      <span class="live-dot"></span> Network live
    </span>
  </div>
</footer>
</body>
</html>
<?php } // end page_foot