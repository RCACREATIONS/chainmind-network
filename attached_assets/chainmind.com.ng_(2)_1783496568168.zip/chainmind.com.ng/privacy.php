<?php
require_once __DIR__.'/_shared.php';
page_head('Privacy Policy','How ChainMind collects, uses, and protects your personal information.');
$updated = 'June 9, 2025';
?>

<main>
<div class="container">
  <div class="page-hero">
    <div class="eyebrow">Legal</div>
    <h1>Privacy Policy</h1>
    <div class="meta">
      <span><i class="ti ti-calendar"></i> Effective: <?=$updated?></span>
      <span><i class="ti ti-map-pin"></i> Applies to: chainmind.com.ng</span>
    </div>
  </div>

  <div class="legal-body">

    <div class="callout">
      <p><strong>Short version:</strong> We collect only what we need to run the service. We do not sell your data. You can request deletion at any time by emailing <a href="mailto:support@chainmind.com.ng">support@chainmind.com.ng</a>.</p>
    </div>

    <div class="toc">
      <div class="toc-title">Contents</div>
      <ol>
        <li><a href="#who-we-are">Who we are</a></li>
        <li><a href="#data-we-collect">Data we collect</a></li>
        <li><a href="#how-we-use">How we use your data</a></li>
        <li><a href="#sharing">Who we share it with</a></li>
        <li><a href="#cookies">Cookies &amp; tracking</a></li>
        <li><a href="#retention">Data retention</a></li>
        <li><a href="#your-rights">Your rights</a></li>
        <li><a href="#children">Children's privacy</a></li>
        <li><a href="#security">Security</a></li>
        <li><a href="#international">International transfers</a></li>
        <li><a href="#changes">Changes to this policy</a></li>
        <li><a href="#contact">Contact us</a></li>
      </ol>
    </div>

    <h2 id="who-we-are">1. Who we are</h2>
    <p>ChainMind ("<strong>ChainMind</strong>", "<strong>we</strong>", "<strong>our</strong>", or "<strong>us</strong>") operates the website <strong>chainmind.com.ng</strong> and the associated API, dashboard, and AI chat interfaces. We are a decentralised AI inference platform registered and operating in Nigeria.</p>
    <p>For questions about this policy, contact us at <a href="mailto:support@chainmind.com.ng">support@chainmind.com.ng</a>.</p>

    <h2 id="data-we-collect">2. Data we collect</h2>
    <h3>2.1 Information you give us</h3>
    <ul>
      <li><strong>Account data:</strong> email address, chosen username, and hashed password when you register.</li>
      <li><strong>Payment data:</strong> billing details you submit when purchasing credits. Card numbers are processed by our payment processor and are never stored on our servers.</li>
      <li><strong>Communications:</strong> messages you send us via email or support tickets.</li>
      <li><strong>Node operator data:</strong> hardware specifications, wallet address for earnings payouts, and uptime data you provide when registering as a node operator.</li>
    </ul>

    <h3>2.2 Information collected automatically</h3>
    <ul>
      <li><strong>Log data:</strong> IP address, browser type, referring URL, pages visited, timestamps.</li>
      <li><strong>API usage:</strong> model called, token counts, latency, error codes. <em>We do not store the content of your prompts or completions beyond what is needed for abuse prevention (maximum 30 days).</em></li>
      <li><strong>Device data:</strong> operating system, screen resolution, language settings.</li>
      <li><strong>Cookies &amp; similar technologies:</strong> see Section 5.</li>
    </ul>

    <h3>2.3 Information from third parties</h3>
    <ul>
      <li>OAuth sign-in providers (Google, GitHub) may share your name and email address when you choose to sign in with them.</li>
    </ul>

    <h2 id="how-we-use">3. How we use your data</h2>
    <p>We use the information we collect to:</p>
    <ul>
      <li>Create and manage your account and authenticate you.</li>
      <li>Process payments and manage your credit balance.</li>
      <li>Operate and improve the inference network, including routing requests to available nodes.</li>
      <li>Calculate and pay out node operator earnings.</li>
      <li>Send transactional emails (account confirmation, password reset, low-credit alerts). We do not send marketing emails without your explicit consent.</li>
      <li>Detect and prevent fraud, abuse, and violations of our Acceptable Use Policy.</li>
      <li>Comply with legal obligations.</li>
      <li>Respond to your support requests.</li>
    </ul>

    <h2 id="sharing">4. Who we share your data with</h2>
    <p>We do <strong>not</strong> sell, rent, or trade your personal data. We share data only as follows:</p>
    <ul>
      <li><strong>Payment processors</strong> (e.g., Paystack, Stripe): solely to process transactions.</li>
      <li><strong>Infrastructure providers</strong>: cloud hosting, CDN, and email delivery services acting as data processors under contractual data-protection obligations.</li>
      <li><strong>Node operators</strong>: inference requests are forwarded to nodes, but nodes receive only the encrypted payload. IP addresses and account identifiers are not exposed to operators.</li>
      <li><strong>Legal authorities</strong>: if required by law, court order, or to protect the rights and safety of users.</li>
      <li><strong>Business transfers</strong>: in the event of a merger or acquisition, users will be notified before data is transferred.</li>
    </ul>

    <h2 id="cookies">5. Cookies &amp; tracking</h2>
    <p>We use cookies and similar technologies for authentication, security, and performance monitoring. See our <a href="/cookies.php">Cookie Policy</a> for the full list of cookies we set.</p>

    <h2 id="retention">6. Data retention</h2>
    <ul>
      <li><strong>Account data</strong> is kept for the life of your account plus 90 days after deletion.</li>
      <li><strong>API request logs</strong> (excluding prompt/completion content) are kept for 12 months for billing and abuse investigation.</li>
      <li><strong>Prompt &amp; completion content</strong> is retained for a maximum of 30 days for abuse detection, then automatically deleted.</li>
      <li><strong>Payment records</strong> are kept for 7 years as required by Nigerian financial regulations.</li>
    </ul>

    <h2 id="your-rights">7. Your rights</h2>
    <p>Regardless of where you are located, you may:</p>
    <ul>
      <li><strong>Access</strong> the personal data we hold about you.</li>
      <li><strong>Correct</strong> inaccurate data.</li>
      <li><strong>Delete</strong> your account and associated data (subject to legal retention requirements).</li>
      <li><strong>Export</strong> your data in a machine-readable format.</li>
      <li><strong>Withdraw consent</strong> for any processing based on consent.</li>
      <li><strong>Object</strong> to processing for direct marketing.</li>
    </ul>
    <p>To exercise any of these rights, email <a href="mailto:support@chainmind.com.ng">support@chainmind.com.ng</a> with the subject line "Data Request". We will respond within 30 days.</p>

    <h2 id="children">8. Children's privacy</h2>
    <p>ChainMind is not directed at children under the age of 13 (or 16 in jurisdictions where a higher age applies). We do not knowingly collect personal data from children. If you believe a child has provided us with personal data, please contact us immediately and we will delete it.</p>

    <h2 id="security">9. Security</h2>
    <p>We implement industry-standard security measures including TLS encryption in transit, hashed passwords, access controls, and regular security reviews. No system is perfectly secure, and we cannot guarantee absolute security. In the event of a data breach affecting your personal data, we will notify you as required by applicable law.</p>

    <h2 id="international">10. International transfers</h2>
    <p>ChainMind is based in Nigeria. If you access our services from outside Nigeria, your data may be transferred to and processed in Nigeria or other countries where our infrastructure providers operate. We ensure appropriate safeguards are in place for such transfers.</p>

    <h2 id="changes">11. Changes to this policy</h2>
    <p>We may update this policy from time to time. When we make material changes, we will update the effective date at the top and notify registered users by email at least 14 days before the changes take effect. Continued use of the service after changes constitute acceptance.</p>

    <h2 id="contact">12. Contact us</h2>
    <p>For privacy questions, requests, or complaints:</p>
    <ul>
      <li>Email: <a href="mailto:support@chainmind.com.ng">support@chainmind.com.ng</a></li>
      <li>Subject line for data requests: <strong>Data Request</strong></li>
      <li>Subject line for privacy complaints: <strong>Privacy Complaint</strong></li>
    </ul>
    <p>We aim to resolve all privacy concerns promptly and fairly.</p>

  </div>
</div>
</main>

<?php page_foot(); ?>