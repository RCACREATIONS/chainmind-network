<?php
require_once __DIR__.'/_shared.php';
page_head('Cookie Policy','How ChainMind uses cookies and similar technologies.');
$updated = 'June 9, 2025';
?>

<main>
<div class="container">
  <div class="page-hero">
    <div class="eyebrow">Legal</div>
    <h1>Cookie Policy</h1>
    <div class="meta">
      <span><i class="ti ti-calendar"></i> Effective: <?=$updated?></span>
    </div>
  </div>

  <div class="legal-body">

    <h2 id="what-are-cookies">1. What are cookies?</h2>
    <p>Cookies are small text files stored on your device by your browser when you visit a website. They allow the website to remember your preferences and actions over time. Similar technologies include local storage, session storage, and pixel tags.</p>

    <h2 id="how-we-use">2. How ChainMind uses cookies</h2>

    <h3>Essential cookies</h3>
    <p>These are required for the service to function. You cannot opt out of these without stopping use of the service.</p>
    <div style="overflow-x:auto;margin:1rem 0">
      <table style="width:100%;border-collapse:collapse;font-size:.82rem">
        <thead>
          <tr style="border-bottom:1px solid var(--border2)">
            <th style="text-align:left;padding:.6rem .75rem;color:var(--muted);font-family:var(--mono);font-size:.65rem;letter-spacing:.08em">Cookie</th>
            <th style="text-align:left;padding:.6rem .75rem;color:var(--muted);font-family:var(--mono);font-size:.65rem;letter-spacing:.08em">Purpose</th>
            <th style="text-align:left;padding:.6rem .75rem;color:var(--muted);font-family:var(--mono);font-size:.65rem;letter-spacing:.08em">Duration</th>
          </tr>
        </thead>
        <tbody>
          <tr style="border-bottom:1px solid var(--border)">
            <td style="padding:.55rem .75rem;color:var(--text);font-family:var(--mono);font-size:.78rem">cm_session</td>
            <td style="padding:.55rem .75rem;color:var(--text2)">Authenticates your logged-in session</td>
            <td style="padding:.55rem .75rem;color:var(--text2)">Session</td>
          </tr>
          <tr style="border-bottom:1px solid var(--border)">
            <td style="padding:.55rem .75rem;color:var(--text);font-family:var(--mono);font-size:.78rem">cm_csrf</td>
            <td style="padding:.55rem .75rem;color:var(--text2)">Prevents cross-site request forgery attacks</td>
            <td style="padding:.55rem .75rem;color:var(--text2)">Session</td>
          </tr>
          <tr style="border-bottom:1px solid var(--border)">
            <td style="padding:.55rem .75rem;color:var(--text);font-family:var(--mono);font-size:.78rem">cm_remember</td>
            <td style="padding:.55rem .75rem;color:var(--text2)">Keeps you logged in if you select "Remember me"</td>
            <td style="padding:.55rem .75rem;color:var(--text2)">30 days</td>
          </tr>
        </tbody>
      </table>
    </div>

    <h3>Functional cookies</h3>
    <p>These remember your preferences to improve your experience. You can disable them but the service may behave differently.</p>
    <div style="overflow-x:auto;margin:1rem 0">
      <table style="width:100%;border-collapse:collapse;font-size:.82rem">
        <thead>
          <tr style="border-bottom:1px solid var(--border2)">
            <th style="text-align:left;padding:.6rem .75rem;color:var(--muted);font-family:var(--mono);font-size:.65rem;letter-spacing:.08em">Cookie</th>
            <th style="text-align:left;padding:.6rem .75rem;color:var(--muted);font-family:var(--mono);font-size:.65rem;letter-spacing:.08em">Purpose</th>
            <th style="text-align:left;padding:.6rem .75rem;color:var(--muted);font-family:var(--mono);font-size:.65rem;letter-spacing:.08em">Duration</th>
          </tr>
        </thead>
        <tbody>
          <tr style="border-bottom:1px solid var(--border)">
            <td style="padding:.55rem .75rem;color:var(--text);font-family:var(--mono);font-size:.78rem">cm_theme</td>
            <td style="padding:.55rem .75rem;color:var(--text2)">Stores your dark/light mode preference</td>
            <td style="padding:.55rem .75rem;color:var(--text2)">1 year</td>
          </tr>
          <tr style="border-bottom:1px solid var(--border)">
            <td style="padding:.55rem .75rem;color:var(--text);font-family:var(--mono);font-size:.78rem">cm_lang</td>
            <td style="padding:.55rem .75rem;color:var(--text2)">Remembers your preferred language</td>
            <td style="padding:.55rem .75rem;color:var(--text2)">1 year</td>
          </tr>
        </tbody>
      </table>
    </div>

    <h3>Analytics cookies</h3>
    <p>These help us understand how the site is used so we can improve it. We use privacy-respecting analytics that do not share data with advertising networks.</p>
    <div style="overflow-x:auto;margin:1rem 0">
      <table style="width:100%;border-collapse:collapse;font-size:.82rem">
        <thead>
          <tr style="border-bottom:1px solid var(--border2)">
            <th style="text-align:left;padding:.6rem .75rem;color:var(--muted);font-family:var(--mono);font-size:.65rem;letter-spacing:.08em">Cookie</th>
            <th style="text-align:left;padding:.6rem .75rem;color:var(--muted);font-family:var(--mono);font-size:.65rem;letter-spacing:.08em">Purpose</th>
            <th style="text-align:left;padding:.6rem .75rem;color:var(--muted);font-family:var(--mono);font-size:.65rem;letter-spacing:.08em">Duration</th>
          </tr>
        </thead>
        <tbody>
          <tr style="border-bottom:1px solid var(--border)">
            <td style="padding:.55rem .75rem;color:var(--text);font-family:var(--mono);font-size:.78rem">cm_analytics</td>
            <td style="padding:.55rem .75rem;color:var(--text2)">Anonymous page view and event tracking</td>
            <td style="padding:.55rem .75rem;color:var(--text2)">90 days</td>
          </tr>
        </tbody>
      </table>
    </div>

    <h2 id="third-party">3. Third-party cookies</h2>
    <p>We do not place third-party advertising or social media tracking cookies. If you use OAuth login (Google, GitHub), those providers may set their own cookies per their respective policies.</p>

    <h2 id="control">4. How to control cookies</h2>
    <p>You can control cookies through your browser settings. Instructions for common browsers:</p>
    <ul>
      <li><a href="https://support.google.com/chrome/answer/95647" target="_blank" rel="noopener">Google Chrome</a></li>
      <li><a href="https://support.mozilla.org/en-US/kb/cookies-information-websites-store-on-your-computer" target="_blank" rel="noopener">Mozilla Firefox</a></li>
      <li><a href="https://support.apple.com/guide/safari/manage-cookies-sfri11471" target="_blank" rel="noopener">Apple Safari</a></li>
      <li><a href="https://support.microsoft.com/en-us/microsoft-edge/delete-cookies-in-microsoft-edge" target="_blank" rel="noopener">Microsoft Edge</a></li>
    </ul>
    <p>Disabling essential cookies will prevent you from logging in or using the dashboard.</p>

    <h2 id="changes">5. Changes to this policy</h2>
    <p>We will update this Cookie Policy when we change the cookies we set. Please check this page periodically.</p>

    <h2 id="contact">6. Contact</h2>
    <p>Cookie questions: <a href="mailto:support@chainmind.com.ng?subject=Cookie Policy">support@chainmind.com.ng</a></p>

  </div>
</div>
</main>

<?php page_foot(); ?>